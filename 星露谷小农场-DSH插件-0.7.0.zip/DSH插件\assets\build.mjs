/**
 * 构建页面脚本：assets/widget.template.js → assets/widget.js
 *
 *   node assets/extract-farmlife.mjs   # （素材有变时）生成 sprites + ui-atlas.css
 *   node assets/build.mjs              # 把样式、UI 图集、位图字体、精灵图内联进 widget.js
 *
 * 内联后页面 / 桌面端只需要一个 widget.js，不会有任何素材 404；
 * 图片（精灵 + UI 9-slice + 字体图集）会一起打包进 DSH 插件与 exe。
 */
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const spriteDir = join(here, 'sprites')
const template = readFileSync(join(here, 'widget.template.js'), 'utf8')

if (!existsSync(join(spriteDir, 'index.json'))) {
  throw new Error('缺少 assets/sprites：先运行 `node assets/extract-farmlife.mjs`')
}
const index = JSON.parse(readFileSync(join(spriteDir, 'index.json'), 'utf8'))
const atlasCss = existsSync(join(spriteDir, 'ui-atlas.css'))
  ? readFileSync(join(spriteDir, 'ui-atlas.css'), 'utf8')
  : ''
// UI 图集放在页面样式之后：9-slice / 图标类只作用在显式加上的元素上
const css = readFileSync(join(here, 'widget.css'), 'utf8') + '\n' + atlasCss

// 精灵条 → data URI 表
const sprites = {}
for (const [name, meta] of Object.entries(index.sprites)) {
  const png = readFileSync(join(spriteDir, name + '.png'))
  sprites[name] = {
    src: 'data:image/png;base64,' + png.toString('base64'),
    w: meta.w,
    h: meta.h,
    frames: meta.frames,
  }
}

// 作物表：11 种 FarmLife 真作物
const crops = Object.entries(index.crops).map(([key, value]) => {
  const name = typeof value === 'string' ? value : value.name
  const sprite = typeof value === 'object' && value.sprite ? value.sprite : 'crop'
  return { key, name, sprite }
})

// 帮手：FarmLife 没有动物素材，沿用现有 4 只 side-view 动物（32×32×4）
const HELPER_NAMES = ['cow', 'goat', 'pig', 'sheep']
const missing = []
for (const crop of crops) if (!sprites[crop.sprite]) missing.push(crop.sprite)
for (const name of HELPER_NAMES) if (!sprites[name]) missing.push(name)
for (const ui of ['font_black', 'soil', 'grass_tile', 'bar_green', 'expr_happy1']) {
  if (!sprites[ui]) missing.push(ui)
}
if (!index.font) missing.push('font-meta')
if (missing.length) throw new Error('缺少精灵 / 字体：' + missing.join(', '))

const replace = (source, token, value) => {
  if (!source.includes(token)) throw new Error('模板缺少占位符 ' + token)
  return source.replace(token, () => value)
}

let out = template
out = replace(out, '__DSF_CSS_JSON__', JSON.stringify(css))
out = replace(out, '__DSF_SPRITES_JSON__', JSON.stringify(sprites))
out = replace(out, '__DSF_CROPS_JSON__', JSON.stringify(crops))
out = replace(out, '__DSF_FONT_JSON__', JSON.stringify(index.font))

writeFileSync(join(here, 'widget.js'), out)
const kb = (n) => (n / 1024).toFixed(1) + ' KB'
console.log(`[stardew] widget.js: ${kb(out.length)}（精灵 ${Object.keys(sprites).length} 条 / 作物 ${crops.length} 种 / 帮手 ${HELPER_NAMES.length} 种 / UI 图集 ${kb(atlasCss.length)} / 字体 ${index.font ? index.font.chars.length + ' 字形' : '无'}）`)
