/**
 * dsh-stardew-farm —— 宿主半区
 *
 * 能力（不含渲染）：
 *   1. 页面脚本：/dsh-stardew/widget.js（CSS 与精灵图都已内联，无素材路由）
 *   2. 会话事实：待办（todo/write）、AI 忙闲、**只有 AI 提问时**的「需要老乡处理」
 *      - /dsh-stardew/api/state   一次性快照（首屏 / SSE 不可用时兜底）
 *      - /dsh-stardew/api/events  SSE 推送：会话事件一发生就推给页面，不等轮询
 *   3. 农场存档：/api/snapshot、/api/mutate（$DSH_HOME/plugin-data/dsh-stardew-farm/farm.json）
 *   4. 余额：/api/balance（API key 优先，退回 DSH 账号登录态）
 *
 * 约束：
 *   - 只读 `session/event`，不写会话日志、不注册新事件类型。
 *   - 可选服务全部 ctx.get + try/catch，失败只降级，绝不影响宿主启动。
 *   - 不声明 `dsh.client`（声明了却无 ./client 会让宿主启动失败）。
 */
import { readFile, writeFile, mkdir, rename, readdir } from 'node:fs/promises'
import { readFileSync, statSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { userInfo } from 'node:os'
import { join, dirname, basename } from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'dsh-stardew-farm'
export const inject = ['webServer']

const HERE = dirname(fileURLToPath(import.meta.url))
const WIDGET_JS = join(HERE, 'assets', 'widget.js')
const VERSION = '0.7.0'
// 版本化 URL：升级后浏览器不会再拿旧缓存跑页面脚本
const WIDGET_URL = '/dsh-stardew/widget.js?v=' + VERSION

const JSON_HEADERS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
}
const SSE_HEADERS = {
  'Content-Type': 'text/event-stream; charset=utf-8',
  'Cache-Control': 'no-cache, no-transform',
  Connection: 'keep-alive',
  'X-Accel-Buffering': 'no',
}

const MAX_SESSIONS = 8

function emptySession(id) {
  return {
    id,
    todos: null,
    todosAt: 0,
    todosSeq: 0,
    busy: false,
    turns: 0,
    attention: null,
    lastAssistant: null,
    lastUser: null,
    updatedAt: 0,
  }
}

function localDay() {
  const d = new Date()
  const p = (n) => (n < 10 ? '0' + n : String(n))
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate())
}

/** 页面标题用系统用户名，不把 Windows 域前缀带进去。 */
function localUserName() {
  try {
    return String(userInfo().username || '').replace(/^.*[\\/]/, '').trim().slice(0, 24)
  } catch {
    return ''
  }
}

function textOfContent(content) {
  if (content === null || content === undefined) return ''
  if (typeof content === 'string') return content
  if (Array.isArray(content)) {
    return content.map((block) => {
      if (typeof block === 'string') return block
      if (!block || typeof block !== 'object') return ''
      if (block.type === 'text') return String(block.text || '')
      return ''
    }).filter(Boolean).join('\n')
  }
  if (typeof content === 'object') {
    if (typeof content.text === 'string') return content.text
    if (content.content) return textOfContent(content.content)
  }
  return ''
}

function clip(text, max = 600) {
  const value = String(text || '').replace(/\s+/g, ' ').trim()
  return value.length > max ? value.slice(0, max) + '…' : value
}

/** 只有这些工具调用才算「AI 在向你提问」。 */
const QUESTION_TOOLS = /^(ask_user_question|exit_plan_mode)$/

function foldEvent(session, event, live) {
  if (event === null || typeof event !== 'object' || typeof event.type !== 'string') return false
  const data = event.data && typeof event.data === 'object' ? event.data : {}
  const st = live.sessions[session.id] || (live.sessions[session.id] = emptySession(session.id))
  let changed = true

  switch (event.type) {
    case 'todo/write': {
      const todos = normalizeTodos(data.todos)
      st.todos = todos
      st.todosAt = Date.now()
      st.todosSeq = Number(event.seq) || st.todosSeq
      break
    }
    case 'turn/start':
      st.busy = true
      st.turns += 1
      st.attention = null
      break
    case 'turn/end':
      st.busy = false
      break
    case 'step/start':
      st.busy = true
      break
    case 'user/message': {
      const text = clip(textOfContent(data.content === undefined ? data : data.content))
      if (text) st.lastUser = { text, at: Date.now() }
      break
    }
    case 'assistant/message': {
      const text = clip(textOfContent(data.content === undefined ? data : data.content))
      if (text) st.lastAssistant = { text, at: Date.now() }
      break
    }
    case 'tool/call': {
      // 关键：只有「提问」类工具才让小人抬头；授权/报错不再打扰
      const toolName = String(data.name || data.toolName || '')
      if (QUESTION_TOOLS.test(toolName)) {
        const args = data.arguments && typeof data.arguments === 'object' ? data.arguments : {}
        const question = args.question
          || (Array.isArray(args.questions) && args.questions[0] && args.questions[0].question)
          || args.plan
          || 'AI 在等你回答'
        st.attention = {
          kind: toolName === 'exit_plan_mode' ? '方案确认' : '提问',
          text: clip(question, 200),
          at: Date.now(),
          callId: data.callId || null,
        }
      } else {
        changed = false
      }
      break
    }
    case 'tool/result': {
      // 只有「那次提问」返回结果时才收起提示，别的工具不影响
      const callId = (data.message && data.message.callId) || data.callId || null
      if (st.attention && callId && st.attention.callId === callId) {
        st.attention = null
      } else {
        changed = false
      }
      break
    }
    default:
      return false
  }
  if (!changed) return false
  st.updatedAt = Date.now()
  touchSession(live, session.id)
  return true
}

function touchSession(live, id) {
  live.order = live.order.filter((item) => item !== id)
  live.order.unshift(id)
  while (live.order.length > MAX_SESSIONS) {
    const dropped = live.order.pop()
    if (dropped !== undefined) delete live.sessions[dropped]
  }
}

function dataDir() {
  const home = process.env.DSH_HOME
    || join(process.env.HOME || process.env.USERPROFILE || '.', '.dsh')
  return join(home, 'plugin-data', 'dsh-stardew-farm')
}

function readBody(req, limit = 1_000_000) {
  return new Promise((resolve, reject) => {
    let size = 0
    const chunks = []
    req.on('data', (chunk) => {
      size += chunk.length
      if (size > limit) {
        reject(new Error('body too large'))
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    req.on('error', reject)
  })
}

function num(value) {
  const n = Number(value)
  return Number.isFinite(n) ? n : null
}

// ---------------------------------------------------------------------------
// 待办首次水合：插件启动前已经写过的 todo/write 不能丢
// ---------------------------------------------------------------------------
function normalizeTodos(list) {
  if (!Array.isArray(list)) return []
  return list.map((item) => ({
    content: clip(item && item.content, 300),
    status: String((item && item.status) || 'pending'),
  })).filter((item) => item.content)
}

function dshHome() {
  return process.env.DSH_HOME
    || join(process.env.HOME || process.env.USERPROFILE || '.', '.dsh')
}

/** 投影缓存里的 todos 可能被包在 { val: ... } / { items: ... } 里，递归找数组。 */
function coerceTodoArray(value) {
  if (Array.isArray(value)) return normalizeTodos(value)
  if (!value || typeof value !== 'object') return null
  for (const key of ['todos', 'val', 'items', 'list']) {
    if (key in value) {
      const found = coerceTodoArray(value[key])
      if (found) return found
    }
  }
  return null
}

/**
 * 读取 ~/.dsh/storages/session_projcache 的 todos 投影。
 * 这里只读 rows.todos，不碰整个 session 日志，启动开销很小。
 */
async function readProjectionTodos() {
  const out = new Map()
  const dir = join(dshHome(), 'storages', 'session_projcache', 'sessions')
  let names = []
  try {
    names = await readdir(dir)
  } catch {
    return out
  }
  for (const name of names) {
    if (!name.endsWith('.json')) continue
    try {
      const doc = JSON.parse(await readFile(join(dir, name), 'utf8'))
      const rows = doc && doc.record && doc.record.rows
      const row = rows && rows.todos
      if (!row) continue
      const todos = coerceTodoArray(row.val)
      if (!todos) continue
      out.set(basename(name, '.json'), { todos, seq: Number(row.seq) || 0 })
    } catch { /* 单个投影坏掉不影响其它会话 */ }
  }
  // 兼容旧版单文件 session_projcache.json
  try {
    const legacy = JSON.parse(await readFile(join(dshHome(), 'storages', 'session_projcache.json'), 'utf8'))
    const sessions = legacy && legacy.sessions && typeof legacy.sessions === 'object'
      ? legacy.sessions
      : (legacy && typeof legacy === 'object' && !Array.isArray(legacy) ? legacy : null)
    if (sessions) {
      for (const [id, value] of Object.entries(sessions)) {
        const todos = coerceTodoArray(value)
        const row = value && value.rows && value.rows.todos
        if (todos) out.set(id, { todos, seq: Number(row && row.seq) || 0 })
      }
    }
  } catch { /* 没有旧文件 */ }
  return out
}

// ---------------------------------------------------------------------------
// 余额（保持不变：API key 优先，退回账号登录态）
// ---------------------------------------------------------------------------
async function keyBalance(ctx) {
  let cred = null
  try {
    cred = await ctx.get('credentials')?.resolve?.('DEEPSEEK_API_KEY')
  } catch {
    cred = null
  }
  const key = (cred && (cred.value || cred.secret || cred.token)) || process.env.DEEPSEEK_API_KEY
  if (!key) return null
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), 8000)
  try {
    const res = await fetch('https://api.deepseek.com/user/balance', {
      headers: { Authorization: 'Bearer ' + key },
      signal: ctrl.signal,
    })
    if (!res.ok) return { ok: false, error: '余额接口返回 HTTP ' + res.status }
    const data = await res.json()
    const infos = Array.isArray(data.balance_infos) ? data.balance_infos : []
    const pick = infos.find((item) => item && item.currency === 'CNY') || infos[0]
    if (!pick) return { ok: false, error: '接口没有返回余额钱包' }
    return {
      ok: true,
      source: 'api-key',
      currency: String(pick.currency || 'CNY'),
      totalBalance: Number(Number(pick.total_balance).toFixed(6)),
      bonusBalance: null,
      available: Boolean(data.is_available),
      updatedAt: new Date().toISOString(),
      accountTag: createHash('sha256').update('dsh-stardew:' + String(key).slice(-8)).digest('hex').slice(0, 12),
    }
  } catch (err) {
    return { ok: false, error: '余额请求失败：' + String((err && err.message) || err).slice(0, 160) }
  } finally {
    clearTimeout(timer)
  }
}

async function accountBalance(ctx) {
  let account = null
  try {
    account = ctx.get('deepseekAccount')
  } catch {
    account = null
  }
  if (!account || typeof account.getBalance !== 'function') {
    return { ok: false, error: '当前 DSH 没有账号服务（未登录 DeepSeek 账号？）' }
  }
  let result
  try {
    result = await account.getBalance({
      version: String(process.env.DSH_CLIENT_VERSION || process.env.DSH_VERSION || '') || 'unknown',
      locale: String(process.env.DSH_LOCALE || '') || 'zh_CN',
      timezoneOffsetSeconds: -new Date().getTimezoneOffset() * 60,
    })
  } catch (err) {
    return { ok: false, error: '账号余额接口调用失败：' + String((err && err.message) || err).slice(0, 160) }
  }
  if (!result) return { ok: false, error: '未登录 DeepSeek 账号' }
  if (result.status !== 'ready') return { ok: false, error: '账号余额尚未就绪（' + String(result.status || 'unknown') + '）' }
  const usable = (list) => (Array.isArray(list) ? list : []).filter((item) => item && num(item.balance) !== null)
  const normal = usable(result.value)
  const bonus = usable(result.bonusWallets)
  const all = normal.concat(bonus)
  if (all.length === 0) return { ok: false, error: '账号没有余额钱包' }
  const currencyOf = (item) => String((item && item.currency) || 'CNY').toUpperCase()
  const pick = all.find((item) => num(item.balance) > 0 && currencyOf(item) === 'CNY')
    || all.find((item) => num(item.balance) > 0)
    || all.find((item) => currencyOf(item) === 'CNY')
    || all[0]
  const currency = currencyOf(pick)
  const sum = (list) => list.filter((item) => currencyOf(item) === currency).reduce((total, item) => total + Number(item.balance), 0)
  const recharge = sum(normal)
  const bonusSum = sum(bonus)
  return {
    ok: true,
    source: 'account',
    currency,
    totalBalance: Number((recharge + bonusSum).toFixed(6)),
    bonusBalance: Number(bonusSum.toFixed(6)),
    updatedAt: new Date().toISOString(),
  }
}

async function balance(ctx) {
  const keyErr = await keyBalance(ctx)
  if (keyErr && keyErr.ok) return keyErr
  const accountErr = await accountBalance(ctx)
  if (accountErr.ok) return accountErr
  return {
    ok: false,
    error: (keyErr ? 'API key 路：' + String(keyErr.error || '失败') : '未配置 DEEPSEEK_API_KEY')
      + '；账号登录路：' + String(accountErr.error || '拿不到余额'),
    updatedAt: new Date().toISOString(),
  }
}

// ---------------------------------------------------------------------------
// 插件本体
// ---------------------------------------------------------------------------
export function apply(ctx, config = {}) {
  const farmFile = join(dataDir(), 'farm.json')
  const disposers = []
  const live = { sessions: {}, order: [] }
  let accountName = ''

  // 优先用 DSH 账号昵称（例如「玩.jpg」）作为农场标题；拿不到就退回“老乡的农场”
  async function loadAccountName() {
    try {
      const account = ctx.get('deepseekAccount')
      if (!account || typeof account.getProfile !== 'function') return
      const result = await account.getProfile({
        version: String(process.env.DSH_CLIENT_VERSION || process.env.DSH_VERSION || '') || 'unknown',
        locale: String(process.env.DSH_LOCALE || '') || 'zh_CN',
        timezoneOffsetSeconds: -new Date().getTimezoneOffset() * 60,
      })
      if (result && result.status === 'ready' && result.value && result.value.name) {
        accountName = String(result.value.name).trim().slice(0, 24)
        broadcast()
      }
    } catch { /* 未登录 / 老宿主：用默认标题 */ }
  }
  setTimeout(() => { loadAccountName().catch(() => {}) }, 0)

  // ---- SSE 客户端表（页面打开期间常驻） ----
  const clients = new Set()

  /**
   * 从 DSH 的 AgentRegistry 补一层忙闲兜底。
   * 有时 turn/start 没落到 session/event 上，只靠事件会让小人一直空闲；
   * 这里读 live agent.status（idle / running），并在新 agent 出现时补进 live.order。
   */
  function syncAgents() {
    let registry = null
    try { registry = ctx.get('agents') } catch { registry = null }
    if (!registry || typeof registry.list !== 'function') return false
    let raw = null
    try { raw = registry.list() } catch { return false }
    const agents = Array.isArray(raw)
      ? raw
      : (raw && typeof raw === 'object' ? Object.values(raw) : [])
    const now = Date.now()
    let changed = false
    for (const agent of agents) {
      if (!agent || typeof agent !== 'object') continue
      const sessionId = (agent.session && agent.session.id) || agent.sessionId
      if (typeof sessionId !== 'string' || !sessionId) continue
      const st = live.sessions[sessionId] || (live.sessions[sessionId] = emptySession(sessionId))
      const status = String(agent.status || '')
      if (status === 'running') {
        if (!st.busy) {
          st.busy = true
          st.updatedAt = now
          changed = true
        }
      } else if (status === 'idle' && st.busy && now - (st.updatedAt || 0) > 5000) {
        // 给 turn/start 留 5 秒缓冲，避免 registry 状态晚一拍造成闪烁。
        st.busy = false
        st.updatedAt = now
        changed = true
      }
      if (!live.order.includes(sessionId)) {
        touchSession(live, sessionId)
        changed = true
      }
    }
    return changed
  }

  function snapshot() {
    syncAgents()
    const sessions = live.order.map((id) => live.sessions[id]).filter(Boolean)
    let totalPending = 0
    for (const session of sessions) {
      for (const todo of session.todos || []) {
        if (todo.status !== 'completed') totalPending += 1
      }
    }
    const attentionSession = sessions.find((session) => session.attention) || null
    return {
      ok: true,
      now: Date.now(),
      day: localDay(),
      source: 'dsh',
      userName: accountName,
      activeSessionId: live.order[0] || null,
      sessions: sessions.map((session) => ({
        id: session.id,
        busy: session.busy,
        turns: session.turns,
        todos: session.todos,
        todosAt: session.todosAt,
        attention: session.attention,
        lastAssistant: session.lastAssistant,
        lastUser: session.lastUser,
        updatedAt: session.updatedAt,
      })),
      totalPending,
      attention: attentionSession ? attentionSession.attention : null,
      harness: false,
      harnessNames: [],
      usage: null,
      workApp: null,
      agents: live.order.length,
    }
  }

  /** 推给所有 SSE 客户端；没有客户端时零开销。 */
  function broadcast() {
    if (clients.size === 0) return
    const payload = 'data: ' + JSON.stringify(snapshot()) + '\n\n'
    for (const res of clients) {
      try { res.write(payload) } catch { clients.delete(res) }
    }
  }

  function applyHydratedTodos(id, todos, seq, at) {
    if (typeof id !== 'string' || !id || !Array.isArray(todos)) return false
    const st = live.sessions[id] || (live.sessions[id] = emptySession(id))
    // 已经有更新的 todo/write：不要被旧投影覆盖
    if (seq && st.todosSeq && seq < st.todosSeq) return false
    st.todos = todos
    st.todosSeq = seq || st.todosSeq
    st.todosAt = at || Date.now()
    st.updatedAt = Date.now()
    return true
  }

  /**
   * 启动水合：
   *   1. 先读投影缓存（便宜，保证离线也能显示）
   *   2. 再用 sessionQuery 读 live 会话的完整日志，找最后一条 todo/write（权威）
   * 只处理最近几个会话，避免把全部历史读进内存。
   */
  async function hydrateTodos() {
    let changed = false
    const hydrated = new Set()

    try {
      const projected = await readProjectionTodos()
      for (const [id, item] of projected) {
        if (applyHydratedTodos(id, item.todos, item.seq, Date.now())) {
          hydrated.add(id)
          changed = true
        }
      }
    } catch { /* 投影不可用 */ }

    try {
      const sq = ctx.get('sessionQuery')
      if (sq && typeof sq.listSessions === 'function' && typeof sq.readSession === 'function') {
        const list = await sq.listSessions()
        const records = Array.isArray(list) ? list : []
        const liveFirst = records.filter((rec) => rec && rec.live)
        const rest = records.filter((rec) => rec && !rec.live)
        const picked = liveFirst.concat(rest.slice(0, 2)).slice(0, 6)
        for (const rec of picked) {
          const id = (rec.header && rec.header.id) || rec.id
          if (typeof id !== 'string' || !id) continue
          let read = null
          try { read = await sq.readSession(id) } catch { continue }
          const events = read && Array.isArray(read.events) ? read.events : []
          for (let i = events.length - 1; i >= 0; i -= 1) {
            const event = events[i]
            if (!event || event.type !== 'todo/write') continue
            const data = event.data && typeof event.data === 'object' ? event.data : {}
            const todos = normalizeTodos(data.todos)
            const seq = Number(event.seq) || 0
            const at = typeof event.time === 'number' ? event.time : (Date.parse(event.time) || Date.now())
            if (applyHydratedTodos(id, todos, seq, at)) {
              hydrated.add(id)
              changed = true
            }
            break
          }
          // live 会话若还没进入 order，补进去；不打断已有的 active 顺序
          if (rec.live) {
            if (!live.order.includes(id)) live.order.push(id)
          }
        }
      }
    } catch { /* sessionQuery 不可用就用投影 */ }

    // order 为空（宿主刚启动）时，把水合到的会话按 todo seq 旧→新补进来，最新的成为 active
    if (!live.order.length) {
      const ids = [...hydrated].sort((a, b) => {
        const sa = (live.sessions[a] && live.sessions[a].todosSeq) || 0
        const sb = (live.sessions[b] && live.sessions[b].todosSeq) || 0
        return sa - sb
      })
      for (const id of ids) touchSession(live, id)
    }
    if (changed) broadcast()
    return changed
  }

  // 不阻塞宿主启动；SSE 首帧之后广播水合结果
  setTimeout(() => { hydrateTodos().catch(() => { /* 水合失败只降级 */ }) }, 0)

  // ---- 会话事件（只读） ----
  try {
    const off = ctx.on('session/event', (session, event) => {
      try {
        if (!session || typeof session.id !== 'string') return
        if (foldEvent(session, event, live)) broadcast()
      } catch { /* 单条采集失败不影响会话 */ }
    })
    if (typeof off === 'function') disposers.push(off)
  } catch { /* 没有事件总线：仍可用 /api/state 兜底 */ }

  // ---- agent 状态（忙闲兜底；事件参数在不同版本里可能是 (agent,status) 或 (status,agent)） ----
  try {
    const off = ctx.on('agent/status', (a, b) => {
      try {
        const agent = a && typeof a === 'object' && a.session ? a
          : (b && typeof b === 'object' && b.session ? b : null)
        const status = typeof a === 'string' ? a : (typeof b === 'string' ? b : (agent && agent.status))
        if (agent && agent.session && typeof agent.session.id === 'string') {
          const sessionId = agent.session.id
          const st = live.sessions[sessionId] || (live.sessions[sessionId] = emptySession(sessionId))
          if (status === 'running' || status === 'idle') {
            st.busy = status === 'running'
            st.updatedAt = Date.now()
          }
          touchSession(live, sessionId)
        } else {
          syncAgents()
        }
        broadcast()
      } catch { /* 单条状态失败不影响宿主 */ }
    })
    if (typeof off === 'function') disposers.push(off)
  } catch { /* 老宿主没有 agent/status */ }

  let widgetCache = null
  let widgetMtime = 0
  function widgetBytes() {
    const st = statSync(WIDGET_JS)
    if (!widgetCache || st.mtimeMs !== widgetMtime) {
      widgetCache = readFileSync(WIDGET_JS)
      widgetMtime = st.mtimeMs
    }
    return widgetCache
  }

  const register = (route) => ctx.webServer.register(route)

  // ---- 页面脚本 ----
  disposers.push(register({
    kind: 'exact',
    path: '/dsh-stardew/widget.js',
    handler: (req, res) => {
      try {
        const bytes = widgetBytes()
        res.writeHead(200, {
          'Content-Type': 'application/javascript; charset=utf-8',
          'Cache-Control': 'no-cache',
          'Content-Length': String(bytes.length),
        })
        res.end(bytes)
      } catch (err) {
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('stardew widget unavailable: ' + String((err && err.message) || err))
      }
    },
  }))

  // ---- 会话事实：一次性快照 ----
  disposers.push(register({
    kind: 'exact',
    path: '/dsh-stardew/api/state',
    handler: (req, res) => {
      res.writeHead(200, JSON_HEADERS)
      res.end(JSON.stringify(snapshot()))
    },
  }))

  // ---- 会话事实：SSE 推送（待办/提问一发生就推，延迟 ~0） ----
  disposers.push(register({
    kind: 'exact',
    path: '/dsh-stardew/api/events',
    handler: (req, res) => {
      res.writeHead(200, SSE_HEADERS)
      res.write('retry: 1000\n\n')
      clients.add(res)
      // 首帧立即给当前状态
      try { res.write('data: ' + JSON.stringify(snapshot()) + '\n\n') } catch { /* 忽略 */ }
      const ping = setInterval(() => {
        try { res.write(': ping\n\n') } catch { /* 断开时清理 */ }
      }, 15000)
      const cleanup = () => {
        clearInterval(ping)
        clients.delete(res)
      }
      req.on('close', cleanup)
      req.on('error', cleanup)
      res.on('error', cleanup)
    },
  }))

  // ---- 农场存档 ----
  disposers.push(register({
    kind: 'exact',
    path: '/dsh-stardew/api/snapshot',
    handler: async (req, res) => {
      let data = null
      try {
        data = JSON.parse(await readFile(farmFile, 'utf8'))
      } catch {
        data = null
      }
      res.writeHead(200, JSON_HEADERS)
      res.end(JSON.stringify({ ok: true, data }))
    },
  }))

  disposers.push(register({
    kind: 'exact',
    path: '/dsh-stardew/api/mutate',
    handler: async (req, res) => {
      if (req.method !== 'POST') {
        res.writeHead(405, JSON_HEADERS)
        res.end(JSON.stringify({ ok: false, error: 'POST only' }))
        return
      }
      try {
        const body = JSON.parse(await readBody(req))
        const data = body && body.data
        if (!data || typeof data !== 'object' || typeof data.day !== 'string') {
          res.writeHead(400, JSON_HEADERS)
          res.end(JSON.stringify({ ok: false, error: 'bad farm document' }))
          return
        }
        data.updatedAt = Date.now()
        await mkdir(dirname(farmFile), { recursive: true })
        const tmp = farmFile + '.tmp-' + process.pid
        await writeFile(tmp, JSON.stringify(data), 'utf8')
        await rename(tmp, farmFile)
        res.writeHead(200, JSON_HEADERS)
        res.end(JSON.stringify({ ok: true, savedAt: data.updatedAt }))
      } catch (err) {
        res.writeHead(500, JSON_HEADERS)
        res.end(JSON.stringify({ ok: false, error: String((err && err.message) || err) }))
      }
    },
  }))

  // ---- 余额 ----
  disposers.push(register({
    kind: 'exact',
    path: '/dsh-stardew/api/balance',
    handler: async (req, res) => {
      let payload
      try {
        payload = await balance(ctx)
      } catch (err) {
        payload = { ok: false, error: String((err && err.message) || err) }
      }
      res.writeHead(200, JSON_HEADERS)
      res.end(JSON.stringify(payload))
    },
  }))

  // ---- 自检 ----
  disposers.push(register({
    kind: 'exact',
    path: '/dsh-stardew/api/health',
    handler: (req, res) => {
      let size = 0
      let selfContained = false
      try {
        const bytes = widgetBytes()
        size = bytes.length
        const text = bytes.toString('utf8')
        selfContained = text.includes('data:image/png;base64,') && text.includes('dsh-stardew-css')
      } catch { /* 还没构建 */ }
      res.writeHead(200, JSON_HEADERS)
      res.end(JSON.stringify({
        ok: true,
        version: VERSION,
        mode: 'dsh',
        source: 'dsh',
        widgetBytes: size,
        selfContained,
        sseClients: clients.size,
        sessions: live.order.length,
        sessionsWithTodos: live.order.filter((id) => live.sessions[id] && Array.isArray(live.sessions[id].todos) && live.sessions[id].todos.length).length,
        busy: live.order.some((id) => live.sessions[id] && live.sessions[id].busy),
        agents: live.order.length,
        farmFile,
      }))
    },
  }))

  // ---- 注入页面脚本 ----
  try {
    const onInject = (table) => {
      table.push({ kind: 'script-src', placement: 'body', src: WIDGET_URL })
    }
    ctx.on('webserver/index-inject', onInject)
    disposers.push(() => {
      try { ctx.off('webserver/index-inject', onInject) } catch { /* 已卸载 */ }
    })
  } catch { /* 老宿主无结构化注入 */ }

  try {
    disposers.push(ctx.webServer.tapIndex((html) => {
      if (typeof html !== 'string' || html.includes('dsh-stardew/widget.js')) return html
      const tag = '<script defer src="' + WIDGET_URL + '"></script>'
      return html.includes('</body>') ? html.replace('</body>', tag + '</body>') : html + tag
    }))
  } catch { /* tapIndex 不可用 */ }

  ctx.effect(() => () => {
    widgetCache = null
    for (const res of clients) {
      try { res.end() } catch { /* 忽略 */ }
    }
    clients.clear()
    for (const dispose of disposers) {
      try { dispose() } catch { /* teardown 尽力而为 */ }
    }
    disposers.length = 0
  })
}
