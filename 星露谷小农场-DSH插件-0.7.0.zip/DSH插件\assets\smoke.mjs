/**
 * 最小 DOM 冒烟测试：不开浏览器也能验证 widget.js 能启动、能响应按键、
 * 能渲染面板、且没有运行时异常。
 *
 *   node assets/smoke.mjs
 *
 * 它实现了一个刚够用的假 DOM（元素树 / style / classList / 事件 / 定时器），
 * 把构建产物 widget.js 执行一遍，再用假按键和假接口驱动几个关键路径。
 */
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import vm from 'node:vm'

const here = dirname(fileURLToPath(import.meta.url))
const source = readFileSync(join(here, 'widget.js'), 'utf8')
const cssSource = readFileSync(join(here, 'widget.css'), 'utf8')

// ---------------- 假 DOM ----------------
class Style {
  constructor() { this._map = new Map() }
  setProperty(name, value) { this._map.set(name, String(value)) }
  getPropertyValue(name) { return this._map.get(name) || '' }
  removeProperty(name) { this._map.delete(name) }
}
const styleProxy = (style) => new Proxy(style, {
  get(target, prop) {
    if (prop === 'setProperty' || prop === 'getPropertyValue' || prop === 'removeProperty') return target[prop].bind(target)
    if (prop === '_map') return target._map
    return target._map.get(String(prop)) ?? ''
  },
  set(target, prop, value) { target._map.set(String(prop), String(value)); return true },
})

class ClassList {
  constructor() { this._set = new Set() }
  add(...names) { names.forEach((n) => this._set.add(n)) }
  remove(...names) { names.forEach((n) => this._set.delete(n)) }
  contains(name) { return this._set.has(name) }
  toggle(name, force) {
    const next = force === undefined ? !this._set.has(name) : Boolean(force)
    if (next) this._set.add(name)
    else this._set.delete(name)
    return next
  }
  get value() { return [...this._set].join(' ') }
}

class ClassNode {
  constructor(tagName) {
    this.tagName = String(tagName || 'div').toUpperCase()
    this.childNodes = []
    this._elementChildren = []   // 活数组：widget 里 `layer.children.length` 必须随增删变化
    this.parentNode = null
    this.attributes = new Map()
    this.listeners = new Map()
    this.style = styleProxy(new Style())
    this.classList = new ClassList()
    this.dataset = {}
    this.textContent = ''
    this._className = ''
    this.id = ''
    this.width = 0
    this.height = 0
    this.clientWidth = 300
    this.clientHeight = 200
    this.scrollTop = 0
    this.value = ''
    this.checked = false
  }
  get className() { return this._className || this.classList.value }
  set className(value) {
    this._className = String(value || '')
    this.classList = new ClassList()
    this._className.split(/\s+/).filter(Boolean).forEach((name) => this.classList.add(name))
  }
  get children() { return this._elementChildren }
  get childElementCount() { return this._elementChildren.length }
  get firstChild() { return this.childNodes[0] || null }
  get lastChild() { return this.childNodes[this.childNodes.length - 1] || null }
  get nextSibling() { return null }
  appendChild(node) {
    if (!node) return node
    if (node.nodeType === 3) {
      // 文本节点：假 DOM 里直接累加到 textContent，方便断言按钮文案
      this.textContent = (this.textContent || '') + String(node.textContent || '')
      this.childNodes.push(node)
      return node
    }
    node.parentNode = this
    this.childNodes.push(node)
    if (node instanceof ClassNode) this._elementChildren.push(node)
    return node
  }
  insertBefore(node, before) {
    node.parentNode = this
    const at = this.childNodes.indexOf(before)
    if (at < 0) this.childNodes.push(node)
    else this.childNodes.splice(at, 0, node)
    if (node instanceof ClassNode) {
      const elementAt = this._elementChildren.indexOf(before)
      if (elementAt < 0) this._elementChildren.push(node)
      else this._elementChildren.splice(elementAt, 0, node)
    }
    return node
  }
  removeChild(node) {
    const at = this.childNodes.indexOf(node)
    if (at >= 0) this.childNodes.splice(at, 1)
    const elementAt = this._elementChildren.indexOf(node)
    if (elementAt >= 0) this._elementChildren.splice(elementAt, 1)
    node.parentNode = null
    return node
  }
  remove() { if (this.parentNode) this.parentNode.removeChild(this) }
  replaceChildren(...nodes) {
    this.childNodes.forEach((node) => { node.parentNode = null })
    this.childNodes = []
    this._elementChildren = []
    nodes.forEach((node) => this.appendChild(node))
  }
  set innerHTML(value) { this.replaceChildren() }
  get innerHTML() { return '' }
  setAttribute(name, value) {
    this.attributes.set(name, String(value))
    if (name === 'class') this.className = String(value)
    if (name === 'id') this.id = String(value)
    if (name.startsWith('data-')) this.dataset[name.slice(5)] = String(value)
  }
  getAttribute(name) {
    if (name === 'class') return this.className
    return this.attributes.get(name) ?? null
  }
  removeAttribute(name) { this.attributes.delete(name) }
  hasAttribute(name) { return this.attributes.has(name) }
  addEventListener(type, handler) {
    const list = this.listeners.get(type) || []
    list.push(handler)
    this.listeners.set(type, list)
  }
  removeEventListener(type, handler) {
    const list = this.listeners.get(type) || []
    const at = list.indexOf(handler)
    if (at >= 0) list.splice(at, 1)
  }
  dispatchEvent(event) {
    const list = this.listeners.get(event.type) || []
    list.slice().forEach((handler) => handler.call(this, event))
    if (this.parentNode) this.parentNode.dispatchEvent(event)
    return true
  }
  closest(selector) {
    if (!selector.startsWith('.')) return null
    const name = selector.slice(1)
    let node = this
    while (node) {
      if (node instanceof ClassNode && node.classList.contains(name)) return node
      node = node.parentNode
    }
    return null
  }
  getBoundingClientRect() {
    return { width: this.clientWidth, height: this.clientHeight, top: 0, left: 0, right: this.clientWidth, bottom: this.clientHeight }
  }
  focus() {}
  contains(node) {
    let current = node
    while (current) {
      if (current === this) return true
      current = current.parentNode
    }
    return false
  }
  querySelector(selector) {
    const results = []
    const walk = (node) => {
      node.children.forEach((child) => {
        if (matches(child, selector)) results.push(child)
        walk(child)
      })
    }
    walk(this)
    return results[0] || null
  }
  querySelectorAll(selector) {
    const results = []
    const walk = (node) => {
      node.children.forEach((child) => {
        if (matches(child, selector)) results.push(child)
        walk(child)
      })
    }
    walk(this)
    return results
  }
}

function matches(node, selector) {
  if (selector.startsWith('.')) return node.classList.contains(selector.slice(1))
  if (selector.startsWith('[') && selector.endsWith(']')) {
    const name = selector.slice(1, -1)
    return node.attributes.has(name)
  }
  return node.tagName === selector.toUpperCase()
}

// ---------------- 全局环境 ----------------
const TODAY = (() => {
  const d = new Date()
  const p = (n) => (n < 10 ? '0' + n : String(n))
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate())
})()

const HOST_STATE = {
  ok: true,
  now: Date.now(),
  day: TODAY,
  source: 'dsh',
  activeSessionId: 'session-test',
  totalPending: 3,
  attention: { kind: '提问', text: '要不要继续部署？', at: Date.now() },
  harness: false,
  harnessNames: [],
  usage: null,
  workApp: null,
  sessions: [{
    id: 'session-test',
    busy: true,
    turns: 2,
    todos: [
      { content: '搭好农场插件', status: 'completed' },
      { content: '验证小人在田里干活', status: 'in_progress' },
      { content: '查一次余额', status: 'pending' },
    ],
    lastAssistant: { text: '农场已就绪', at: Date.now() },
  }],
}
const EventSourceLog = []
const EventSourceInstances = []
const windowKeydownHandlers = []

const documentListeners = new Map()
const timers = new Set()
const intervals = new Set()
const fetchLog = []

const document = new ClassNode('#document')
const documentElement = new ClassNode('html')
const head = new ClassNode('head')
const body = new ClassNode('body')
document.documentElement = documentElement
document.head = head
document.body = body
document.readyState = 'complete'
document.hidden = false
document.visibilityState = 'visible'
document.createElement = (tag) => new ClassNode(tag)
document.createTextNode = (text) => ({ nodeType: 3, textContent: String(text) })
document.getElementById = (id) => (id === 'x' ? null : null)
document.querySelector = (selector) => body.querySelector(selector) || head.querySelector(selector)
document.querySelectorAll = (selector) => body.querySelectorAll(selector)
document.addEventListener = (type, handler) => {
  const list = documentListeners.get(type) || []
  list.push(handler)
  documentListeners.set(type, list)
}
document.removeEventListener = (type, handler) => {
  const list = documentListeners.get(type) || []
  const at = list.indexOf(handler)
  if (at >= 0) list.splice(at, 1)
}
document.dispatchEvent = (event) => {
  const seen = new Set()
  ;(documentListeners.get(event.type) || []).slice().forEach((handler) => { seen.add(handler); handler(event) })
  windowKeydownHandlers.slice().forEach((handler) => { if (!seen.has(handler)) handler(event) })
}

class ImageShim extends ClassNode {
  constructor() { super('img') }
}
const performanceNow = () => Date.now()
const errors = []

const sandbox = {
  document,
  Image: ImageShim,
  console: {
    log: () => {},
    warn: (...args) => errors.push('warn: ' + args.join(' ')),
    error: (...args) => errors.push('error: ' + args.join(' ')),
  },
  setTimeout: (fn, ms, ...args) => {
    const id = setTimeout(() => { timers.delete(id); try { fn(...args) } catch (err) { errors.push('timeout: ' + err.message) } }, Math.min(ms || 0, 4000))
    timers.add(id)
    return id
  },
  clearTimeout: (id) => { clearTimeout(id); timers.delete(id) },
  setInterval: (fn, ms) => {
    const id = setInterval(() => { try { fn() } catch (err) { errors.push('interval: ' + err.message) } }, Math.min(ms || 0, 100))
    intervals.add(id)
    return id
  },
  clearInterval: (id) => { clearInterval(id); intervals.delete(id) },
  requestAnimationFrame: (fn) => {
    const id = setTimeout(() => { try { fn(performanceNow()) } catch (err) { errors.push('raf: ' + err.message) } }, 0)
    return id
  },
  cancelAnimationFrame: () => {},
  performance: { now: performanceNow },
  localStorage: {
    _map: new Map(),
    getItem(key) { return this._map.has(key) ? this._map.get(key) : null },
    setItem(key, value) { this._map.set(key, String(value)) },
    removeItem(key) { this._map.delete(key) },
  },
  getComputedStyle: () => ({ getPropertyValue: () => '#1e1e1e' }),
  matchMedia: () => ({ matches: false, addEventListener: () => {}, removeEventListener: () => {} }),
  MutationObserver: class { observe() {} disconnect() {} },
  fetch: (url, options) => {
    fetchLog.push({ url: String(url), method: (options && options.method) || 'GET' })
    const payload = String(url).includes('/api/state') || String(url).includes('/api/events')
      ? HOST_STATE
      : String(url).includes('/api/snapshot')
        ? { ok: true, data: { day: TODAY, v: 5, coins: 40, plots: [], keys: {}, settings: {} } }
        : String(url).includes('/api/balance')
          ? { ok: true, source: 'api-key', currency: 'CNY', totalBalance: 4.29, bonusBalance: null }
          : { ok: true }
    return Promise.resolve({ ok: true, json: () => Promise.resolve(payload), text: () => Promise.resolve(JSON.stringify(payload)) })
  },
  EventSource: class {
    constructor(url) {
      EventSourceLog.push(String(url))
      this.url = String(url)
      this.readyState = 1
      EventSourceInstances.push(this)
      setTimeout(() => { if (this.onmessage) this.onmessage({ data: JSON.stringify(HOST_STATE) }) }, 5)
    }
    close() { this.readyState = 2 }
  },
  navigator: { userAgent: 'smoke-test' },
  location: { href: 'http://127.0.0.1:3080/' },
  AudioContext: class {
    constructor() { this.currentTime = 0; this.destination = {} }
    createOscillator() { return { type: '', frequency: { value: 0 }, connect: () => ({ connect: () => {} }), start() {}, stop() {} } }
    createGain() { return { gain: { value: 0, exponentialRampToValueAtTime() {} }, connect: (n) => n } }
  },
  innerWidth: 1440,
  innerHeight: 900,
  addEventListener: (type, handler) => {
    const list = documentListeners.get(type) || []
    list.push(handler)
    documentListeners.set(type, list)
    if (type === 'keydown') windowKeydownHandlers.push(handler)
  },
  removeEventListener: (type, handler) => {
    const list = documentListeners.get(type) || []
    const at = list.indexOf(handler)
    if (at >= 0) list.splice(at, 1)
  },
}
sandbox.window = sandbox
sandbox.globalThis = sandbox
sandbox.self = sandbox

// ---------------- 执行 widget ----------------
const context = vm.createContext(sandbox)
// 跨天存档：昨天的金币必须在今天启动时保留下来（田地/按键仍按新一天重置）
sandbox.localStorage.setItem('dsh-stardew-farm:v5', JSON.stringify({
  v: 5, day: '2000-01-01', coins: 77, farmSeconds: 9, keys: { A: { n: 2 } }, plots: [],
}))
try {
  vm.runInContext(source, context, { filename: 'widget.js' })
} catch (err) {
  console.error('❌ widget 启动即抛错：', err && err.stack)
  process.exit(1)
}

// 等首帧 / 首个轮询完成
await new Promise((resolve) => setTimeout(resolve, 200))

const failures = []
const check = (name, condition, extra) => {
  if (condition) console.log('✅', name)
  else { failures.push(name); console.log('❌', name, extra === undefined ? '' : extra) }
}

const root = body.querySelector('.dsf-root')
const api = sandbox.__dshStardew
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
const clone = (value) => JSON.parse(JSON.stringify(value))
const textOf = (el) => {
  if (!el) return ''
  let text = el.textContent || ''
  if (el.children) el.children.forEach((child) => { text += textOf(child) })
  return text
}
const allPlots = () => root.querySelectorAll('.dsf-plot')
const allKeys = () => root.querySelectorAll('.dsf-key')
check('跨天存档保留金币', api.state.coins >= 77, 'coins=' + api.state.coins)
check('跨天存档不把旧田地/按键带进新一天', api.state.plots.every((p) => p.stage === 0) && Object.keys(api.state.keys).length === 0,
  JSON.stringify({ stages: api.state.plots.map((p) => p.stage), keys: Object.keys(api.state.keys) }))
const viewOn = (cls) => {
  const el = root.querySelector('.' + cls)
  return Boolean(el && el.classList.contains('dsf-view-on'))
}

check('农场根节点已挂到 body', Boolean(root))
check('有 26 块固定地', allPlots().length === 26, 'got ' + allPlots().length)
check('地块按 A–Z 排好', allPlots().map((el) => el.getAttribute('data-letter')).join('') === 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')
check('没有房子/谷仓/鸡舍', !root.querySelector('.dsf-house') && !root.querySelector('.dsf-decor-house') && !root.querySelector('.dsf-barn') && !root.querySelector('.dsf-coop'))
check('有小人精灵', Boolean(root.querySelector('.dsf-farmer')))
check('有记录员小人', Boolean(root.querySelector('.dsf-clerk')))
check('有土地装饰：水塘/花/草 + 4 只帮手', root.querySelectorAll('.dsf-prop').length >= 6
  && root.querySelectorAll('.dsf-helper').length === 4
  && Boolean(root.querySelector('.dsf-clerk')))
check('有 5 个页签', root.querySelectorAll('.dsf-tabbtn').length === 5, 'got ' + root.querySelectorAll('.dsf-tabbtn').length)
const tabButtons = root.querySelector('.dsf-tabbar').children
check('页签使用素材图标', tabButtons.length === 5 && [...tabButtons].every((btn) => btn.children.length >= 1),
  'got ' + tabButtons.filter((btn) => btn.children.length >= 1).length)
check('外框使用 9-slice 面板', Boolean(root.querySelector('.dsf-frame')
  && root.querySelector('.dsf-frame').classList.contains('dsf-panel-paper')))
check('ASCII 走 8×10 位图字库',
  root.querySelectorAll('.dsf-glyph').length > 10
  && Boolean(root.querySelector('.dsf-glyph'))
  && String(root.querySelector('.dsf-glyph').style.backgroundImage).includes('data:image/png'))
check('版本 0.7.0', api.version === '0.7.0', api.version)
const FARM_CROPS = ['beetroot', 'cabbage', 'cauliflower', 'carrot', 'kale', 'potato', 'pumpkin', 'radish', 'parsnip', 'sunflower', 'wheat']
  .map((name) => 'crop_' + name)
check('11 种真实 FarmLife 作物', api.crops.length === 11
  && api.crops.map((c) => c.sprite).sort().join('|') === FARM_CROPS.slice().sort().join('|'),
  JSON.stringify(api.crops.map((c) => c.sprite)))
check('走了 SSE 推送通道', EventSourceLog.some((u) => u.includes('/api/events')), EventSourceLog.join(','))
check('键盘农场 26 键', allKeys().length === 26, 'got ' + allKeys().length)
const keyRows = root.querySelectorAll('.dsf-keyrow')
check('QWERTY 三行 10+9+7', keyRows.length === 3
  && keyRows[0].children.length === 10
  && keyRows[1].children.length === 9
  && keyRows[2].children.length === 7,
  keyRows.map((row) => row.children.length).join('/'))
check('键位字母也是 A–Z', allKeys().map((el) => el.getAttribute('data-letter')).sort().join('') === 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')
check('CSS 里作物踩在土块内',
  /\.dsf-plot \.dsf-plant\s*\{[^}]*top:\s*9px/.test(cssSource)
  && /\.dsf-plot \.dsf-plant\s*\{[^}]*width:\s*16px/.test(cssSource)
  && /\.dsf-plot \.dsf-plant\s*\{[^}]*height:\s*20px/.test(cssSource)
  && /\.dsf-plot \.dsf-soil\s*\{[^}]*top:\s*1px/.test(cssSource))
check('CSS 不再有房子样式', !/\.dsf-house|\.dsf-barn|\.dsf-coop/.test(cssSource))

// ---- 键盘：3 击成熟 → 立刻加金币 ----
const coinsBefore = api.state.coins
const press = (key) => document.dispatchEvent({
  type: 'keydown', key, isComposing: false,
  ctrlKey: false, metaKey: false, altKey: false, shiftKey: false,
})
for (let i = 0; i < 3; i += 1) press('a')
await wait(120)
check('3 击记入 A 地', Boolean(api.state.keys.A) && api.state.keys.A.n === 3, JSON.stringify(api.state.keys.A))
check('A 地成熟', api.state.plots[0].stage === 3, 'stage=' + api.state.plots[0].stage)
check('收割立刻加金币', api.state.coins >= coinsBefore + 4, coinsBefore + ' -> ' + api.state.coins)
check('A 地收割计数', api.state.keys.A.harvests === 1, 'harvests=' + api.state.keys.A.harvests)
check('收割气泡', textOf(root.querySelector('.dsf-bubble')).includes('收获'), textOf(root.querySelector('.dsf-bubble')))

// ---- 键盘 B 键和农场 B 地必须共用同一份状态 ----
for (let i = 0; i < 2; i += 1) press('b')
await wait(80)
check('B 地长到 2/3', api.state.plots[1].stage === 2, 'stage=' + api.state.plots[1].stage)
api.switchTab('keys')
await wait(60)
check('切到键盘农场页', viewOn('dsf-view-keys'))
const keyB = allKeys().find((el) => el.getAttribute('data-letter') === 'B')
const keyBPlant = keyB && keyB.querySelector('.dsf-key-plant')
check('键盘 B 键显示同一块地的作物', Boolean(keyBPlant), 'no plant')
check('键盘 B 键作物帧 = 农场 B 地', Boolean(keyBPlant && keyBPlant.style.backgroundPosition === '-32px 0px'),
  keyBPlant && keyBPlant.style.backgroundPosition)
const farmB = allPlots().find((el) => el.getAttribute('data-letter') === 'B')
const farmBPlant = farmB && farmB.querySelector('.dsf-plant')
check('农场 B 地和键盘 B 键是同一状态',
  Boolean(farmBPlant && farmBPlant.style.backgroundPosition === '-32px 0px'),
  farmBPlant && farmBPlant.style.backgroundPosition)

await wait(1500)
check('成熟动画后 A 地清空', api.state.plots[0].stage === 0, 'stage=' + api.state.plots[0].stage)
const keyA = allKeys().find((el) => el.getAttribute('data-letter') === 'A')
check('A 地清空后键盘也清空', !(keyA && keyA.querySelector('.dsf-key-plant')))
api.switchTab('farm')
await wait(60)
check('切回农场页', viewOn('dsf-view-farm'))

// ---- 键盘：中文输入法上屏（input 兜底） ----
const totalKeysBefore = Object.keys(api.state.keys).reduce((n, k) => n + (api.state.keys[k].n || 0), 0)
await wait(120)
document.dispatchEvent({ type: 'input', data: '你好', isComposing: false })
await wait(100)
const totalKeysAfter = Object.keys(api.state.keys).reduce((n, k) => n + (api.state.keys[k].n || 0), 0)
check('输入法上屏也计数', totalKeysAfter >= totalKeysBefore + 2, totalKeysBefore + ' -> ' + totalKeysAfter)

// ---- 提问 → 小人抬头；一轮结束 → 轻提醒 ----
const badge = root.querySelector('.dsf-badge')
check('提问时出现徽标', Boolean(badge && badge.classList.contains('dsf-badge-show')))
const farmerNode = root.querySelector('.dsf-farmer')
check('提问时小人看向屏幕', Boolean(farmerNode && farmerNode.classList.contains('dsf-looking')))

const stream = EventSourceInstances[0]
const ended = clone(HOST_STATE)
ended.attention = null
ended.sessions[0].busy = false
ended.sessions[0].lastAssistant = { text: '这轮做完了', at: Date.now() }
stream.onmessage({ data: JSON.stringify(ended) })
await wait(100)
check('提问结束后徽标收起', !badge.classList.contains('dsf-badge-show'))
check('一轮结束给提示气泡', textOf(root.querySelector('.dsf-bubble')).includes('这轮忙完啦'), textOf(root.querySelector('.dsf-bubble')))

// ---- 任务切换：小人提醒老乡 ----
const nextTask = clone(ended)
nextTask.sessions[0].busy = true
nextTask.sessions[0].todos = [
  { content: '搭好农场插件', status: 'completed' },
  { content: '验证小人在田里干活', status: 'completed' },
  { content: '查一次余额', status: 'in_progress' },
]
stream.onmessage({ data: JSON.stringify(nextTask) })
await wait(100)
check('任务切换气泡', textOf(root.querySelector('.dsf-bubble')).includes('老乡，我该做下一步了'), textOf(root.querySelector('.dsf-bubble')))
check('任务页同步新待办', api.host.todos.some((todo) => todo.content === '查一次余额' && todo.status === 'in_progress'))
api.switchTab('tasks')
await wait(60)
check('切到任务页', viewOn('dsf-view-tasks'))
check('任务页显示待办', root.querySelector('.dsf-view-tasks').querySelectorAll('.dsf-item').length >= 3)
const currentRows = root.querySelectorAll('.dsf-task-current')
const currentChip = root.querySelector('.dsf-current-chip')
check('待办当前项高亮', currentRows.length >= 1 && Boolean(currentChip),
  JSON.stringify({ current: currentRows.length, chip: Boolean(currentChip) }))
const taskView = root.querySelector('.dsf-view-tasks')
const clickRow = taskView.querySelectorAll('.dsf-item')[1]
clickRow.dispatchEvent({ type: 'click', stopPropagation() {} })
await wait(60)
const selectedRows = root.querySelectorAll('.dsf-task-on')
check('点击待办出现选中态', selectedRows.length === 1, 'got ' + selectedRows.length)
check('选中态有「已选」标记', Boolean(root.querySelector('.dsf-selected-chip')))
// ---- 当前会话还没写 todo/write 时，退回最近一轮的待办 ----
const fallbackState = clone(nextTask)
fallbackState.activeSessionId = 'session-new'
fallbackState.sessions = [
  { id: 'session-new', busy: false, turns: 0, todos: null, attention: null, lastAssistant: null },
  { id: 'session-old', busy: false, turns: 0, todos: nextTask.sessions[0].todos, attention: null, lastAssistant: null },
]
stream.onmessage({ data: JSON.stringify(fallbackState) })
await wait(100)
check('当前会话没有待办时回退到最近一轮', api.host.todos.length >= 3 && api.host.todosFallback === true,
  JSON.stringify({ todos: api.host.todos.length, fallback: api.host.todosFallback }))
api.switchTab('tasks')
await wait(60)
check('回退待办有来源提示', Boolean(root.querySelector('.dsf-task-source')),
  textOf(root.querySelector('.dsf-task-source')))
const bounds = (() => {
  const b = root.querySelector('.dsf-bubble')
  const f = root.querySelector('.dsf-fieldbody')
  if (!b || !f) return null
  return {
    left: parseFloat(b.style.left || 'NaN'),
    top: parseFloat(b.style.top || 'NaN'),
    max: parseFloat(b.style.maxWidth || 'NaN'),
    fieldW: f.clientWidth,
    fieldH: f.clientHeight,
  }
})()
check('气泡按农场边界限宽/夹紧', Boolean(bounds) && bounds.left >= 0 && bounds.top >= 0
  && bounds.max <= bounds.fieldW - 8 && bounds.left + bounds.max <= bounds.fieldW + 1,
  JSON.stringify(bounds))

// ---- 桌面端工时：软件切换 → 「工作中」+ 自动劳动 ----
const usage = {
  ok: true,
  source: 'desktop',
  day: TODAY,
  totalSeconds: 12,
  updatedAt: Date.now(),
  harness: false,
  harnessNames: [],
  idleSeconds: 0,
  apps: [
    { key: 'code', name: 'VS Code', process: 'code', title: 'main.js', seconds: 8, lastAt: Date.now() },
    { key: 'chrome', name: 'Chrome', process: 'chrome', title: 'docs', seconds: 4, lastAt: Date.now() },
  ],
  current: {
    key: 'code', name: 'VS Code', process: 'code', title: 'main.js',
    ignored: false, reason: '', since: Date.now() - 1000, switchedAt: Date.now(),
  },
}
const desktopState = clone(nextTask)
desktopState.source = 'desktop'
desktopState.harness = false
desktopState.harnessNames = []
desktopState.usage = usage
desktopState.workApp = usage.current
desktopState.sessions[0].busy = true
stream.onmessage({ data: JSON.stringify(desktopState) })
await wait(100)
check('软件切换气泡是「工作中」', textOf(root.querySelector('.dsf-bubble')) === '工作中', textOf(root.querySelector('.dsf-bubble')))
check('有前台软件时小人自动干活', api.workingNow() === true)
check('状态栏显示正在用的软件', textOf(root.querySelector('.dsf-statusbar')).includes('VS Code'), textOf(root.querySelector('.dsf-statusbar')))
api.switchTab('usage')
await wait(60)
check('切到工时页', viewOn('dsf-view-usage'))
check('工时页显示总时长', Boolean(root.querySelector('.dsf-view-usage').querySelector('.dsf-usage-total')))
check('工时页列出软件', root.querySelector('.dsf-view-usage').querySelectorAll('.dsf-usage-row').length >= 2,
  'got ' + root.querySelector('.dsf-view-usage').querySelectorAll('.dsf-usage-row').length)
check('工时页显示正在用', textOf(root.querySelector('.dsf-usage-now')).includes('VS Code'), textOf(root.querySelector('.dsf-usage-now')))

// ---- 空闲：记录员暂停 ----
const idleState = clone(desktopState)
idleState.sessions[0].busy = false
idleState.usage = clone(usage)
idleState.usage.current = {
  key: 'code', name: 'VS Code', process: 'code', title: 'main.js',
  ignored: true, reason: 'idle', since: Date.now(), switchedAt: usage.current.switchedAt,
}
idleState.workApp = idleState.usage.current
stream.onmessage({ data: JSON.stringify(idleState) })
await wait(100)
check('空闲时工时页显示未记录', textOf(root.querySelector('.dsf-usage-now')).includes('当前未记录'), textOf(root.querySelector('.dsf-usage-now')))

// ---- harness：自动开工 ----
const harnessState = clone(idleState)
harnessState.harness = true
harnessState.harnessNames = ['opencode']
harnessState.usage = clone(usage)
harnessState.usage.harness = true
harnessState.usage.harnessNames = ['opencode']
harnessState.usage.current = null
harnessState.workApp = null
stream.onmessage({ data: JSON.stringify(harnessState) })
await wait(100)
check('检测到 harness', api.host.harness === true)
check('harness 时小人自动劳动', api.workingNow() === true)
check('工时页显示 harness', textOf(root.querySelector('.dsf-usage-harness')).includes('opencode'), textOf(root.querySelector('.dsf-usage-harness')))
check('地块数量始终是 26', api.state.plots.length === 26)

// ---- 角色状态机：走路 / 干活期间不推进作物，干完才推进并开心 1 秒 ----
api.state.plots[5].stage = 0
api.state.plots[5].harvestAt = 0
api.clearQueue()
const actor = api.farmer
actor.x = 20; actor.y = 20; actor.tx = 20; actor.ty = 20; actor.phase = 'idle'; actor.moving = false
api.debugJob(5)
const phases = new Set()
let maxWhileMoving = 0
let happySteps = 0
for (let i = 0; i < 400; i += 1) {
  api.advance(0.05)
  phases.add(actor.phase)
  if (actor.phase === 'walk' || actor.phase === 'act') maxWhileMoving = Math.max(maxWhileMoving, api.state.plots[5].stage)
  if (actor.phase === 'happy') happySteps += 1
}
check('走路/干活动作没播完不推进作物', maxWhileMoving === 0, 'maxWhileMoving=' + maxWhileMoving)
check('干完动作推进作物', api.state.plots[5].stage >= 1, 'stage=' + api.state.plots[5].stage)
check('干完显示开心表情约 1 秒', phases.has('happy') && Math.abs(happySteps * 50 - 1000) <= 100,
  JSON.stringify({ phases: [...phases], happyMs: happySteps * 50 }))
// ---- 方向：整段走路只定一次，不在每帧 dx/dy 之间来回翻面 ----
api.state.plots[6].stage = 0
api.state.plots[6].harvestAt = 0
api.clearQueue()
actor.x = 20; actor.y = 150; actor.tx = 20; actor.ty = 150; actor.phase = 'idle'; actor.moving = false
api.debugJob(6)
const dir0 = actor.dir
let dirFlips = 0
for (let i = 0; i < 80; i += 1) {
  api.advance(0.05)
  if (actor.phase === 'walk' && actor.dir !== dir0) dirFlips += 1
}
check('走路方向稳定，不会反复翻面', dirFlips === 0, 'dir=' + dir0 + ' flips=' + dirFlips)

// ---- 帮手独立干活：解锁后自己选地/走路，不是跟着小人 ----
api.state.helpers = 1
api.state.helperSeconds = 0
api.state.lastWorkAt = Date.now()
const helper0 = api.helperActors[0]
const helperStart = { x: helper0.x, y: helper0.y }
await wait(400)
check('帮手独立选地/走路/干活',
  Boolean(helper0.job) || helper0.phase === 'walk' || helper0.phase === 'act' || helper0.x !== helperStart.x || helper0.y !== helperStart.y,
  JSON.stringify({ phase: helper0.phase, job: Boolean(helper0.job), x: helper0.x, y: helper0.y }))
check('帮手数量与出场一致', root.querySelectorAll('.dsf-helper-on').length === 1,
  'got ' + root.querySelectorAll('.dsf-helper-on').length)

// ---- 余额页 ----
api.switchTab('balance')
await wait(200)
check('切到余额页', viewOn('dsf-view-balance'))
check('余额页显示金额', Boolean(root.querySelector('.dsf-bal-big')), 'no .dsf-bal-big')
api.switchTab('farm')
await wait(60)

// ---- 开场待办卡 ----
check('开场闪现代办卡片', Boolean(root.querySelector('.dsf-intro')))

// ---- ☰ 面板：尺寸设置 ----
const menuBtn = root.querySelector('.dsf-iconbtn')
menuBtn.dispatchEvent({ type: 'click', stopPropagation() {} })
await wait(60)
check('☰ 能打开尺寸面板', Boolean(root.querySelector('.dsf-panel')))
const panelEl = root.querySelector('.dsf-panel')
const autoBtn = panelEl ? panelEl.querySelector('.dsf-btn-on') : null
check('面板有自动缩放开关', Boolean(autoBtn && /自动缩放/.test(autoBtn.textContent || '')), 'text=' + (autoBtn && autoBtn.textContent))
const closeBtn = root.querySelector('.dsf-x')
if (closeBtn) { closeBtn.dispatchEvent({ type: 'click', stopPropagation() {} }); await wait(30) }
check('面板可关闭', !root.querySelector('.dsf-panel'))

check('没有运行时错误', errors.length === 0, errors.slice(0, 3).join(' | '))

// 收尾：清掉定时器，避免假环境里空转
intervals.forEach((id) => clearInterval(id))
timers.forEach((id) => clearTimeout(id))

console.log('\n' + (failures.length === 0 ? '全部通过 ✅' : failures.length + ' 项失败 ❌'))
process.exit(failures.length === 0 ? 0 : 1)
