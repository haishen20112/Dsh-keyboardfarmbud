"""从星露谷素材包里裁出小农场用到的「精灵条」，并生成 assets/sprites/index.json。

    python3 assets/extract.py [素材包解压目录]

素材包目录默认取环境变量 SV_PACK，再退回 /tmp/sv2/<中文长目录>。
输出到 assets/sprites/：
  * 每个精灵一条水平动画条 PNG（帧等宽）
  * index.json：每个精灵的 帧宽/帧高/帧数/名称/用途

为什么按「条」裁：浏览器里只要 `background-position: -frame*fw px 0` 就能取帧，
不需要任何二维坐标表，也就不会出现上一版那种「帧错位」。
"""
import json
import os
import sys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'sprites')
SUB = 'PNG游戏素材星露谷物语StardewValley像素风场景道具图标角色立绘'

def resolve_pack():
    for cand in (sys.argv[1] if len(sys.argv) > 1 else None,
                 os.environ.get('SV_PACK'),
                 '/tmp/sv2/' + SUB):
        if cand and os.path.isdir(cand):
            return cand
    raise SystemExit('找不到素材包目录：请传入参数或设置 SV_PACK')

PACK = resolve_pack()
os.makedirs(OUT, exist_ok=True)
meta = {}

def strip(name, rel, box, cell_w, cell_h, frames, note=''):
    """按 (x0,y0) 起点水平取 frames 帧，拼成一条 PNG。"""
    img = Image.open(os.path.join(PACK, rel)).convert('RGBA')
    x0, y0 = box
    out = Image.new('RGBA', (cell_w * frames, cell_h), (0, 0, 0, 0))
    for i in range(frames):
        out.alpha_composite(img.crop((x0 + i * cell_w, y0, x0 + (i + 1) * cell_w, y0 + cell_h)), (i * cell_w, 0))
    out.save(os.path.join(OUT, name + '.png'))
    meta[name] = {'w': cell_w, 'h': cell_h, 'frames': frames, 'note': note}

# ---------------- 房子 / 牧场建筑 ----------------
strip('house', 'Buildings/houses..png', (0, 0), 144, 160, 1, '初始小屋（houses.png 左上）')
strip('barn', 'Buildings/Barn..png', (0, 0), 112, 128, 1, '谷仓')
strip('coop', 'Buildings/Coop..png', (0, 0), 96, 128, 1, '鸡舍')
strip('silo', 'Buildings/Silo..png', (0, 0), 48, 128, 1, '筒仓')
strip('well', 'Buildings/Well..png', (0, 0), 48, 80, 1, '水井')

# ---------------- 农夫（Abigail，4 方向 × 4 帧走路） ----------------
# 行：0=朝下 1=朝右 2=朝上 3=朝左（已逐帧核对）
for row, name in ((0, 'down'), (1, 'right'), (2, 'up'), (3, 'left')):
    strip('farmer_' + name, 'Characters/Abigail..png', (0, row * 32), 16, 32, 4, '农夫朝' + name)

# ---------------- 牲畜（全部取第 1 行：侧面 4 帧走路） ----------------
for name, rel, cell in (
    ('chicken', 'Animals/White Chicken..png', 16),
    ('duck', 'Animals/Duck..png', 16),
    ('rabbit', 'Animals/Rabbit..png', 16),
    ('cow', 'Animals/Brown Cow..png', 32),
    ('sheep', 'Animals/Sheep..png', 32),
    ('pig', 'Animals/Pig..png', 32),
    ('goat', 'Animals/Goat..png', 32),
    ('cat', 'Animals/cat..png', 32),
):
    strip(name, rel, (0, cell), cell, cell, 4, '侧面走路 4 帧')

# ---------------- 作物（crops.png：每行两种作物，各 5 个生长阶段） ----------------
# 取第 0/1/3/4 阶段做 4 帧：种子 → 发芽 → 成长 → 成熟
CROPS = [
    # (key, 中文名, 行, 起始列)
    ('cauliflower', '花椰菜', 1, 0),
    ('blueberry', '蓝莓', 3, 0),
    ('potato', '土豆', 3, 8),
    ('corn', '玉米', 5, 0),
    ('tomato', '番茄', 7, 0),
    ('radish', '萝卜', 7, 8),
    ('melon', '甜瓜', 9, 8),
    ('wheat', '小麦', 11, 8),
    ('cabbage', '甘蓝', 13, 0),
    ('eggplant', '茄子', 13, 8),
    ('pumpkin', '南瓜', 19, 0),
    ('spinach', '菠菜', 11, 0),
]
STAGES = [0, 1, 3, 4]  # 在 5 阶段里取哪 4 个
crop_meta = {}
crops_img = Image.open(os.path.join(PACK, 'TileSheets/crops..png')).convert('RGBA')
for key, cn, row, col0 in CROPS:
    out = Image.new('RGBA', (16 * len(STAGES), 16), (0, 0, 0, 0))
    for i, stage in enumerate(STAGES):
        box = (col0 + stage, row)
        out.alpha_composite(crops_img.crop((box[0] * 16, box[1] * 16, box[0] * 16 + 16, box[1] * 16 + 16)), (i * 16, 0))
    fn = 'crop_' + key
    out.save(os.path.join(OUT, fn + '.png'))
    meta[fn] = {'w': 16, 'h': 16, 'frames': len(STAGES), 'note': '作物：' + cn}
    crop_meta[key] = cn

# ---------------- 环境装饰（星露谷户外瓷砖表里的树/水井/筒仓） ----------------
strip('tree_a', 'spring_outdoorsTileSheet..png', (0, 0), 48, 96, 1, '大树 A')
strip('tree_b', 'spring_outdoorsTileSheet..png', (96, 0), 48, 96, 1, '大树 B')
strip('tree_c', 'spring_outdoorsTileSheet..png', (144, 0), 48, 112, 1, '松树 C')
strip('silo_small', 'Buildings/Silo..png', (0, 0), 48, 128, 1, '筒仓（牧场装饰）')

# ---------------- 土地 ----------------
strip('dirt', 'TerrainFeatures/hoeDirt..png', (0, 0), 16, 16, 1, '耕地土块')

with open(os.path.join(OUT, 'index.json'), 'w', encoding='utf-8') as f:
    json.dump({'sprites': meta, 'crops': crop_meta}, f, ensure_ascii=False, indent=1)

total = sum(os.path.getsize(os.path.join(OUT, n + '.png')) for n in meta)
print('精灵条 %d 个，共 %d 字节 → %s' % (len(meta), total, OUT))
print('作物:', ', '.join(crop_meta.values()))
