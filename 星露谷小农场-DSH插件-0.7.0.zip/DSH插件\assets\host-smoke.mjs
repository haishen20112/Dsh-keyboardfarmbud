/**
 * 宿主待办水合冒烟测试（不启动 DSH）：
 *   node assets/host-smoke.mjs
 *
 * 覆盖两条路：
 *   1. sessionQuery.readSession 里最后一条 todo/write（权威）
 *   2. session_projcache 的 todos 投影（离线/老宿主兜底）
 */
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { apply } from '../index.js'

const checks = []
const check = (name, ok, detail) => {
  checks.push({ name, ok: !!ok })
  console.log((ok ? '✅' : '❌') + ' ' + name + (ok || detail === undefined ? '' : ' :: ' + detail))
}
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

function makeCtx({ sessionQuery = null, account = null } = {}) {
  const routes = {}
  const ctx = {
    get(name) {
      if (name === 'sessionQuery') return sessionQuery
      if (name === 'deepseekAccount') return account
      if (name === 'agents') return null
      if (name === 'credentials') return null
      return null
    },
    on() { return () => {} },
    off() {},
    effect(fn) { try { fn() } catch { /* 忽略 */ } },
    webServer: {
      register(route) { routes[route.path] = route; return () => {} },
      tapIndex() { return () => {} },
    },
  }
  return { ctx, routes }
}

async function readState(routes) {
  let body = ''
  const res = { writeHead() {}, end(value) { body = String(value || '') }, write() {} }
  await routes['/dsh-stardew/api/state'].handler({}, res)
  return JSON.parse(body)
}

// ---- 1. 权威日志 ----
{
  const sessionQuery = {
    async listSessions() {
      return [{ header: { id: 'session-hydrate' }, live: true, persisted: true }]
    },
    async readSession() {
      return {
        events: [
          { type: 'turn/start', seq: 1, time: Date.now() },
          { type: 'todo/write', seq: 2, time: Date.now(), data: { todos: [{ content: '旧任务', status: 'completed' }] } },
          { type: 'todo/write', seq: 9, time: Date.now(), data: { todos: [{ content: '水合出来的任务', status: 'in_progress' }, { content: '第二条', status: 'pending' }] } },
        ],
      }
    },
  }
  const { ctx, routes } = makeCtx({ sessionQuery })
  apply(ctx)
  await wait(300)
  const state = await readState(routes)
  const todos = state.sessions && state.sessions[0] && state.sessions[0].todos
  check('sessionQuery 水合出最后一条 todo/write', Array.isArray(todos) && todos.length === 2
    && todos[0].content === '水合出来的任务' && todos[0].status === 'in_progress', JSON.stringify(todos))
  check('水合后 activeSessionId 指向该会话', state.activeSessionId === 'session-hydrate', state.activeSessionId)
}

// ---- 2. 投影缓存兜底 ----
{
  const home = await mkdtemp(join(tmpdir(), 'dsf-host-'))
  process.env.DSH_HOME = home
  const dir = join(home, 'storages', 'session_projcache', 'sessions')
  await mkdir(dir, { recursive: true })
  await writeFile(join(dir, 'session-proj.json'), JSON.stringify({
    version: 7,
    record: {
      rows: {
        todos: { ver: 2, seq: 12, val: [{ content: '投影里的任务', status: 'pending' }] },
      },
    },
  }), 'utf8')
  const { ctx, routes } = makeCtx({ sessionQuery: null })
  apply(ctx)
  await wait(300)
  const state = await readState(routes)
  const todos = state.sessions && state.sessions[0] && state.sessions[0].todos
  check('投影缓存兜底水合待办', Array.isArray(todos) && todos.length === 1 && todos[0].content === '投影里的任务',
    JSON.stringify(todos))
  await rm(home, { recursive: true, force: true })
}

console.log('\n' + (checks.every((item) => item.ok) ? '全部通过 ✅' : checks.filter((item) => !item.ok).length + ' 项失败 ❌'))
process.exit(checks.every((item) => item.ok) ? 0 : 1)
