/*!
 * dsh-stardew-farm —— 页面脚本（自包含：样式、位图字体与精灵图都由构建内联）
 *
 * v0.7：全面换成 FarmLife / SunnysideWorld 素材
 *   · 26 块 A–Z 固定地 + 11 种真实 FarmLife 作物（6 帧，成熟映射 0/2/4/5）
 *   · 小人：走路 → 到位 → 完整干活动作 → 开心表情 1 秒 → 下一块地
 *   · 帮手：解锁后像小人一样独立选地、走路、干活、推进作物，不再只跟着小人
 *   · 待办：SSE 实时 + 宿主启动时水合；当前项高亮，点击可选中
 *   · 气泡：按农场容器边界自动限宽/夹紧位置，不会越界
 *   · 字体：ASCII 用素材包 8×10 位图字库，中文继续系统字体
 */
(function () {
  'use strict'
  if (window.__dshStardewFarm) return
  window.__dshStardewFarm = true

  var VERSION = '0.7.0'
  var PREFIX = '/dsh-stardew'
  var LS_KEY = 'dsh-stardew-farm:v5'
  var LS_KEY_V4 = 'dsh-stardew-farm:v4'
  var DESKTOP = !!window.__DSF_DESKTOP__
  var GLOBAL_KEYS = !!window.__DSF_GLOBAL_KEYS__

  var DSF_CSS = __DSF_CSS_JSON__
  var SPRITES = __DSF_SPRITES_JSON__
  var CROPS = __DSF_CROPS_JSON__
  var FONT = __DSF_FONT_JSON__

  // ------------------------------------------------------------------
  // 小工具
  // ------------------------------------------------------------------
  function $(sel, scope) { return (scope || document).querySelector(sel) }
  function h(tag, attrs, children) {
    var el = document.createElement(tag)
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k]
      if (v === undefined || v === null || v === false) return
      if (k === 'style' && typeof v === 'object') Object.assign(el.style, v)
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v)
      else if (k === 'text') el.textContent = v
      else el.setAttribute(k, v === true ? '' : String(v))
    })
    if (children) [].concat(children).forEach(function (c) {
      if (c === null || c === undefined || c === false) return
      el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c)
    })
    return el
  }
  function sprite(name, frame) {
    var meta = SPRITES[name]
    var box = h('div', { class: 'dsf-spr' })
    if (!meta) return box
    box.style.width = meta.w + 'px'
    box.style.height = meta.h + 'px'
    box.style.backgroundImage = "url('" + meta.src + "')"
    box.style.backgroundPosition = (-(frame || 0) * meta.w) + 'px 0px'
    return box
  }
  function setFrame(el, name, frame) {
    var meta = SPRITES[name]
    if (!meta || !el) return
    if (el.__spriteName !== name) {
      el.__spriteName = name
      el.style.backgroundImage = "url('" + meta.src + "')"
      el.style.width = meta.w + 'px'
      el.style.height = meta.h + 'px'
    }
    el.style.backgroundPosition = (-(frame || 0) * meta.w) + 'px 0px'
  }
  function ico(name) {
    return h('span', { class: 'dsf-ico dsf-ico-' + name })
  }
  /** 土地格子：直接使用 SunnysideWorld 的方形 / 圆形泥土贴图（按地块奇偶交替）。 */
  function dirtEl(cls, w, hgt, round) {
    var el = h('div', { class: 'dsf-spr ' + (cls || '') })
    var meta = SPRITES[round ? 'dirt_patch_round' : 'dirt_patch'] || SPRITES.soil
    if (!meta) return el
    el.style.backgroundImage = "url('" + meta.src + "')"
    el.style.backgroundRepeat = 'no-repeat'
    el.style.backgroundSize = '100% 100%'
    el.style.width = w + 'px'
    el.style.height = hgt + 'px'
    return el
  }
  function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v }
  function rand(lo, hi) { return lo + Math.random() * (hi - lo) }
  function pad2(n) { return n < 10 ? '0' + n : '' + n }
  function todayKey() { var d = new Date(); return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) }
  function clampText(s, n) { s = String(s || ''); return s.length > n ? s.slice(0, n - 1) + '…' : s }
  function fmtShort(sec) {
    sec = Math.max(0, Math.round(Number(sec) || 0))
    if (sec >= 3600) return Math.floor(sec / 3600) + 'h' + pad2(Math.floor(sec % 3600 / 60)) + 'm'
    if (sec >= 60) return Math.floor(sec / 60) + 'm' + pad2(sec % 60) + 's'
    return sec + 's'
  }
  function fmtLong(sec) {
    sec = Math.max(0, Math.round(Number(sec) || 0))
    var hh = Math.floor(sec / 3600)
    var mm = Math.floor(sec % 3600 / 60)
    var ss = sec % 60
    if (hh) return hh + ' 小时 ' + mm + ' 分'
    if (mm) return mm + ' 分 ' + ss + ' 秒'
    return ss + ' 秒'
  }

  function hashKey(name) {
    var hash = 2166136261
    for (var i = 0; i < name.length; i++) {
      hash ^= name.charCodeAt(i)
      hash = Math.imul(hash, 16777619)
    }
    return Math.abs(hash)
  }
  var LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')
  var PLOT_COUNT = 26
  var KEY_ROWS = [
    ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
    ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
    ['Z', 'X', 'C', 'V', 'B', 'N', 'M'],
  ]
  var CONTROL_KEY = /^(F\d{1,2}|Enter|Backspace|Escape|Delete|Insert|Home|End|PageUp|PageDown|ArrowLeft|ArrowRight|ArrowUp|ArrowDown|Shift|Control|Alt|Meta|CapsLock|NumLock|ScrollLock|Tab|ContextMenu|OS|Fn|Process|Unidentified|Dead|Spacebar|NumpadEnter)$/

  /** 把任意可打印输入落到 A–Z：字母直接映射，中文/符号按哈希。控制键忽略。 */
  function letterForKey(raw) {
    var s = String(raw === undefined || raw === null ? '' : raw)
    if (!s) return null
    if (s.length === 1) {
      var up = s.toUpperCase()
      if (up >= 'A' && up <= 'Z') return up
      if (s === ' ' || s === '\n' || s === '\t' || s === '\r') return null
      if (s.charCodeAt(0) < 32) return null
      return LETTERS[hashKey(s) % PLOT_COUNT]
    }
    if (s.length > 4) return null
    if (CONTROL_KEY.test(s)) return null
    if (/^[a-z]$/i.test(s)) return s.toUpperCase()
    return LETTERS[hashKey(s) % PLOT_COUNT]
  }
  function cropForLetter(letter) { return CROPS[hashKey(String(letter)) % CROPS.length] }
  function plotIndex(letter) { return LETTERS.indexOf(String(letter || '').toUpperCase()) }
  /** 3 次成熟映射到素材的 6 帧：0 → 0，1 → 2，2 → 4，收割瞬间 → 5。 */
  function cropFrame(stage, harvesting) {
    if (harvesting) return 5
    if (stage >= 3) return 4
    if (stage === 2) return 2
    return 0
  }

  // ------------------------------------------------------------------
  // 位图字体：素材包 8×10 字库只覆盖 ASCII，中文继续用系统字体
  // ------------------------------------------------------------------
  var FONT_CHARS = (FONT && FONT.chars) || ''
  var FONT_COLS = (FONT && FONT.cols) || 10
  var FONT_CW = (FONT && FONT.cw) || 8
  var FONT_CH = (FONT && FONT.ch) || 10
  var FONT_BLACK = (FONT && FONT.black) || 'font_black'
  var FONT_WHITE = (FONT && FONT.white) || 'font_white'

  function glyphIndex(ch) {
    var i = FONT_CHARS.indexOf(String(ch).toUpperCase())
    return i
  }
  function appendBText(parent, text, opts) {
    opts = opts || {}
    var meta = SPRITES[opts.white ? FONT_WHITE : FONT_BLACK]
    var str = String(text === undefined || text === null ? '' : text)
    var lastText = null
    for (var i = 0; i < str.length;) {
      var code = str.codePointAt(i)
      var ch = String.fromCodePoint(code)
      i += ch.length
      // emoji 的变体选择符（U+FE0F / U+FE0E）跟着前一个字符走，不能单独成格
      if (code === 0xFE0F || code === 0xFE0E) {
        if (lastText) lastText.textContent = (lastText.textContent || '') + ch
        continue
      }
      if (ch === '\n') {
        var br = h('br')
        br.textContent = '\n'
        parent.appendChild(br)
        lastText = null
        continue
      }
      if (ch === ' ') {
        var space = h('span', { class: 'dsf-glyph-space' })
        space.textContent = ' '
        parent.appendChild(space)
        lastText = space
        continue
      }
      var idx = glyphIndex(ch)
      if (idx < 0 || !meta) {
        var cjk = h('span', { class: 'dsf-cjk' }, ch)
        parent.appendChild(cjk)
        lastText = cjk
        continue
      }
      var g = h('span', { class: 'dsf-glyph' })
      // 真正的字形是背景图；保留透明文本给读屏、复制与测试使用
      g.textContent = ch
      g.style.backgroundImage = "url('" + meta.src + "')"
      g.style.backgroundPosition = (-(idx % FONT_COLS) * FONT_CW) + 'px ' + (-Math.floor(idx / FONT_COLS) * FONT_CH) + 'px'
      parent.appendChild(g)
      lastText = g
    }
  }
  function btext(text, opts) {
    var el = h('span', { class: 'dsf-btext' + (opts && opts.class ? ' ' + opts.class : '') })
    appendBText(el, text, opts)
    return el
  }
  function setBText(el, text, opts) {
    if (!el) return
    el.innerHTML = ''
    appendBText(el, text, opts)
  }

  // ------------------------------------------------------------------
  // 存档（v5：26 块固定地）
  // ------------------------------------------------------------------
  var COIN_PER_MINUTE = 6
  var HARVEST_COINS = 4
  var KEY_PER_HARVEST = 3
  var HELPER_EVERY = 300
  var HELPER_MAX = 4
  var HELPER_IDLE_RESET = 900
  var DESIGN_W = 300
  var DESIGN_H = 370
  // 农场容器：7×4 格；前 21 格铺满前三行，第四行 5 格居中，左右两个空格放水塘和记录员
  var FIELD = { w: 262, h: 166, x0: 10, y0: 18, dx: 36, dy: 36, cell: 32 }

  function makePlots() {
    return LETTERS.map(function (letter) { return { key: letter, stage: 0, harvestAt: 0 } })
  }

  var state = {
    day: todayKey(),
    coins: 0,
    farmSeconds: 0,
    onlineSeconds: 0,
    keys: {},
    plots: makePlots(),
    helpers: 0,
    helperSeconds: 0,
    lastWorkAt: 0,
    todos: [],
    selectedTask: -1,
    selectedTaskKey: '',
    busy: false,
    turns: 0,
    settings: { scale: 1.5, position: 'bottom-left', collapsed: false, autoScale: true, tab: 'farm' },
  }

  function normalizeKeys(src) {
    var out = {}
    if (!src || typeof src !== 'object') return out
    Object.keys(src).forEach(function (raw) {
      var letter = letterForKey(raw)
      if (!letter) return
      var r = src[raw]
      if (!r) return
      var rec = out[letter] || (out[letter] = { n: 0, harvests: 0, name: cropForLetter(letter).name, lastRaw: '' })
      rec.n = Math.max(rec.n, Number(r.n) || 0)
      rec.harvests = Math.max(rec.harvests, Number(r.harvests) || 0)
      if (r.name) rec.name = String(r.name)
      if (r.lastRaw) rec.lastRaw = String(r.lastRaw)
    })
    return out
  }

  function applyPlots(list) {
    if (!Array.isArray(list) || !list.length) return false
    var next = makePlots()
    var used = false
    if (list.length === PLOT_COUNT) {
      list.forEach(function (p, i) {
        if (!p) return
        next[i].stage = clamp(Math.floor(Number(p.stage) || 0), 0, 3)
        next[i].harvestAt = 0
        used = true
      })
    } else {
      list.forEach(function (p) {
        if (!p) return
        var letter = letterForKey(p.key)
        var idx = plotIndex(letter)
        if (idx < 0) return
        next[idx].stage = clamp(Math.floor(Number(p.stage) || 0), 0, 3)
        next[idx].harvestAt = 0
        used = true
      })
    }
    if (used) state.plots = next
    return used
  }

  var saveTimer = null
  function serialize() {
    return {
      v: 5, day: state.day, coins: state.coins, farmSeconds: state.farmSeconds,
      onlineSeconds: state.onlineSeconds, keys: state.keys,
      helpers: state.helpers, helperSeconds: state.helperSeconds, lastWorkAt: state.lastWorkAt,
      plots: state.plots.map(function (p) { return { key: p.key, stage: p.stage } }),
      settings: state.settings, turns: state.turns,
    }
  }
  function persist() {
    try { localStorage.setItem(LS_KEY, JSON.stringify(serialize())) } catch (e) { /* 忽略 */ }
    if (saveTimer) return
    saveTimer = setTimeout(function () {
      saveTimer = null
      fetch(PREFIX + '/api/mutate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: serialize() }),
      }).catch(function () { /* 宿主不可达也不影响本地 */ })
    }, 1000)
  }

  function loadLocal() {
    var raw = null
    try { raw = localStorage.getItem(LS_KEY) } catch (e) { raw = null }
    if (!raw) {
      try { raw = localStorage.getItem(LS_KEY_V4) } catch (e) { raw = null }
    }
    if (!raw) return
    try {
      var d = JSON.parse(raw)
      if (!d) return
      if (d.day !== state.day) {
        state.coins = Math.max(state.coins, Number(d.coins) || 0)
        return
      }
      state.coins = Math.max(state.coins, Number(d.coins) || 0)
      state.farmSeconds = Number(d.farmSeconds) || 0
      state.onlineSeconds = Number(d.onlineSeconds) || 0
      state.helpers = clamp(Math.floor(Number(d.helpers) || 0), 0, HELPER_MAX)
      state.helperSeconds = clamp(Number(d.helperSeconds) || 0, 0, HELPER_EVERY)
      state.lastWorkAt = Number(d.lastWorkAt) || 0
      if (state.lastWorkAt && Date.now() - state.lastWorkAt > HELPER_IDLE_RESET * 1000) {
        state.helpers = 0
        state.helperSeconds = 0
        state.lastWorkAt = 0
      }
      state.keys = normalizeKeys(d.keys)
      applyPlots(d.plots)
      if (d.settings && typeof d.settings === 'object') Object.assign(state.settings, d.settings)
      if (typeof d.turns === 'number') state.turns = d.turns
    } catch (e) { /* 坏档当新的一天 */ }
  }

  function rollover() {
    var today = todayKey()
    if (today === state.day) return
    state.day = today
    state.farmSeconds = 0
    state.onlineSeconds = 0
    state.keys = {}
    state.plots = makePlots()
    state.selectedTask = -1
    state.selectedTaskKey = ''
    typingUntil = 0
    workUntil = 0
    actionQueue.length = 0
    claims = {}
    clearHelperJobs()
    persist()
    say('新的一天！昨天的收成入库了', 3200, 1)
    renderKeys(); renderPlots(); renderHeader(); renderUsageView()
  }

  /** 服务端存档是跨浏览器/桌面端的权威副本；同一天时合并进当前状态。 */
  function applySnapshot(d) {
    if (!d) return false
    if (Number.isFinite(Number(d.coins))) state.coins = Math.max(state.coins, Number(d.coins))
    if (d.day !== state.day) { renderHeader(); return false }
    if (Number.isFinite(Number(d.farmSeconds))) state.farmSeconds = Math.max(state.farmSeconds, Number(d.farmSeconds))
    if (Number.isFinite(Number(d.onlineSeconds))) state.onlineSeconds = Math.max(state.onlineSeconds, Number(d.onlineSeconds))
    if (Number.isFinite(Number(d.helpers))) state.helpers = clamp(Math.max(state.helpers, Math.floor(Number(d.helpers))), 0, HELPER_MAX)
    if (Number.isFinite(Number(d.helperSeconds))) state.helperSeconds = Math.max(state.helperSeconds, Number(d.helperSeconds))
    if (Number.isFinite(Number(d.lastWorkAt))) state.lastWorkAt = Math.max(state.lastWorkAt, Number(d.lastWorkAt))
    var remoteKeys = normalizeKeys(d.keys)
    Object.keys(remoteKeys).forEach(function (letter) {
      var local = state.keys[letter]
      if (!local) { state.keys[letter] = remoteKeys[letter]; return }
      local.n = Math.max(local.n || 0, remoteKeys[letter].n || 0)
      local.harvests = Math.max(local.harvests || 0, remoteKeys[letter].harvests || 0)
      if (!local.name) local.name = remoteKeys[letter].name
    })
    applyPlots(d.plots)
    if (d.settings && typeof d.settings === 'object') Object.assign(state.settings, d.settings)
    if (typeof d.turns === 'number') state.turns = d.turns
    renderHeader(); renderPlots(); renderKeys(); renderTasksView(); renderUsageView(); applySettings()
    return true
  }

  // ------------------------------------------------------------------
  // 气泡 / 粒子 / 忙碌判定
  // ------------------------------------------------------------------
  var bubbleEl = null
  var bubbleText = ''
  var bubbleUntil = 0
  var sparks = []
  var sparksLayer = null
  var typingUntil = 0
  var workUntil = 0
  var clerkWorkUntil = 0
  var lastTypingBubbleAt = 0
  var lastFarmBubbleAt = 0
  var workBubbleUntil = 0
  var lookTimer = 0

  function say(text, ms, priority) {
    var p = Number(priority) || 0
    var now = Date.now()
    if (now < workBubbleUntil && p < 2) return false
    if (p >= 2) workBubbleUntil = 0
    bubbleText = String(text || '')
    bubbleUntil = now + (ms || 3000)
    renderBubble()
    return true
  }

  function sayWork(text, ms) {
    var now = Date.now()
    workBubbleUntil = now + (ms || 3000)
    bubbleText = String(text || '')
    bubbleUntil = workBubbleUntil
    renderBubble()
  }
  function sparkle(x, y) { sparks.push({ x: x, y: y, life: 1 }) }

  function renderSparks() {
    if (!sparksLayer) return
    while (sparksLayer.firstChild) sparksLayer.removeChild(sparksLayer.firstChild)
    sparks = sparks.filter(function (s) { s.life -= 0.06; return s.life > 0 })
    sparks.forEach(function (s) {
      var el = h('div', { class: 'dsf-spark' }, '✦')
      el.style.left = Math.round(s.x - 4) + 'px'
      el.style.top = Math.round(s.y - 8 - (1 - s.life) * 10) + 'px'
      el.style.opacity = String(clamp(s.life, 0, 1))
      sparksLayer.appendChild(el)
    })
  }

  function workingNow() {
    if (host.busy || host.harness) return true
    if (Date.now() < typingUntil || Date.now() < workUntil) return true
    var app = host.workApp || (host.usage && host.usage.current)
    return !!(app && !app.ignored)
  }

  // ------------------------------------------------------------------
  // 宿主状态（SSE 推送）
  // ------------------------------------------------------------------
  var host = {
    ready: false, busy: false, attention: null, todos: [], activeId: null,
    lastAssistant: null, usage: null, workApp: null, harness: false,
    harnessNames: [], source: 'dsh', totalPending: 0, todosFallback: false,
  }
  var lastAttentionKey = ''
  var lastBusy = false
  var lastHarness = false
  var lastSwitchAt = 0
  var lastTaskKey = ''
  var taskInitialized = false
  var introShown = false
  var headerCoins = null
  var headerCoinsText = null
  var lastStatusKey = ''
  var lastUsageKey = ''

  function applyHostState(payload) {
    if (!payload || payload.ok !== true) return
    host.ready = true
    var nextActive = payload.activeSessionId || null
    if (nextActive !== host.activeId) {
      taskInitialized = false
      lastTaskKey = ''
      host.todos = []
    }
    host.activeId = nextActive
    var sessions = Array.isArray(payload.sessions) ? payload.sessions : []
    var active = null
    for (var i = 0; i < sessions.length; i++) {
      if (sessions[i].id === host.activeId) { active = sessions[i]; break }
    }
    if (!active && sessions.length) active = sessions[0]

    host.harness = !!payload.harness
    host.harnessNames = Array.isArray(payload.harnessNames) ? payload.harnessNames : []
    host.source = String(payload.source || 'dsh')
    var nextName = String(payload.userName || '').trim().slice(0, 16)
    if (nextName !== hostUserName) {
      hostUserName = nextName
      renderFarmTitle()
    }
    host.usage = payload.usage && typeof payload.usage === 'object' ? payload.usage : null
    host.workApp = payload.workApp && typeof payload.workApp === 'object'
      ? payload.workApp
      : (host.usage && host.usage.current ? host.usage.current : null)
    host.totalPending = Number(payload.totalPending) || 0

    if (active) {
      host.busy = !!active.busy || !!host.harness
      host.lastAssistant = active.lastAssistant || null
      // 当前会话还没写过 todo/write（null）时，退回最近一轮有待办的会话；
      // 如果它是明确的空数组，说明用户清空了待办，不要拿旧会话的待办回来。
      var todoSession = active
      var fallback = false
      if (todoSession && todoSession.todos === null) {
        for (var s = 0; s < sessions.length; s++) {
          if (Array.isArray(sessions[s].todos) && sessions[s].todos.length) {
            todoSession = sessions[s]
            fallback = true
            break
          }
        }
      }
      if (todoSession && Array.isArray(todoSession.todos)) {
        host.todos = todoSession.todos.map(function (t) {
          return { content: clampText(t.content, 200), status: String(t.status || 'pending') }
        }).filter(function (t) { return t.content })
        host.todosFallback = fallback && todoSession.id !== active.id
        noteTaskSwitch(host.todos)
        renderPlots()
        renderTasksView()
      } else if (active) {
        host.todos = []
        host.todosFallback = false
        renderTasksView()
      }
    } else {
      host.busy = !!host.harness
    }

    state.attention = payload.attention || null
    var key = state.attention ? (state.attention.kind + '|' + state.attention.at + '|' + state.attention.text) : ''
    if (state.attention && key !== lastAttentionKey) {
      lastAttentionKey = key
      lookTimer = 9
      say('老乡，有个事要你处理…\n' + clampText(state.attention.text, 40), 9000, 3)
      renderBadge()
    }
    if (!state.attention) { lastAttentionKey = ''; renderBadge() }

    var current = host.usage && host.usage.current
    var switchAt = Number(current && (current.switchedAt || current.since)) || Number(host.workApp && host.workApp.at) || 0
    if (switchAt && switchAt !== lastSwitchAt) {
      lastSwitchAt = switchAt
      if (!(current && current.ignored)) {
        workUntil = Date.now() + 3000
        clerkWorkUntil = Date.now() + 3000
        sayWork('工作中', 3000)
      }
    }

    if (host.harness && !lastHarness) {
      if (!bubbleText) say('检测到 harness，开工！', 3000, 2)
      workUntil = Date.now() + 3000
    }
    lastHarness = host.harness

    if (lastBusy && !host.busy) {
      lookTimer = Math.max(lookTimer, 3)
      var tip = host.lastAssistant && host.lastAssistant.text ? clampText(host.lastAssistant.text, 36) : ''
      say(tip ? '这轮忙完啦：' + tip : '这轮忙完啦，来看看结果～', 4200, 2)
    }
    lastBusy = host.busy
    state.busy = host.busy

    if (!introShown && host.todos.length) {
      introShown = true
      setTimeout(showIntro, 400)
    }
    renderHeader()
    renderUsageView()
  }

  /** 当前任务从「进行中」换到下一项时，小人提醒老乡。 */
  function noteTaskSwitch(todos) {
    var current = null
    for (var i = 0; i < todos.length; i++) {
      if (todos[i].status === 'in_progress') { current = todos[i]; break }
    }
    if (!current) {
      for (var j = 0; j < todos.length; j++) {
        if (todos[j].status !== 'completed') { current = todos[j]; break }
      }
    }
    var key = current ? (current.status + '|' + current.content) : ''
    if (!taskInitialized) {
      taskInitialized = true
      lastTaskKey = key
      return
    }
    if (key && key !== lastTaskKey) {
      lookTimer = Math.max(lookTimer, 3.2)
      say('老乡，我该做下一步了\n' + clampText(current.content, 30), 4200, 2)
    }
    lastTaskKey = key
  }

  function pollState() {
    fetch(PREFIX + '/api/state', { cache: 'no-store' })
      .then(function (r) { return r.json() })
      .then(applyHostState)
      .catch(function () { /* 宿主重启中 */ })
  }

  /** SSE 推送：待办/忙碌/提问/软件切换一发生就推；断线才退回 1 秒轮询。 */
  var sse = null
  var sseRetry = 0
  var fallbackTimer = null
  function startStream() {
    if (typeof EventSource !== 'function') { startFallback(); return }
    try {
      sse = new EventSource(PREFIX + '/api/events')
    } catch (e) { startFallback(); return }
    sse.onmessage = function (event) {
      sseRetry = 0
      try { applyHostState(JSON.parse(event.data)) } catch (e) { /* 坏帧忽略 */ }
    }
    sse.onerror = function () {
      sseRetry += 1
      if (sseRetry > 6) {
        try { sse.close() } catch (e) {}
        sse = null
        startFallback()
      }
    }
  }
  function startFallback() {
    if (fallbackTimer) return
    pollState()
    fallbackTimer = setInterval(function () { if (!document.hidden) pollState() }, 1000)
  }

  // ------------------------------------------------------------------
  // 玩法：26 块固定地
  // ------------------------------------------------------------------
  function onKey(raw) {
    rollover()
    var letter = letterForKey(raw)
    if (!letter) return
    var now = Date.now()
    typingUntil = now + 3000
    if (now > lastTypingBubbleAt + 1400 || !bubbleText) {
      lastTypingBubbleAt = now
      say('干活中', 3000, 1)
    }
    var crop = cropForLetter(letter)
    var rec = state.keys[letter] || (state.keys[letter] = { n: 0, harvests: 0, name: crop.name, lastRaw: '' })
    rec.n += 1
    rec.name = crop.name
    rec.lastRaw = String(raw)
    rec.lastAt = now

    var idx = plotIndex(letter)
    var plot = state.plots[idx]
    if (!plot) return
    if (plot.harvestAt) { renderKeys(); renderPlots(); persist(); return }
    if (plot.stage >= 3) {
      harvestPlot(idx, 'manual')
    } else {
      plot.stage = clamp(plot.stage + 1, 0, 3)
      if (plot.stage >= 3) harvestPlot(idx, 'manual')
      else {
        sparkleAtPlot(idx)
        enqueueAction(idx, 'visit', false)
      }
    }
    renderKeys(); renderPlots(); renderHeader(); renderUsageStats(); persist()
  }

  /** 自动劳动到地后推进一阶段；成熟时立刻结算金币。 */
  function advancePlot(idx, source) {
    var plot = state.plots[idx]
    if (!plot || plot.harvestAt) return false
    if (plot.stage >= 3) return harvestPlot(idx, source)
    plot.stage = clamp(plot.stage + 1, 0, 3)
    if (plot.stage >= 3) return harvestPlot(idx, source)
    var crop = cropForLetter(plot.key)
    sparkleAtPlot(idx)
    if (source === 'auto' && Date.now() > lastFarmBubbleAt + 4200) {
      lastFarmBubbleAt = Date.now()
      say('给 ' + crop.name + ' 浇了点水', 1600)
    }
    renderPlots(); renderKeys(); renderHeader(); renderFieldStats(); persist()
    return true
  }

  /** 收割：金币立刻到账，地保留 0.9 秒成熟动画后由 tickHarvest 清空。 */
  function harvestPlot(idx, source) {
    var plot = state.plots[idx]
    if (!plot || plot.harvestAt) return false
    var crop = cropForLetter(plot.key)
    plot.stage = 3
    plot.harvestAt = Date.now() + 900
    state.coins += HARVEST_COINS
    var rec = state.keys[plot.key]
    if (rec) rec.harvests = (rec.harvests || 0) + 1
    if (Date.now() > lastFarmBubbleAt + 1000) {
      lastFarmBubbleAt = Date.now()
      // 手动收割是玩家动作，优先盖过「工作中」这类后台提示
      say('收获 ' + crop.name + ' +' + HARVEST_COINS + ' 金币', 2200, source === 'manual' ? 2 : 0)
    }
    sparkleAtPlot(idx)
    renderPlots(); renderKeys(); renderHeader(); renderFieldStats(); persist()
    return true
  }

  function sparkleAtPlot(idx) {
    var c = plotCenter(idx)
    sparkle(c.x, c.y - 4)
  }

  function plotPos(idx) {
    var col = idx % 7
    var row = Math.floor(idx / 7)
    // 第四行只有 V–Z 五块，往中间挪一格，左右对称各留一个空格
    if (row === 3) col += 1
    return { x: FIELD.x0 + col * FIELD.dx, y: FIELD.y0 + row * FIELD.dy }
  }
  function plotCenter(idx) {
    var pos = plotPos(idx)
    return { x: pos.x + FIELD.cell / 2, y: pos.y + FIELD.cell / 2 }
  }

  // ------------------------------------------------------------------
  // 角色状态机：walk → arrive → act（完整 8 帧）→ happy（1 秒）→ pause
  // ------------------------------------------------------------------
  var ACT_DUR = 0.72
  var HAPPY_DUR = 1.0
  var PAUSE_DUR = 0.14
  var WALK_FRAME = 0.085
  var ACT_FRAME = ACT_DUR / 8
  var IDLE_FRAME = 0.26
  var HAPPY_NAMES = ['expr_happy1', 'expr_happy2', 'expr_happy3', 'expr_happy4']
  var HELPER_NAMES = ['cow', 'goat', 'pig', 'sheep']

  function makeActor(kind, index) {
    return {
      kind: kind, index: index,
      x: 120, y: 160, tx: 120, ty: 160,
      dir: 'down', phase: 'idle', phaseT: 0, frame: 0, frameT: 0,
      moving: false, onArrive: null, job: null, nextAt: 0,
      speed: kind === 'farmer' ? 34 : 30,
      el: null, emoteEl: null, emoteVisible: false,
    }
  }
  var farmer = makeActor('farmer', 0)
  farmer.x = 112; farmer.y = 158; farmer.tx = 112; farmer.ty = 158
  var helperActors = []
  var helperEls = []
  var helpersLayer = null
  var farmerEl = null
  var clerkEl = null
  var clerkLabel = null

  function dirFor(a, dx, dy) {
    if (a.kind === 'helper') {
      if (Math.abs(dx) > 1) return dx > 0 ? 'right' : 'left'
      return a.dir === 'right' || a.dir === 'left' ? a.dir : 'right'
    }
    if (Math.abs(dx) > Math.abs(dy)) return dx > 0 ? 'right' : 'left'
    return dy > 0 ? 'down' : 'up'
  }

  function startJob(a, idx, auto, kind) {
    if (!a || idx < 0 || idx >= PLOT_COUNT) return false
    var c = plotCenter(idx)
    a.job = { idx: idx, auto: !!auto, kind: kind || 'auto' }
    claimPlot(idx, a)
    a.tx = clamp(c.x + rand(-2, 2), 16, FIELD.w - 16)
    a.ty = clamp(c.y + 12, 8, FIELD.h - 10)
    a.dir = dirFor(a, a.tx - a.x, a.ty - a.y)
    a.phase = 'walk'
    a.phaseT = 0
    a.frame = 0
    a.frameT = 0
    a.moving = true
    return true
  }

  function finishAct(a) {
    var job = a.job
    if (job && job.auto && job.idx >= 0 && job.idx < PLOT_COUNT) {
      advancePlot(job.idx, a.kind === 'helper' ? 'helper' : 'auto')
    }
    if (job) releasePlot(job.idx, a)
    a.job = null
    var shown = showEmote(a)
    if (shown) {
      a.phase = 'happy'
      a.phaseT = 0
      a.frame = 0
      a.frameT = 0
    } else {
      a.phase = 'pause'
      a.phaseT = 0
    }
    a.nextAt = Date.now() + (a.kind === 'helper' ? rand(700, 1900) : rand(400, 1000))
  }

  function showEmote(a) {
    if (!a || !a.emoteEl) return false
    var name = a.kind === 'farmer'
      ? HAPPY_NAMES[Math.floor(Math.random() * HAPPY_NAMES.length)]
      : (SPRITES.expr_love ? 'expr_love' : null)
    if (!name || !SPRITES[name]) { a.emoteVisible = false; return false }
    setFrame(a.emoteEl, name, 0)
    a.emoteEl.style.display = 'block'
    a.emoteVisible = true
    return true
  }
  function hideEmote(a) {
    if (!a || !a.emoteEl) return
    a.emoteVisible = false
    a.emoteEl.style.display = 'none'
  }

  function updateActor(a, dt) {
    if (!a) return
    if (a.phase === 'walk') {
      var dx = a.tx - a.x
      var dy = a.ty - a.y
      var dist = Math.sqrt(dx * dx + dy * dy)
      if (dist > 0.5) {
        var step = Math.min(dist, a.speed * dt)
        a.x += dx / dist * step
        a.y += dy / dist * step
        a.moving = true
        // 方向在起步时按整段位移定好，走路过程中不再按单帧 dx/dy 反复翻面
      } else {
        a.x = a.tx
        a.y = a.ty
        a.moving = false
        a.phase = 'act'
        a.phaseT = 0
        a.frame = 0
        a.frameT = 0
        var cb = a.onArrive
        a.onArrive = null
        if (cb) cb()
      }
    } else {
      a.moving = false
    }

    if (a.phase === 'act') {
      a.phaseT += dt
      if (a.phaseT >= ACT_DUR) finishAct(a)
    } else if (a.phase === 'happy') {
      a.phaseT += dt
      if (a.phaseT >= HAPPY_DUR) {
        hideEmote(a)
        a.phase = 'pause'
        a.phaseT = 0
      }
    } else if (a.phase === 'pause') {
      a.phaseT += dt
      if (a.phaseT >= PAUSE_DUR) {
        a.phase = 'idle'
        a.phaseT = 0
        a.frame = 0
        a.frameT = 0
      }
    }

    a.frameT += dt
    var dur = IDLE_FRAME
    var count = 9
    if (a.phase === 'walk') { dur = WALK_FRAME; count = 8 }
    else if (a.phase === 'act') { dur = ACT_FRAME; count = 8 }
    if (a.kind === 'helper') count = 4
    while (a.frameT >= dur) { a.frameT -= dur; a.frame = (a.frame + 1) % count }
  }

  function drawActor(a) {
    if (!a || !a.el) return
    var name
    if (a.kind === 'farmer') {
      if (a.phase === 'walk') name = 'farmer_walk_' + a.dir
      else if (a.phase === 'act') name = 'farmer_act_' + a.dir
      else name = 'farmer_idle_' + a.dir
      setFrame(a.el, name, a.frame % 9)
      // right 精灵已经在素材阶段水平镜像，页面不再翻转；只整体放大一点，跟地块更协调
      a.el.style.transform = 'scale(1.3)'
      a.el.style.left = Math.round(a.x - 32) + 'px'
      a.el.style.top = Math.round(a.y - 30) + 'px'
      a.el.classList.toggle('dsf-acting', a.phase === 'act')
      a.el.classList.toggle('dsf-looking', lookTimer > 0)
    } else {
      name = HELPER_NAMES[a.index]
      setFrame(a.el, name, a.frame % 4)
      a.el.style.transform = a.dir === 'left' ? 'scaleX(-1)' : 'none'
      a.el.style.left = Math.round(a.x - 16) + 'px'
      a.el.style.top = Math.round(a.y - 28) + 'px'
    }
    if (a.emoteEl) {
      a.emoteEl.style.left = Math.round(a.x - 7) + 'px'
      a.emoteEl.style.top = Math.round(a.y - 46) + 'px'
    }
  }

  // 地权：同一块地同时只让一个角色干活，避免小人和帮手抢同一格
  var claims = {}
  function claimPlot(idx, a) {
    var now = Date.now()
    claims[idx] = { by: a, at: now }
  }
  function releasePlot(idx, a) {
    var c = claims[idx]
    if (!c || c.by === a) delete claims[idx]
  }
  function claimedByOther(idx, a) {
    var c = claims[idx]
    if (!c) return false
    if (Date.now() - c.at > 30000) { delete claims[idx]; return false }
    return c.by !== a
  }

  var actionQueue = []
  function enqueueAction(idx, kind, auto) {
    if (idx < 0 || idx >= PLOT_COUNT) return
    var last = actionQueue[actionQueue.length - 1]
    if (last && last.idx === idx && last.kind === kind && !!last.auto === !!auto) return
    actionQueue.push({ idx: idx, kind: kind, auto: !!auto })
    if (actionQueue.length > 8) actionQueue.shift()
  }
  function clearHelperJobs() {
    helperActors.forEach(function (a) {
      if (a.job) releasePlot(a.job.idx, a)
      a.job = null
      a.phase = 'idle'
      a.phaseT = 0
      a.moving = false
      hideEmote(a)
    })
  }

  function processActions() {
    if (farmer.phase !== 'idle' || farmer.moving) return
    if (!actionQueue.length) return
    var item = actionQueue.shift()
    startJob(farmer, item.idx, item.auto, item.kind)
  }

  var harvestCheck = 0
  function tickHarvest(dt) {
    harvestCheck -= dt
    if (harvestCheck > 0) return
    harvestCheck = 1
    var wall = Date.now()
    var changed = false
    state.plots.forEach(function (plot, idx) {
      if (plot.harvestAt && wall >= plot.harvestAt) {
        plot.harvestAt = 0
        plot.stage = 0
        changed = true
      } else if (plot.stage >= 3 && !plot.harvestAt && workingNow()) {
        harvestPlot(idx, 'auto')
        changed = true
      }
    })
    if (changed) { renderPlots(); renderKeys(); renderHeader(); persist() }
  }

  /** 自动劳动选地：先收成熟，再种空地，最后照顾生长中的地；跳过别人已经占住的。 */
  function pickAutoPlot(owner) {
    var mature = []
    var empty = []
    var growing = []
    state.plots.forEach(function (plot, idx) {
      if (!plot || plot.harvestAt) return
      if (claimedByOther(idx, owner)) return
      if (plot.stage >= 3) mature.push(idx)
      else if (plot.stage <= 0) empty.push(idx)
      else growing.push(idx)
    })
    var pool = mature.length ? mature : empty.length ? empty : growing
    if (!pool.length) return -1
    return pool[Math.floor(Math.random() * pool.length)]
  }

  /** 工作 5 分钟解锁一只小动物，最多 4 只；900 秒不工作清零。 */
  function updateHelpers(dt) {
    var now = Date.now()
    if (workingNow()) {
      state.lastWorkAt = now
      state.helperSeconds += dt
      var unlocked = false
      while (state.helperSeconds >= HELPER_EVERY && state.helpers < HELPER_MAX) {
        state.helperSeconds -= HELPER_EVERY
        state.helpers += 1
        unlocked = true
        var idx = state.helpers - 1
        var actor = helperActors[idx]
        if (actor) {
          actor.x = 18 + idx * 13
          actor.y = 178
          actor.tx = actor.x
          actor.ty = actor.y
          actor.phase = 'idle'
          actor.nextAt = now + rand(300, 900)
          if (actor.el) {
            actor.el.classList.add('dsf-helper-pop')
            setTimeout(function (el) {
              return function () { el.classList.remove('dsf-helper-pop') }
            }(actor.el), 900)
          }
        }
        say('第 ' + state.helpers + ' 只小动物来帮忙啦！', 3000, 1)
        renderFieldStats()
      }
      if (unlocked) persist()
    } else if (state.lastWorkAt && now - state.lastWorkAt > HELPER_IDLE_RESET * 1000
      && (state.helpers > 0 || state.helperSeconds > 0)) {
      state.helpers = 0
      state.helperSeconds = 0
      state.lastWorkAt = 0
      clearHelperJobs()
      say('小动物们回去休息了…', 2600, 1)
      renderFieldStats()
      persist()
    }

    for (var i = 0; i < HELPER_MAX; i++) {
      var a = helperActors[i]
      if (!a) continue
      var on = i < state.helpers
      if (a.el) a.el.classList.toggle('dsf-helper-on', on)
      if (!on) {
        if (a.job) releasePlot(a.job.idx, a)
        a.job = null
        a.phase = 'idle'
        a.moving = false
        hideEmote(a)
        continue
      }
      if (a.phase === 'idle' && !a.moving && now >= a.nextAt) {
        var target = pickAutoPlot(a)
        if (target >= 0) {
          startJob(a, target, true, 'helper')
        } else {
          a.tx = clamp(rand(20, FIELD.w - 20), 16, FIELD.w - 16)
          a.ty = clamp(rand(60, FIELD.h - 14), 30, FIELD.h - 10)
          a.dir = dirFor(a, a.tx - a.x, a.ty - a.y)
          a.phase = 'walk'
          a.phaseT = 0
          a.moving = true
          a.nextAt = now + rand(1400, 3000)
        }
      }
      updateActor(a, dt)
    }
  }

  function drawHelpers() {
    for (var i = 0; i < helperActors.length; i++) {
      if (i < state.helpers) drawActor(helperActors[i])
    }
  }

  /** 让小人走到某点；已经在目标点时立即回调，避免队列卡死。 */
  function walkFarmerTo(x, y, cb) {
    farmer.tx = clamp(x, 14, FIELD.w - 14)
    farmer.ty = clamp(y, 8, FIELD.h - 8)
    farmer.dir = dirFor(farmer, farmer.tx - farmer.x, farmer.ty - farmer.y)
    farmer.phase = 'walk'
    farmer.phaseT = 0
    farmer.frame = 0
    farmer.frameT = 0
    farmer.moving = true
    farmer.onArrive = cb || null
    if (Math.abs(farmer.tx - farmer.x) < 0.6 && Math.abs(farmer.ty - farmer.y) < 0.6) {
      farmer.x = farmer.tx
      farmer.y = farmer.ty
      farmer.moving = false
      farmer.phase = 'idle'
      var done = farmer.onArrive
      farmer.onArrive = null
      if (done) setTimeout(done, 0)
    }
  }

  function drawClerk(now) {
    if (!clerkEl) return
    var working = Date.now() < clerkWorkUntil
    var name = working ? 'clerk_work' : 'clerk_idle'
    var frames = working ? 8 : 9
    setFrame(clerkEl, name, Math.floor(now / (working ? 120 : 260)) % frames)
  }

  /** 气泡按农场容器边界自动限宽，并在四个方向夹紧，绝不越界。 */
  function updateBubblePosition() {
    if (!bubbleEl || !fieldBody) return
    var W = fieldBody.clientWidth || FIELD.w
    var H = fieldBody.clientHeight || FIELD.h
    var maxW = clamp(W - 8, 72, 124)
    bubbleEl.style.maxWidth = maxW + 'px'
    var width = bubbleEl.offsetWidth || Math.min(maxW, 110)
    var height = bubbleEl.offsetHeight || 24
    if (width > W - 4) width = W - 4
    if (height > H - 4) height = H - 4
    var cx = farmer.x
    var left = Math.round(clamp(cx - width / 2, 2, Math.max(2, W - width - 2)))
    var top = Math.round(farmer.y - 38 - height)
    if (top < 2) top = Math.round(clamp(farmer.y + 8, 2, Math.max(2, H - height - 2)))
    bubbleEl.style.left = left + 'px'
    bubbleEl.style.top = top + 'px'
    bubbleEl.style.setProperty('--dsf-bubble-arrow', Math.round(clamp(cx - left, 8, width - 8)) + 'px')
  }

  // ------------------------------------------------------------------
  // 界面
  // ------------------------------------------------------------------
  var root = null
  var frameEl = null
  var fieldBody = null
  var plotsLayer = null
  var decorLayer = null
  var keysList = null
  var keysSummary = null
  var tasksList = null
  var usageView = null
  var tabBar = null
  var views = {}
  var badgeEl = null
  var statusEl = null
  var fieldStats = null
  var titleEl = null
  var workStatText = null
  var helperStatText = null
  var coinStatText = null
  var hostUserName = ''
  var panelHost = null
  var cssInjected = false
  var currentScaleValue = 1.5
  var hitRectsFrame = 0

  function farmTitle() { return hostUserName ? hostUserName + ' 的农场' : '老乡的农场' }
  function renderFarmTitle() {
    // 用户名保留原始大小写，标题走系统字体；其它 ASCII 仍用位图字库
    if (titleEl) titleEl.textContent = farmTitle()
    if (panel) {
      var head = panel.querySelector('.dsf-panel-title')
      if (head) head.textContent = farmTitle()
    }
  }

  function reportHitRects() {
    if (!DESKTOP || !window.dsfDesktop || typeof window.dsfDesktop.setHitRects !== 'function') return
    if (hitRectsFrame) return
    hitRectsFrame = requestAnimationFrame(function () {
      hitRectsFrame = 0
      var rects = []
      function add(el) {
        if (!el) return
        var r = el.getBoundingClientRect()
        if (r.width > 1 && r.height > 1) rects.push({ x: r.left, y: r.top, w: r.width, h: r.height })
      }
      add(frameEl)
      if (panelHost && panelHost.classList.contains('dsf-panel-open')) add(panel)
      add(document.querySelector('.dsf-resize-grip'))
      add(introEl)
      if (root && root.classList.contains('dsf-collapsed')) add(document.querySelector('.dsf-openbtn'))
      window.dsfDesktop.setHitRects(rects)
    })
  }

  function injectCss() {
    if (cssInjected || document.getElementById('dsh-stardew-css')) return
    cssInjected = true
    var style = document.createElement('style')
    style.id = 'dsh-stardew-css'
    style.textContent = DSF_CSS
    document.head.appendChild(style)
  }

  function currentTab() { return state.settings.tab || 'farm' }

  function switchTab(tab) {
    state.settings.tab = tab
    if (tabBar) {
      Array.prototype.forEach.call(tabBar.children, function (btn) {
        btn.classList.toggle('dsf-tab-on', btn.getAttribute('data-tab') === tab)
      })
    }
    Object.keys(views).forEach(function (name) {
      views[name].classList.toggle('dsf-view-on', name === tab)
    })
    if (tab === 'keys') renderKeys()
    if (tab === 'tasks') renderTasksView()
    if (tab === 'usage') renderUsageView()
    if (tab === 'balance') renderBalanceView()
    if (state.settings.autoScale) requestAnimationFrame(applySettings)
    reportHitRects()
    persist()
  }

  function tabIcon(name) {
    var wrap = h('span', { class: 'dsf-tab-ico' })
    var meta = SPRITES[name]
    var sp = sprite(name)
    if (meta) {
      var scale = Math.min(1, 14 / Math.max(meta.w, meta.h))
      if (scale < 1) sp.style.transform = 'scale(' + scale.toFixed(2) + ')'
    }
    wrap.appendChild(sp)
    return wrap
  }

  function statText(text) {
    return btext(text)
  }

  function statIcon(name, cls) {
    return h('span', { class: 'dsf-stat-ico ' + (cls || '') }, [sprite(name)])
  }

  function buildUI() {
    injectCss()
    root = h('div', { class: 'dsf-root' })
    frameEl = h('div', { class: 'dsf-frame dsf-panel-paper' })

    headerCoinsText = h('span', { class: 'dsf-coins-text' })
    headerCoins = h('span', { class: 'dsf-coins' }, [sprite('itemdisc'), headerCoinsText])
    titleEl = h('span', { class: 'dsf-title' })
    var headerEl = h('div', { class: 'dsf-header' }, [
      h('span', { class: 'dsf-logo' }, [btext('FARM', { class: 'dsf-logo-text', white: true })]),
      titleEl,
      headerCoins,
      h('button', { class: 'dsf-iconbtn', title: '尺寸 / 停靠 / 详细设置', onclick: function (e) { e.stopPropagation(); openPanel('settings') } }, [h('span', { class: 'dsf-system-ico' }, '☰')]),
      h('button', { class: 'dsf-iconbtn dsf-collapsebtn', title: '收起（Alt+Shift+F）', onclick: function (e) { e.stopPropagation(); setCollapsed(true) } }, [h('span', { class: 'dsf-system-ico' }, '▾')]),
    ])
    renderFarmTitle()
    frameEl.appendChild(headerEl)
    if (DESKTOP) {
      headerEl.addEventListener('mousedown', function (e) {
        if (e.button !== 0) return
        var tag = e.target && e.target.tagName
        if (tag === 'BUTTON' || tag === 'INPUT') return
        e.preventDefault()
        if (window.dsfDesktop && window.dsfDesktop.startDrag) window.dsfDesktop.startDrag()
      })
      window.addEventListener('mouseup', function () {
        if (window.dsfDesktop && window.dsfDesktop.endDrag) window.dsfDesktop.endDrag()
      })
    }
    statusEl = h('div', { class: 'dsf-statusbar' })
    frameEl.appendChild(statusEl)

    // 页签：统一 14px 素材图标 + 两字中文，不夹 emoji，保证 5 个等宽不溢出
    tabBar = h('div', { class: 'dsf-tabbar' })
    ;[
      ['farm', '农场', 'basket'],
      ['keys', '键盘', 'seed'],
      ['tasks', '任务', 'plan'],
      ['usage', '工时', 'sandtimer'],
      ['balance', '余额', 'itemdisc'],
    ].forEach(function (pair) {
      tabBar.appendChild(h('button', {
        class: 'dsf-tabbtn', 'data-tab': pair[0],
        onclick: function (e) { e.stopPropagation(); switchTab(pair[0]) },
      }, [tabIcon(pair[2]), h('span', { class: 'dsf-tab-label' }, pair[1])]))
    })
    frameEl.appendChild(tabBar)

    // ---- 页 1：农场（土地 + 底部状态栏，避免工时牌浮在土地上） ----
    plotsLayer = h('div', { class: 'dsf-plots' })
    decorLayer = h('div', { class: 'dsf-decor' })
    farmerEl = h('div', { class: 'dsf-farmer', title: '点我：让小人去田里干活' })
    farmerEl.addEventListener('click', function (e) { e.stopPropagation(); startTending() })
    farmer.el = farmerEl
    farmer.emoteEl = h('div', { class: 'dsf-emote' })
    bubbleEl = h('div', { class: 'dsf-bubble' })
    bubbleEl.addEventListener('click', function (e) { e.stopPropagation(); switchTab('tasks') })
    sparksLayer = h('div', { class: 'dsf-sparks' })
    fieldBody = h('div', { class: 'dsf-fieldbody' }, [decorLayer, plotsLayer, farmerEl, farmer.emoteEl, bubbleEl, sparksLayer])
    fieldStats = h('div', { class: 'dsf-fieldstats' })

    workStatText = statText('已工作 0s')
    clerkLabel = workStatText
    helperStatText = statText('帮手 0/4')
    coinStatText = statText('金币 0')
    var railWork = h('div', { class: 'dsf-stat', title: '今日工时：点开工时页' }, [statIcon('stopwatch', 'dsf-stat-ico-clock'), workStatText])
    railWork.addEventListener('click', function (e) { e.stopPropagation(); switchTab('usage') })
    var railHelper = h('div', { class: 'dsf-stat', title: '帮手工时：每工作 5 分钟来一只' }, [statIcon('cow', 'dsf-stat-ico-cow'), helperStatText])
    var railCoin = h('div', { class: 'dsf-stat', title: '今天的金币' }, [statIcon('itemdisc', 'dsf-stat-ico-disc'), coinStatText])
    var fieldRail = h('div', { class: 'dsf-fieldrail' }, [railWork, railHelper, railCoin])

    var field = h('div', { class: 'dsf-field' }, [
      h('div', { class: 'dsf-fieldhead' }, [
        h('div', { class: 'dsf-sec-label' }, '土地 · 26 块 A–Z'),
        fieldStats,
      ]),
      fieldBody,
      fieldRail,
    ])
    views.farm = h('div', { class: 'dsf-view dsf-view-farm' }, [field])
    buildDecor()

    // ---- 页 2：键盘农场 ----
    keysSummary = h('div', { class: 'dsf-keysummary' })
    keysList = h('div', { class: 'dsf-keylist' })
    views.keys = h('div', { class: 'dsf-view dsf-view-keys' }, [
      h('div', { class: 'dsf-sec-label' }, 'QWERTY 26 键 · 每块地一个字母'),
      keysSummary,
      keysList,
      h('div', { class: 'dsf-keyhint' }, '按键盘上的字母，农场里同一块地就会长作物；每 3 次成熟 +4 金币。'),
    ])

    // ---- 页 3：任务 ----
    tasksList = h('div', { class: 'dsf-tasklist dsf-panel-paper' })
    views.tasks = h('div', { class: 'dsf-view dsf-view-tasks' }, [
      h('div', { class: 'dsf-sec-label' }, '今日待办（实时同步）'),
      tasksList,
    ])

    // ---- 页 4：工时 ----
    usageView = h('div', { class: 'dsf-view dsf-view-usage' })
    views.usage = usageView

    // ---- 页 5：余额 ----
    views.balance = h('div', { class: 'dsf-view dsf-view-balance' })

    Object.keys(views).forEach(function (name) { frameEl.appendChild(views[name]) })

    badgeEl = h('div', { class: 'dsf-badge' }, [ico('face_exclaim'), h('span', { class: 'dsf-badge-text' }, '有个事要你处理')])
    badgeEl.addEventListener('click', function (e) { e.stopPropagation(); switchTab('tasks') })
    frameEl.appendChild(badgeEl)
    root.appendChild(frameEl)

    var openBtn = h('button', { class: 'dsf-openbtn' }, [sprite('basket'), h('span', null, '农场')])
    openBtn.addEventListener('click', function (e) { e.stopPropagation(); setCollapsed(false) })
    root.appendChild(openBtn)

    document.body.appendChild(root)
    if (DESKTOP) {
      panelHost = h('div', { class: 'dsf-panel-host' })
      document.body.appendChild(panelHost)
      buildResizeGrip()
    }

    renderHeader(); renderPlots(); renderKeys(); renderTasksView(); renderUsageView()
    switchTab(currentTab())

    bindKeyboard()
    bindDesktopKeys()
    applySettings()
    reportHitRects()
    window.addEventListener('resize', function () { applySettings(); reportHitRects() })
    setInterval(reportHitRects, 1000)
    requestAnimationFrame(function () { lastNow = performance.now(); tick(lastNow) })
    startStream()
  }

  function buildDecor() {
    decorLayer.innerHTML = ''
    helperEls = []

    // 装饰只放在顶部留白和第四行左右两个空格里，均匀、不压地块
    var props = [
      ['pond', 15, 129, .42, 1],
      ['flower_patch', 70, 1, .35, 1],
      ['flower_patch', 132, 1, .35, 1],
      ['flower_patch', 194, 1, .35, 1],
      ['grass_tuft', 100, 2, .4, 1],
      ['grass_tuft', 164, 2, .4, 1],
    ]
    props.forEach(function (p) {
      var el = sprite(p[0])
      if (!el) return
      el.classList.add('dsf-prop')
      el.style.left = p[1] + 'px'
      el.style.top = p[2] + 'px'
      el.style.transform = 'scale(' + p[3] + ')'
      el.style.zIndex = String(p[4])
      decorLayer.appendChild(el)
    })

    // 帮手：4 只 side-view 小动物，各自带独立状态机
    helpersLayer = h('div', { class: 'dsf-helpers' })
    helperActors = []
    HELPER_NAMES.forEach(function (name, i) {
      var el = sprite(name, 0)
      el.classList.add('dsf-helper', 'dsf-helper-' + i)
      var item = makeActor('helper', i)
      item.el = el
      item.x = 18 + i * 13
      item.y = 182
      item.tx = item.x
      item.ty = item.y
      item.dir = 'right'
      item.emoteEl = h('div', { class: 'dsf-emote dsf-emote-helper' })
      item.emoteEl.style.display = 'none'
      el.style.left = item.x + 'px'
      el.style.top = item.y + 'px'
      helpersLayer.appendChild(el)
      helperEls.push(item)
      helperActors.push(item)
      fieldBody.appendChild(item.emoteEl)
    })
    // 帮手必须放在 fieldBody 的独立图层里，不能塞进 z-index:1 的装饰层，否则会被土地盖住
    fieldBody.appendChild(helpersLayer)

    // 工时记录员：站在右下角空地上，不再挂浮动工时牌（工时改到底部状态栏）
    clerkEl = h('div', { class: 'dsf-clerk', title: '工时记录员：点我看今天用了哪些软件' })
    clerkEl.addEventListener('click', function (e) { e.stopPropagation(); switchTab('usage') })
    fieldBody.appendChild(clerkEl)

    fieldBody.style.backgroundImage = SPRITES.grass_tile
      ? "url('" + SPRITES.grass_tile.src + "'), linear-gradient(#8fcc57, #6aae3b)"
      : 'linear-gradient(#8fcc57, #6aae3b)'
    if (SPRITES.grass_tile) fieldBody.style.backgroundSize = '64px 64px, auto'
  }

  // ------------------------------------------------------------------
  // 键盘：keydown 为主动作，输入法/粘贴等用 input 兜底
  // ------------------------------------------------------------------
  var lastKeydownAt = 0
  var composing = false
  var recentKeys = {}

  function countKey(key, source) {
    if (!key) return
    var letter = letterForKey(key)
    if (!letter) return
    var now = Date.now()
    var rec = recentKeys[letter] || (recentKeys[letter] = {})
    var from = source || 'page'
    var other = from === 'global' ? 'page' : (from === 'page' ? 'global' : '')
    if (other && now - (rec[other] || 0) < 45) return
    rec[from] = now
    onKey(key)
  }

  function onKeyDown(ev) {
    if (!root || root.classList.contains('dsf-collapsed')) return
    if (ev.altKey && ev.shiftKey && (ev.key === 'F' || ev.key === 'f')) {
      setCollapsed(!state.settings.collapsed)
      return
    }
    if (CONTROL_KEY.test(String(ev.key || ''))) return
    lastKeydownAt = Date.now()
    if (ev.isComposing || composing || ev.key === 'Process' || ev.key === 'Unidentified' || ev.key === 'Dead') {
      return
    }
    countKey(ev.key, 'page')
  }

  function onInput(ev) {
    if (Date.now() - lastKeydownAt < 60) return
    var data = ev && ev.data
    if (typeof data !== 'string' || !data.length) return
    if (composing) return
    for (var i = 0; i < data.length; i++) {
      var ch = data[i]
      if (ch.trim() === '') continue
      countKey(ch, 'input')
    }
  }

  function bindKeyboard() {
    window.addEventListener('keydown', onKeyDown, true)
    document.addEventListener('compositionstart', function () { composing = true }, true)
    document.addEventListener('compositionend', function (ev) {
      composing = false
      lastKeydownAt = 0
      var data = ev && ev.data
      if (!data) return
      for (var i = 0; i < data.length; i++) {
        var ch = data[i]
        if (ch.trim() === '') continue
        countKey(ch, 'composition')
      }
    }, true)
    document.addEventListener('input', onInput, true)
  }

  function bindDesktopKeys() {
    if (!DESKTOP || !window.dsfDesktop || typeof window.dsfDesktop.onKey !== 'function') return
    window.dsfDesktop.onKey(function (key) {
      if (key) countKey(String(key), 'global')
    })
  }

  // ------------------------------------------------------------------
  // 渲染
  // ------------------------------------------------------------------
  function renderHeader() {
    if (!headerCoins) return
    setBText(headerCoinsText, ' ' + Math.floor(state.coins))
    headerCoins.title = '今日耕种 ' + Math.round(state.farmSeconds) + ' 秒 · 收割 ' + totalHarvests() + ' 次'
    renderStatus()
    renderFieldStats()
  }

  function statusLabel() {
    if (host.busy) return '干活中'
    if (host.harness) return 'harness'
    if (Date.now() < typingUntil) return '打字中'
    if (Date.now() < workUntil) return '干活中'
    return '空闲'
  }

  function renderStatus() {
    if (!statusEl) return
    var pending = host.todos.filter(function (t) { return t.status !== 'completed' }).length
    var totalTodos = host.todos.length
    var todoLabel = totalTodos ? ('待办 ' + pending + '/' + totalTodos) : '待办 0'
    var total = host.usage ? host.usage.totalSeconds : state.onlineSeconds
    var app = host.workApp && host.workApp.name ? clampText(host.workApp.name, 8) : ''
    var label = statusLabel()
    if (app && !(host.workApp && host.workApp.ignored) && (Date.now() < workUntil || (host.usage && host.usage.current))) {
      label = app
    }
    var key = [state.day, label, pending, totalTodos, Math.floor(total / 60), DESKTOP ? 'd' : 'w', host.harness ? 'h' : ''].join('|')
    if (key === lastStatusKey) return
    lastStatusKey = key
    statusEl.innerHTML = ''
    statusEl.appendChild(h('span', { class: 'dsf-status-item', title: state.day }, [btext(state.day.slice(5))]))
    statusEl.appendChild(h('span', { class: 'dsf-status-item' + (workingNow() ? ' dsf-status-busy' : '') }, [btext(label)]))
    statusEl.appendChild(h('span', { class: 'dsf-status-item' }, [btext(todoLabel)]))
    statusEl.appendChild(h('span', { class: 'dsf-status-item' }, [btext('工时 ' + fmtShort(total))]))
    if (DESKTOP) statusEl.appendChild(h('span', { class: 'dsf-status-item dsf-desktop-badge' }, [btext('桌面')]))
  }

  function renderFieldStats() {
    if (!fieldStats) return
    var mature = 0
    state.plots.forEach(function (plot) { if (plot && plot.stage >= 3) mature += 1 })
    setBText(fieldStats, '成熟 ' + mature + ' · 收割 ' + totalHarvests())
    fieldStats.title = '今日耕种 ' + Math.round(state.farmSeconds) + ' 秒 · 26 块地固定 A–Z'
    var total = host.usage ? Number(host.usage.totalSeconds) || 0 : state.onlineSeconds
    if (workStatText) setBText(workStatText, '已工作 ' + fmtShort(total))
    if (helperStatText) setBText(helperStatText, '帮手 ' + state.helpers + '/' + HELPER_MAX)
    if (coinStatText) setBText(coinStatText, '金币 ' + Math.floor(state.coins))
  }

  function totalHarvests() {
    var n = 0
    Object.keys(state.keys).forEach(function (k) { n += state.keys[k].harvests || 0 })
    return n
  }

  function renderPlots() {
    if (!plotsLayer) return
    plotsLayer.innerHTML = ''
    state.plots.forEach(function (plot, idx) {
      var pos = plotPos(idx)
      var cell = h('div', { class: 'dsf-plot', 'data-letter': plot.key })
      cell.style.left = pos.x + 'px'
      cell.style.top = pos.y + 'px'
      var soil = dirtEl('dsf-soil', 30, 30, idx % 2 === 1)
      cell.appendChild(soil)
      cell.appendChild(h('span', { class: 'dsf-plot-letter' }, [btext(plot.key)]))
      var crop = cropForLetter(plot.key)
      if (plot.stage > 0) {
        var plant = sprite(crop.sprite, cropFrame(plot.stage, !!plot.harvestAt))
        plant.classList.add('dsf-plant')
        cell.appendChild(plant)
        if (plot.stage >= 3) cell.classList.add('dsf-ready')
      } else {
        cell.classList.add('dsf-empty')
      }
      var pips = h('div', { class: 'dsf-pips dsf-pips-plot' })
      for (var p = 0; p < 3; p++) pips.appendChild(h('span', { class: 'dsf-pip' + (p < plot.stage ? ' on' : '') }))
      cell.appendChild(pips)
      cell.setAttribute('title', plot.key + ' 地：' + (plot.stage > 0
        ? crop.name + (plot.stage >= 3 ? '（成熟，马上收割）' : '（生长 ' + plot.stage + '/3）')
        : '空地，按 ' + plot.key + ' 种上'))
      cell.addEventListener('click', function (e) { e.stopPropagation(); onKey(plot.key) })
      plotsLayer.appendChild(cell)
    })
  }

  function renderKeys() {
    if (!keysList) return
    keysList.innerHTML = ''
    var mature = state.plots.filter(function (p) { return p.stage >= 3 }).length
    if (keysSummary) {
      keysSummary.innerHTML = ''
      keysSummary.appendChild(sprite('basket'))
      keysSummary.appendChild(btext('26 键 = 26 块地 · 成熟 ' + mature + ' · 今日收割 ' + totalHarvests() + ' 次 · 每 3 次 +' + HARVEST_COINS + ' 金币'))
    }
    KEY_ROWS.forEach(function (row) {
      var rowEl = h('div', { class: 'dsf-keyrow' })
      row.forEach(function (letter) {
        var idx = plotIndex(letter)
        var plot = state.plots[idx]
        var crop = cropForLetter(letter)
        var rec = state.keys[letter]
        var cell = h('div', { class: 'dsf-key', 'data-letter': letter })
        var soil = dirtEl('dsf-key-soil', 20, 20, idx % 2 === 1)
        cell.appendChild(soil)
        if (plot.stage > 0) {
          var plant = sprite(crop.sprite, cropFrame(plot.stage, !!plot.harvestAt))
          plant.classList.add('dsf-key-plant')
          cell.appendChild(plant)
        } else {
          cell.classList.add('dsf-empty')
        }
        cell.appendChild(h('span', { class: 'dsf-key-letter' }, [btext(letter, { white: true })]))
        var pips = h('div', { class: 'dsf-key-pips' })
        for (var p = 0; p < 3; p++) pips.appendChild(h('span', { class: 'dsf-pip' + (p < plot.stage ? ' on' : '') }))
        cell.appendChild(pips)
        if (plot.stage >= 3) cell.classList.add('dsf-ready')
        cell.setAttribute('title', letter + ' 地：' + crop.name + (rec
          ? ' · 已按 ' + rec.n + ' 次 · 收割 ' + (rec.harvests || 0) + ' 次'
          : ' · 还没种'))
        cell.addEventListener('click', function (e) { e.stopPropagation(); onKey(letter) })
        rowEl.appendChild(cell)
      })
      keysList.appendChild(rowEl)
    })
  }

  function taskIcon(status) {
    var glyph = status === 'completed' ? '✔' : status === 'in_progress' ? '◐' : '○'
    return h('span', { class: 'dsf-task-glyph' }, glyph)
  }

  function todoKey(todo) {
    return String(todo && todo.status || '') + '|' + String(todo && todo.content || '')
  }

  function taskRow(todo, index) {
    var key = todoKey(todo)
    var on = state.selectedTaskKey === key
    var row = h('div', {
      class: 'dsf-item dsf-todo-' + todo.status
        + (todo.status === 'in_progress' ? ' dsf-task-current' : '')
        + (on ? ' dsf-task-on dsf-select-skin' : ''),
      'data-index': String(index),
      role: 'button',
      tabindex: '0',
      onclick: function (e) {
        e.stopPropagation()
        state.selectedTaskKey = state.selectedTaskKey === key ? '' : key
        state.selectedTask = state.selectedTaskKey ? index : -1
        renderTasksView()
        if (state.selectedTaskKey === key) say(clampText(todo.content, 60), 3000, 1)
      },
    }, [
      h('span', { class: 'dsf-task-icon dsf-task-' + todo.status }, [taskIcon(todo.status)]),
      h('span', { class: 'dsf-item-text' }, todo.content),
      todo.status === 'in_progress' ? h('span', { class: 'dsf-current-chip dsf-label-skin' }, '当前') : null,
      on ? h('span', { class: 'dsf-selected-chip dsf-label-skin' }, '已选') : null,
    ])
    return row
  }

  function renderTasksView() {
    if (!tasksList) return
    tasksList.innerHTML = ''
    state.selectedTask = -1
    host.todos.forEach(function (todo, i) {
      if (state.selectedTaskKey && todoKey(todo) === state.selectedTaskKey) state.selectedTask = i
    })
    var completed = host.todos.filter(function (t) { return t.status === 'completed' }).length
    var pct = host.todos.length ? Math.round(completed / host.todos.length * 100) : 0
    var bar = h('div', { class: 'dsf-progress', title: completed + ' / ' + host.todos.length })
    var fill = h('div', { class: 'dsf-progress-fill', style: { width: pct + '%' } })
    bar.appendChild(fill)
    tasksList.appendChild(bar)
    tasksList.appendChild(h('div', { class: 'dsf-dim dsf-small' },
      '完成 ' + completed + ' / ' + host.todos.length + ' · 耕种 ' + Math.round(state.farmSeconds) + ' 秒 · 收割 ' + totalHarvests() + ' 次'))
    if (host.todosFallback && host.todos.length) {
      tasksList.appendChild(h('div', { class: 'dsf-task-source' }, '当前会话还没写待办，显示最近一轮的待办'))
    }
    if (!host.todos.length) {
      tasksList.appendChild(h('div', { class: 'dsf-item dsf-dim' }, '还没有待办。AI 更新待办清单时会实时同步到这里。'))
      return
    }
    host.todos.forEach(function (todo, i) { tasksList.appendChild(taskRow(todo, i)) })
  }

  function renderUsageView() {
    if (!usageView) return
    var usage = host.usage
    var total = usage ? Number(usage.totalSeconds) || 0 : state.onlineSeconds
    var cur = usage && usage.current ? usage.current : null
    var key = [
      usage ? usage.updatedAt : 0, Math.floor(total),
      cur ? cur.name : '', cur && cur.ignored ? 'i' : '',
      usage && Array.isArray(usage.apps) ? usage.apps.length : 0,
      host.harness ? 1 : 0,
    ].join('|')
    if (key === lastUsageKey) return
    lastUsageKey = key
    usageView.innerHTML = ''

    var head = h('div', { class: 'dsf-usage-head' }, [
      h('div', { class: 'dsf-usage-total' }, [btext(fmtLong(total))]),
      h('div', { class: 'dsf-dim dsf-small' }, usage ? '今日前台软件使用时长' : '本页在线时长（桌面版记录软件）'),
    ])
    usageView.appendChild(head)

    if (cur) {
      var curName = String(cur.name || cur.process || '未知')
      usageView.appendChild(h('div', { class: 'dsf-usage-now' + (cur.ignored ? ' dsf-usage-idle' : '') }, [
        ico(cur.ignored ? 'face_cry' : 'face_green'),
        h('span', null, cur.ignored ? '当前未记录：' + curName : '正在用：' + curName),
        h('span', { class: 'dsf-usage-live' }, cur.ignored ? '暂停' : '记录中'),
      ]))
    }
    if (host.harness) {
      usageView.appendChild(h('div', { class: 'dsf-usage-harness' },
        '🤖 检测到 harness：' + (host.harnessNames && host.harnessNames.length ? host.harnessNames.join(' / ') : '运行中')))
    }

    var apps = usage && Array.isArray(usage.apps) ? usage.apps : []
    if (!apps.length) {
      usageView.appendChild(h('div', { class: 'dsf-item dsf-dim' },
        usage ? '今天还没有记录到软件使用。切到别的窗口再回来就会开始记。' : '桌面版会在后台记录每个前台软件的使用时长；DSH 页面只能记本页在线时长。'))
    } else {
      var max = 1
      apps.forEach(function (app) { max = Math.max(max, Number(app.seconds) || 0) })
      apps.slice(0, 10).forEach(function (app) {
        var sec = Number(app.seconds) || 0
        var pct = Math.max(2, Math.round(sec / max * 100))
        usageView.appendChild(h('div', { class: 'dsf-usage-row' + (app.current ? ' dsf-usage-current' : '') }, [
          h('div', { class: 'dsf-usage-line' }, [
            h('span', { class: 'dsf-usage-name', title: app.title || app.name }, [btext(String(app.name || app.key || '未知'))]),
            h('span', { class: 'dsf-usage-time' }, [btext(fmtShort(sec))]),
          ]),
          h('div', { class: 'dsf-usage-bar' }, [
            h('div', { class: 'dsf-usage-fill', style: { width: pct + '%' } }),
          ]),
        ]))
      })
    }
    usageView.appendChild(h('div', { class: 'dsf-usage-note' },
      '记录员每 1 秒看一眼前台窗口；切换软件时，小人会冒 3 秒「工作中」并下田。'))
  }

  function renderUsageStats() {
    var total = host.usage ? Number(host.usage.totalSeconds) || 0 : state.onlineSeconds
    if (clerkLabel) setBText(clerkLabel, '已工作 ' + fmtShort(total))
    renderStatus()
  }

  function renderBalanceView() {
    var box = views.balance
    if (!box) return
    box.innerHTML = ''
    box.appendChild(h('div', { class: 'dsf-dim dsf-small' }, '读取中…'))
    fetch(PREFIX + '/api/balance', { cache: 'no-store' })
      .then(function (r) { return r.json() })
      .then(function (data) {
        box.innerHTML = ''
        if (!data || !data.ok) {
          box.appendChild(h('div', { class: 'dsf-dim' }, '读取不到余额：' + String((data && data.error) || '未知错误')))
          return
        }
        var cur = data.currency === 'CNY' ? '¥' : data.currency === 'USD' ? '$' : (data.currency || '')
        box.appendChild(h('div', { class: 'dsf-balance' }, [
          h('div', { class: 'dsf-dim dsf-small' }, '可用余额（' + (data.source === 'account' ? '账号登录' : 'API Key') + '）'),
          h('div', { class: 'dsf-bal-big' }, [btext(cur + Number(data.totalBalance).toFixed(2))]),
          data.bonusBalance !== null && data.bonusBalance !== undefined
            ? h('div', { class: 'dsf-dim dsf-small' }, '其中赠金 ' + cur + Number(data.bonusBalance).toFixed(2)) : null,
          h('button', { class: 'dsf-btn', onclick: function (e) { e.stopPropagation(); renderBalanceView() } }, '刷新'),
        ]))
      })
      .catch(function () { box.innerHTML = ''; box.appendChild(h('div', { class: 'dsf-dim' }, '网络错误')) })
  }

  function renderBadge() {
    if (!badgeEl) return
    if (state.attention) {
      var txt = badgeEl.querySelector('.dsf-badge-text')
      if (txt) txt.textContent = '🙋 ' + state.attention.kind + '：' + clampText(state.attention.text, 16)
      badgeEl.classList.add('dsf-badge-show')
    } else {
      badgeEl.classList.remove('dsf-badge-show')
    }
  }

  function renderBubble() {
    if (!bubbleEl) return
    if (!bubbleText) {
      bubbleEl.innerHTML = ''
      bubbleEl.classList.remove('dsf-bubble-show')
      return
    }
    bubbleEl.innerHTML = ''
    appendBText(bubbleEl, bubbleText)
    bubbleEl.classList.add('dsf-bubble-show')
    updateBubblePosition()
  }

  function startTending() {
    workUntil = Date.now() + 8000
    say('去干活啦', 1800, 1)
    for (var i = 0; i < 6; i++) {
      var idx = pickAutoPlot(farmer)
      if (idx >= 0) enqueueAction(idx, 'auto', true)
    }
  }

  // ------------------------------------------------------------------
  // ☰ 面板：尺寸 / 停靠 / 详细
  // ------------------------------------------------------------------
  var panel = null
  function closePanel() {
    if (!panel) return
    panel.remove()
    panel = null
    if (panelHost) panelHost.classList.remove('dsf-panel-open')
    reportHitRects()
  }
  function hideIntro() {
    if (!introEl) return
    introEl.remove()
    introEl = null
  }
  function openPanel(tab) {
    closePanel()
    hideIntro()
    var active = tab || 'settings'
    var body = h('div', { class: 'dsf-panel-body' })
    var tabsEl = h('div', { class: 'dsf-tabs' })
    function render() {
      body.innerHTML = ''
      if (active === 'settings') body.appendChild(renderSettings())
      else if (active === 'tasks') body.appendChild(renderTasksPanel())
      else { body.appendChild(h('div', { class: 'dsf-dim' }, '读取中…')); renderBalancePanel(body) }
    }
    function switchPanelTab(t) {
      active = t
      Array.prototype.forEach.call(tabsEl.children, function (c) {
        c.classList.toggle('dsf-tab-on', c.getAttribute('data-tab') === t)
      })
      render()
    }
    ;[['settings', '尺寸'], ['tasks', '任务'], ['balance', '余额']].forEach(function (pair) {
      tabsEl.appendChild(h('button', {
        class: 'dsf-tab', 'data-tab': pair[0], onclick: function () { switchPanelTab(pair[0]) },
      }, pair[1]))
    })
    panel = h('div', { class: 'dsf-panel dsf-panel-paper', role: 'dialog', 'aria-label': farmTitle() }, [
      h('div', { class: 'dsf-panel-head' }, [
        h('div', null, [h('b', { class: 'dsf-panel-title' }, farmTitle()), h('span', { class: 'dsf-dim dsf-small' }, ' ' + state.day)]),
        h('button', { class: 'dsf-x', 'aria-label': '关闭', onclick: closePanel }, [h('span', { class: 'dsf-x-text' }, '×')]),
      ]),
      tabsEl,
      body,
    ])
    panel.addEventListener('click', function (e) { e.stopPropagation() })
    if (DESKTOP && panelHost) {
      panelHost.appendChild(panel)
      panelHost.classList.add('dsf-panel-open')
    } else {
      root.appendChild(panel)
    }
    switchPanelTab(active)
    reportHitRects()
  }

  function setWindowPreset(name) {
    if (!DESKTOP || !window.dsfDesktop || typeof window.dsfDesktop.setWindowSize !== 'function') return
    window.dsfDesktop.setWindowSize(name)
    say(name === 'small' ? '窗口调小了' : name === 'large' ? '窗口调大了' : '窗口调成中号', 1600)
  }

  function fitWindow() {
    if (!DESKTOP || !window.dsfDesktop || typeof window.dsfDesktop.fitWindow !== 'function') return
    closePanel()
    var rect = frameEl.getBoundingClientRect()
    state.settings.autoScale = false
    state.settings.scale = currentScaleValue
    applySettings()
    persist()
    window.dsfDesktop.fitWindow({
      width: Math.ceil(rect.width) + 24,
      height: Math.ceil(rect.height) + 24,
    })
    say('窗口已贴合内容', 1800)
  }

  function renderSettings() {
    var wrap = h('div')
    if (DESKTOP) wrap.appendChild(h('div', { class: 'dsf-desktop-note' }, '🖥️ 桌面版：全局按键已接管，Alt+Shift+F 显示/隐藏窗口；拖右下角把手也能改窗口大小'))
    wrap.appendChild(h('div', { class: 'dsf-sec-title' }, '尺寸'))
    wrap.appendChild(h('div', { class: 'dsf-dim dsf-small' },
      state.settings.autoScale ? '自动缩放：开（随窗口大小自适应）' : '当前 ' + Number(state.settings.scale).toFixed(2) + '×（手动）'))
    wrap.appendChild(h('div', { class: 'dsf-actions' }, [
      h('button', {
        class: 'dsf-btn' + (state.settings.autoScale ? ' dsf-btn-on' : ''),
        onclick: function () {
          state.settings.autoScale = !state.settings.autoScale
          if (!state.settings.autoScale) state.settings.scale = autoScaleValue()
          applySettings(); persist(); openPanel('settings')
        },
      }, state.settings.autoScale ? '自动缩放：开' : '自动缩放：关'),
    ]))
    if (DESKTOP) {
      wrap.appendChild(h('div', { class: 'dsf-actions' }, [
        h('button', { class: 'dsf-btn', onclick: function () { setWindowPreset('small'); openPanel('settings') } }, '小 320×520'),
        h('button', { class: 'dsf-btn', onclick: function () { setWindowPreset('medium'); openPanel('settings') } }, '中 400×700'),
        h('button', { class: 'dsf-btn', onclick: function () { setWindowPreset('large'); openPanel('settings') } }, '大 500×860'),
      ]))
      wrap.appendChild(h('div', { class: 'dsf-actions' }, [
        h('button', { class: 'dsf-btn', onclick: fitWindow }, '贴合当前内容'),
        h('button', { class: 'dsf-btn', onclick: function () { openPanel('settings') } }, '当前 ' + window.innerWidth + '×' + window.innerHeight),
      ]))
      var widthInput = h('input', {
        class: 'dsf-input', type: 'number', min: '300', max: '1600', step: '10',
        value: String(Math.round(window.innerWidth)), 'aria-label': '窗口宽度',
      })
      var heightInput = h('input', {
        class: 'dsf-input', type: 'number', min: '420', max: '1200', step: '10',
        value: String(Math.round(window.innerHeight)), 'aria-label': '窗口高度',
      })
      wrap.appendChild(h('div', { class: 'dsf-size-row' }, [
        h('span', { class: 'dsf-dim dsf-small' }, '自定义'),
        widthInput,
        h('span', { class: 'dsf-dim dsf-small' }, '×'),
        heightInput,
        h('button', {
          class: 'dsf-btn',
          onclick: function () {
            var w = clamp(Math.round(Number(widthInput.value) || window.innerWidth), 300, 1600)
            var hgt = clamp(Math.round(Number(heightInput.value) || window.innerHeight), 420, 1200)
            if (window.dsfDesktop && window.dsfDesktop.setWindowSizePx) {
              window.dsfDesktop.setWindowSizePx(w, hgt)
              say('窗口改成 ' + w + '×' + hgt, 1800)
            }
            openPanel('settings')
          },
        }, '应用'),
      ]))
    }
    wrap.appendChild(h('div', { class: 'dsf-actions' }, [
      h('button', { class: 'dsf-btn', onclick: function () { state.settings.autoScale = false; state.settings.scale = clamp((Number(state.settings.scale) || 1.5) - 0.25, 0.75, 2.5); applySettings(); persist(); openPanel('settings') } }, '－ 小'),
      h('button', { class: 'dsf-btn', onclick: function () { state.settings.autoScale = false; state.settings.scale = clamp((Number(state.settings.scale) || 1.5) + 0.25, 0.75, 2.5); applySettings(); persist(); openPanel('settings') } }, '＋ 大'),
    ]))
    wrap.appendChild(h('div', { class: 'dsf-sec-title' }, '停靠'))
    var pos = h('div', { class: 'dsf-actions' })
    ;[['bottom-left', '左下'], ['bottom-right', '右下'], ['top-left', '左上'], ['top-right', '右上']].forEach(function (p) {
      pos.appendChild(h('button', {
        class: 'dsf-btn' + (state.settings.position === p[0] ? ' dsf-btn-on' : ''),
        onclick: function () { state.settings.position = p[0]; applySettings(); persist(); openPanel('settings') },
      }, p[1]))
    })
    wrap.appendChild(pos)
    wrap.appendChild(h('div', { class: 'dsf-dim dsf-small' }, '快捷键 Alt+Shift+F 收起/展开；切页签不影响窗口大小'))
    wrap.appendChild(h('div', { class: 'dsf-sec-title' }, '存档'))
    wrap.appendChild(h('div', { class: 'dsf-actions' }, [
      h('button', {
        class: 'dsf-btn',
        onclick: function () {
          fetch(PREFIX + '/api/snapshot', { cache: 'no-store' })
            .then(function (r) { return r.json() })
            .then(function (payload) { applySnapshot(payload && payload.data); openPanel('settings') })
            .catch(function () { /* 忽略 */ })
        },
      }, '重新读取存档'),
    ]))
    return wrap
  }

  function renderTasksPanel() {
    var wrap = h('div')
    wrap.appendChild(h('div', { class: 'dsf-sec-title' }, '今日待办'))
    if (!host.todos.length) {
      wrap.appendChild(h('div', { class: 'dsf-item dsf-dim' }, '还没有待办。'))
      return wrap
    }
    host.todos.forEach(function (todo, i) {
      var key = todoKey(todo)
      var on = state.selectedTaskKey === key
      wrap.appendChild(h('div', {
        class: 'dsf-item dsf-todo-' + todo.status
          + (todo.status === 'in_progress' ? ' dsf-task-current' : '')
          + (on ? ' dsf-task-on dsf-select-skin' : ''),
        onclick: function (e) {
          e.stopPropagation()
          state.selectedTaskKey = state.selectedTaskKey === key ? '' : key
          state.selectedTask = state.selectedTaskKey ? i : -1
          renderTasksView()
          openPanel('tasks')
          if (state.selectedTaskKey === key) say(clampText(todo.content, 60), 3000, 1)
        },
      }, [
        h('span', { class: 'dsf-task-icon dsf-task-' + todo.status }, [taskIcon(todo.status)]),
        h('span', { class: 'dsf-item-text' }, todo.content),
        todo.status === 'in_progress' ? h('span', { class: 'dsf-current-chip dsf-label-skin' }, '当前') : null,
        on ? h('span', { class: 'dsf-selected-chip dsf-label-skin' }, '已选') : null,
      ]))
    })
    return wrap
  }

  function renderBalancePanel(box) {
    fetch(PREFIX + '/api/balance', { cache: 'no-store' })
      .then(function (r) { return r.json() })
      .then(function (data) {
        box.innerHTML = ''
        if (!data || !data.ok) {
          box.appendChild(h('div', { class: 'dsf-dim' }, '读取不到余额：' + String((data && data.error) || '未知错误')))
          return
        }
        var cur = data.currency === 'CNY' ? '¥' : data.currency === 'USD' ? '$' : (data.currency || '')
        box.appendChild(h('div', { class: 'dsf-balance' }, [
          h('div', { class: 'dsf-dim dsf-small' }, '可用余额（' + (data.source === 'account' ? '账号登录' : 'API Key') + '）'),
          h('div', { class: 'dsf-bal-big' }, [btext(cur + Number(data.totalBalance).toFixed(2))]),
          h('button', { class: 'dsf-btn', onclick: function () { openPanel('balance') } }, '刷新'),
        ]))
      })
      .catch(function () { box.innerHTML = ''; box.appendChild(h('div', { class: 'dsf-dim' }, '网络错误')) })
  }

  // ------------------------------------------------------------------
  // 开场待办 / 缩放 / 窗口把手 / 主循环 / 启动
  // ------------------------------------------------------------------
  var introEl = null
  function showIntro() {
    if (introEl) introEl.remove()
    var list = h('ul', { class: 'dsf-intro-list' })
    var items = host.todos.slice(0, 5)
    if (!items.length) list.appendChild(h('li', { class: 'dsf-intro-item dsf-dim' }, '今天还没待办，我先种着田～'))
    items.forEach(function (todo, i) {
      list.appendChild(h('li', { class: 'dsf-intro-item dsf-' + todo.status }, [
        h('span', { class: 'dsf-dot' }, [taskIcon(todo.status)]),
        h('span', { class: 'dsf-intro-text', title: todo.content }, clampText(todo.content, 26)),
        todo.status === 'in_progress' ? h('span', { class: 'dsf-current-chip dsf-label-skin' }, '当前') : null,
      ]))
    })
    introEl = h('div', { class: 'dsf-intro dsf-panel-paper', role: 'status' }, [
      h('div', { class: 'dsf-intro-head' }, [
        h('b', null, '📋 今日待办'),
        h('span', { class: 'dsf-dim dsf-small' }, '💰 ' + Math.floor(state.coins) + ' 金币'),
      ]),
      list,
      h('div', { class: 'dsf-dim dsf-small' }, '切页签看：农场 / 键盘 / 任务 / 工时 · 点这里展开'),
    ])
    introEl.addEventListener('click', function () { introEl.remove(); introEl = null; switchTab('tasks'); reportHitRects() })
    root.appendChild(introEl)
    requestAnimationFrame(function () { if (introEl) introEl.classList.add('dsf-intro-show'); reportHitRects() })
    setTimeout(function () {
      if (!introEl) return
      introEl.classList.remove('dsf-intro-show')
      setTimeout(function () { if (introEl) { introEl.remove(); introEl = null; reportHitRects() } }, 350)
    }, 8000)
  }

  function autoScaleValue() {
    var availW
    var availH
    if (DESKTOP) {
      availW = Math.max(220, window.innerWidth - 28)
      availH = Math.max(260, window.innerHeight - 28)
    } else {
      availW = Math.min(430, Math.max(260, window.innerWidth * 0.32))
      availH = Math.max(320, window.innerHeight - 120)
    }
    return clamp(Math.min(availW / DESIGN_W, availH / DESIGN_H), 0.75, 2.5)
  }

  function applySettings() {
    if (!root) return
    var s = state.settings.autoScale
      ? autoScaleValue()
      : clamp(Number(state.settings.scale) || 1.5, 0.75, 2.5)
    s = Math.round(s * 20) / 20
    currentScaleValue = s
    root.style.setProperty('--dsf-scale', String(s))
    root.classList.toggle('dsf-pos-bl', state.settings.position === 'bottom-left')
    root.classList.toggle('dsf-pos-br', state.settings.position === 'bottom-right')
    root.classList.toggle('dsf-pos-tl', state.settings.position === 'top-left')
    root.classList.toggle('dsf-pos-tr', state.settings.position === 'top-right')
    setCollapsed(!!state.settings.collapsed)
    reportHitRects()
  }
  function setCollapsed(v) {
    state.settings.collapsed = !!v
    root.classList.toggle('dsf-collapsed', !!v)
    persist()
    reportHitRects()
  }

  function buildResizeGrip() {
    var grip = h('div', { class: 'dsf-resize-grip', title: '拖动调整窗口大小；双击贴合内容' })
    grip.addEventListener('mousedown', function (e) {
      if (e.button !== 0) return
      e.preventDefault()
      e.stopPropagation()
      if (window.dsfDesktop && window.dsfDesktop.startResize) window.dsfDesktop.startResize()
    })
    window.addEventListener('mouseup', function () {
      if (window.dsfDesktop && window.dsfDesktop.endResize) window.dsfDesktop.endResize()
    })
    grip.addEventListener('dblclick', function (e) { e.stopPropagation(); fitWindow() })
    document.body.appendChild(grip)
  }

  // 主循环
  var lastNow = 0
  var coinCarry = 0
  var dayCheck = 0
  var statusTick = 0
  function tick(now) {
    var dt = lastNow ? Math.min(0.06, (now - lastNow) / 1000) : 0.016
    lastNow = now

    state.onlineSeconds += dt
    tickHarvest(dt)
    updateHelpers(dt)
    processActions()

    if (workingNow()) {
      state.farmSeconds += dt
      coinCarry += dt * (COIN_PER_MINUTE / 60)
      if (coinCarry >= 1) {
        var gain = Math.floor(coinCarry)
        coinCarry -= gain
        state.coins += gain
        renderHeader()
      }
      if (farmer.phase === 'idle' && !actionQueue.length && Date.now() >= farmer.nextAt) {
        var autoIdx = pickAutoPlot(farmer)
        if (autoIdx >= 0) {
          enqueueAction(autoIdx, 'auto', true)
          farmer.nextAt = Date.now() + rand(1000, 2800) / (1 + state.helpers * 0.22)
        } else {
          farmer.nextAt = Date.now() + 1000
        }
      }
    }

    updateActor(farmer, dt)
    drawActor(farmer)
    drawHelpers()
    drawClerk(now)
    renderSparks()

    if (lookTimer > 0) lookTimer -= dt
    if (bubbleUntil && Date.now() > bubbleUntil) { bubbleUntil = 0; bubbleText = ''; renderBubble() }

    dayCheck -= dt
    if (dayCheck <= 0) {
      dayCheck = 1
      rollover()
      renderHeader()
      renderUsageStats()
      updateBubblePosition()
    }

    statusTick -= dt
    if (statusTick <= 0) {
      statusTick = 1
      renderStatus()
      renderUsageStats()
    }
    requestAnimationFrame(tick)
  }

  function boot() {
    if (DESKTOP) document.documentElement.classList.add('dsf-desktop')
    loadLocal()
    buildUI()
    fetch(PREFIX + '/api/snapshot', { cache: 'no-store' })
      .then(function (r) { return r.json() })
      .then(function (payload) {
        applySnapshot(payload && payload.data)
        // 存档里已有的帮手恢复出场
        updateHelpers(0)
      })
      .catch(function () {})
    window.__dshStardew = {
      version: VERSION,
      state: state,
      host: host,
      farmer: farmer,
      helperActors: helperActors,
      switchTab: switchTab,
      showIntro: showIntro,
      say: say,
      fitWindow: fitWindow,
      setWindowPreset: setWindowPreset,
      pressKey: function (key) { if (key) onKey(String(key)) },
      workingNow: workingNow,
      plotCenter: plotCenter,
      refreshUsage: renderUsageView,
      spriteNames: Object.keys(SPRITES),
      crops: CROPS,
      font: FONT,
      helpers: function () { return state.helpers },
      enqueueAuto: function (idx) { enqueueAction(Number(idx) || 0, 'auto', true) },
      clearQueue: function () {
        actionQueue.length = 0
        claims = {}
        farmer.job = null
        farmer.phase = 'idle'
        farmer.moving = false
      },
      selectTask: function (i) {
        var idx = clamp(Number(i) || 0, 0, host.todos.length - 1)
        state.selectedTask = idx
        state.selectedTaskKey = host.todos[idx] ? todoKey(host.todos[idx]) : ''
        renderTasksView()
      },
      // 自检/调试：直接驱动一次角色状态机（不依赖真实帧率）
      debugJob: function (idx, auto) { return startJob(farmer, Number(idx) || 0, auto !== false, 'auto') },
      advance: function (dt) { updateActor(farmer, Number(dt) || 0.016) },
    }
    if (Array.isArray(window.__dsfKeyQueue) && window.__dsfKeyQueue.length) {
      var queued = window.__dsfKeyQueue.splice(0)
      queued.forEach(function (key) { if (key) onKey(String(key)) })
    }
    window.addEventListener('beforeunload', function () {
      try {
        var body = JSON.stringify({ data: serialize() })
        if (navigator.sendBeacon) navigator.sendBeacon(PREFIX + '/api/mutate', new Blob([body], { type: 'application/json' }))
      } catch (e) { /* 忽略 */ }
    })
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot)
  else boot()
})()
