/**
 * 从 FarmLife / SunnysideWorld / IconsPropsMonsters 里只挑「农场相关」素材，
 * 裁成小农场用的精灵条与 UI 图集。
 *
 *   FARMLIFE_DIR=... FARMLIFE_PREVIEW=... FONT_SRC=... node assets/extract-farmlife.mjs
 *
 * 只处理文件名里带 farm / crop / seed / tool / ui / character / soil / grass /
 * water / tree / bush / rock / fence / flower / animal 等关键词的素材；
 * 不遍历 7GB 素材库，也不把整张 1024×1024 图集塞进页面。
 *
 * 产物：
 *   assets/sprites/*.png          动态精灵（角色 / 11 种作物 / 动物 / 土地 / 装饰）
 *   assets/sprites/index.json     精灵尺寸、帧数、作物表、字体映射
 *   assets/sprites/ui-atlas.css   静态 UI 图标 + 9-slice 的 CSS（data URI，构建时内联）
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { PNG } from '../desktop/node_modules/pngjs/lib/png.js'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const OUT = path.join(HERE, 'sprites')
const SRC = process.env.FARMLIFE_DIR || 'C:\\Users\\Kvein\\AppData\\Local\\Temp\\opencode\\farmlife'
const PREVIEW = process.env.FARMLIFE_PREVIEW || 'E:\\Projects\\_asset_preview\\FarmLife'
const FONT_SRC = process.env.FONT_SRC
  || 'C:\\Users\\Kvein\\AppData\\Local\\Temp\\opencode\\iconsprops\\IconsPropsMonsters\\Menu\\Text\\Text (Black) (8x10).png'
const FONT_WHITE_SRC = FONT_SRC.replace('Text (Black)', 'Text (White)')
if (!fs.existsSync(SRC)) throw new Error('找不到 FarmLife 素材目录：' + SRC)
if (!fs.existsSync(PREVIEW)) throw new Error('找不到 FarmLife 预览目录：' + PREVIEW)
fs.mkdirSync(OUT, { recursive: true })

const load = (dir, name) => PNG.sync.read(fs.readFileSync(path.join(dir, name)))
const blank = (w, h) => {
  const p = new PNG({ width: w, height: h })
  p.data.fill(0)
  return p
}
const px = (p, x, y) => (y * p.width + x) * 4
function blit(dst, src, dx, dy) {
  for (let y = 0; y < src.height; y++) for (let x = 0; x < src.width; x++) {
    const tx = dx + x, ty = dy + y
    if (tx < 0 || ty < 0 || tx >= dst.width || ty >= dst.height) continue
    const si = px(src, x, y), di = px(dst, tx, ty)
    const sa = src.data[si + 3] / 255
    if (sa <= 0) continue
    const da = dst.data[di + 3] / 255
    const oa = sa + da * (1 - sa)
    if (oa <= 0) continue
    for (let c = 0; c < 3; c++) {
      dst.data[di + c] = Math.round((src.data[si + c] * sa + dst.data[di + c] * da * (1 - sa)) / oa)
    }
    dst.data[di + 3] = Math.round(oa * 255)
  }
}
function crop(src, x, y, w, h) {
  const out = blank(w, h)
  blit(out, src, -x, -y)
  return out
}
function flipX(src) {
  const out = blank(src.width, src.height)
  for (let y = 0; y < src.height; y++) for (let x = 0; x < src.width; x++) {
    const si = px(src, x, y), di = px(out, src.width - 1 - x, y)
    for (let c = 0; c < 4; c++) out.data[di + c] = src.data[si + c]
  }
  return out
}
function sheet(frames, w, h) {
  const out = blank(w * frames.length, h)
  frames.forEach((f, i) => blit(out, f, i * w, 0))
  return out
}
function trim(src) {
  let minX = src.width, minY = src.height, maxX = -1, maxY = -1
  for (let y = 0; y < src.height; y++) for (let x = 0; x < src.width; x++) {
    if (src.data[px(src, x, y) + 3] > 8) {
      if (x < minX) minX = x
      if (x > maxX) maxX = x
      if (y < minY) minY = y
      if (y > maxY) maxY = y
    }
  }
  if (maxX < 0) return { x: 0, y: 0, w: src.width, h: src.height }
  return { x: minX, y: minY, w: maxX - minX + 1, h: maxY - minY + 1 }
}
function placeFit(dst, src, maxW, maxH) {
  const b = trim(src)
  let sw = b.w, sh = b.h
  let scaled = null
  if (sw > maxW || sh > maxH) {
    const s = Math.min(maxW / sw, maxH / sh)
    sw = Math.max(1, Math.floor(sw * s))
    sh = Math.max(1, Math.floor(sh * s))
    scaled = blank(sw, sh)
    for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) {
      const sx = b.x + Math.min(b.w - 1, Math.floor(x / s))
      const sy = b.y + Math.min(b.h - 1, Math.floor(y / s))
      const si = px(src, sx, sy), di = px(scaled, x, y)
      for (let c = 0; c < 4; c++) scaled.data[di + c] = src.data[si + c]
    }
  }
  const img = scaled || crop(src, b.x, b.y, b.w, b.h)
  const dx = Math.floor((maxW - sw) / 2)
  const dy = maxH - sh
  blit(dst, img, dx, dy)
}
function framesFromStrip(src, frameW, frameH, count, outW, outH, offsetX = 0, offsetY = 0) {
  const list = []
  for (let i = 0; i < count; i++) {
    const f = blank(outW, outH)
    blit(f, src, -i * frameW + offsetX, offsetY)
    list.push(f)
  }
  return list
}
const meta = {}
function set(name, png, frames, note) {
  fs.writeFileSync(path.join(OUT, name + '.png'), PNG.sync.write(png))
  meta[name] = { w: Math.round(png.width / frames), h: png.height, frames, note }
}
function setStatic(name, png, note) {
  fs.writeFileSync(path.join(OUT, name + '.png'), PNG.sync.write(png))
  meta[name] = { w: png.width, h: png.height, frames: 1, note }
}
function makeBack(frame, w, h) {
  const out = blank(w, h)
  blit(out, frame, 0, 0)
  const alphaAt = (x, y) => (x < 0 || y < 0 || x >= w || y >= h ? 0 : out.data[px(out, x, y) + 3])
  let minX = w, minY = h, maxX = -1
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    if (out.data[px(out, x, y) + 3] < 8) continue
    if (x < minX) minX = x
    if (x > maxX) maxX = x
    if (y < minY) minY = y
  }
  if (maxX < 0) return out
  // 头顶几行决定头部宽度，避免把旁边的工具/手也涂成头发
  let headX0 = w, headX1 = -1
  for (let y = minY; y < Math.min(h, minY + 3); y++) for (let x = 0; x < w; x++) {
    if (out.data[px(out, x, y) + 3] < 8) continue
    if (x < headX0) headX0 = x
    if (x > headX1) headX1 = x
  }
  const headBottom = Math.min(h - 1, minY + 12)
  const hair = [117, 61, 58]
  for (let y = minY; y <= headBottom; y++) {
    for (let x = Math.max(0, headX0 - 1); x <= Math.min(w - 1, headX1 + 1); x++) {
      const i = px(out, x, y)
      if (out.data[i + 3] < 8) continue
      const r = out.data[i], g = out.data[i + 1], b = out.data[i + 2]
      const edge = alphaAt(x - 1, y) < 8 || alphaAt(x + 1, y) < 8
        || alphaAt(x, y - 1) < 8 || alphaAt(x, y + 1) < 8
      // 保留外轮廓线；其余皮肤/眼睛/脸内部统一成头发色，得到干净背面
      if (edge && (r + g + b) < 190) continue
      out.data[i] = hair[0]
      out.data[i + 1] = hair[1]
      out.data[i + 2] = hair[2]
    }
  }
  return out
}

// ---------------------------------------------------------------------------
// 角色：FarmLife 只有正面帧。右向用镜像，上向用「干净的背面」回退。
// 统一画布 64×34，给干活动作里的工具留出位置，避免帧切换时人物跳动。
// ---------------------------------------------------------------------------
const FW = 64, FH = 34
const idleSrc = load(SRC, 'spr_basecharacter_idle_strip9.png')
const walkSrc = load(SRC, 'spr_basecharacter_walk_strip8.png')
const doingSrc = load(SRC, 'spr_basecharacter_doing_strip8.png')
const idleFront = framesFromStrip(idleSrc, 49, 34, 9, FW, FH, 8, 0)
const walkFront = framesFromStrip(walkSrc, 49, 34, 8, FW, FH, 8, 0)
const actFront = framesFromStrip(doingSrc, 64, 34, 8, FW, FH, 0, 0)
const idleBack = idleFront.map((f) => makeBack(f, FW, FH))
const walkBack = walkFront.map((f) => makeBack(f, FW, FH))
const actBack = actFront.map((f) => makeBack(f, FW, FH))
const dirs = {
  down: [idleFront, walkFront, actFront],
  left: [idleFront, walkFront, actFront],
  right: [idleFront.map(flipX), walkFront.map(flipX), actFront.map(flipX)],
  up: [idleBack, walkBack, actBack],
}
for (const dir of Object.keys(dirs)) {
  const [idle, walk, act] = dirs[dir]
  set('farmer_idle_' + dir, sheet(idle, FW, FH), 9, '农夫 idle · ' + dir + '（FarmLife）')
  set('farmer_walk_' + dir, sheet(walk, FW, FH), 8, '农夫走路 · ' + dir + '（FarmLife）')
  set('farmer_act_' + dir, sheet(act, FW, FH), 8, '农夫干活 · ' + dir + '（FarmLife）')
  set('farmer_' + dir, sheet(walk, FW, FH), 8, '农夫走路 · ' + dir + '（兼容别名）')
}

// 记录员：紫色衣服角色，工时页专用
const clerkIdleSrc = load(SRC, 'spr_idle_strip9.png')
const clerkDoingSrc = load(SRC, 'spr_doing_strip8.png')
const clerkIdle = framesFromStrip(clerkIdleSrc, 96, 64, 9, FW, FH, -18, -7)
const clerkWork = framesFromStrip(clerkDoingSrc, 96, 64, 8, FW, FH, -18, -8)
set('clerk_idle', sheet(clerkIdle, FW, FH), 9, '工时记录员 idle（FarmLife）')
set('clerk_work', sheet(clerkWork, FW, FH), 8, '工时记录员干活（FarmLife）')

// ---------------------------------------------------------------------------
// 作物：11 种真实 FarmLife 作物，每种 6 帧，统一 16×20 画布，底部对齐
// ---------------------------------------------------------------------------
const CROP_DEFS = [
  ['beetroot', '甜菜根'],
  ['cabbage', '甘蓝'],
  ['cauliflower', '花椰菜'],
  ['carrot', '胡萝卜'],
  ['kale', '羽衣甘蓝'],
  ['potato', '土豆'],
  ['pumpkin', '南瓜'],
  ['radish', '萝卜'],
  ['parsnip', '欧防风'],
  ['sunflower', '向日葵'],
  ['wheat', '小麦'],
]
const crops = {}
for (const [key, name] of CROP_DEFS) {
  const frames = []
  for (let i = 0; i < 6; i++) {
    const f = blank(16, 20)
    placeFit(f, load(PREVIEW, key + '_0' + i + '.png'), 16, 20)
    frames.push(f)
  }
  set('crop_' + key, sheet(frames, 16, 20), 6, '作物：' + name + ' 6 阶段（FarmLife）')
  crops[key] = { name, sprite: 'crop_' + key }
}

// ---------------------------------------------------------------------------
// 土地 / 水 / 草
// ---------------------------------------------------------------------------
setStatic('soil', load(SRC, 'soil_00.png'), '耕地土块（FarmLife soil_00）')
setStatic('soil_wet', load(SRC, 'soil_04.png'), '湿土块（FarmLife soil_04）')
setStatic('water_tile', load(SRC, 'cand_water1.png'), '水面平铺（FarmLife cand_water1）')
setStatic('grass_tile', crop(load(SRC, 'cand_grass1.png'), 32, 48, 64, 64), '草地平铺（FarmLife cand_grass1 纯色区域）')
setStatic('basket', load(SRC, 'basket.png'), '收获篮（FarmLife）')
setStatic('plant', load(SRC, 'plant.png'), '幼苗（FarmLife）')
setStatic('seed', load(PREVIEW, 'seeds_generic.png'), '种子袋（FarmLife）')
setStatic('egg', load(PREVIEW, 'egg.png'), '鸡蛋（FarmLife）')
setStatic('milk', load(PREVIEW, 'milk.png'), '牛奶（FarmLife）')
setStatic('fish', load(PREVIEW, 'fish.png'), '鱼（FarmLife）')
setStatic('itemdisc', load(PREVIEW, 'itemdisc_01.png'), '金币圆盘（FarmLife）')
setStatic('sandtimer', load(PREVIEW, 'sandtimer.png'), '沙漏（FarmLife）')
setStatic('stopwatch', load(PREVIEW, 'stopwatch.png'), '秒表（FarmLife）')
setStatic('plan', load(PREVIEW, 'plan alt.png'), '计划板（FarmLife）')

// ---------------------------------------------------------------------------
// SunnysideWorld 场景装饰（坐标来自连通域分析，已修正旧版错位）
// ---------------------------------------------------------------------------
const world = load(PREVIEW, 'SunnysideWorld_Tileset_V0.1.png')
const prop = (name, x, y, w, h, note) => setStatic(name, crop(world, x, y, w, h), note)
// 两块真正的泥土贴图：一块偏方、一块偏圆，按地块奇偶交替铺
const dirtPatch = (name, x, y, w, h, note) => {
  const png = crop(world, x, y, w, h)
  for (let i = 0; i < png.data.length; i += 4) {
    const r = png.data[i], g = png.data[i + 1], b = png.data[i + 2], a = png.data[i + 3]
    if (a > 8 && g > r * 1.2 && g > b * 1.3 && g > 110) png.data[i + 3] = 0
  }
  setStatic(name, png, note)
}
dirtPatch('dirt_patch', 239, 44, 50, 53, '方形泥土贴图（SunnysideWorld）')
dirtPatch('dirt_patch_round', 304, 44, 48, 52, '圆形泥土贴图（SunnysideWorld）')
prop('tree_big', 11, 43, 90, 83, '大树（SunnysideWorld）')
prop('tree_fruit', 35, 342, 26, 34, '果树（SunnysideWorld）')
prop('tree_fruit2', 67, 342, 26, 34, '果树 2（SunnysideWorld）')
prop('tree_orange', 35, 390, 26, 34, '橙果树（SunnysideWorld）')
prop('bush', 67, 310, 25, 21, '灌木（SunnysideWorld）')
prop('berry_bush', 35, 310, 25, 21, '红果灌木（SunnysideWorld）')
prop('stump', 99, 390, 26, 24, '树桩（SunnysideWorld）')
prop('pond', 94, 125, 52, 69, '水塘（SunnysideWorld）')
prop('rock_small', 17, 195, 14, 10, '小石头（SunnysideWorld）')
prop('rock_big', 32, 194, 16, 11, '大石头（SunnysideWorld）')
prop('flower_patch', 16, 210, 32, 14, '花丛（SunnysideWorld）')
prop('grass_tuft', 16, 432, 32, 16, '草丛（SunnysideWorld）')
prop('stone_wall', 112, 240, 64, 16, '石墙（SunnysideWorld）')
prop('fence', 21, 242, 70, 59, '木栅栏（SunnysideWorld）')

// ---------------------------------------------------------------------------
// 帮手：4 只现有 side-view 动物（FarmLife 没有动物素材）
// ---------------------------------------------------------------------------
for (const name of ['cow', 'goat', 'pig', 'sheep']) {
  const src = path.join(OUT, name + '.png')
  if (!fs.existsSync(src)) continue
  const png = PNG.sync.read(fs.readFileSync(src))
  meta[name] = { w: Math.round(png.width / 4), h: png.height, frames: 4, note: '帮手（现有 side-view 动物素材）' }
}

// ---------------------------------------------------------------------------
// 表情 / UI 动态条
// ---------------------------------------------------------------------------
const expr = (name, file) => setStatic(name, load(PREVIEW, file), '表情：' + file)
expr('expr_working', 'expression_working.png')
expr('expr_chat', 'expression_chat.png')
expr('expr_love', 'expression_love.png')
expr('expr_happy1', 'happiness_01.png')
expr('expr_happy2', 'happiness_02.png')
expr('expr_happy3', 'happiness_03.png')
expr('expr_happy4', 'happiness_04.png')
expr('expr_alert', 'expression_alerted.png')
expr('expr_confused', 'expression_confused.png')
expr('expr_stress', 'expression_stress.png')

const bar = (name, prefix, count) => {
  const frames = []
  for (let i = 0; i < count; i++) frames.push(load(PREVIEW, prefix + '_0' + i + '.png'))
  set(name, sheet(frames, 15, 7), count, 'UI 进度条 ' + prefix)
}
bar('bar_green', 'greenbar', 7)
bar('bar_blue', 'bluebar', 6)
bar('bar_red', 'redbar', 7)

// ---------------------------------------------------------------------------
// 8×10 位图字体（ASCII 用素材字体，中文继续系统字体）
// ---------------------------------------------------------------------------
let font = null
if (fs.existsSync(FONT_SRC)) {
  const black = PNG.sync.read(fs.readFileSync(FONT_SRC))
  setStatic('font_black', black, '8×10 位图字体（黑）')
  if (fs.existsSync(FONT_WHITE_SRC)) {
    setStatic('font_white', PNG.sync.read(fs.readFileSync(FONT_WHITE_SRC)), '8×10 位图字体（白）')
  }
  font = {
    // 字库第 3 行只有 U–Z 六个字形，后面留 4 个空位，数字从第 30 格开始
    chars: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' + '\u0001'.repeat(4) + '0123456789.,:?!()+-',
    cols: 10,
    rows: 5,
    cw: 8,
    ch: 10,
    black: 'font_black',
    white: 'font_white',
  }
}

// ---------------------------------------------------------------------------
// UI 静态图集：去绿底、9-slice 拼图、生成 CSS
// ---------------------------------------------------------------------------
const uiSheet = load(PREVIEW, 'SUNNYSIDE_WORLD_UI_V1.png')
const isUiBg = (r, g, b) =>
  (Math.abs(r - 80) < 14 && Math.abs(g - 155) < 14 && Math.abs(b - 75) < 14) ||
  (Math.abs(r - 62) < 14 && Math.abs(g - 137) < 14 && Math.abs(b - 72) < 14)
function uiCrop(x, y, w, h) {
  const out = blank(w, h)
  for (let yy = 0; yy < h; yy++) for (let xx = 0; xx < w; xx++) {
    const si = px(uiSheet, x + xx, y + yy), di = px(out, xx, yy)
    const r = uiSheet.data[si], g = uiSheet.data[si + 1], b = uiSheet.data[si + 2]
    if (isUiBg(r, g, b)) continue
    for (let c = 0; c < 4; c++) out.data[di + c] = uiSheet.data[si + c]
  }
  return out
}
function nineSlice(prefix) {
  const names = ['tl', 'tc', 'tr', 'lc', 'c', 'rc', 'bl', 'bc', 'br']
  const out = blank(9, 9)
  names.forEach((n, i) => {
    const cell = load(PREVIEW, prefix + '_9slice_' + n + '.png')
    blit(out, cell, (i % 3) * 3, Math.floor(i / 3) * 3)
  })
  return out
}
const panelLight = nineSlice('lt_box')
const panelDark = nineSlice('dt_box')
const panelWhite = nineSlice('w_box')
const label = blank(24, 13)
blit(label, load(PREVIEW, 'label_left.png'), 0, 0)
for (let x = 0; x < 16; x++) blit(label, load(PREVIEW, 'label_middle.png'), 4 + x, 0)
blit(label, load(PREVIEW, 'label_right.png'), 20, 0)
const select = blank(16, 18)
blit(select, load(PREVIEW, 'selectbox_tl.png'), 0, 0)
blit(select, load(PREVIEW, 'selectbox_tr.png'), 8, 0)
blit(select, load(PREVIEW, 'selectbox_bl.png'), 0, 9)
blit(select, load(PREVIEW, 'selectbox_br.png'), 8, 9)

const UI = {
  panel_light: panelLight,
  panel_dark: panelDark,
  panel_white: panelWhite,
  label,
  select,
  heart: uiCrop(60, 52, 36, 32),
  avatar: uiCrop(40, 96, 64, 88),
  hardhat: uiCrop(388, 4, 52, 56),
  basket: uiCrop(520, 136, 48, 48),
  plant: uiCrop(584, 136, 48, 48),
  axe: uiCrop(640, 136, 60, 52),
  watering: uiCrop(644, 72, 52, 52),
  pickaxe: uiCrop(584, 268, 44, 44),
  hand: uiCrop(388, 260, 48, 52),
  circle: uiCrop(460, 264, 44, 48),
  face_green: uiCrop(852, 208, 28, 32),
  face_red: uiCrop(916, 212, 28, 28),
  face_pink: uiCrop(976, 204, 32, 36),
  face_yellow: uiCrop(852, 272, 28, 32),
  face_blue: uiCrop(916, 272, 28, 36),
  face_exclaim: uiCrop(984, 272, 16, 36),
  face_orange: uiCrop(852, 336, 28, 32),
  face_cry: uiCrop(916, 336, 28, 32),
  face_question: uiCrop(980, 332, 28, 40),
  face_anger: uiCrop(852, 400, 28, 32),
  face_love: uiCrop(912, 400, 36, 32),
  face_chat: uiCrop(972, 400, 36, 36),
  check: uiCrop(908, 456, 48, 44),
  cross: uiCrop(848, 456, 44, 44),
  cursor_up: uiCrop(912, 16, 32, 36),
  cursor_down: uiCrop(912, 80, 32, 36),
  cursor_right: uiCrop(976, 16, 32, 36),
  cursor_left: uiCrop(976, 80, 32, 36),
}

const b64 = (png) => 'data:image/png;base64,' + PNG.sync.write(png).toString('base64')
let atlas = '/* 自动生成：FarmLife / SunnysideWorld UI 图集（去绿底） */\n'
atlas += '.dsf-panel-skin{border:8px solid transparent;border-image:url(' + b64(panelLight) + ') 3 fill / 8px stretch;background:#f3d9a4;}\n'
atlas += '.dsf-panel-paper{border:8px solid transparent;border-image:url(' + b64(panelLight) + ') 3 / 8px stretch;background:#f7e8c3;}\n'
atlas += '.dsf-panel-dark{border:8px solid transparent;border-image:url(' + b64(panelDark) + ') 3 fill / 8px stretch;background:#4b2c16;}\n'
atlas += '.dsf-panel-white{border:8px solid transparent;border-image:url(' + b64(panelWhite) + ') 3 fill / 8px stretch;background:#fff8e6;}\n'
atlas += '.dsf-label-skin{border:4px solid transparent;border-image:url(' + b64(label) + ') 4 fill / 4px stretch;background:#c98d4e;}\n'
atlas += '.dsf-label-paper{border:4px solid transparent;border-image:url(' + b64(label) + ') 4 / 4px stretch;background:#f7e8c3;}\n'
atlas += '.dsf-select-skin{border:5px solid transparent;border-image:url(' + b64(select) + ') 9 8 9 8 fill / 5px stretch;}\n'
for (const [name, png] of Object.entries(UI)) {
  if (['panel_light', 'panel_dark', 'panel_white', 'label', 'select'].includes(name)) continue
  atlas += '.dsf-ico-' + name + '{background-image:url(' + b64(png) + ');}\n'
}
fs.writeFileSync(path.join(OUT, 'ui-atlas.css'), atlas)

const index = { sprites: meta, crops, font }
fs.writeFileSync(path.join(OUT, 'index.json'), JSON.stringify(index, null, 1))
console.log('[farmlife] 生成精灵 ' + Object.keys(meta).length + ' 条 / 作物 ' + Object.keys(crops).length + ' 种 / UI ' + Object.keys(UI).length + ' 项')
