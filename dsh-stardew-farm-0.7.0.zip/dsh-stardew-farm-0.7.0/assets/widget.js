/*!
 * dsh-stardew-farm —— 页面脚本（自包含：样式、位图字体与精灵图都由构建内联）
 *
 * v0.7：全面换成 FarmLife / SunnysideWorld 素材
 *   · 26 块 A–Z 固定地 + 11 种真实 FarmLife 作物（6 帧，成熟映射 0/2/4/5）
 *   · 小人：走路 → 到位 → 完整干活动作 → 开心表情 1 秒 → 下一块地
 *   · 帮手：解锁后像小人一样独立选地、走路、干活、推进作物，不再只跟着小人
 *   · 待办：SSE 实时 + 宿主启动时水合；当前项高亮，点击可选中
 *   · 气泡：按农场容器边界自动限宽/夹紧位置，不会越界
 *   · 字体：ASCII 用素材包 8×10 位图字库，中文继续系统字体
 */
(function () {
  'use strict'
  if (window.__dshStardewFarm) return
  window.__dshStardewFarm = true

  var VERSION = '0.7.0'
  var PREFIX = '/dsh-stardew'
  var LS_KEY = 'dsh-stardew-farm:v5'
  var LS_KEY_V4 = 'dsh-stardew-farm:v4'
  var DESKTOP = !!window.__DSF_DESKTOP__
  var GLOBAL_KEYS = !!window.__DSF_GLOBAL_KEYS__

  var DSF_CSS = "/* dsh-stardew-farm —— FarmLife / SunnysideWorld 像素小农场\n *\n * v0.7 布局：\n *   标题栏 → 状态条 → 5 个页签 → 内容卡片（农场页带底部状态栏）\n *   土地是干净的 7×4 网格；工时放在底部状态栏，不再用浮动牌子压住土地。\n * ASCII 走素材 8×10 位图字库，中文走系统字体。\n */\n\n.dsf-root {\n  --dsf-scale: 1.5;\n  --paper: #fef4d8;\n  --paper-2: #f5dda9;\n  --ink: #33250f;\n  --wood: #936a3a;\n  --wood-dark: #543518;\n  --wood-hi: #d9a463;\n  --leaf: #5ca930;\n  --grass: #88c84d;\n  --grass-dark: #6da83c;\n  position: fixed;\n  left: 14px;\n  bottom: 14px;\n  z-index: 2147482000;\n  width: 300px;\n  transform-origin: bottom left;\n  transform: scale(var(--dsf-scale));\n  font-family: 'Zpix', 'WenQuanYi Bitmap Song', 'Noto Sans SC', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;\n  font-size: 11px;\n  color: var(--ink);\n  user-select: none;\n  -webkit-user-select: none;\n}\n.dsf-root.dsf-pos-br { left: auto; right: 14px; transform-origin: bottom right; }\n.dsf-root.dsf-pos-tl { bottom: auto; top: 56px; transform-origin: top left; }\n.dsf-root.dsf-pos-tr { bottom: auto; top: 56px; left: auto; right: 14px; transform-origin: top right; }\n\n/* ---------------- 位图字体 ---------------- */\n.dsf-btext {\n  display: inline-flex;\n  align-items: center;\n  flex-wrap: wrap;\n  line-height: 10px;\n  vertical-align: middle;\n  min-height: 10px;\n}\n.dsf-glyph {\n  display: inline-block;\n  width: 8px;\n  height: 10px;\n  flex: none;\n  background-repeat: no-repeat;\n  image-rendering: pixelated;\n  vertical-align: top;\n  font-size: 0;\n  line-height: 0;\n  color: transparent;\n  overflow: hidden;\n}\n.dsf-glyph-space { display: inline-block; width: 4px; height: 10px; flex: none; font-size: 0; color: transparent; }\n.dsf-cjk {\n  font-family: inherit;\n  font-size: 11px;\n  line-height: 1.25;\n  white-space: pre-wrap;\n  word-break: break-word;\n}\n\n/* ---------------- 外框 ---------------- */\n.dsf-frame {\n  box-sizing: border-box;\n  position: relative;\n  width: 100%;\n  border: 8px solid #543518;\n  border-radius: 10px;\n  background-color: var(--paper);\n  background-image:\n    radial-gradient(circle at 24% 28%, rgba(147, 106, 58, .055) 0 1px, transparent 1.5px),\n    radial-gradient(circle at 72% 64%, rgba(147, 106, 58, .04) 0 1px, transparent 1.5px);\n  background-size: 11px 11px, 17px 17px;\n  box-shadow: \n    inset 0 0 0 3px #d9a463, \n    inset 0 0 0 4px rgba(84, 53, 24, .3),\n    0 6px 0 #2a1a0c, \n    0 12px 28px rgba(0, 0, 0, .4);\n  overflow: hidden;\n  padding: 4px 7px 7px;\n}\n/* 四角木钉，让它更像一块钉在桌面上的木牌 */\n.dsf-frame::before,\n.dsf-frame::after {\n  content: '';\n  position: absolute;\n  top: 5px;\n  width: 5px;\n  height: 5px;\n  border-radius: 50%;\n  background: radial-gradient(circle at 35% 30%, #ffe2a8, #b98243 55%, #6b431d 100%);\n  box-shadow: 0 1px 0 rgba(42, 26, 12, .45);\n  z-index: 30;\n  pointer-events: none;\n}\n.dsf-frame::before { left: 5px; }\n.dsf-frame::after { right: 5px; }\n\n/* ---------------- 标题栏 ---------------- */\n.dsf-header {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n  padding: 2px 1px 6px;\n  border-bottom: 2px solid rgba(84, 53, 24, .25);\n  margin-bottom: 5px;\n  min-height: 20px;\n  position: relative;\n  background: linear-gradient(180deg, rgba(255, 250, 226, .55), rgba(255, 250, 226, 0));\n}\n.dsf-header::after {\n  content: '';\n  position: absolute;\n  left: 3%;\n  right: 3%;\n  bottom: 1px;\n  height: 1px;\n  background: linear-gradient(90deg, transparent, rgba(217, 164, 99, .9), transparent);\n  pointer-events: none;\n}\n.dsf-logo {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  padding: 2px 6px;\n  min-height: 16px;\n  background: linear-gradient(#543518, #3d2612);\n  border: 1px solid #2a1a0c;\n  border-radius: 4px;\n  box-shadow: inset 0 1px 0 rgba(217, 164, 99, .3), 0 1px 0 rgba(255, 255, 255, .15);\n  position: relative;\n}\n.dsf-logo::before,\n.dsf-logo::after {\n  content: '';\n  position: absolute;\n  top: 3px;\n  width: 3px;\n  height: 3px;\n  border-radius: 50%;\n  background: #d9a463;\n  box-shadow: 0 1px 0 #2a1a0c;\n}\n.dsf-logo::before { left: 3px; }\n.dsf-logo::after { right: 3px; }\n.dsf-title {\n  display: flex;\n  align-items: center;\n  font-weight: 800;\n  color: #543518;\n  flex: 1;\n  min-width: 0;\n  font-size: 11px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  text-shadow: 0 1px 0 rgba(255, 255, 255, .7);\n}\n.dsf-title .dsf-cjk { font-size: 11px; }\n.dsf-coins {\n  display: inline-flex;\n  align-items: center;\n  gap: 2px;\n  flex: none;\n  font-variant-numeric: tabular-nums;\n  font-weight: 800;\n  color: #8a5a00;\n  background: linear-gradient(#fffae0, #f9d97a);\n  border: 1px solid #b88a32;\n  border-radius: 5px;\n  padding: 0 5px 0 3px;\n  line-height: 17px;\n  min-height: 18px;\n  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .5), 0 1px 0 rgba(0, 0, 0, .1);\n}\n.dsf-coins .dsf-spr {\n  width: 13px !important;\n  height: 13px !important;\n  background-size: contain !important;\n  background-position: center !important;\n  filter: sepia(1) saturate(3.2) hue-rotate(-12deg) brightness(1.12);\n}\n.dsf-iconbtn {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  font: inherit;\n  width: 21px;\n  height: 21px;\n  line-height: 1;\n  padding: 0;\n  border: 1px solid #543518;\n  border-radius: 5px;\n  background: linear-gradient(#f9dda3, #d9a463);\n  color: #4a2e0c;\n  cursor: pointer;\n  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .4), 0 1px 0 rgba(0, 0, 0, .1);\n  transition: all .1s;\n}\n.dsf-iconbtn .dsf-ico { width: 12px; height: 12px; }\n.dsf-system-ico { font-size: 13px; line-height: 1; transform: translateY(-1px); }\n.dsf-iconbtn:hover { \n  filter: brightness(1.1); \n  transform: translateY(-1px);\n  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .4), 0 2px 0 rgba(0, 0, 0, .1);\n}\n.dsf-iconbtn:active { \n  transform: translateY(1px); \n  box-shadow: inset 0 1px 2px rgba(0, 0, 0, .2);\n}\n\n/* ---------------- 状态条 ---------------- */\n.dsf-statusbar {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  gap: 3px;\n  padding: 0 0 4px;\n  color: #5c4418;\n  min-height: 16px;\n}\n.dsf-status-item {\n  display: inline-flex;\n  align-items: center;\n  gap: 2px;\n  flex: none;\n  padding: 0 5px;\n  min-height: 15px;\n  line-height: 15px;\n  border: 1px solid #d3b87e;\n  border-radius: 8px;\n  background: linear-gradient(#fff8e3, #f2e2b8);\n  white-space: nowrap;\n}\n.dsf-status-item .dsf-cjk { font-size: 9px; }\n.dsf-status-busy {\n  border-color: #7cae4a;\n  background: linear-gradient(#e9ffd2, #cbe9a4);\n  color: #2f5a12;\n  font-weight: 700;\n}\n.dsf-status-busy::before {\n  content: '';\n  width: 5px;\n  height: 5px;\n  border-radius: 50%;\n  background: #4f9e22;\n  animation: dsf-dot-pulse 1.3s ease-out infinite;\n}\n.dsf-desktop-badge {\n  border-color: #7ea6d8;\n  background: linear-gradient(#eaf4ff, #cfe4fb);\n  color: #24476e;\n  font-weight: 700;\n}\n@keyframes dsf-dot-pulse {\n  0% { box-shadow: 0 0 0 0 rgba(79, 158, 34, .5); }\n  70% { box-shadow: 0 0 0 4px rgba(79, 158, 34, 0); }\n  100% { box-shadow: 0 0 0 0 rgba(79, 158, 34, 0); }\n}\n\n/* ---------------- 页签 ---------------- */\n.dsf-tabbar {\n  display: grid;\n  grid-template-columns: repeat(5, minmax(0, 1fr));\n  gap: 4px;\n  padding: 3px 4px 4px;\n  margin-bottom: 2px;\n  border: 1px solid #543518;\n  border-radius: 8px;\n  background: linear-gradient(#c99a5c, #a9773f);\n  box-shadow:\n    inset 0 1px 0 rgba(255, 235, 180, .35),\n    inset 0 -2px 0 rgba(84, 53, 24, .35),\n    0 2px 0 rgba(42, 26, 12, .28);\n}\n.dsf-tabbtn {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 2px;\n  min-width: 0;\n  min-height: 25px;\n  font: inherit;\n  font-size: 9px;\n  padding: 3px 2px;\n  border: 1px solid #8a5a2b;\n  border-radius: 5px;\n  background: linear-gradient(#f9e8bd, #e2c989);\n  color: #5a3d18;\n  cursor: pointer;\n  white-space: nowrap;\n  overflow: hidden;\n  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .45), 0 1px 0 rgba(42, 26, 12, .25);\n  transition: all .1s;\n}\n.dsf-tab-ico {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 14px;\n  height: 14px;\n  flex: none;\n  overflow: hidden;\n}\n.dsf-tab-ico .dsf-spr { image-rendering: pixelated; }\n.dsf-tab-label { line-height: 12px; }\n.dsf-tabbtn:hover { \n  filter: brightness(1.08); \n  transform: translateY(-1px);\n  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .3), 0 2px 0 rgba(0, 0, 0, .05);\n}\n.dsf-tabbtn.dsf-tab-on {\n  background: linear-gradient(#fffcf0, #fef4d8);\n  border-color: #936a3a;\n  color: #33250f;\n  font-weight: 800;\n  box-shadow: \n    inset 0 0 0 1px rgba(147, 106, 58, .2),\n    inset 0 -3px 0 #f0c25a,\n    0 2px 0 rgba(0, 0, 0, .1);\n  transform: translateY(0);\n}\n.dsf-tabbtn.dsf-tab-on:hover {\n  transform: translateY(0);\n}\n\n/* ---------------- 视图 / 分区 ---------------- */\n.dsf-view { display: none; }\n.dsf-view.dsf-view-on { display: block; }\n.dsf-sec-label {\n  font-size: 10px;\n  color: #6d4a17;\n  font-weight: 700;\n  letter-spacing: .3px;\n  text-shadow: 0 1px 0 #fff6db;\n  margin-bottom: 2px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.dsf-spr { background-repeat: no-repeat; image-rendering: pixelated; display: block; flex: none; }\n\n/* ---------------- 农场页 ---------------- */\n.dsf-field {\n  border: 2px solid #7a9e4b;\n  border-radius: 7px;\n  background: linear-gradient(135deg, #a0d968 0%, #88c84d 50%, #6fae3a 100%);\n  padding: 5px 6px 6px;\n  overflow: hidden;\n  box-shadow: \n    inset 0 0 0 1px rgba(255, 255, 255, .2),\n    inset 0 2px 4px rgba(70, 105, 34, .15),\n    0 2px 0 rgba(0, 0, 0, .1);\n}\n.dsf-fieldhead {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 6px;\n  min-height: 18px;\n  padding: 2px 6px;\n  margin-bottom: 4px;\n  border: 1px solid rgba(122, 86, 34, .65);\n  border-radius: 5px;\n  background: linear-gradient(#fff8e6, #f3dfb2);\n  box-shadow:\n    inset 0 1px 0 rgba(255, 255, 255, .7),\n    0 1px 0 rgba(70, 105, 34, .25);\n}\n.dsf-fieldhead .dsf-sec-label { margin-bottom: 0; }\n.dsf-fieldstats {\n  display: inline-flex;\n  align-items: center;\n  flex: none;\n  font-size: 9px;\n  color: #4e3a12;\n  background: rgba(254, 252, 240, .92);\n  border: 1px solid #d3b87e;\n  border-radius: 7px;\n  padding: 0 6px;\n  min-height: 16px;\n  line-height: 16px;\n  white-space: nowrap;\n  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .6), 0 1px 0 rgba(0, 0, 0, .05);\n}\n.dsf-fieldstats .dsf-cjk { font-size: 9px; }\n.dsf-fieldbody {\n  position: relative;\n  height: 166px;\n  margin-top: 4px;\n  border-radius: 5px;\n  overflow: hidden;\n  background-color: #88c84d;\n  background-repeat: repeat;\n  border: 1px solid rgba(70, 105, 34, .5);\n  image-rendering: pixelated;\n  box-shadow: inset 0 2px 4px rgba(70, 105, 34, .2);\n}\n/* 细碎的草地明暗，不画横条，避免看起来像一条条色带 */\n.dsf-fieldbody::before {\n  content: '';\n  position: absolute;\n  inset: 0;\n  background:\n    radial-gradient(circle at 20% 30%, rgba(160, 217, 104, .18) 0 1px, transparent 2px) 0 0 / 19px 19px,\n    radial-gradient(circle at 70% 65%, rgba(70, 105, 34, .14) 0 1px, transparent 2px) 0 0 / 23px 23px,\n    radial-gradient(circle at 45% 85%, rgba(255, 255, 200, .08) 0 1px, transparent 1.5px) 0 0 / 17px 17px;\n  pointer-events: none;\n  z-index: 1;\n}\n.dsf-plots { position: absolute; inset: 0; z-index: 2; }\n.dsf-plot {\n  position: absolute;\n  width: 32px;\n  height: 32px;\n  border-radius: 5px;\n  cursor: pointer;\n  transition: all .12s;\n}\n.dsf-plot::before {\n  content: '';\n  position: absolute;\n  left: 3px;\n  top: 4px;\n  width: 26px;\n  height: 26px;\n  border-radius: 50%;\n  background: rgba(44, 80, 24, .12);\n  pointer-events: none;\n}\n.dsf-plot:hover { \n  filter: brightness(1.15); \n  transform: scale(1.05);\n}\n.dsf-plot .dsf-soil {\n  position: absolute;\n  left: 1px;\n  top: 1px;\n  width: 30px;\n  height: 30px;\n  z-index: 2;\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n  image-rendering: pixelated;\n  filter: drop-shadow(0 1px 1px rgba(34, 60, 20, .28));\n}\n/* 作物 16×20，底边落在泥土贴图里（泥土 1→31，作物 9→29） */\n.dsf-plot .dsf-plant {\n  position: absolute;\n  left: 8px;\n  top: 9px;\n  width: 16px;\n  height: 20px;\n  z-index: 3;\n  transform: scale(1.08);\n  transform-origin: center bottom;\n  filter: drop-shadow(0 1px 1px rgba(0, 0, 0, .25));\n}\n.dsf-plot-letter {\n  position: absolute;\n  left: 1px;\n  top: 0;\n  z-index: 4;\n  min-width: 11px;\n  height: 12px;\n  padding: 0 2px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 8px;\n  line-height: 10px;\n  font-weight: 800;\n  color: #4a3212;\n  background: rgba(254, 250, 230, .92);\n  border: 1px solid rgba(122, 86, 34, .6);\n  border-radius: 3px;\n  box-shadow: 0 1px 1px rgba(0, 0, 0, .15);\n}\n.dsf-plot-letter .dsf-btext { transform: scale(.85); transform-origin: center; }\n.dsf-plot.dsf-empty { opacity: .88; }\n.dsf-plot.dsf-empty .dsf-plot-letter { opacity: .75; }\n.dsf-plot.dsf-ready {\n  box-shadow: 0 0 0 2px #fff6b0, 0 0 8px 2px rgba(255, 210, 74, .95);\n  animation: dsf-ready-glow 1.25s ease-in-out infinite;\n}\n.dsf-plot.dsf-ready .dsf-plant { \n  animation: dsf-ready-bounce .8s ease-in-out infinite;\n  filter: drop-shadow(0 2px 2px rgba(255, 210, 74, .4));\n}\n@keyframes dsf-ready-glow {\n  0%, 100% { box-shadow: 0 0 0 2px #fff6b0, 0 0 6px 1px rgba(255, 210, 74, .65); }\n  50% { box-shadow: 0 0 0 2px #fffdd0, 0 0 10px 3px rgba(255, 210, 74, 1); }\n}\n@keyframes dsf-ready-bounce {\n  0%, 100% { transform: translateY(0) scale(1.08); }\n  50% { transform: translateY(-2px) scale(1.08); }\n}\n\n/* 底部状态栏：工时 / 帮手 / 金币，替代原来浮在土地上的牌子 */\n.dsf-fieldrail {\n  display: flex;\n  gap: 5px;\n  margin-top: 5px;\n}\n.dsf-stat {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 3px;\n  flex: 1;\n  min-width: 0;\n  min-height: 20px;\n  padding: 2px 5px;\n  font-size: 9px;\n  color: #4e3a12;\n  background: rgba(254, 252, 240, .95);\n  border: 1px solid #d3b87e;\n  border-radius: 5px;\n  white-space: nowrap;\n  cursor: pointer;\n  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .6), 0 1px 0 rgba(0, 0, 0, .08);\n  transition: all .1s;\n}\n.dsf-stat:hover {\n  background: rgba(255, 254, 245, 1);\n  transform: translateY(-1px);\n  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .6), 0 2px 0 rgba(0, 0, 0, .08);\n}\n.dsf-stat .dsf-cjk { font-size: 9px; }\n.dsf-stat-ico {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 14px;\n  height: 14px;\n  flex: none;\n  overflow: hidden;\n}\n.dsf-stat-ico .dsf-spr { flex: none; }\n.dsf-stat-ico-cow .dsf-spr { transform: scale(.42); }\n.dsf-stat-ico-disc .dsf-spr { transform: scale(.7); filter: sepia(1) saturate(3) hue-rotate(-12deg); }\n.dsf-stat-ico-clock .dsf-spr { transform: scale(1.05); }\n\n/* ---------------- 农场装饰 ---------------- */\n.dsf-decor {\n  position: absolute;\n  inset: 0;\n  z-index: 1;\n  pointer-events: none;\n}\n.dsf-prop {\n  position: absolute;\n  z-index: 1;\n  image-rendering: pixelated;\n  pointer-events: none;\n  transform-origin: top left;\n  filter: drop-shadow(0 2px 1px rgba(0, 0, 0, .18));\n}\n.dsf-helpers { position: absolute; inset: 0; z-index: 4; pointer-events: none; }\n.dsf-helper {\n  position: absolute;\n  display: none;\n  image-rendering: pixelated;\n  filter: drop-shadow(0 1px 0 rgba(0, 0, 0, .22));\n  transform-origin: bottom center;\n  z-index: 4;\n}\n.dsf-helper.dsf-helper-on { display: block; }\n.dsf-helper.dsf-helper-pop { animation: dsf-helper-pop .8s ease-out; }\n@keyframes dsf-helper-pop {\n  0% { transform: translateY(-18px) scale(.4); opacity: 0; }\n  55% { transform: translateY(0) scale(1.18); opacity: 1; }\n  100% { transform: translateY(0) scale(1); opacity: 1; }\n}\n\n/* ---------------- 工时记录员（右下角空地，无浮动牌） ---------------- */\n.dsf-clerk {\n  position: absolute;\n  left: 212px;\n  top: 126px;\n  width: 64px;\n  height: 34px;\n  z-index: 6;\n  cursor: pointer;\n  image-rendering: pixelated;\n  filter: drop-shadow(0 2px 1px rgba(0, 0, 0, .25));\n  transform: scale(1.15);\n  transform-origin: center bottom;\n  pointer-events: auto;\n}\n.dsf-clerk:hover { filter: drop-shadow(0 0 4px #ffe680); }\n\n/* ---------------- 小人 / 帮手 / 表情 / 气泡 ---------------- */\n.dsf-farmer {\n  position: absolute;\n  width: 64px;\n  height: 34px;\n  background-repeat: no-repeat;\n  image-rendering: pixelated;\n  cursor: pointer;\n  z-index: 5;\n  filter: drop-shadow(0 2px 2px rgba(0, 0, 0, .35));\n  transform-origin: 50% 100%;\n  transition: filter .2s;\n}\n.dsf-farmer.dsf-looking { \n  filter: drop-shadow(0 0 6px #ffe680) drop-shadow(0 2px 2px rgba(0, 0, 0, .35)); \n}\n.dsf-farmer.dsf-acting { \n  filter: drop-shadow(0 0 4px #ffe680) drop-shadow(0 2px 2px rgba(0, 0, 0, .35)); \n}\n\n.dsf-emote {\n  position: absolute;\n  width: 7px;\n  height: 8px;\n  z-index: 9;\n  display: none;\n  image-rendering: pixelated;\n  transform: scale(2);\n  transform-origin: center bottom;\n  pointer-events: none;\n  filter: drop-shadow(0 1px 1px rgba(0, 0, 0, .35));\n}\n.dsf-emote.dsf-emote-helper { transform: scale(1.6); }\n\n/* ---------------- 切换任务 / 软件：床头举牌小人 ---------------- */\n.dsf-herald {\n  position: absolute;\n  left: calc(100% + 12px);\n  right: auto;\n  top: 15%;\n  bottom: auto;\n  width: 230px;\n  height: 140px;\n  z-index: 40;\n  opacity: 0;\n  transform: translate(60px, 30px) scale(.6);\n  transform-origin: 0 100%;\n  pointer-events: none;\n  will-change: transform, opacity;\n}\n.dsf-root.dsf-collapsed .dsf-herald { display: none; }\n.dsf-herald-on { animation: dsf-herald-pop .72s cubic-bezier(.2, 1.35, .4, 1) both; }\n.dsf-herald-out { animation: dsf-herald-out .42s ease-in both; }\n\n/* 床头：一块小木床头 + 奶油色枕头，小人从后面冒出来 */\n.dsf-herald-bed {\n  position: absolute;\n  right: 18px;\n  bottom: 0;\n  width: 74px;\n  height: 18px;\n  z-index: 2;\n  border: 2px solid #3b260f;\n  border-radius: 6px 6px 3px 3px;\n  background: linear-gradient(#b98243, #7a4d23);\n  box-shadow:\n    inset 0 1px 0 rgba(255, 235, 180, .4),\n    0 2px 0 #2a1a0c;\n}\n.dsf-herald-bed::before {\n  content: '';\n  position: absolute;\n  left: 5px;\n  right: 5px;\n  top: 3px;\n  height: 6px;\n  border-radius: 4px;\n  background: linear-gradient(#fffbe8, #f0d9a4);\n  box-shadow: inset 0 -1px 0 rgba(122, 86, 34, .25);\n}\n.dsf-herald-bed::after {\n  content: '';\n  position: absolute;\n  left: -4px;\n  top: -15px;\n  width: 4px;\n  height: 20px;\n  background: #6b431d;\n  box-shadow: 74px 0 0 #6b431d;\n}\n\n.dsf-herald-actor {\n  position: absolute;\n  right: 34px;\n  bottom: 10px;\n  width: 64px;\n  height: 34px;\n  z-index: 3;\n  transform: scale(1.15);\n  transform-origin: 50% 100%;\n  image-rendering: pixelated;\n  filter: drop-shadow(0 2px 1px rgba(0, 0, 0, .3));\n}\n.dsf-herald-actor .dsf-spr { width: 64px; height: 34px; }\n\n.dsf-herald-sign {\n  position: absolute;\n  right: 40px;\n  bottom: 50px;\n  z-index: 5;\n  min-width: 84px;\n  max-width: 190px;\n  padding: 5px 9px;\n  transform: rotate(2deg);\n  transform-origin: 100% 100%;\n  border: 2px solid #3b260f;\n  border-radius: 4px;\n  background: linear-gradient(#d9a463, #9a6530);\n  color: #fff6dc;\n  font-size: 10px;\n  font-weight: 700;\n  line-height: 1.35;\n  text-align: center;\n  text-shadow: 0 1px 0 #4b2c16;\n  box-shadow:\n    inset 0 1px 0 rgba(255, 243, 196, .45),\n    inset 0 -2px 0 rgba(84, 53, 24, .22),\n    0 3px 0 #2a1a0c;\n}\n.dsf-herald-sign::before,\n.dsf-herald-sign::after {\n  content: '';\n  position: absolute;\n  bottom: -24px;\n  width: 3px;\n  height: 26px;\n  background: #6b431d;\n  box-shadow: inset 1px 0 0 rgba(255, 220, 160, .2);\n}\n.dsf-herald-sign::before { left: 20px; }\n.dsf-herald-sign::after { right: 20px; }\n.dsf-herald-text {\n  display: block;\n  min-height: 13px;\n  white-space: pre-wrap;\n  word-break: break-word;\n}\n\n@keyframes dsf-herald-pop {\n  0% { opacity: 0; transform: translate(60px, 30px) scale(.55); }\n  55% { opacity: 1; transform: translate(-6px, -10px) scale(1.06); }\n  76% { transform: translate(1px, 2px) scale(.99); }\n  100% { opacity: 1; transform: translate(0, 0) scale(1); }\n}\n@keyframes dsf-herald-out {\n  0% { opacity: 1; transform: translate(0, 0) scale(1); }\n  100% { opacity: 0; transform: translate(60px, 30px) scale(.6); }\n}\n\n.dsf-bubble {\n  position: absolute;\n  left: 8px;\n  top: 8px;\n  width: max-content;\n  max-width: 124px;\n  max-height: 84px;\n  overflow: hidden;\n  z-index: 35;\n  padding: 4px 6px;\n  background: var(--paper);\n  border: 2px solid var(--wood-dark);\n  border-radius: 7px;\n  font-size: 9px;\n  line-height: 1.35;\n  white-space: pre-wrap;\n  word-break: break-word;\n  opacity: 0;\n  transform: translateY(4px);\n  transition: opacity .18s, transform .18s;\n  pointer-events: none;\n  box-shadow: \n    inset 0 0 0 1px rgba(217, 164, 99, .3),\n    0 3px 0 rgba(0, 0, 0, .15),\n    0 6px 12px rgba(0, 0, 0, .2);\n  cursor: pointer;\n}\n.dsf-bubble .dsf-btext { display: inline-flex; }\n.dsf-bubble .dsf-cjk { font-size: 9px; line-height: 1.35; }\n.dsf-bubble::after {\n  content: '';\n  position: absolute;\n  left: var(--dsf-bubble-arrow, 50%);\n  bottom: -8px;\n  margin-left: -5px;\n  border: 5px solid transparent;\n  border-top-color: var(--wood-dark);\n}\n.dsf-bubble-show { \n  opacity: 1; \n  transform: translateY(0); \n  pointer-events: auto; \n}\n.dsf-bubble-floating::after { display: none; }\n\n.dsf-sparks { position: absolute; inset: 0; z-index: 8; pointer-events: none; }\n.dsf-spark {\n  position: absolute;\n  font-size: 10px;\n  line-height: 1;\n  color: #fff3a0;\n  text-shadow: 0 0 4px #ffd24a;\n  pointer-events: none;\n}\n\n/* ---------------- 键盘农场页 ---------------- */\n.dsf-view-keys { padding: 2px 0 0; }\n.dsf-keylist {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  padding: 7px 3px;\n  background: linear-gradient(#fff8e3, #f4e5bf);\n  border: 1px solid #a8843f;\n  border-radius: 5px;\n}\n.dsf-keyrow {\n  display: flex;\n  justify-content: center;\n  gap: 2px;\n}\n.dsf-key {\n  position: relative;\n  flex: none;\n  box-sizing: border-box;\n  width: 24px;\n  height: 36px;\n  border: 1px solid #6b421c;\n  border-radius: 4px;\n  background:\n    linear-gradient(0deg, rgba(90, 55, 18, .12) 0 8px, transparent 8px),\n    linear-gradient(#d7a15e, #b77a3c);\n  box-shadow: inset 0 1px 0 rgba(255, 243, 196, .55), 0 1px 0 #6b421c;\n  cursor: pointer;\n  transition: filter .12s;\n}\n.dsf-key:hover { filter: brightness(1.1); }\n.dsf-key.dsf-empty { opacity: .86; }\n.dsf-key-soil {\n  position: absolute;\n  left: 2px;\n  top: 14px;\n  width: 20px;\n  height: 20px;\n  z-index: 1;\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n  image-rendering: pixelated;\n}\n.dsf-key-plant {\n  position: absolute;\n  left: 4px;\n  top: 7px;\n  width: 16px;\n  height: 20px;\n  z-index: 2;\n}\n.dsf-key-letter {\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  z-index: 3;\n  display: flex;\n  justify-content: center;\n  text-align: center;\n  font-size: 8px;\n  line-height: 10px;\n  font-weight: 800;\n  color: #fff3c4;\n}\n.dsf-key-letter .dsf-btext { transform: scale(.85); transform-origin: center; }\n.dsf-key-pips {\n  position: absolute;\n  right: 1px;\n  top: 1px;\n  z-index: 4;\n  transform: scale(.85);\n  transform-origin: top right;\n}\n.dsf-key.dsf-ready {\n  box-shadow: 0 0 0 1px #fff0a6, 0 0 6px 1px rgba(255, 210, 74, .9);\n  animation: dsf-ready-glow 1.25s ease-in-out infinite;\n}\n.dsf-key.dsf-ready .dsf-key-plant { animation: dsf-ready-bounce .8s ease-in-out infinite; }\n.dsf-keysummary {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  margin-bottom: 3px;\n  padding: 2px 5px;\n  font-size: 9px;\n  color: #4e3a12;\n  background: linear-gradient(#fff8e3, #f5e6bf);\n  border: 1px dashed #c9a86a;\n  border-radius: 4px;\n}\n.dsf-keysummary .dsf-spr { flex: none; }\n.dsf-keysummary .dsf-cjk { font-size: 9px; }\n.dsf-keyhint {\n  margin-top: 4px;\n  font-size: 9px;\n  line-height: 1.35;\n  color: #7a6539;\n}\n\n/* ---------------- 成长格 ---------------- */\n.dsf-pips { display: flex; align-items: center; gap: 1px; }\n.dsf-pip {\n  width: 4px;\n  height: 4px;\n  border-radius: 1px;\n  background: #c9b184;\n  box-shadow: inset 0 0 0 1px rgba(90, 55, 18, .25);\n}\n.dsf-pip.on {\n  background: linear-gradient(#ffe889, #e8b93e);\n  box-shadow: inset 0 0 0 1px #a97c2a;\n}\n.dsf-pips-plot {\n  position: absolute;\n  left: 3px;\n  bottom: 1px;\n  z-index: 4;\n}\n.dsf-pips-plot .dsf-pip { width: 3px; height: 3px; }\n\n/* ---------------- 任务页 ---------------- */\n.dsf-view-tasks { padding: 2px 0 0; }\n.dsf-tasklist {\n  max-height: 270px;\n  overflow-y: auto;\n  padding: 5px;\n  box-sizing: border-box;\n}\n.dsf-item {\n  display: flex;\n  gap: 6px;\n  align-items: flex-start;\n  padding: 4px 5px;\n  border-radius: 4px;\n  line-height: 1.4;\n  min-height: 22px;\n  cursor: pointer;\n}\n.dsf-item + .dsf-item { border-top: 1px dashed rgba(120, 90, 40, .22); }\n.dsf-task-source {\n  margin: 2px 2px 4px;\n  padding: 2px 4px;\n  font-size: 8.5px;\n  line-height: 1.35;\n  color: #7a6539;\n  background: rgba(255, 248, 224, .7);\n  border: 1px dashed #cdb37c;\n  border-radius: 3px;\n}\n.dsf-item-text { flex: 1; word-break: break-word; }\n.dsf-todo-completed .dsf-item-text { color: #8b8b78; text-decoration: line-through; }\n.dsf-todo-in_progress .dsf-item-text { color: #4b2c16; font-weight: 700; }\n.dsf-task-current {\n  background: linear-gradient(90deg, #fff3c4, #fbe7a8);\n  box-shadow: inset 3px 0 0 #e0a92e;\n}\n.dsf-task-on {\n  background: #ffe8a3;\n  box-shadow: inset 0 0 0 2px #c98d4e, 0 1px 2px rgba(90, 55, 18, .18);\n  outline: 2px solid #b98420;\n  outline-offset: -2px;\n}\n.dsf-current-chip {\n  flex: none;\n  align-self: center;\n  font-size: 8px;\n  line-height: 12px;\n  min-height: 12px;\n  padding: 0 4px;\n  color: #7a4b00;\n  background: #ffe8a3;\n}\n.dsf-current-chip.dsf-label-skin {\n  color: #fff5da;\n  background: #c98d4e;\n  border-width: 2px;\n  border-style: solid;\n  border-color: #7a4d14;\n  border-radius: 4px;\n}\n.dsf-selected-chip {\n  flex: none;\n  align-self: center;\n  font-size: 8px;\n  line-height: 12px;\n  min-height: 12px;\n  padding: 0 3px;\n  color: #fff5da;\n  font-weight: 800;\n  background: #c98d4e;\n}\n.dsf-progress {\n  position: relative;\n  height: 7px;\n  margin: 2px 2px 5px;\n  border: 1px solid #a8843f;\n  border-radius: 4px;\n  background: #e6d6ae;\n  box-shadow: inset 0 1px 2px rgba(90, 55, 18, .18);\n  overflow: hidden;\n}\n.dsf-progress-fill {\n  height: 100%;\n  width: 0;\n  background: linear-gradient(90deg, #8fd155, #4e9a2f);\n  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .4);\n  transition: width .3s ease-out;\n}\n.dsf-task-icon {\n  flex: none;\n  align-self: center;\n  width: 14px;\n  height: 14px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 13px;\n  line-height: 1;\n}\n.dsf-task-glyph { font-size: 13px; line-height: 1; }\n.dsf-task-completed { color: #4e9a2f; }\n.dsf-task-in_progress { color: #d08a00; }\n.dsf-todo-completed .dsf-task-icon { opacity: .6; }\n\n/* ---------------- 工时页 ---------------- */\n.dsf-view-usage { padding: 2px 0 0; }\n.dsf-usage-head {\n  display: flex;\n  align-items: baseline;\n  justify-content: space-between;\n  gap: 6px;\n  padding: 4px 6px;\n  background: linear-gradient(#fff8e3, #f3e3ba);\n  border: 1px solid #cbb079;\n  border-radius: 5px;\n}\n.dsf-usage-total {\n  font-size: 17px;\n  font-weight: 800;\n  color: #2f6b1f;\n  font-variant-numeric: tabular-nums;\n}\n.dsf-usage-now {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n  margin-top: 4px;\n  padding: 4px 6px;\n  font-size: 9.5px;\n  color: #2f5a12;\n  background: linear-gradient(#e9ffd2, #d5efb0);\n  border: 1px solid #8fbe59;\n  border-radius: 4px;\n}\n.dsf-usage-now .dsf-ico { flex: none; width: 15px; height: 15px; }\n.dsf-usage-live {\n  margin-left: auto;\n  font-size: 8px;\n  padding: 0 5px;\n  line-height: 13px;\n  border-radius: 6px;\n  background: #4f9e22;\n  color: #f4ffe8;\n  animation: dsf-pulse 1.4s ease-in-out infinite;\n}\n.dsf-usage-now.dsf-usage-idle {\n  color: #6a5a3a;\n  background: linear-gradient(#fbf3df, #efe2c2);\n  border-color: #c9b184;\n}\n.dsf-usage-idle .dsf-usage-live {\n  background: #8a7a58;\n  animation: none;\n}\n.dsf-usage-harness {\n  margin-top: 4px;\n  padding: 3px 6px;\n  font-size: 9px;\n  color: #24476e;\n  background: linear-gradient(#eaf4ff, #d5e8fc);\n  border: 1px solid #7ea6d8;\n  border-radius: 4px;\n}\n.dsf-usage-row {\n  margin-top: 4px;\n  padding: 3px 5px;\n  background: #fff8e6;\n  border: 1px solid #e0cfa6;\n  border-radius: 4px;\n}\n.dsf-usage-row.dsf-usage-current {\n  border-color: #8fbe59;\n  background: #f2ffe2;\n}\n.dsf-usage-line {\n  display: flex;\n  align-items: baseline;\n  justify-content: space-between;\n  gap: 6px;\n}\n.dsf-usage-name {\n  font-size: 9.5px;\n  color: #4a3212;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.dsf-usage-name .dsf-cjk { font-size: 9.5px; }\n.dsf-usage-time {\n  flex: none;\n  font-size: 9px;\n  color: #7a5a20;\n  font-variant-numeric: tabular-nums;\n}\n.dsf-usage-bar {\n  height: 4px;\n  margin-top: 2px;\n  border-radius: 2px;\n  background: #e6d6ae;\n  overflow: hidden;\n}\n.dsf-usage-fill {\n  height: 100%;\n  background: linear-gradient(90deg, #f0c25a, #d89a2e);\n  border-radius: 2px;\n}\n.dsf-usage-current .dsf-usage-fill { background: linear-gradient(90deg, #8fd155, #4e9a2f); }\n.dsf-usage-note {\n  margin-top: 5px;\n  font-size: 8.5px;\n  line-height: 1.35;\n  color: #7a6539;\n}\n\n/* ---------------- 余额页 ---------------- */\n.dsf-view-balance { padding: 8px 5px; }\n.dsf-balance { display: flex; flex-direction: column; gap: 5px; align-items: flex-start; }\n.dsf-bal-big { font-size: 22px; font-weight: 800; color: #2f6b1f; font-variant-numeric: tabular-nums; }\n\n.dsf-dim { color: #7a6539; }\n.dsf-small { font-size: 10px; }\n\n/* ---------------- 提问徽标 ---------------- */\n.dsf-badge {\n  display: none;\n  align-items: center;\n  gap: 5px;\n  margin-top: 4px;\n  padding: 3px 6px;\n  border: 2px solid #a12d17;\n  border-radius: 5px;\n  background: #ffe0d6;\n  color: #7a2413;\n  font-weight: 700;\n  font-size: 10px;\n  cursor: pointer;\n}\n.dsf-badge .dsf-ico { width: 12px; height: 18px; }\n.dsf-badge-show { display: flex; animation: dsf-pulse 1.4s ease-in-out infinite; }\n@keyframes dsf-pulse { 0%, 100% { filter: brightness(1) } 50% { filter: brightness(1.12) } }\n\n/* ---------------- 收起 ---------------- */\n.dsf-root.dsf-collapsed { width: 100px; }\n.dsf-root.dsf-collapsed .dsf-frame { display: none; }\n.dsf-openbtn {\n  display: none;\n  align-items: center;\n  gap: 4px;\n  font: inherit;\n  font-size: 11px;\n  padding: 4px 10px;\n  border: 2px solid #3b260f;\n  border-radius: 16px;\n  background: linear-gradient(#a7e06a, #6fb043);\n  color: #1f2d0c;\n  cursor: pointer;\n  box-shadow: 0 3px 10px rgba(0, 0, 0, .3);\n}\n.dsf-openbtn .dsf-spr { width: 12px !important; height: 12px !important; }\n.dsf-root.dsf-collapsed .dsf-openbtn { display: inline-flex; }\n\n/* ---------------- 开场待办 ---------------- */\n.dsf-intro {\n  position: absolute;\n  left: 0;\n  bottom: calc(100% + 8px);\n  width: 296px;\n  box-sizing: border-box;\n  padding: 6px 8px;\n  box-shadow: 0 6px 18px rgba(0, 0, 0, .35);\n  opacity: 0;\n  transform: translateY(6px);\n  transition: opacity .2s, transform .2s;\n  cursor: pointer;\n  z-index: 20;\n}\n.dsf-root.dsf-pos-tl .dsf-intro, .dsf-root.dsf-pos-tr .dsf-intro { bottom: auto; top: calc(100% + 8px); }\n.dsf-intro-show { opacity: 1; transform: translateY(0); }\n.dsf-intro-head { display: flex; justify-content: space-between; align-items: baseline; gap: 6px; margin-bottom: 4px; }\n.dsf-intro-list { margin: 0; padding: 0; list-style: none; display: flex; flex-direction: column; gap: 2px; }\n.dsf-intro-item { display: flex; gap: 5px; align-items: baseline; line-height: 1.35; font-size: 11px; }\n.dsf-intro-item .dsf-dot { display: inline-flex; width: 13px; height: 13px; flex: none; justify-content: center; }\n.dsf-intro-item.dsf-in_progress .dsf-dot { color: #d08a00; }\n.dsf-intro-item.dsf-completed { color: #8b8b78; text-decoration: line-through; }\n.dsf-intro-text { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n\n/* ---------------- ☰ 面板 ---------------- */\n.dsf-panel {\n  position: absolute;\n  left: 0;\n  bottom: calc(100% + 8px);\n  width: 296px;\n  max-height: 390px;\n  box-sizing: border-box;\n  display: flex;\n  flex-direction: column;\n  box-shadow: 0 10px 30px rgba(0, 0, 0, .4);\n  overflow: hidden;\n  z-index: 25;\n}\n.dsf-root.dsf-pos-tl .dsf-panel, .dsf-root.dsf-pos-tr .dsf-panel { bottom: auto; top: calc(100% + 8px); }\n.dsf-root.dsf-pos-br .dsf-panel, .dsf-root.dsf-pos-tr .dsf-panel { left: auto; right: 0; }\n.dsf-panel-head {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 4px 6px;\n  background: linear-gradient(#c98d4e, #8a5a2b);\n  color: #fff5da;\n  border-bottom: 2px solid var(--wood-dark);\n}\n.dsf-panel-head .dsf-dim { color: #f7e6bd; }\n.dsf-x {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  border: 1px solid #3b260f;\n  background: #f0c25a;\n  color: #2b1a06;\n  border-radius: 4px;\n  width: 20px;\n  height: 20px;\n  padding: 0;\n  font: inherit;\n  cursor: pointer;\n}\n.dsf-x .dsf-ico { width: 11px; height: 11px; }\n.dsf-tabs { display: flex; gap: 3px; padding: 6px 8px 0; }\n.dsf-tab {\n  font: inherit;\n  font-size: 10px;\n  padding: 2px 9px;\n  border: 1px solid #b79a63;\n  border-bottom: none;\n  border-radius: 5px 5px 0 0;\n  background: var(--paper-2);\n  color: #5a4522;\n  cursor: pointer;\n}\n.dsf-tab-on { background: #fff8e6; color: var(--ink); border-color: var(--wood-dark); }\n.dsf-panel-body {\n  padding: 8px;\n  overflow: auto;\n  flex: 1;\n  border-top: 2px solid var(--wood-dark);\n  background: #fff8e6;\n}\n.dsf-sec-title { font-weight: 700; margin: 6px 0 3px; color: #5a3a12; font-size: 11px; }\n.dsf-actions { display: flex; gap: 5px; flex-wrap: wrap; margin-top: 7px; }\n.dsf-btn {\n  font: inherit;\n  font-size: 10px;\n  padding: 3px 9px;\n  border: 1px solid #7a4d14;\n  border-radius: 5px;\n  background: linear-gradient(#ffe9a1, #f0c25a);\n  color: #2b1a06;\n  cursor: pointer;\n}\n.dsf-btn:active { transform: translateY(1px); }\n.dsf-btn-on { background: linear-gradient(#a7e06a, #6fb043); }\n.dsf-size-row {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  margin-top: 5px;\n  font-size: 10px;\n}\n.dsf-input {\n  font: inherit;\n  font-size: 10px;\n  width: 54px;\n  padding: 2px 4px;\n  border: 1px solid #a8843f;\n  border-radius: 4px;\n  background: #fffdf4;\n  color: var(--ink);\n  box-sizing: border-box;\n}\n.dsf-input:focus { outline: 2px solid #e0b34a; outline-offset: 0; }\n.dsf-desktop-note {\n  margin-bottom: 4px;\n  padding: 4px 6px;\n  font-size: 10px;\n  line-height: 1.4;\n  color: #24476e;\n  background: linear-gradient(#eef6ff, #d9eafc);\n  border: 1px solid #7ea6d8;\n  border-radius: 4px;\n}\n\n/* ---------------- 金币跳动 ---------------- */\n.dsf-coin-pop { animation: dsf-coin-pop .34s ease-out; }\n@keyframes dsf-coin-pop {\n  0% { transform: scale(1); }\n  45% { transform: scale(1.16); }\n  100% { transform: scale(1); }\n}\n\n/* ---------------- 桌面端：固定面板层 / 窗口把手 ---------------- */\n.dsf-panel-host {\n  position: fixed;\n  inset: 0;\n  z-index: 2147483000;\n  display: none;\n  align-items: center;\n  justify-content: center;\n  pointer-events: none;\n}\n.dsf-panel-host.dsf-panel-open { display: flex; }\n.dsf-panel-host .dsf-panel {\n  position: relative;\n  left: auto;\n  right: auto;\n  top: auto;\n  bottom: auto;\n  width: min(330px, 92vw);\n  max-height: 88vh;\n  transform: none;\n  margin: 0;\n  pointer-events: auto;\n}\n.dsf-resize-grip {\n  position: fixed;\n  right: 5px;\n  bottom: 5px;\n  width: 16px;\n  height: 16px;\n  z-index: 2147483100;\n  cursor: nwse-resize;\n  opacity: .55;\n  background:\n    linear-gradient(135deg, transparent 0 42%, #5a3712 42% 52%, transparent 52% 64%, #5a3712 64% 74%, transparent 74%);\n  filter: drop-shadow(0 1px 0 rgba(255, 255, 255, .6));\n}\n.dsf-resize-grip:hover { opacity: .95; }\n\n/* ---------------- 桌面窗口（Electron） ---------------- */\nhtml.dsf-desktop,\nhtml.dsf-desktop body {\n  margin: 0;\n  background: transparent !important;\n  overflow: hidden;\n}\nhtml.dsf-desktop body { min-height: 100vh; }\nhtml.dsf-desktop .dsf-root {\n  left: 2px !important;\n  right: auto !important;\n  top: auto !important;\n  bottom: 8px !important;\n  margin-left: 0;\n  transform-origin: bottom left !important;\n}\nhtml.dsf-desktop .dsf-header { cursor: move; }\nhtml.dsf-desktop .dsf-iconbtn,\nhtml.dsf-desktop .dsf-tabbar,\nhtml.dsf-desktop .dsf-tabbtn,\nhtml.dsf-desktop .dsf-coins,\nhtml.dsf-desktop .dsf-statusbar,\nhtml.dsf-desktop .dsf-view,\nhtml.dsf-desktop .dsf-bubble,\nhtml.dsf-desktop .dsf-badge,\nhtml.dsf-desktop .dsf-panel,\nhtml.dsf-desktop .dsf-intro,\nhtml.dsf-desktop .dsf-openbtn { -webkit-app-region: no-drag; }\n\n@media (prefers-reduced-motion: reduce) {\n  .dsf-farmer.dsf-looking, .dsf-farmer.dsf-acting, .dsf-badge-show,\n  .dsf-status-busy::before, .dsf-helper,\n  .dsf-plot.dsf-ready, .dsf-plot.dsf-ready .dsf-plant,\n  .dsf-key.dsf-ready, .dsf-key.dsf-ready .dsf-key-plant,\n  .dsf-usage-live, .dsf-coin-pop,\n  .dsf-herald-on, .dsf-herald-out { animation: none !important; }\n  /* 关掉动画时仍要让举牌小人显示出来，否则会停在 opacity:0 */\n  .dsf-herald-on { opacity: 1; transform: translate(0, 0) scale(1); }\n  .dsf-herald-out { opacity: 0; transform: translate(60px, 30px) scale(.6); }\n}\n\n/* 自动生成：FarmLife / SunnysideWorld UI 图集（去绿底） */\n.dsf-panel-skin{border:8px solid transparent;border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJCAYAAADgkQYQAAAAa0lEQVR4AY3BMRHEIBBA0b9ooFgDzFyFBk5BBFEjKAoODVSZwQAFHvYoUlHxnvBSH4zNmF1YhEV9sFYLu5gyY3YR9cFaLTz3j93n+hJTxnHAccBxwHFAWNQHa7WwiykzZhfhpT4YmzG7sPwBEKQdXnTly5EAAAAASUVORK5CYII=) 3 fill / 8px stretch;background:#f3d9a4;}\n.dsf-panel-paper{border:8px solid transparent;border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJCAYAAADgkQYQAAAAa0lEQVR4AY3BMRHEIBBA0b9ooFgDzFyFBk5BBFEjKAoODVSZwQAFHvYoUlHxnvBSH4zNmF1YhEV9sFYLu5gyY3YR9cFaLTz3j93n+hJTxnHAccBxwHFAWNQHa7WwiykzZhfhpT4YmzG7sPwBEKQdXnTly5EAAAAASUVORK5CYII=) 3 / 8px stretch;background:#f7e8c3;}\n.dsf-panel-dark{border:8px solid transparent;border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJCAYAAADgkQYQAAAAfUlEQVR4AY3BIQ7DIBiA0e9vqqsQpHIpbpJkp+hVOAxX4RRLkHMskwsCtQswRJs0pKLvCRutTKWTSxIaodHK1OhXetYFckkiWpka/crr+aF3f9ywLjBy8P7+2C3zxG7ggoELRg6WeeKM0GhlavQrPesCuSQRNlqZSieXJDR/g/ogrvkp4qoAAAAASUVORK5CYII=) 3 fill / 8px stretch;background:#4b2c16;}\n.dsf-panel-white{border:8px solid transparent;border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJCAYAAADgkQYQAAAAZUlEQVR4AY3BsQ3DIBBA0X/MANJRRzCBe8+ePhOAXIMEOxAKV1fxnvBSnxZGn1XYhE19Wm0UrBgyfVYR9Wm1Ufj+Hqz7+hBDxnHAccBxwHFA2NSn1UbBiiHTZxXhpT4tjD6rsP0BOuAdXs0evIoAAAAASUVORK5CYII=) 3 fill / 8px stretch;background:#fff8e6;}\n.dsf-label-skin{border:4px solid transparent;border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAANCAYAAACzbK7QAAAAaElEQVR4AbXBMRUDIRBF0TejYQoMcE4qNBAFEUQ9gqIgaKBaN2SLlcC/13iUqBsB41ai7jWTk1ofrJlYibrXTK7vj5NenzetDxwxR8wRc8QcMUfMEXPEjFuJutdMTmp9sGZiPErUjcAfX/EW1FT9XdsAAAAASUVORK5CYII=) 4 fill / 4px stretch;background:#c98d4e;}\n.dsf-label-paper{border:4px solid transparent;border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAANCAYAAACzbK7QAAAAaElEQVR4AbXBMRUDIRBF0TejYQoMcE4qNBAFEUQ9gqIgaKBaN2SLlcC/13iUqBsB41ai7jWTk1ofrJlYibrXTK7vj5NenzetDxwxR8wRc8QcMUfMEXPEjFuJutdMTmp9sGZiPErUjcAfX/EW1FT9XdsAAAAASUVORK5CYII=) 4 / 4px stretch;background:#f7e8c3;}\n.dsf-select-skin{border:5px solid transparent;border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAASCAYAAABSO15qAAAA80lEQVR4AaXBMY6EIBiA0e83noWGbmtL7mCy/VB6IO1JuAMlNR0N55ieZRJNXDKzWeN7wk5pU7mg5CA0QqO0qdFbetO88hK9pTfNKyUHGZQ2NXrLVdFblDZ1pJM2Ry9tjsPX45uzgZtGOkt4cig5CM2Cqezig19GmrQ5zkoOwknJQWiUNjVtjrOBm4RGaVPZlRyEPyhtKruSgwzcJEqbGr3lMM0rJQfhDaVNjd5ymOaVgZtG3lDaVP5ppBO95TDNKy/RWz4ZaNLmuCptjpeRXdocn6TN8clQcpAlPLlqCU9KDiLslDaVTslBaJQ2lU7JQWh+AKjNX0LPpYdCAAAAAElFTkSuQmCC) 9 8 9 8 fill / 5px stretch;}\n.dsf-ico-heart{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAgCAYAAAB6kdqOAAAA4UlEQVR4Ac3BoW7DMBSG0c9Xe4CodNzEJCigGqo8sgca2XuFLAqaCoJGQsxHq7JBj94WuLI08J8TeCCmXGko+xJwYsqVhrIvgQZDjCHGEBO4E1OuON9vEy3jvOGtAzcOxwlvnDe8si8BxxBjiDHEhJhyxVkHmg7HCe9y3mh5/vrE+33/wBvnDc8QY4gxxDzR6XLe6PHz8koPQ4whxhBjiDHEGGIMMYE7MeWKsw78q9OVG2VfAo4hxhBjiAk8EFOuOOtAl9OVG2VfAg2GGEOMISbQKaZc6VD2JdDBEGOIMcT8Af4pMLWlSajuAAAAAElFTkSuQmCC);}\n.dsf-ico-avatar{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABYCAYAAABF7PEoAAAEAUlEQVR4AeXBQYgUZBjH4d/7MkJKheRsu6dWh2aNZCU301OQJ6MsCEqtFLNTJHawa1YHr3kovKaQkXUJEiqDEiIWCtZgpcAdWXeEctcdMYsSFHy7/r85fDKoFLzPYwxopNkORFAy6uZ7HeN/xEnOSc5JzriJkWY7ED++8heqOTqOMkqL3dOoDYfvRi1cOmv8h5zknOSc5Iw+w80HA/Hjrr8YhJmh3v1+GPX17D+oMKMQQSGCghk1872OMQAnOSc5Jzmjz3CzHYi3Jxz19PgfKDNDHZ++F/XM2j8pBSVDDY2Oo4JSrztNyVAbj9yDmu91jAonOSc5Jzmjz3CzHYj9E0YhKExdWYp65/F5aswoRFBlZqiIoKbTaaJ2Tl5Dzfc6hnCSc5JzkjP6jAy1A/HWOqNmy/gVlJlRExHUmBkqIqgxo+rMzArUzsnrKCc5JzknucZIsx2oG5SCwtSVZahXV46iLs5NU2NmqKHRcdTFuWnU/SvXoi7OTaOGRteiLs5No8bal1A2eS/KSc5JzkmuEQRq/4RTEwTqwy+6qN3PrkX1uqdRMzMrUBHTKDND/fDNb6jVqw212J1GzcysQI2NXaLGSc5Jzkmu4RhVZlSZoQ4fP4/aMh6ooGRmlIKCUYgIqoxCp9NEBddQTnJOck5yRp+RZjuoeLK1DLV++VVKRiECNbZ0CcooBf0CZRgq6BeoXZPXURd6HUM4yTnJOck16DPf6xgVX/FgINavc5QZhTBDrXn9NWoe3fE+auroG9Ss3/kBauroXtSNyfepcZJzknOSazCghd5ZQxz4uR2IqaN7UZ8f/IA7KSJQERSMOic5JzknuQa3mRmF5/btpcaMwuzurajL1M3ufh51mZKZUeMk5yTnJGfcZsPNdiCO7duEGpsYp8boYxQiqJo5dRr10sGTqAu9jiGc5JzknOQa3GZOaezLWdS3R6ZQB5YsR711/QqlQB1Ych/qu+WB2n6mi1rodYwKJzknOSc54xYNN9uBOPXQKCqCghmFF+5ahfrs6jmUGYWtS1uoY3/PotwoTJzpohZ6HUM4yTnJOck1uEVGaeapFurFgydRrUeeQEVQ2LashYowCjcC9dhMF/XJm5sonJmjxknOSc5JrsEtemBbC7X9ve9QZk7JUWaBWvx9FrViZBXK3VFGaft7J1Gj21qohUNnUU5yTnJOcsaANuzZHFQYpe6n51Avr2miPv5lEfXAthbq/KezqB0PD6E++nURNbq1RcGCGic5JzknOWNAG/dsDkRwM0EhjIEYt1cEyknOSc5JzrhFG/dsDkTQJ4KSUWVBySgEJWMgPx06YQgnOSc5JznjDtuwZ3MgjFJwM0HJqPnp0AljAE5yTnJOcv8CoTUeOvoCN8EAAAAASUVORK5CYII=);}\n.dsf-ico-hardhat{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA4CAYAAACyutuQAAABoUlEQVR4Ad3BMW7aYBjH4d/3N3OzWJFB7ugti4UqbtALcAc21lwgR0DqwAU6cYFIUcfIqpCXbIyhYCEvHADc9Q3Dh7wg9D5PoKcsLTpuqGk3gR6EM8IZ4UzgiiwtOozPvz+J0X5LH+dhTsz3H69YTbsJRAhnhDPCmcCFLC06jN3yAetUTrilpK6wRrMjVtNuAoZwRjgjnAlZWnQYu+UD1qmccE+SusIazY5YwhnhjHBmwIVTOSFG+y3WeZgTo/0W6zzMidF+i3Ue5lincsJXr1jCGeGMcGbAFUldYZ3KCX2E5h9fDHNizsMcK6krrFM5IUY4I5wRzgy4kNQV9yypK2KEM8IZ4UzgQpYWHcZu+cA9Gc2OWE27CRjCGeGMcGbAFb9+f+O+HIkRzghnhDMDriifHomZLtZYq/mYPqaLNdZqPibqzycxwhnhjHBGOCOcEc4IZwZcUX8csMqnR6zdyzPW++GNPnYvz1jvhzes+uNAH8IZ4YxwJnBFlhYdxmo+5pamizVW024CEcIZ4YxwJtBTlhYdN9S0m0APwhnhjHDmPwK+Yy7LCAjoAAAAAElFTkSuQmCC);}\n.dsf-ico-basket{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAABeUlEQVR4AdXBMWsUURiG0Wc+prrTGBhhKq0Gi7TrIlhpOdZpFpv4w6xkf8ItTZdiSBmLZSGwNllwiEiY247tt1PcsIRF33MKjtTU7cQJ7YdtwREMcYY4Q1zBE5q6nXCuvrzilD58/Ym3H7YFGYY4Q5whruRI97cD3qpPPMd6GXgOQ5whzhBXMtPU7YRzd3mB93Ddc2iHd3d5gfdw3eMtNju8d+ef8G7+9HgLmHD2w7bAMcQZ4gxxRVO3E87Nm9fkfP/1m1P6+PKMnMVmh2eIM8QZ4kpmHt9P5LzlBaf0yETWhgOGOEOcIa5k5v52QIkhzhBniCuZWfUJ7/N5zb/07cdAjiHOEGeIK5lZLwOHEl4cA15XJXLiGPC6KpETx4C3Xga8VZ/wDHGGOENcyRPiGPC6KpETx4DXVYmcOAa8rkocwxBniDPElczEMeB1VSInjgGvqxI5cQx4XZXIiWPgUMIzxBniDHEFM03dTvzH9sO2wDHEGeIMcX8Bimhd+ZXQFSEAAAAASUVORK5CYII=);}\n.dsf-ico-plant{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAABgUlEQVR4AdXBsYrVQBSA4f8cUl3BYk2RxjKQJxBS2AthfADbNILPI9ikE19gyLK9RWB7IZDSJsVoIdy1HNvjFrOEq7uc7xPuaeo2c8CeNuEJKc4pzinOSVO3GWOIHUfMYcXa0yY8IsU5xTnFuYoHTH0UjHEJGWOIHdYcyBh72oT/SHFOcU5xTpq6zRhD7CiZ+igY4xIyBXNYsfa0Cf+Q4pzinOKccE9TtxljiB0lUx8FY1xCxpjDirWnTTCaus0csKdNMBTnFOcU54QHNHWbMYbYUfL145mSXzffsYbYccQcVizFOcU5xTnhoKZuMwXP37yk5PWHZ5RMfRSMcQkZYw4rluKc4pziXMVBe9oEo6nbzAWmPgrGuITMAYpzinOKcxWPbOqjYIxLyBTMYcXa0yYYinOKc4pzwkFN3WaML69OWO+vXlDy6ecPrHe3d5TsaRMKFOcU5xTnKi50fT5hvT3/puSaE3+7w9rTJhygOKc4pzhXcaHP3xJPSXFOcU5x7g8gF2cf+rgZEgAAAABJRU5ErkJggg==);}\n.dsf-ico-axe{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA0CAYAAADWr1sfAAAB30lEQVR4AeXBoU5bYRjH4d/3puroI45YOnWSCkTpUi4A1wsgK5Ml2Q0gZ+aQ9c2KIiQLJFPrXOsRU8VwMrekR3w4iv1m/6s4S1PGRt7nCfxjRV4mtlDHKrADwxnDGcOZwDMr8jIhTs/GNHnz5QPq3c0jqo5VYAuGM4YzhjMt/rIiLxPi9GxMk363g5p8P+Y3N1N2YThjOGM4E3hiRV4mxOnZmCb9bgc1Ob9mG/OrKaqOVaCB4YzhjOFMi2fW73ZQk/NrdnF4dIKaX00Too5VQBjOGM4YzgSeWJGXCXF5kKE+vT7mKe339lD9bgc1HAxQhjOGM4YzLXZU5GVCXB5kqK8PGern/DPq1eFbtrHf22MXhjOGM4YzgS0VeZkQi1EbtVpG1Mcfhrq7f6DJ4dEJar+3R5N+t4MaDgaoOlYBYThjOGM40+IPirxMiMWojVotI2q2zlB39xFVxyrQYH41TYj3o280GQ4GqDpWgQaGM4YzhjOBDUVeJsRi1EatlhE1W2eoi9uIqmMV2EGRl4kGdawCWzCcMZwxnAlFXibEYtRGrZYRNVtnqIvbiKpjFfiPGc4YzhjOtNiwWkbUbJ2hLm4jqo5V4AUxnDGcMZwJbCjyMtGgjlXgBTOcMZwxnPkF3SOAvuSHYWgAAAAASUVORK5CYII=);}\n.dsf-ico-watering{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA0CAYAAADFeBvrAAABjElEQVR4Ad3BsWsTcRzG4c/vJVNcb7ip20HAJUt0rtuJo0IQpxTdS3DoX5BBSnelmUQKOorZ7KxZsgiB2zrdcKtZr+uXDFcOa5T3eRI95VnR0kPdVIkDEmaEGWEmcYc8K1qC69kRfRwvb4jqpkoEeVa0dKibKtGDMCPMCDOJPXlWtATXsyOiyx87+jh5PCQ6Xt4QzRcXRJPxiGhalkR1UyU6CDPCjDCT2JNnRUvw6dGQ6NvvIdHHXw3Rq4cZ0dMHO6KXP3d0mS8uiCbjEdG0LInqpkoEwowwI8wM+MeevDghevv6WSJ49+FrS3C1WhFNy7IlEGaEGWEm5VnRElytVvxN75df6PL98yVd5osLovOzUyJhRpgRZgYc2JvZc6JpWRLVTZXocH522hLUTZUIhBlhRpgZsGe92RJNxiPu03qz5U/UTZXoIMwIM8LMgDusN1uiyXhEH+vNlkMSZoQZYUaYEWaEGWFGmBFmhBlhZkBP682W/5kwI8wIM4k9eVa0HFDdVIl7JMwIM8LMLf9FXZuaM5rKAAAAAElFTkSuQmCC);}\n.dsf-ico-pickaxe{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAABSklEQVR4AdXBIa7cMBRA0eunLCGW4gXEewkvGFzQLfydFBSUVQooNy7vCmwVO5K9h5Q+DfDIGn3wznF8sm3dbwauXhwTBGMEYwRjHC9s634zcPXiULZ1v1Fqy4wEH9GuXhwDgjGCMYIxjifbut8otWW04CMjtWVGgo9otWW04CPa1YtDEYwRjBGMWXhTbZmR4CNabZl3CMYIxgjGLEyqLTMSfESrLTMSfESrLaMFH28UwRjBGMGYhUl//v5j5EyJkeAjWm2ZGYIxgjGCMW5b95uBMyXe8ePnb7Rf3z8YCT6iXb04FMEYwRjBmIUnZ0poj+NAO1NixrevXxgJPqJdvTgGBGMEYwRjFl44U0J7HAfamRIzgo9oVy+OCYIxgjGCMY4n27rfKGdKjDyOgxlXL443CMYIxgjGOF7Y1v1mwtWL4xMJxgjGCMb8B9B2WdiAZopiAAAAAElFTkSuQmCC);}\n.dsf-ico-hand{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAA0CAYAAADMk7uRAAABWklEQVR4AdXBMYrbQBiG4Xd+dBNBmmyToF5NTuEb+ATSEVyqWkEM6VZVjqBmtvUUbgzGMGdR2j8qZhFWsnzPE1g5HE8LG0xjH/hEhjhDnCGuOhxPC87ba0dJTJmVhYJp7AP/kCHOEGeIq9iobWq8tunwYsqsLBRMYx94giHOEGeIq9hZ29R4bdPhxZRZWSiYxj5QYIgzxBniKlZiynhtU7Ontqnx2qbDiymzsuBMYx9wDHGGOENcYOVwPC04b68dnymmjPfz1288Q5whzhBniDPEGeIMcRUfiCnjtU3NnmLKeJfrnZL0PuMZ4gxxhriKlWnsA39bcNqmY4uYMt7lemdPhjhDnCGuYqOYMiWX651nnIeBksdtDjiGOEOcIa7iA+l9xvv2/YVnnIeBksdtDmxgiDPEGeIqdnYeBkoetzmwI0OcIc4QF9joy9cfCwWP2xz4jwxxhjhD3B/zTleIucQuAwAAAABJRU5ErkJggg==);}\n.dsf-ico-circle{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAwCAYAAABqkJjhAAABNklEQVR4AdXBMUrDcBjG4d//JUeIEOcQT5A90M29BcGxmzfxCoV2LrR7toJ7bxDcM+QOcf3aIRI0yvs8iZmKvBqZ0A9dYkHCjDAjzCS+UeTVSHBsW6KmLokeH56I+qFL/CJhRpgRZjLuFHk1EhzblqipS+Yo8mpkhn7oEhOEGWFGmElFXo0Ex7YlauqSJX1cP4lenp+J+qFLBMKMMCPMZMe2JWrqkr/U1CVzCDPCjDAjzAgzwowwk+0OZ26tiZq6ZEkf10/mEGaEGWEm487ucObWmqipS6a8vr2zJGFGmBFmsstpT7TabIl2hzO31vwnYUaYEWYSd4q8GglWmy1zXE57fqIfusQEYUaYEWYS3yjyaiRYbbZMuZz2RP3QJX6RMCPMCDOJmYq8GpnQD11iQcKMMCPMfAH1QkEvX89NUQAAAABJRU5ErkJggg==);}\n.dsf-ico-face_green{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAgCAYAAAABtRhCAAAAoklEQVR4Ab3BsQ2EMBREweeVEzdCQg3OKMVluRQy13DJNeKQS78IQOjQziROlnU7eNH3sycCYSbMhFla1u0gqL3wptEmkTATZsIsc2O0SVR7IRptEtVeuCLMhJkwy9yovXCl9sITwkyYCbPMjdEmUe2FaLRJVHvhijATZsIs89Bok38IM2EmzDI3ai+8SZgJM2GWOFnW7eBF38+eCISZMBNmP61pHaBD/q0SAAAAAElFTkSuQmCC);}\n.dsf-ico-face_red{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAApUlEQVR4Ab3BoQ3DMABE0e9TBvAUISFFGcAK6sBFlWFAUElIh6i8QUptA0uVqnsv0JmX7eKP3uczUBFmwkyYhXnZLgZe95Xa7XFQe91XarfHwYgwE2bCbKKTI43PfjDy2Q9qOdJIhYYwE2bCLMzLdmEkzISZMJvo5MhQKjRyZCgVGsJMmAmziU4qNHLkJ6kwJMyEmTALdOZlu/ij9/kMVISZMBNmX+iNIF/uXurrAAAAAElFTkSuQmCC);}\n.dsf-ico-face_pink{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAkCAYAAADo6zjiAAAA1klEQVR4AcXBsanDMABF0auHV7EbjRFN4gECmsTgATJEarnKBoE00TD+rXChYL7hnRP4YYpp50LfTwk0hJkwE2aBgymmnY5tXul5v560ci30CDNhJszCFNNOxzavtG6PO2csY6KVa6ElzISZMBs42OaV1u1xp2cZE61cC2cIM2EmzAZOWsZEK9fCfwgzYSbMBg7eryc9uRZay5joybXQI8yEmTALU0w7HcuYaOVauJIwE2bCLHAwxbTTsYyJM3It9AgzYSbMAj9MMe1c6PspgYYwE2bC7A/3wzDofv/2qQAAAABJRU5ErkJggg==);}\n.dsf-ico-face_yellow{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAgCAYAAAABtRhCAAAAkklEQVR4Ab3BwQnEIBRF0evDNtwGIW1Y9m8jILO1kMxWsogE5J2TeDjOdrPR74rERJgJM2GWjrPdTHoUdqptMBNmwkyYZRZqG8x6FGa1DWY9Cm+EmTATZpmFHoU3PQpfCDNhJsyEmTATZsIss1Db4IsehTfCTJgJs8xCj8JOwkyYCbPEw3G2m41+VyQmwkyYCbM/xDAa7eN3hQ0AAAAASUVORK5CYII=);}\n.dsf-ico-face_blue{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAkCAYAAACaJFpUAAAA20lEQVR4Ab3BsW3CUBiF0e9doRRewBIDPAqbLeyaOdIwTBrmoI4zhXGRN0AkFqA17S+Kh6xI95zERrkbVoKyTIkNhJkwE2aJN3I3rAS/t2+iQz8SlWVKVAgzYSbMEi9yN6wEHz9Xaua2ITr0I1FZpkQgzISZMBNmwkyYCbOUu2ElKOcLUX/aUzO3DTWHfiQSZsJMmO34p+P9QTS3DTXCTJgJsx1v3K5/RP1pT83x/qBGmAkzYZZ4kbthJSjnC1vkr0+iskyJQJgJM2GWeCN3w8oGZZkSFcJMmAmzJ7ZpKucLdQrTAAAAAElFTkSuQmCC);}\n.dsf-ico-face_exclaim{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAkCAYAAACAGLraAAAAiElEQVR4AaXBsRGCQABFwcefK+CqUGa0DC3AFuyDiOIMDE0owZAOMD0JYJi3250utwUhSEEKUmFlGmda3eNN63y90wpSkIJU2LF8n2wJUpCCVNjz+vCv0gpSkIIUpCAFKUiFlX6oHBGkIAWpsDKNM1v6odIKUpCCFKQgBSlIhZV+qBwRpCAF6Qc8gg5FCS4PngAAAABJRU5ErkJggg==);}\n.dsf-ico-face_orange{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAgCAYAAAABtRhCAAAAoklEQVR4Ab3BwQnEIBRF0evDAqwiCGkjbbmyrWljQKaK30FmK1kkCOGdk7jY9uPkRb/vJzERZsJMmKVtP04mowdvqq0wE2bCTJhlHtRWmI0ezGorzEYP7ggzYSbMMg9GD+6MHqwQZsJMmGUe1FZYMXpwR5gJM2GWWTR6MKutsEKYCTNhlnkwenBn9GCFMBNmwixxse3HyYt+309iIsyEmTD7A1CcIgi+f8O7AAAAAElFTkSuQmCC);}\n.dsf-ico-face_cry{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAgCAYAAAABtRhCAAAAnElEQVR4Ab3BwQnDMBBE0a/BbehqBG5jy942DMJXFeJclxxsAmHea3zZj7j5o+vMRiHMhJkwa/sRN8XMzj+NWFTCTJgJs40XIxbVzE41YlHN7DwRZsJMmAkzYSbMhNnGi5mdJzM7vxBmwkyYNb7sR9wUMzvViEU1s1ONWFTXmY1CmAkzYSbMhJkwE2aNF/sRNz+4zmw8EGbCTJh9AGjjIDfdXOzMAAAAAElFTkSuQmCC);}\n.dsf-ico-face_question{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAoCAYAAADt5povAAAAzklEQVR4Ab3BsW3DMABE0c8DG68RBEqhFKw0gdJojQAZKkDWYOUJWKlxYxhew6XSMiokEHLuvcBK148LT3S9nAMVYSbMhFno+nGhMk8DLU6vL/zx9Unt7f2DmjATZsIsctDjdqd2+v5hizATZsIs0ijlQm2eBmqP250twkyYCbPISsqF/yTMhJkwC6x0/bhQmaeBI1Iu1ISZMBNmkYNSLrQQZsJMmEV2pFxocb2cAxuEmTATZpEd8zSwJeVCC2EmzIRZZEfKhWcSZsJMmP0CgVAjUtxptP4AAAAASUVORK5CYII=);}\n.dsf-ico-face_anger{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAgCAYAAAABtRhCAAAAkklEQVR4Ab3BwQ2EIBRF0csLBVCFG7sglm3owo1V0IGz5buQTELeOYmXbT8eFrqvMzEQZsJMmKVtPx4GrbBU7QTCTJgJs8xE7QStENRO0AqfhJkwE2aZiVYIaidohb8IM2EmzDITtfOpdoJW+CTMhJkwE2bCTJgJs8xEKywlzISZMEu8bPvxsNB9nYmBMBNmwuwHg2kWqDiV66kAAAAASUVORK5CYII=);}\n.dsf-ico-face_love{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAgCAYAAAB6kdqOAAAA4klEQVR4Ac3BIW7EMBRF0euvkrJRF2FiUhRQDYo8JPsq6YKKooEBQSEm4aVRduDSnwEeRS145wSeiClXGtYyBpyYcqVhLWOgwRBjiDHEBB7ElCvOMnR42zTj9TsHy9DR8v49461lDDiGGEOMISbElCvOMnR4r1+feD/XGy1vHx3eNs209DsHhhhDjCHmhQfbNHNwvXHGNs38hSHGEGOIMcQYYgwxhpjAg5hyxblf+Ff9zsFaxoBjiDHEGGICT8SUK879win9zsFaxkCDIcYQY4gJnBRTrpywljFwgiHGEGOI+QXEFTNOnpdqVwAAAABJRU5ErkJggg==);}\n.dsf-ico-face_chat{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAA7ElEQVR4Ac3BMY6CYBSF0e+/cSckWEBJTwP7sDIuyVi5D2joKaGAxLUw7QsFZjKOueckdvKi2fiide4TgTAjzAgzKS+ajeDxvBPVVcYnDeOL6Hq5EQkzwowwc2KnrjL+U11lHBFmhBlh5sQb57IlWqaO6Fy2RMvUEZ3LlmiZOo4IM8KMMJPyotkIlqnjm85lSyTMCDPCzImdYXwR1VXGJw3jiyPCjDAjzCR28qLZOLBMHdEwvoiulxu/sc59IhBmhBlhJvFGXjQbweN5J7pebkTr3Cf+QJgRZoSZxBt50WwcWOc+8UHCjDAjzPwAR5k1B3e8R38AAAAASUVORK5CYII=);}\n.dsf-ico-check{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAsCAYAAAAjFjtnAAABMElEQVR4AdXBIXLcQBCG0W/+WqLae4gM8gHEBucUy/Y8w3STiA0xE4lAdI8pM09oZ8G6umLH1e8lvtmcy8DhPLaEIYITwYngEv/ZnMvA+P3rJ9bt9QfPtNsblghOBCeCS3yxOZeBsawTHq12/rILSwQnghPBXXgw5zJwOI8tYcy5DIxlnfBoteMhghPBieDSnMvAWNYJj3Z7w1rWCY9WOy67sERwIjgR3IUHrXas5X7lmWWd8Gi147IL6zy2hCGCE8GJ4C58oNWOtdyveLTacdmFdR5b4gkRnAhOBHfBqdWOtdyvWK12XHZhnceWcBDBieBEcIkHcy4D6+WdT7UL6zy2xD8QwYngRHCJD8y5DKyXd1x2YZ3HlvhEIjgRnAgu4TTnMnA4jy3xhURwIjgR3B+qk01ZpZIj5QAAAABJRU5ErkJggg==);}\n.dsf-ico-cross{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAABdUlEQVR4AdXBIW7DMBSA4d9PPUCVQ4SYBBkERkY54qRdI2RRoYFRwAIWTTtCVDbo0eeCVpZG3vc5HvQ+Fhoc++po0PtYaHDsq0MRjBGMEYxxvY8F5evzg8rbO9rv9w/asGS0Y18dSu9jQfn6/KDy9o72+/2DNiwZTTBGMEYwxvU+FpTblUo3BloMS0bb5kCLM2W06U5FMEYwRjDmwgtnymjdGHhmmwMtzpRpIRgjGCMY43jQ+1hQblcq053KNgdaDEtGu12pTHcqx746FMEYwRjBGMcLvY8FZZsD/2lYMtqxr44nBGMEYwRjHA96HwvKNgdanCmjdWOgxbBktGNfHYpgjGCMYIzrfSwo2xxocaZMi24MtBiWjCYYIxgjGHPhwZkyWjcGtDNlnpnuVG5XKmfKaN0Y0M6UeUYwRjBGMObCC2fKPDPdqRz76lAmHwvK7UrlTJkWgjGCMYIxjge9j4UGx746GvQ+Fhoc++pQBGMEYwRj/gAepHH15+A7LQAAAABJRU5ErkJggg==);}\n.dsf-ico-cursor_up{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAkCAYAAADo6zjiAAAAnklEQVR4AcXBoQ3DMABE0e+TZzHxCoXeoRsEdqCGR8oOhsFhIZmj3KVRSBW57b0X+CDl0vghYSbMhFngJOXSOFjmgW+63Z8cCTNhJsxiyqVxsMwD/yTMhJkwi3Rax4kewkyYCTNhJsyEmTCLdHrUF1fsWw0cCDNhJswiJ+s40WPfauACYSbMhJkwE2bCTJgFTlIujQv2rQY6CDNhJsze9LIY8ZmuQHkAAAAASUVORK5CYII=);}\n.dsf-ico-cursor_down{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAkCAYAAADo6zjiAAAAsklEQVR4AcXBIQ7CMACF4b8vk5yjpg6N7B2W4EFyGCTzS7jDJBo3s3Pgi21mSMOW932BlZhyocEyT4E/CDNhJsxCTLlQeT2vtDj1D2rLPAUaCDNhJsyEmTATZsKsY2Mx5UIDYSbMhFnHn17PKy1O/YOaMBNmwqxj5T2M1I6XM3sSZsJMmHX88B5G9iTMhJkwC6zElAuVez6wpdv0oSbMhJkwC/wQUy5saJmnQEWYCTNh9gVNGB2EZV6fxgAAAABJRU5ErkJggg==);}\n.dsf-ico-cursor_right{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAkCAYAAADo6zjiAAAArklEQVR4AcXBIQ6DMACF4b8vyJ0Dg5tG9g4k8yA5zOz8Eu5QiZ7DcI75zjaIJQ1b3veFtouZP9q3FPhCmAkzYdZwsC4Tv9QPZAr7lgIFYSbMhFnDn63LRKkfyBSEmTATZg0Hr8eTGtfxxhnCTJgJM2EmzISZMGv2LQUKMzFTYR05RZgJM2EWqNR2MVO4xws15vSmJMyEmTATZsJMmAmzwEltFzMV9i0FCsJMmAmzD+CpHl4lKz6fAAAAAElFTkSuQmCC);}\n.dsf-ico-cursor_left{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAkCAYAAADo6zjiAAAAn0lEQVR4AcXBsQ2DMABE0e+TZ6HxCim9QzagzEChR2IHl9R0NMyR3mktCiSUwL0X+FGXcuWEbS2BhjATZsIscFKXcqUxTz1nPJ5vWsJMmAkzYSbMhJkwi13KFSNhJsyEWWRnnnruJMyEmTCLXGwZRo4IM2EmzCI7yzByJ2EmzIRZ5GKv8qG1rSXQEGbCTJgFdrqUK3+0rSVwQJgJM2H2BVybGPOyKNJJAAAAAElFTkSuQmCC);}\n"
  var SPRITES = {"farmer_idle_down":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAkAAAAAiCAYAAAC3OWZOAAAPPklEQVR4Ae3BP2hcZ77H4c/XSSHbSZyMzswZGRaNxBFIBv1xY0H+VAqqjJzGxgPStAqkMWvSbJMQcGGWTRHsYlIFKWFwF5atplmbhUVSI2kCmqz3ZBOrsGbOHrRcofVUm9+dM+OB2LDVxcrl9fs8eJ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7n/b8UBpEV8xNGVzGYsGIQGS+RMIismJ8wuorBhBWDyHiJhEFkxfyE0VUMJqwYRIbneZ7nvDCIrJifMLqKwYQVg8j4FZ3iV/D19RmKQWTr5RleRl9fn6EYRLZenuFl9PX1GYpBZOvlGTzvZRIGkRXzE0ZXMZiwYhAZL5EwiKyYnzC6isGEFYPIeImEQWTF/ITRVQwmrBhExkvm6+szFIPI1ssz/NrECQmDyASsTBXA6DKQWG8mGH3tNBaOCoPIBKxMFcDoMpBYbyYYfe00Fo4Kg8gErEwVwOgykFhvJhh97TQWjguDyCTR+uffVQwmDIxWGouXRBhEJonWP/+uYjBhYLTSWLwkwiCyb8qzLNd2WS/PslLbpZXG4iURBpF9U55lubbLenmWldourTQWL4kwiOyb8izLtV3Wy7Os1HZppbFwXBhEJmBlqgBGl4HEejPB6GunsThh4gSEQWSVyTwgwFi8eJ5MfeeAHgMEa82EdhoLx4RBZJXJPCDAWLx4nkx954AeAwRrzYR2GgvHhEFklck8IMBYvHieTH3ngB4DBGvNhHYaCweFQWQCDPimPMtybZf18iwrtV2MvnYaC0eFQWQCDPimPMtybZf18iwrtV2MvnYaC0eFQWQCVqYKYHQZSKw3E4y+dhoLR4VBZAJWpgpgdBlIrDcTjL52GgtHhUFkAlamCmB0GUisNxOMvnYaCweFQWSVyTwgwFi8eJ5MfeeAHgMEa82EdhqLEyResDCIrDKZBwnMGFi8OAKITH3ngIG1ZkI7jYUjwiCyymQeJDBjYPHiCCAy9Z0DBtaaCe00Fo4Ig8gqk3mQwIyBxYsjgMjUdw4YWGsmtNNYOCQMIqtM5gEBxuLF82TqOwf0GCBYaya001g4Jgwiq0zmAQHG4sXzZOo7B/QYIFhrJrTTWDgmDCKrTOYBAcbixfNk6jsH9BggWGsmtNNYOCYMIqtM5gEBxuLF82TqOwf0GCBYaya001g4Jgwiq0zmAQHG4sXzZOo7B/QYIFhrJrTTWDgkDCKrTOZBAjMGFi+OACJT3zlgYK2Z0E5jcUJO8YIJ8QyJTH2nxcDi3AiYgRnCLUI8QyJT32kxsDg3AmZghnCLEM+QyNR3Wgwszo2AGZgh3BIGkVUm8yABRqa+/RgwFudGWJwbAdFTmSoQBpHhkDCIrDKZBwkwMvXtx4CxODfC4twIiJ7KVIEwiAyHhEFklck8SICRqW8/BozFuREW50ZA9FSmCoRBZDgkDCKrTOZBAoxMffsxYCzOjbA4NwKipzJVIAwiwyFhEFllMg8SYGTq248BY3FuhMW5ERA9lakCYRAZDhHiGRKZ+k6LgcW5ETADM8TJOsUJ2Ew6ZLaSDn0iU98+oL5zQH37MUiAcNFm0iGzlXToE5n69gH1nQPq249BAoSLNpMOma2kQ5/I1LcPqO8cUN9+DBIgXCPEMyQy9Z0WA4tzI2AGZgi3CPEMiUx9p8XA4twImIEZwi1CPEMiU99pMbA4NwJmYIZwixDPkMjUd1oMLM6NgBmYIdwixDMkMvWdFgOLcyNgBmYI92wmHTJbSYc+kalvH1DfOaC+/RgkQJy0V3nRRM9W0sGAraTDpfwQGE8JJDKbyRMMx4ieraSDAVtJh0v5ITCeEkhkNpMnGI4RPVtJBwO2kg6X8kNgPCWQyGwmTzDcs5l0mA/PsJV0uBSeAUSmvn0AAsxAAsNJm0mH+fAMW0mHS+EZQGTq2wcgwAwkMJy0mXSYD8+wlXS4FJ4BRKa+fQACzEACw0mbSYf58AxbSYdL4RlAZOrbByDADCQwnLSZdJgPz7CVdLgUngFEpr59AALMQALDPaJnK+lgwFbS4VJ+CIynBBKZzeQJxsl6lRfMzJBERhK3r1+gT0hgRo8E63c2aKexcIiZIYmMJG5fv0CfkMCMHgnW72zQTmPhEDNDEhlJ3L5+gT4hgRk9Eqzf2aCdxsIlomcr6WDAVtLhUn4IjKcEEpnN5AmGY0TPVtLBgK2kw6X8EBhPCSQym8kTDMeInq2kgwFbSYdL+SEwnhJIZDaTJxiOET1bSQcDtpIOl/JDYDwlkMhsJk8wHCN6tpIOBmwlHS7lh8B4SiCR2UyeYLjFzJBERhK3r1+gT0hgRo8E63c2aKexOEGvcgLMDEmYGaXpcSSYWa3RqJYxYG61xm61DGzgIjNDEmZGaXocCWZWazSqZQyYW62xWy0DG7jIzJCEmVGaHkeCmdUajWoZA+ZWa+xWy8AGrjEzJJGRxO3rF+gTEpjRI8H6nQ3aaSwcYmZIIiOJ29cv0CckMKNHgvU7G7TTWDjEzJBERhK3r1+gT0hgRo8E63c2aKexcIiZIYmMJG5fv0CfkMCMHgnW72zQTmPhEDNDEhlJ3L5+gT4hgRk9Eqzf2aCdxsIxZoYkzIzS9DgSzKzWaFTLGDC3WmO3WgY2OGmneMHaaayHh8fcu3WZ+cJpwDAD0Se6JFzVTmM9PDzm3q3LzBdOA4YZiD7RJeGqdhrr4eEx925dZr5wGjDMQPSJLgmXmRkZM6M0Pc7YzDhX7m5Qmh6jNDPGB3c3KE2P4SozI2NmlKbHGZsZ58rdDUrTY5Rmxvjg7gal6TFcZWZkzIzS9DhjM+NcubtBaXqM0swYH9zdoDQ9hqvMjIyZUZoeZ2xmnCt3NyhNj1GaGeODuxuUpsdwlZmRMTNK0+OMzYxz5e4GpekxSjNjfHB3g9L0GC5qp7EeHh5z79Zl5gunAcMMRJ/okvi1nOKESHDzxgID+yvXMMCA/eWrmOE0CW7eWGBgf+UaBhiwv3wVM5wmwc0bCwzsr1zDAAP2l69ihpPaaayHh8fcu3WZ+cJpwDAD0Se6JFzVTmM9PDzm3q3LzBdOA4YZiD7RJeGqdhrr4eEx925dZr5wGjDMQPSJLglXtdNYDw+PuXfrMvOF04BhBqJPdEm4qp3Genh4zL1bl5kvnAYMMxB9okvCdRLcvLHAwP7KNQwwYH/5Kmb8Kk5xAlpprNnVGj999yNISHD4zilElxn/evcV5j6s0Upj4aBWGmt2tcZP3/0IEhIcvnMK0WXGv959hbkPa7TSWDiolcaaXa3x03c/goQEh++cQnSZ8a93X2HuwxqtNBaOkuDmjQUG9leuYYAB+8tXMcNpEty8scDA/so1DDBgf/kqZjhNgps3FhjYX7mGAQbsL1/FDKdJcPPGAgP7K9cwwID95auY4TQJbt5YYGB/5RoGGLC/fBUznNVKY82u1vjpux9BQoLDd04husz417uvMPdhjVYaixMmTkAYRMZTn589xyevneOz4yMM49PX3+So9YhMO42Fw8Igss/PnuOT187x2fERhvHp629y1HpEO42F48Igss/PnuOT187x2fERhvHp629y1HpEO42Fw4pBZN9+NE9pZhwBZoYkzAxJzK7WaKWxcFQxiOzbj+YpzYwjwMyQhJkhidnVGq00Fo4qBpF9+9E8pZlxBJgZkjAzJDG7WqOVxsJRxSCybz+apzQzjgAzQxJmhiRmV2u00lg4qhhE9u1H85RmxhFgZkjCzJDE7GqNVhoLB4VBZDz1+dlzfPLaOT47PsIwPn39TY5aj8i001icsFd5wcIgst1qGQHXfvcn3j+b44vcKAuHjzCDL4ZHOWo9olEtM7Nas3YaC8eEQWR0fX72HP9NGETWTmPhoDCIjK7Pz57jvwmDyNppLBwTBpHR9Yez5/jhq+/5ge/55LVzfHZ8hGF8+vqbHLUekQmDyNppLBwSBpHR9Yez5/jhq+/5ge/55LVzfHZ8hGF8+vqbHLUekQmDyNppLBwTBpEZ8MNX3/MD3/PJa+f47PgIw/j09Tc5aj3CZWEQmQH/+OpvjA0nLOVG+ePhI8zgyvAoP+3cx2VhEJkB//jqb4wNJyzlRvnj4SPM4MrwKD/t3MdVYRDZbrWMgGu/+xPvn83xRW6UhcNHmMEXw6MctR7RqJaZWa1ZO43FCTrFCya6DBr398gs5UbJXBkucWV4lIHG/T1cFAaR7VbLNKplvhz6mfeHcwyPjLMw/BYLuRy54hiZRrVMGESGY8Igst1qmUa1zJdDP/P+cI7hkXEWht9iIZcjVxwj06iWCYPIcEgYRLZbLdOolvly6Gcy7w/nGB4ZZ2H4LRZyOXLFMTK71TKNapkwiAxHhEFku9UyjWqZL4d+JvP+cI7hkXEWht9iIZcjVxwjs1st06iWCYPIcEgYRLZbLdOolvly6GfeH84xPDLOwvBbLORy5IpjZBrVMmEQGY4Jg8h2q2Ua1TLVof+wlBsls5Qb5crwKAONapkwiAzHhEFku9UyjWqZ6tB/WMqNklnKjXJleJSBRrVMGESGY0SXQeP+Hpml3CiZK8MlrgyPMtC4v8ev4VVesFYaa+7Dmhl9pd/Q8+P2n3mjOMrAcm2XdhoLx4gug8aDPTJLuVEyS7lRfqlxfw8XiS6DxoM9Mku5UTJLuVF+qXF/D9eILoPGgz0yv/33/1CauEhmKTfKMwwaD/ZwiegyaDzYI/Pbf/8PpYmLZJZyozzDoPFgD9eILoPGgz0yS7lRMku5UX6pcX8PF4kug8aDPX7pp537vFEcZaBxfw8XiS6DxoM9fumnnfu8URxloHF/Dxe10lhzH9bM6Cv9hp4ft//MG8VRBpZru7TTWJwwcYI+fu9tW2smPK8yVeD3f/mrcFQxiMyAylSBtWbC8ypTBdaaCe00Fg4qBpEZUJkqsNZMeF5lqsBaM6GdxsIxxSAyA9pprI/fe9vWmgnPq0wVWG8mGNBOY+GQYhCZAe001sfvvW1rzYTnVaYKrDcTDGinsXBMMYjMgMpUgbVmwvMqUwXWmgntNBYOKgaRGVCZKrDWTHheZarAWjOhncbCQcUgMgMqUwXWmgnPq0wVWGsmtNNYOOzj9962tWbC8ypTBX7/l78Kz/M8z/M8z/M8z/M8z/M8z/M8z/P+r/4XQSdkxvlW8QQAAAAASUVORK5CYII=","w":64,"h":34,"frames":9},"farmer_walk_down":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAANwklEQVR4Ae3BT2ic953H8fdHG1hbdlaK/Mw8I5NYM+JRKxk0lnqwnEB3CypDC07cJcRYYM+xcjaXkNCLL7YDpoRCCq7CVrciOQy+teBDmUNSt2WRdNEfUqu4T+PYLZp5nj5W10bWZE/f1TOS2HXOa5l99Hu9cBzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcf4f8b3ACrkBY0vBG7CCFxj7iO8FVsgNGFsK3oAVvMBwnH3C9wIr5AaMLQVvwApeYOwjvhdYITdgbCl4A1bwAuM56mCP+V5ghdyAsaXgDVjBCwxnX7lxrkzBC2x2osx+dONcmYIX2OxEmf3G9wIr5AaMLQVvwApeYDj7yo1zZQpeYLMTZfajG+fKFLzAZifKPG9ij/leYJ9MnOB8bZnZiRNcqC3TTEKxT/heYJJo/u1PKngDBkYzCUXG+V5gAi4M5Xm5p5O/PnzCy94hfvz7LzG2RUkoMsr3AhNwYSgPxhYDidnVGGNblIQi43wvsE8mTnC+tszsxAku1JZpJqHYJ3wvMEk0//YnFbwBA6OZhCLjfC8wAReG8rzc08lfHz7hZe8QP/79lxjboiQUGeV7gQm4MJQHY4uBxOxqjLEtSkKxx8Qe8b3ABFwYyoOxxUBidjXG2BYlocgo3wtMgAGfTJzgfG2Z2YkTnK8tsytKQpFBvhdYdTAHCDAqo0dJ1ZcatBkgmFmNiZJQZIzvBVYdzAECjMroUVL1pQZtBghmVmOiJBQZ5HuBCbgwlAdji4HE7GqMsS1KQpFRvheYAAM+mTjB+doysxMnuFBbxtgWJaHIIN8LrDqYAwQYldGjpOpLDdoMEMysxkRJKDLG9wKrDuYAAUZl9Cip+lKDNgMEM6sxURKKPST2gO8FVh3MAQKMyuhRUvWlBm0GCGZWY6IkFBnje4FVB3OAAKMyepRUfalBmwGCmdWYKAlFhvheYNXBHEhgxq7KaC8gUvWlBrtmVmOiJBQZ4XuBVQdzIIEZuyqjvYBI1Zca7JpZjYmSUGSI7wVWHcwBAozK6FFS9aUGbQYIZlZjoiQUGeN7gVUHc4AAozJ6lFR9qUGbAYKZ1ZgoCUWG+F5g1cEcSGDGrspoLyBS9aUGu2ZWY6IkFBnhe4FVB3MggRm7KqO9gEjVlxrsmlmNiZJQ7JEOnjHfC6w6mAMJMFL1xTXAqIz0UhnpBdFWHcrje4GRIb4XWHUwBxJgpOqLa4BRGemlMtILoq06lMf3AiNDhHiKRKq+1GRXZaQXzMAMkS1CPEUiVV9qsqsy0gtmYIbIFt8LrDqYAwkwUvXFNcCojPRSGekF0VYdyuN7gZEhvhdYdTAHEmCk6otrgFEZ6aUy0guirTqUx/cCI0OEeIpEqr7UZFdlpBfMwAyRLUI8RSJVX2qyqzLSC2ZghthbHTxjQjxFIlVfarKrMtILZmCGyBYhniKRqi812VUZ6QUzMENkz3zcIrUQt9gmUvXFBvWlBvXFNZAAkUXzcYvUQtxim0jVFxvUlxrUF9dAAkTWCPEUiVR9qcmuykgvmIEZIluEeIpEqr7UZFdlpBfMwAyRPfNxi9RC3GKbSNUXG9SXGtQX10ACRBbNxy1SC3GLbSJVX2xQX2pQX1wDCRB77QX2wHzcYszvZCFucdLvBESqvtgAAWYggZFJ83GLMb+ThbjFSb8TEKn6YgMEmIEERvaItoW4hQELcYuTuQNg7BBIpObjTYyMEW0LcQsDFuIWJ3MHwNghkEjNx5sY2TMftxjzO1mIW5z0OwGRqi82QIAZSGBk0nzcYszvZCFucdLvBESqvtgAAWYggZE9om0hbmHAQtziZO4AGDsEEqn5eBMjY0TbQtzCgIW4xcncATB2CCRS8/Emxt56gWdNtC3ELQxYiFuczB0AY4dAIjUfb2JkjGhbiFsYsBC3OJk7AMYOgURqPt7EyBYzQxIpSaTeHO8HhARmtEkwOzVHlIQiQ8wMSaQkkXpzvB8QEpjRJsHs1BxREoosEW0LcQsDFuIWJ3MHwNghkEjNx5sYGSPaFuIWBizELU7mDoCxQyCRmo83MbLFzJBEShIfnjvONiGBGW0SzE7NESWhyBAzQxIpSXx47jjbhARmtEkwOzVHlIRiD73AM2ZmSCIliQ/PHWebkMCMNglmp+aIklBkiJkhiZQkPjx3nG1CAjPaJJidmiNKQpExZoYkzIxUqdzPvZV7vDE1x/L0BF+u3OPM1BxZZWZIwsxIlcr9/L35d/7l8q9Znp7gP5t/5zuXf00WmRmSSEki9eZ4PyAkMKNNgtmpOaIkFBliZkgiJYnUm+P9gJDAjDYJZqfmiJJQZIyZIQkzozjcjwTlyRq/eucUxXKJkckav3znFFllZkjCzCgO9yNBebLGbz/4Pl1+NyOTNW5/8H2ehw72gJmRMjOKw/2Uyv2c+XiO4nCJYrnEDz6eozhcIqvMjJSZURzup1Tu58zHcxSHSxTLJX7w8RzF4RJZFCWh7q5vcPPaacbyBxnLH8SMNgFih0QWRUmou+sb3Lx2mrH8QcbyBzGjTYDYIZFVZkbKzDAzSuV+iuUSb0zNUSyXKJZLnJmaI6vMjJSZYWaUyv0UyyXemJqjWC5RLJc4MzVHFkVJqLvrG9y8dpqx/EHAMAOxTWyRyKooCXV3fYOb104zlj8IGGYgtoktEs9LB89YlIS6u77BzWunGcsfBAwzENvEFomsipJQd9c3uHntNGP5g4BhBmKb2CKRdRK8/+447787TqpYLvHgwlkMKJZLPDj/FlkmwfvvjvP+u+Okugsv8eDCWQzo9rt5cP4tsihKQt1d3+DmtdOM5Q8ylj+IGW0CxA6JLIqSUHfXN7h57TRj+YOM5Q9iRpsAsUMiyyR4/91xdj24cJZiuYQBD86/RXG4RJZJ8P674+x6cOEsXX43Bjw4/xZd+W6eh39gDxzu7Lny9uvDvHqqxDZx6aXjtI51kLrUPUTrlQ5+futzNjbXr5Ixhzt7rrz9+jCvniqxTVx66TitYx2kLnUP0Xqlg5/f+pyNzfWrZMzG5vrVG5+uXfle3yG6Cz1IgBlf9XWAGZL45rWbNJNQZNDG5vrVG5+uXfn3W5/z81uf82+vD4MZX/V1gBmS+Oa1mzSTUGTQ4c6eK2+/Psyrp0q8dqofEAguvXSc1rEOUpe6h/jpyh/Y2Fy/SsYc7uy58vbrw7x6qsRrp/oBgeDSS8dpHesgdal7iJ+u/IGNzfWrZMzG5vrVG5+uXfle3yG6Cz1I0HpFSAIzvurrYORijWYSigza2Fy/euPTtSvf6ztEd6EHCVqvCElgxld9HYxcrNFMQrHHxB7wvcDY8qt3xiiW+xFgZkjCzJDEickazSQUGeR7gbHlV++MUSz3I8DMkISZIYkTkzWaSSgyyvcCY8tHh7rYdflwF1c3HvHek0dESSgyzPcCW56eQEB5ssZHh7q4fLiLqxuPeO/JI6IkFBlW8AIztq1MT2BmSMLMkMSJyRrNJBQZVfAC++U7YxTL/QgwMyRhZkjixGSNZhKKDPO9wD461MXlw118sPEYw7jyYjePm/eJklBklO8Fxo6PDnVx+XAXH2w8xjCuvNjN4+Z9VqYnKE/WiJJQ7KEXeMZ8L7Dl6QkEnL10ix/+4o9cPtzFBxuPMYwrL3bzuHmflekJypM1i5JQZIjvBbY8PYGAs5du8cNf/JHU5cNdXN14ROq9J4/IMt8LbHl6AgHlyRorx0qkrvf0Mf7wPjx5hO8FFiWhyCixxWDl9h1S3z3Sw/WePsYf3ocnj8g6A5anJxBQnqzx0aEuLh/u4urGI9578ogoCUWGNZNQZz7GYJ6PDnVx+XAXVzcekXrvySOiJBQZ5nuBseW7R3q43tPH+Pp9zOD6kT4eN+/je4FFSSgyxvcCW56eQMDZS7f47qEervf0Mb5+HzO4fqSPx837rPzmDs/DCzxjYovByu07pK4PjHIEuC5hZhyReNy8z8pv7pBFYovByu07pK4PjJLyJK6bIQkWP2NleoLyZM2iJBQZI7YYrNy+Q+qNnj4kgRlnjvTBX+6Rdc0k1MjFmhlQHPkOZyQw48yRPvjLPbJObDFYuX2H1M++8S2OmPEzCRY/I+t8L7Dl6QkElCdrlL7xLa6bIQkWPyPLfC+w5ekJBJQnaxR7+jhzpIiZIYksE1sMVm7fIfVGTx+pM0eKmBm7zteWiZJQ7LEXeMaaSaiRizUzoDqU57dsS9b+zP92vrZMlIQiY5pJqJGLNTO2VfN3+O0/HsfMeNj4gl0rv7lDVjWTUCMXa2Zse9j4gtSR3n7++b/u8CUQJaHIOANe9I/xsPEFkugplNgvmkmokYs1M+BF/xjJ2p850tuPmbEfiC0GK7fvsEsSZkbWiS0GK7fvsMvMeNj4gn/t+Yp7QJSEIoOaSaiRizUzthVfoe3e4mf8U6GPXVESiudA7CHfC4yvqQ7mmPnj34iSUOwDvhcYO6pDeWZWYwQYECWhyDjfC6w6lGdmNWZXlIRiH/jRt1+zmdWYr6sO5fnJ7/5DZJzvBcbXVIfyzKzGREkoMq7gBWb8j+pQnpnVmCgJRcYVvMCMbdWhPDOrMbuiJBT7wI++/ZrNrMZ8XXUoz09+9x/CcRzHcRzHcRzHcRzHcRzHcRzn/8Z/A+lPsjC6a0nkAAAAAElFTkSuQmCC","w":64,"h":34,"frames":8},"farmer_act_down":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAAPWklEQVR4Ae3BT2yTd5rA8e+T4QAmLGBexw7bEjt9QxM0TowKhCIxIE1ldTX0j1aaIZGKr6RCWrVl6QGpu85qOTCVkEYiUjitlMCkPnTbQ1dU3lFENKtRYrKKgUrRJM7w54DtN5aZso49Ug/P+rWxFKreyu5Eb36fD4ZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhbDBBy9ZQoEepC1k9GrJsZRMJWraGAj1KXcjq0ZBlK4ZhGIbnBS1bQ4EepS5k9WjIspUNrI3/A9eH+glZtk4O97MZXR/qJ2TZOjncj2FsJkHL1lCgR6kLWT0asmxlEwlatoYCPUpdyOrRkGUrm0jQsjUU6FHqQlaPhixb2WSuD/UTsmydHO5no/sJL0jQsnWHz59M9HWwkq8wYPlYKVa4W1pju8+fbPf5k2vV8igeFbRs3eHzJxN9HazkKwxYPlaKFe6W1tju8yfbff7kWrU8iscFLVt3bN+TrFTLoyGrR9t9/mSlWh5lkwhatu7YvidZqZZHQ1aPtvv8yUq1PMom0e7zJ28MD5D+03fJyeEBvvimSKVaHmWTaPf5kzeGB0j/6bvk5PAAX3xTpFItj7JJtPv8yRvDA6T/9F1ycniAL74pUqmWR/G4oGXrDp8/mejrYCVfYcDysVKscLe0xnafP9nu8yfXquVRNhjhBQhatiZ6A4AASvzgXlzpbJ4GBQQmFh2KpZzgMUHL1kRvABBAiR/ciyudzdOggMDEokOxlBM8KGjZKoACN4YHeG/qDpPDA5yZuoPSVCzlBI8KWrYKoMCN4QHem7rD5PAAZ6buoDQVSznBo4KWrQKc6esApU5BhMlFB6WpWMoJHhW0bBXgTF8HKHUKIkwuOihNxVJO8KigZasAZ/o6QKlTEGFy0UFpKpZyggcFLVsTvQFAACV+cC+udDZPgwICE4sOxVJO2ECEHylo2ZroDYAIqNISP9gJCK50Nk/LxKJDsZQTPCJo2ZroDYAIqNISP9gJCK50Nk/LxKJDsZQTPCRo2ZroDQACKPGDe3Gls3kaFBCYWHQolnKCxwQtWxO9AUAAJX5wL650Nk+DAgITiw7FUk7wmKBla6I3AAigxA/uxZXO5mlQQGBi0aFYygkeE7RsTfQGAAGU+MG9uNLZPA0KCEwsOhRLOcFjgpatid4AIIASP7gXVzqbp0EBgYlFh2IpJ3hI0LI10RsAEVClJX6wExBc6WyelolFh2IpJ2wQbfxIgvAcEVzpbIGWeKwTVEEVwVsE4TkiuNLZAi3xWCeogiqCtwQtWxO9ARABFFd64TGgxGOdxGOdIDQk+joIWrbiIUHL1kRvAEQAxZVeeAwo8Vgn8VgnCA2Jvg6Clq14SNCyNdEbABFAcaUXHgNKPNZJPNYJQkOir4OgZSseErRsTfQGQARQXOmFx4ASj3USj3WC0JDo6yBo2YqHBC1bE70BEAEUV3rhMaDEY53EY50gNCT6OghatuIhgvAcEVzpbIGWeKwTVEEVYWNp4wWYc2q4Mk6NJsGVXsiTzuZJLzwGEUDwojmnhivj1GgSXOmFPOlsnvTCYxABBK8RhOeI4EpnC7TEY52gCqoI3iIIzxHBlc4WaInHOkEVVBG8RRCeI4IrnS3QEo91giqoIniLIDxHBFc6W6AlHusEVVBF8BZBeI4IrnS2QEs81gmqoIrgPXNODVfGqdEkuNILedLZPOmFxyACCBvNFn4soSHj1FAg49Q4EtgKyjMCIrjmnCqKxwgNGaeGAhmnxpHAVlCeERDBNedUUbxnzqkxGPSRcWocCfoAwZVeyIMAqiACiifNOTUGgz4yTo0jQR8guNILeRBAFURA8aQ5p8Zg0EfGqXEk6AMEV3ohDwKogggonjTn1BgM+sg4NY4EfYDgSi/kQQBVEAHFk+acGoNBHxmnxpGgDxBc6YU8CKAKIqB4j9CQcWookHFqHAlsBeUZARFcc04VZWPZwo+kqogILhHh8tABmgQRUKVBBCavzlIs5QQPUVVEBJeIcHnoAE2CCKjSIAKTV2cplnKClwgNGaeGAhmnxpHAVlCeERDBNedUUTxGaMg4NRTIODWOBLaC8oyACK45p4riMUJDxqmhQMapcSSwFZRnBERwzTlVFI8RGjJODQUyTo0jga2gPCMggmvOqaJ4jNCQcWookHFqHAlsBeUZARFcc04VxVtUFRHBJSJcHjpAkyACqjSIwOTVWYqlnLCBbOEFUFVEBFUlHO1GBPrPTnH32jAKxM5OcefaMDCLF6kqIoKqEo52IwL9Z6e4e20YBWJnp7hzbRiYxWtUFRHBJSJcHjpAkyACqjSIwOTVWYqlnOAhqoqI4BIRLg8doEkQAVUaRGDy6izFUk7wEFVFRHCJCJeHDtAkiIAqDSIweXWWYikneIiqIiK4RITLQwdoEkRAlQYRmLw6S7GUEzxEVRERXCLC5aEDNAkioEqDCExenaVYygkeo6qICKpKONqNCPSfneLutWEUiJ2d4s61YWCWjaaNH6lYyslSuULq0ikGO7YBiioITUKdCF5VLOVkqVwhdekUgx3bAEUVhCahTgQvU1Vcqko42k2kv5t3xmYJRyOE+yO8OzZLOBrBq1QVl6oSjnYT6e/mnbFZwtEI4f4I747NEo5G8CpVxaWqhKPdRPq7eWdslnA0Qrg/wrtjs4SjEbxKVXGpKuFoN5H+bt4ZmyUcjRDuj/Du2CzhaASvUlVcqko42k2kv5t3xmYJRyOE+yO8OzZLOBrBi4qlnCyVK6QunWKwYxugqILQJNSJsFG18YKIwPkPfk7LozO/QgEFHr33S1TxNBE4/8HPaXl05lcooMCj936JKg0hq0fxkGIpJ0vlCqlLpxjs2AYoqiA0CXUitISsHsVDiqWcLJUrpC6dYrBjG6CogtAk1IngVcVSTpbKFVKXTjHYsQ1QVEFoEupE8KpiKSdL5QqpS6cY7NgGKKogNAl1IrSErB7FQ4qlnCyVK6QunWKwYxugqILQJNSJ0BKyejRk9SgeIwLnP/g5LY/O/AoFFHj03i9RpSFk9WjI6lE2iJ/wAlSq5dHr04+Tb3ZtZ1fIjwjUXhZEBFT5S1cbsZEpQGj37UlWquVRPKRSLY9en36cfLNrO7tCfkSg9rIgIqDKX7raiI1MkR0f4p//7QuSdaN1eES7z598/60orx+N0CRc3H2A2r42XBd39VF7uY3xr74hOz7E9el8slItj+IR7T5/8v23orx+NEKTcHH3AWr72nBd3NXH33zwr/zjx//AtbHfJivV8ige0u7zJ99/K8rrRyM0CRd3H6C2rw3XxV191F5uY/yrb2j37Um2+/YkK9XyKB7R7vMn338ryutHIzQJF3cfoLavDdfFXX3UXm5j/KtvyI4PcX06n6xUy6N4RLvPn3z/rSivH43QJFzcfYDavjZcF3f1UXu5jfGvviE7PsTIqZ9yfTqfrFTLo3hApVoevT79OPlm13Z2hfyIQO1lQURAlb90tREbmQKE7PhpRk79lOvT+WSlWh7lr0x4gYKWrVe27+T82lOubN+JoiR37OJp4SGF1WVcxc8/ITaSolBaFjwmaNl6ZftOzq89pWVHaB9PCw/51L+TM3+cZz2pwyNClq1fnhsk3N9N7OxnrHfn2hADZ6f48twg4WiE2EiK/OoSLqnDA0KWrV+eGyTc340AqkpsJIUrv7rEep2B/RRKy4KHhCxbvzw3SLi/GwFUFRFBVREROv7+X3AVP/8EV2wkRaG0LHhEyLL1y3ODhPu7iZ39jJb86hLOv/8TA2en+LV/J/uHewlHI8RGUhRKy4JHhCxbvzw3SLi/m9jZz2jJjp9GRBg4O8Wv/TvZP9xLOBohNpKiUFoWPCRo2Xpl+07Orz3lyvadKEpyxy6eFh7y36+G+dv/+k9cxc8/ITaSolBaFv7KhBfoRtdrSt2Jl3Zz6I8PacmvLvFDpA4PudH1mlJ34qXduLZ8eJTYSApFSd38mhOHXuH7pA6PuNH1mlJ34qXduLZ8eBRXbCTFevnVJdaTOjzgRtdrSt35tae4suOnccVGUuRXl1hP6vCYG12vKXXn157SsiO0j6V7v2O94uefEBtJUSgtCx7y265DSt3PXtrFlg+P4oqNpMivLtHSGdhPdvw0sZEUhdKy4CG/7Tqk1P3spV1s+fAorthICkURhPUKpWXBY4KWrXf3Rfhum3Lojw9xdcVO8CB7i8LqMutJHRtAGy/QR2vf8sYeP9OrT5h/tYvs+Gmy46fpDOznh2gdHvLR2re8scfP9OoTplef8ODefbLjpxEE18z8CuvNzK/gJR+tfcsbe/xMrz5hevUJD+7dpyW/ukR+dYlCaVlm5ldomZlfwSs+WvuWN/b4mX+1i/lXu3hw7z4/ZGZ+BZc+g0d8tPYtb+zxM/9qF9nx02THT/M/hUfMzK/QMjO/QmwkRaG0LHjMh2t/5jc9MaZXn/Dg3n3Wm5lfYWZ+BVdsJEWhtCx4zIdrf+Y3PTGmV5/w4N591iuUlqVQWpZCaVkKpWXBo972dzG9+oTs+Gmy46d5mJ0hdfNrvk/r2AC28IK97e/i4aMH/BrYf+8+4WiE9WbmVzhx6BVcM/MreM3b/i4ePnpAw1iG7HgE14lDrzAzv8LM/AotJw69gtZJHR7xtr+Lh48e0DCWATIoysz8Ci0nD9ty63ZOqTt52BY85G1/F+ceLeD6eOwhkOGzmzeZmV+h5eRhW6ibmV/Ba972d3Hu0QL7790nHI3gOv13b5K6+TWuk4dtweM+Lj+FsQyQIb+6xMz8Cq6Th21hE/i4/BTGMkCG/OoSoUAPm8nH5afsv3efcDRCy8z8CicOvULLzPwKG4HwAl04fkwnFh1cgtDy2c2b/JCTh23BQy4cP6YTiw4tguA60xfgF1cmWO/kYVtu3c4pdScP24IHXDh+TCcWHb4v0dfBp7//g+BxF44f04lFB0FwKYor0dfBL65M4Dp52BY86sLxYzqx6CAILYqS6Ovg09//QfC4C8eP6cSigyt182vWO3nYFjzuwvFjOrHokLr5NScOvYJrZn6F//gowae//4PgcReOH9OJRYfC6jKdgf24FCXR18Evrkyw3snDtrCZ3Lqd01u3c4phGMYmcOt2Tm/dzimb0K3bOb11O6dsQrdu5/TW7ZzyPbdu5/TW7ZxiGIZhGIZhGIZhGIbx/+p/AQvBO2sO9eIlAAAAAElFTkSuQmCC","w":64,"h":34,"frames":8},"farmer_down":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAANwklEQVR4Ae3BT2ic953H8fdHG1hbdlaK/Mw8I5NYM+JRKxk0lnqwnEB3CypDC07cJcRYYM+xcjaXkNCLL7YDpoRCCq7CVrciOQy+teBDmUNSt2WRdNEfUqu4T+PYLZp5nj5W10bWZE/f1TOS2HXOa5l99Hu9cBzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcf4f8b3ACrkBY0vBG7CCFxj7iO8FVsgNGFsK3oAVvMBwnH3C9wIr5AaMLQVvwApeYOwjvhdYITdgbCl4A1bwAuM56mCP+V5ghdyAsaXgDVjBCwxnX7lxrkzBC2x2osx+dONcmYIX2OxEmf3G9wIr5AaMLQVvwApeYDj7yo1zZQpeYLMTZfajG+fKFLzAZifKPG9ij/leYJ9MnOB8bZnZiRNcqC3TTEKxT/heYJJo/u1PKngDBkYzCUXG+V5gAi4M5Xm5p5O/PnzCy94hfvz7LzG2RUkoMsr3AhNwYSgPxhYDidnVGGNblIQi43wvsE8mTnC+tszsxAku1JZpJqHYJ3wvMEk0//YnFbwBA6OZhCLjfC8wAReG8rzc08lfHz7hZe8QP/79lxjboiQUGeV7gQm4MJQHY4uBxOxqjLEtSkKxx8Qe8b3ABFwYyoOxxUBidjXG2BYlocgo3wtMgAGfTJzgfG2Z2YkTnK8tsytKQpFBvhdYdTAHCDAqo0dJ1ZcatBkgmFmNiZJQZIzvBVYdzAECjMroUVL1pQZtBghmVmOiJBQZ5HuBCbgwlAdji4HE7GqMsS1KQpFRvheYAAM+mTjB+doysxMnuFBbxtgWJaHIIN8LrDqYAwQYldGjpOpLDdoMEMysxkRJKDLG9wKrDuYAAUZl9Cip+lKDNgMEM6sxURKKPST2gO8FVh3MAQKMyuhRUvWlBm0GCGZWY6IkFBnje4FVB3OAAKMyepRUfalBmwGCmdWYKAlFhvheYNXBHEhgxq7KaC8gUvWlBrtmVmOiJBQZ4XuBVQdzIIEZuyqjvYBI1Zca7JpZjYmSUGSI7wVWHcwBAozK6FFS9aUGbQYIZlZjoiQUGeN7gVUHc4AAozJ6lFR9qUGbAYKZ1ZgoCUWG+F5g1cEcSGDGrspoLyBS9aUGu2ZWY6IkFBnhe4FVB3MggRm7KqO9gEjVlxrsmlmNiZJQ7JEOnjHfC6w6mAMJMFL1xTXAqIz0UhnpBdFWHcrje4GRIb4XWHUwBxJgpOqLa4BRGemlMtILoq06lMf3AiNDhHiKRKq+1GRXZaQXzMAMkS1CPEUiVV9qsqsy0gtmYIbIFt8LrDqYAwkwUvXFNcCojPRSGekF0VYdyuN7gZEhvhdYdTAHEmCk6otrgFEZ6aUy0guirTqUx/cCI0OEeIpEqr7UZFdlpBfMwAyRLUI8RSJVX2qyqzLSC2ZghthbHTxjQjxFIlVfarKrMtILZmCGyBYhniKRqi812VUZ6QUzMENkz3zcIrUQt9gmUvXFBvWlBvXFNZAAkUXzcYvUQtxim0jVFxvUlxrUF9dAAkTWCPEUiVR9qcmuykgvmIEZIluEeIpEqr7UZFdlpBfMwAyRPfNxi9RC3GKbSNUXG9SXGtQX10ACRBbNxy1SC3GLbSJVX2xQX2pQX1wDCRB77QX2wHzcYszvZCFucdLvBESqvtgAAWYggZFJ83GLMb+ThbjFSb8TEKn6YgMEmIEERvaItoW4hQELcYuTuQNg7BBIpObjTYyMEW0LcQsDFuIWJ3MHwNghkEjNx5sY2TMftxjzO1mIW5z0OwGRqi82QIAZSGBk0nzcYszvZCFucdLvBESqvtgAAWYggZE9om0hbmHAQtziZO4AGDsEEqn5eBMjY0TbQtzCgIW4xcncATB2CCRS8/Emxt56gWdNtC3ELQxYiFuczB0AY4dAIjUfb2JkjGhbiFsYsBC3OJk7AMYOgURqPt7EyBYzQxIpSaTeHO8HhARmtEkwOzVHlIQiQ8wMSaQkkXpzvB8QEpjRJsHs1BxREoosEW0LcQsDFuIWJ3MHwNghkEjNx5sYGSPaFuIWBizELU7mDoCxQyCRmo83MbLFzJBEShIfnjvONiGBGW0SzE7NESWhyBAzQxIpSXx47jjbhARmtEkwOzVHlIRiD73AM2ZmSCIliQ/PHWebkMCMNglmp+aIklBkiJkhiZQkPjx3nG1CAjPaJJidmiNKQpExZoYkzIxUqdzPvZV7vDE1x/L0BF+u3OPM1BxZZWZIwsxIlcr9/L35d/7l8q9Znp7gP5t/5zuXf00WmRmSSEki9eZ4PyAkMKNNgtmpOaIkFBliZkgiJYnUm+P9gJDAjDYJZqfmiJJQZIyZIQkzozjcjwTlyRq/eucUxXKJkckav3znFFllZkjCzCgO9yNBebLGbz/4Pl1+NyOTNW5/8H2ehw72gJmRMjOKw/2Uyv2c+XiO4nCJYrnEDz6eozhcIqvMjJSZURzup1Tu58zHcxSHSxTLJX7w8RzF4RJZFCWh7q5vcPPaacbyBxnLH8SMNgFih0QWRUmou+sb3Lx2mrH8QcbyBzGjTYDYIZFVZkbKzDAzSuV+iuUSb0zNUSyXKJZLnJmaI6vMjJSZYWaUyv0UyyXemJqjWC5RLJc4MzVHFkVJqLvrG9y8dpqx/EHAMAOxTWyRyKooCXV3fYOb104zlj8IGGYgtoktEs9LB89YlIS6u77BzWunGcsfBAwzENvEFomsipJQd9c3uHntNGP5g4BhBmKb2CKRdRK8/+447787TqpYLvHgwlkMKJZLPDj/FlkmwfvvjvP+u+Okugsv8eDCWQzo9rt5cP4tsihKQt1d3+DmtdOM5Q8ylj+IGW0CxA6JLIqSUHfXN7h57TRj+YOM5Q9iRpsAsUMiyyR4/91xdj24cJZiuYQBD86/RXG4RJZJ8P674+x6cOEsXX43Bjw4/xZd+W6eh39gDxzu7Lny9uvDvHqqxDZx6aXjtI51kLrUPUTrlQ5+futzNjbXr5Ixhzt7rrz9+jCvniqxTVx66TitYx2kLnUP0Xqlg5/f+pyNzfWrZMzG5vrVG5+uXfle3yG6Cz1IgBlf9XWAGZL45rWbNJNQZNDG5vrVG5+uXfn3W5/z81uf82+vD4MZX/V1gBmS+Oa1mzSTUGTQ4c6eK2+/Psyrp0q8dqofEAguvXSc1rEOUpe6h/jpyh/Y2Fy/SsYc7uy58vbrw7x6qsRrp/oBgeDSS8dpHesgdal7iJ+u/IGNzfWrZMzG5vrVG5+uXfle3yG6Cz1I0HpFSAIzvurrYORijWYSigza2Fy/euPTtSvf6ztEd6EHCVqvCElgxld9HYxcrNFMQrHHxB7wvcDY8qt3xiiW+xFgZkjCzJDEickazSQUGeR7gbHlV++MUSz3I8DMkISZIYkTkzWaSSgyyvcCY8tHh7rYdflwF1c3HvHek0dESSgyzPcCW56eQEB5ssZHh7q4fLiLqxuPeO/JI6IkFBlW8AIztq1MT2BmSMLMkMSJyRrNJBQZVfAC++U7YxTL/QgwMyRhZkjixGSNZhKKDPO9wD461MXlw118sPEYw7jyYjePm/eJklBklO8Fxo6PDnVx+XAXH2w8xjCuvNjN4+Z9VqYnKE/WiJJQ7KEXeMZ8L7Dl6QkEnL10ix/+4o9cPtzFBxuPMYwrL3bzuHmflekJypM1i5JQZIjvBbY8PYGAs5du8cNf/JHU5cNdXN14ROq9J4/IMt8LbHl6AgHlyRorx0qkrvf0Mf7wPjx5hO8FFiWhyCixxWDl9h1S3z3Sw/WePsYf3ocnj8g6A5anJxBQnqzx0aEuLh/u4urGI9578ogoCUWGNZNQZz7GYJ6PDnVx+XAXVzcekXrvySOiJBQZ5nuBseW7R3q43tPH+Pp9zOD6kT4eN+/je4FFSSgyxvcCW56eQMDZS7f47qEervf0Mb5+HzO4fqSPx837rPzmDs/DCzxjYovByu07pK4PjHIEuC5hZhyReNy8z8pv7pBFYovByu07pK4PjJLyJK6bIQkWP2NleoLyZM2iJBQZI7YYrNy+Q+qNnj4kgRlnjvTBX+6Rdc0k1MjFmhlQHPkOZyQw48yRPvjLPbJObDFYuX2H1M++8S2OmPEzCRY/I+t8L7Dl6QkElCdrlL7xLa6bIQkWPyPLfC+w5ekJBJQnaxR7+jhzpIiZIYksE1sMVm7fIfVGTx+pM0eKmBm7zteWiZJQ7LEXeMaaSaiRizUzoDqU57dsS9b+zP92vrZMlIQiY5pJqJGLNTO2VfN3+O0/HsfMeNj4gl0rv7lDVjWTUCMXa2Zse9j4gtSR3n7++b/u8CUQJaHIOANe9I/xsPEFkugplNgvmkmokYs1M+BF/xjJ2p850tuPmbEfiC0GK7fvsEsSZkbWiS0GK7fvsMvMeNj4gn/t+Yp7QJSEIoOaSaiRizUzthVfoe3e4mf8U6GPXVESiudA7CHfC4yvqQ7mmPnj34iSUOwDvhcYO6pDeWZWYwQYECWhyDjfC6w6lGdmNWZXlIRiH/jRt1+zmdWYr6sO5fnJ7/5DZJzvBcbXVIfyzKzGREkoMq7gBWb8j+pQnpnVmCgJRcYVvMCMbdWhPDOrMbuiJBT7wI++/ZrNrMZ8XXUoz09+9x/CcRzHcRzHcRzHcRzHcRzHcRzn/8Z/A+lPsjC6a0nkAAAAAElFTkSuQmCC","w":64,"h":34,"frames":8},"farmer_idle_left":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAkAAAAAiCAYAAAC3OWZOAAAQM0lEQVR4Ae3BT2hbZ7rA4d+bDrRRjKHSsY7Ujf7kBKpS2+omhmkHShS0CnbASYh6Y23TZSZh6C7IiwyUrL1Ql07AzSwG2qWGYQyFYnvjWB3sEE7zxwtXOjlRYyLLgaF9r448KiWry4U48OV7HizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsizLsv4v3uI1SjmejsQStW6vM58aO6HHYvHaXq8zzxsi5Xg6EkvUur3OfGrshB6LxWt7vc48b4iU4+lILFHr9jrzqbETeiwWr+31OvNYlmVZRks5no7EErVurzOfGjuhx2Lx2l6vM88hOsJrdqsyQcrx9PbFCd5EtyoTpBxPb1+c4E10qzJByvH09sUJLOtNknI8TTknlL7U2Al1HU95g6QcT1POCaUvNXZCXcdT3iApx9OUc0LpS42dUNfxlDfMrcoEKcfT2xcneB3e4jVwHU9HYvGaACO/KJNOjB9bXSbHjvGg93btWCxe2+t15jGU63g6EovXBBj5RZl0YvzY6jI5dowHvbdrx2Lx2l6vM4+hXMfTkVi8JsDIL8qkE+PHVpfJsWM86L1dOxaL1/Z6nXkMl3I8HYklat1eZz41dkKPxeK1vV5nnjdEyvF0JJaodXud+dTYCT0Wi9f2ep153hAjsXjtVmWSfzz4T+12ZZK//7vNXq8zzxtiJBav3apM8o8H/6ndrkzy93+32et15nlDjMTitVuVSf7x4D+125VJ/v7vNnu9zjyGcx1PR2LxmgAjvyiTTowfW10mx47xoPd27VgsXtvrdeY5BMIhcx1Pq4UkKCAMlItpIo31HUAAZfHeE9qhLxjGdTytFpKggDBQLqaJNNZ3AAGUxXtPaIe+YBjX8bRaSIICwkC5mCbSWN8BBFAW7z2hHfqCgVzHU/oEuFWZZG5pg9uVSf5naQMBFGiHvmAo1/GUPgFuVSaZW9rgdmWS/1naQAAF2qEvGMp1PKVPgLlCElQBAYFbWwEKtENfMJTreEqfAHOFJKgCAgK3tgIUaIe+YCjX8ZQ+AeYKSVAFBARubQUo0A59wUCu42m1kAQFhIFyMU2ksb4DCKAs3ntCO/SFV0w4RK7jabWQZKhcTHNAaaz/xG9EQJXFe09oh75gCNfxtFpIMlQupjmgNNZ/4jcioMrivSe0Q18whOt4Wi0kGSoX0xxQGus/8RsRUGXx3hPaoS8YxHU8rRaSoIAwUC6miTTWdwABlMV7T2iHvmAY1/G0WkiCAsJAuZgm0ljfAQRQFu89oR36gmFcx9NqIQkKCAPlYppIY30HEEBZvPeEdugLhnEdT6uFJCggDJSLaSKN9R1AAGXx3hPaoS8YxnU8rRaSoIAwUC6miTTWdwABlMV7T2iHvmAQ1/G0WkgyVC6mOaA01n/iNyKgyuK9J7RDX3iFjnCIhD5VUKVcTDPUuNtiQITfEwSTCH2qoEq5mGaocbfFgAi/JwgmEfpUQZVyMc1Q426LARF+TxBM4jqeVgtJBgTKxTTlYhpQGus7HFAQofr+GK7jKQZxHU+rhSQDAuVimnIxDSiN9R0OKIhQfX8M1/EUg7iOp9VCkgGBcjFNuZgGlMb6DgcURKi+P4breIpBXMfTaiHJgEC5mKZcTANKY32HAwoiVN8fw3U8xSCu42m1kGRAoFxMUy6mAaWxvsMBBRGq74/hOp5iEKFPFVQpF9MMNe62GBDh9wThVfsDh05AoLG+AyKggNAnRNaCfU66MVaDfcwkINBY3wERUEDoEyJrwT4n3RirwT5mEhBorO+ACCgg9AmRtWCfk26M1WAf0wh9qkTKH73HUONuiwERUGVIEEwi9KkSKX/0HkONuy0GRECVIUEwidCnSqT80XsMNe62GBABVYYEwSRCnyqR8kfvMdS422JABFQZEgSTCH2qRMofvcdQ426LARFQZUgQzCMg0FjfARFQQOgTImvBPifdGKvBPofhDxwiBVaDHlNuDEQ4oKAMrAUvUGAt2GdAMIoCq0GPKTcGIhxQUAbWghcosBbsMyAYRYHVoMeUGwMRDigoA2vBCxRYC/YZEAwkINBY3wERUEDoEyJrwT4n3RirwT5mEhBorO+ACCgg9AmRtWCfk26M1WAfMwkINNZ3QAQUEPqEyFqwz0k3xmqwj5kEBBrrOyACCgh9QmQt2OekG2M12MdMAgKN9R0QAQWEPiGyFuxz0o2xGuxjGgVWgx5TbgxEOKCgDKwFL1BgLdhnQHjl/sAhaoe+CJ7e/OxDVBkQAVX6lFngi683iYgIqopJ2qEvgqc3P/sQVQZEQJU+ZRb44utNIiKCqmKSduiL4OnNzz5ElQERUKVPmQW++HqTiIigqphEgdWgx5QbAxEOKCgDa8ELFFgL9hkQjKLAatBjyo2BCAcUlIG14AUKrAX7DAhGUWA16DHlxkCEAwrKwFrwAgXWgn0GBKMosBr0mHJjIMIBBWVgLXiBAmvBPgOCURRYDXpMuTEQ4YCCMrAWvECBtWCfAcEo7dAXwdObn32IKgMioEqfMgt88fUmERFBVXnVjvAaZMdznF1YITuRIzueY2ZhhdxEnux4HlUloqqYKjue4+zCCtmJHNnxHDMLK+Qm8mTH86gqEVXFVNnxHGcXVshO5MiO55hZWCE3kSc7nkdViagqpmmHvtzvdDlXyjN7Ks/sqTznTh9ntnSc2VKeLy9+gIgQERFUFZO0Q1/ud7qcK+WZPZVn9lSec6ePM1s6zmwpz5cXP0BEiIgIqopJ2qEv9ztdzpXyzJ7KM3sqz7nTx5ktHWe2lOfLix8gIkREBFXFJO3Ql/udLudKeWZP5Zk9lefc6ePMlo4zW8rz5cUPEBEiIoKqYpJ26Mv9TpdzpTyzp/LMnspz7vRxZkvHmS3l+fLiB4gIERFBVTFRdjzH2YUVshM5suM5ZhZWyE3kyY7nUVUiqsphOMLrIoJwQABV+pSp5FHu3DjD/U6XdugLphJBOCCAKn3KVPIod26c4X6nSzv0BVOJIBwQQJU+ZSp5lDs3znC/06Ud+oKBsuM5zi6skJ3IkR3PMbOwQm4iT3Y8j6oSUVVMlR3PcXZhhexEjux4jpmFFXITebLjeVSViKpiqux4jrMLK2QncmTHc8wsrJCbyJMdz6OqRFQVU2XHc5xdWCE7kSM7nmNmYYXcRJ7seB5VJaKqmCo7nuPswgrZiRzZ8RwzCyvkJvJkx/OoKhFVxWgiCAcEUKVPmUoe5c6NM9zvdGmHvvCKHeE1UIXtS+dRQIHtuQsMXbtSQgSjqcL2pfMooMD23AWGrl0pIYLRVGH70nkUUGB77gJD166UEMF8IggHBFClT5lKHuXOjTPc73Rph75gKhGEAwKo0qdMJY9y58YZ7ne6tENfMJUIwgEBVOlTppJHuXPjDPc7XdqhL5hKBOGAAKr0KVPJo9y5cYb7nS7t0BdMJYJwQABV+pSp5FHu3DjD/U6XdugLBlKF7UvnUUCB7bkLDF27UkKEQ3OEQ9YKfSl+vsTPn7wFqgjQ+fgIIoAIj354yOTlJVqhLxioFfpS/HyJnz95C1QRoPPxEUQAER798JDJy0u0Ql8wUCv0pfj5Ej9/8haoIkDn4yOIACI8+uEhk5eXaIW+YChV2L50HgUU2J67wNC1KyVEMJoqbF86jwIKbM9dYOjalRIiGE0Vti+dRwEFtucuMHTtSgkRjKYK25fOo4AC23MXGLp2pYQIRlOF7UvnUUCB7bkLDF27UkIEY7VCX4qfL/HzJ2+BKgJ0Pj6CCCDCox8eMnl5iVboC4dAeA1cx1P6RlMZas+fIQjXR0aZ7+5ydW+XoXboC4ZyHU9HUxlqz58hCNdHRpnv7nJ1b5d26AuGcx1PR1MZas+fIQjXR0aZ7+5ydW+XdugLBks5nm7UK6gqIoKqIiIo8Kj5gLMLq7RCXzBUyvF0o15BVRERVBURQYFHzQecXVilFfqCoVKOpxv1CqqKiKCqiAgKPGo+4OzCKq3QFwyVcjzdqFdQVUQEVUVEUOBR8wFnF1Zphb5gqJTj6Ua9gqoiIqgqIoICj5oPOLuwSiv0BUO5jqf0jaYy1J4/QxCuj4wy393l6t4uQ+3QF14x4ZC5jqfNeoWJy0tki5/yzdPHiMB0PMO3ncdc2Av521/PoMDk5SXaoS8YxnU8pW80laH2/BmCcH1klPnuLpGre7tE2qEvGMh1PKVvNJWh9vwZgnB9ZJT57i6Rq3u7RNqhLxjGdTzlv0ZTGWrPnyEI10dGme/uMnR1b5dIO/QFg7iOp/zXaCpD7fkzBOH6yCjz3V2Gru7tEmmHvmAY1/GUvtFUhtrzZwjC9ZFR5ru7RK7u7RJph75gINfxlL5s8VO+efoYEZiOZ/i285h/Pv2ZP+89I9IOfcFAruMpfdnip3zz9DEiMB3P8G3nMf98+jN/3ntGpB36gmFcx9NmvcLE5SWyxU/55uljRGA6nuHbzmMu7IX87a9nUGDy8hLt0BdeoSO8Bs3lTYZmEhlmElki0/EMkebyJigI5nEdT5v1CpF4KkcpHqeUeJdEOs/pRJyv3vmVZr3CRr2C63iKYVzH02a9QiSeylGKxykl3iWRznM6Eeerd36lWa+wUa/gOp5iENfxtFmvsFGvEImncpTicUqJd0mk85xOxIl89c6vNOsVNuoVXMdTDOE6njbrFTbqFSLxVI5SPE4p8S6JdJ7TiTiRr975lWa9wka9gut4ikFcx9NmvUIknspRiscpJd4lkc5zOhHnq3d+pVmvsFGv4DqeYhjX8bRZrzA0k8gwHc8QmY5nqL/zC816hY16BdfxFMO4jqfNeoWhmUSG6XiGyHQ8Q/2dX2jWK2zUK7iOpxioubzJ0Ewiw0wiS2Q6niHSXN4EBeHVO8Iha4e+XFraINJpPaTTesjD9X8xdO/pcy4tbVD8fIlW6AsGai5vMjSTyDAdzxCZjmeINJc3QUEwU3N5k6GZRIbpeIbIdDxDpLm8CQqCeZrLm6D8ZiaRYTqeITIdz3B1b5dIc3kTFASzNJc3QfnNTCLDdDxDZDqe4ereLpHm8iYoCOZpLm8yNJPIMB3PEJmOZ4g0lzdBQTBTc3mTSKf1kE7rIY/uLvN7zeVNUBDM1FzeJNJpPaTTesiju8v8XnN5ExQE87RDXy4tbRDptB7SaT3k4fq/GLr39DmXljYofr5EK/SFV0x4Tf7ypz/q4lbAy6qFJDe/+14wmOt4Wi0kWdwKeFm1kGRxK0CAVugLBnIdT6uFJItbAS+rFpIsbgUI0Ap9wTCu46kAc4Uki1sBL6sWktz87ntxHU8FaIW+YBDX8VSAuUKSxa2Al1ULSW5+9724jqcCtEJfMIzreFotJFncCnhZtZBkcStAgFboCwZyHU+rhSSLWwEvqxaSLG4FCNAKfcFAruNptZBkcSvgZdVCksWtAAFaoS8Y6i9/+qMubgW8rFpIcvO77wXLsizLsizLsizLsizLsizLsizLsv4//hfnWbN3NLGzTQAAAABJRU5ErkJggg==","w":64,"h":34,"frames":9},"farmer_walk_left":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAAPE0lEQVR4Ae3BQWhc953A8e9PTpvV0ySWRk/zZgy1ZsZPxgrRWM7BCg5dghV0si0vckKUxkNvceklJJSCA+nMwYc0UIpjk4jeJLO2L4YQHdop6wRKg6QtK1sRtnBfZa/LyprR68QmM28ch+S380ZVCDnuYhme/p8PhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmH8/2zDMB6RpO1qzOou1IJqMdnTpx1WvFAPqkW2iKTtaszqLtSCajHZ06cdVrxQD6pFDGMLSNquxqzuQi2oFpM9fdphxQv1oFpki0jarsas7kItqBaTPX3aYcUL9aBaZBO18QglbVeTdp/SlOzpU8d2FWNLmRrPkbRdPfdyjq1oajxH0nb13Ms5tpqk7WrS7lOakj196tiuYmwpU+M5krar517OsRVNjedI2q6eeznHo7CNRyhmxQtT43v54/JXhXPje7m0WKYeVItsEUnb1ZjVXagF1WKyp087rHihHlSLRJxjuxqz4gUB9nS2k7F+wJdffUMm9kOWg8cLHVa8UA+qRSLKsV2NWfGCALGvlb22xd9Wa+zt6WA5eLzQYcUL9aBaJOJiVrwwNb6XPy5/VTg3vpdLi2XqQbXIFpG0XY1Z3YVaUC0me/q0w4oX6kG1SMQ5tqsxK14QYE9nOxnrB3z51TdkYj9kOXi80GHFC/WgWiSiHNvVmBUvCBD7WtlrW/xttcbeng6Wg8cLHVa8UA+qRTaB8Ag4tqs0CXC8PwGqgIDA1PUKCpR9T4gox3aVfzo3vpfj569ybnwvPzl/FQEUKPueEEGO7Wq+PwEKCC0jgylCpfkVQABlcmmNsu8JEePYrub7E6CA0DIymCJUml8BBFAml9Yo+54QQY7tKk0CHO9PgCogIDB1vYICZd8TIsqxXaVJgKnxvRw/f5Vz43v5yfmrCKBA2feECHJsV/P9CVBAaBkZTBEqza8AAiiTS2uUfU+IGMd2Nd+fAAWElpHBFKHS/AoggDK5tEbZ94SHTNhkju1qvj8BCggtI4MpQqX5FUAAZXJpjbLvCRHj2K7m+xOggNAyMpgiVJpfAQRQJpfWKPueECGO7Wq+P8GGkcEU65TS/B2+JQKqTC6tUfY9ISIc29V8f4INI4Mp1iml+Tt8SwRUmVxao+x7QoQ4tqv5/gQoILSMDKYIleZXAAGUyaU1yr4nRIxju5rvT4ACQsvIYIpQaX4FEECZXFqj7HtChDi2q/n+BBtGBlOsU0rzd/iWCKgyubRG2feEiHBsV/P9CTaMDKZYp5Tm7/AtEVBlcmmNsu8JD1Ebm8ixXc33J2gRGBlMMTKYApTS/ArrFETI7+nBsV0lQhzb1Xx/ghaBkcEUI4MpQCnNr7BOQYT8nh4c21UiRGhSBVVGBlNsKF1ZpUWE7xKEKBGaVEGVkcEUG0pXVmkR4bsEIUoc29V8f4IWgZHBFCODKUApza+wTkGE/J4eHNtVIsSxXc33J2gRGBlMMTKYApTS/ArrFETI7+nBsV0lQoQmVVBlZDDFhtKVVVpE+C5BiBKhSRVUGRlMsaF0ZZUWEb5LEB62x9hEQpMqoZF9O9hQurJKiwioskEQokRoUiU0sm8HG0pXVmkRAVU2CEL0CAiU5ldABBQQmoTQXKXBfsdittIgmgQESvMrIAIKCE1CaK7SYL9jMVtpEDVCkyqhkX072FC6skqLCKiyQRCiRGhSJTSybwcbSldWaREBVTYIQvQICJTmV0AEFBCahNBcpcF+x2K20iCaBARK8ysgAgoITUJortJgv2MxW2mwGR5j0wkIlOZXQAQUEJqE0FylwX7HYrbSIJoEBErzKyACCghNQmiu0mC/YzFbaRA1CsxWAoYcC0RYp6C0zFXuo8BcpUGLECkKzFYChhwLRFinoLTMVe6jwFylQYsQQQICpfkVEAEFhCYhNFdpsN+xmK00iCYBgdL8CoiAAkKTEJqrNNjvWMxWGkSNArOVgCHHAhHWKSgtc5X7KDBXadAiRIoCs5WAIccCEdYpKC1zlfsoMFdp0CI8dI+xiRSYrQQMORaIsE5BaZmr3EeBuUqDFiFSFJitBAw5FoiwTkFpmavcR4G5SoMWIVLKvieCq+++8jSqtIiAKk3K3IVriAghEUFViZKy74ng6ruvPI0qLSKgSpMyd+EaIkJIRFBVokSB2UrAkGOBCOsUlJa5yn0UmKs0aBEiRYHZSsCQY4EI6xSUlrnKfRSYqzRoESKl7HsiuPruK0+jSosIqNKkjAG/vHCNkIigqkRJ2fdEcPXdV55GlRYRUKVJGQN+eeEaIRFBVXnY2thEZd+TG9Uax4azjB3MMnYwy7EXdjE2vIux4SzvvPwUIkJIRFBVoqTse3KjWuPYcJaxg1nGDmY59sIuxoZ3MTac5Z2Xn0JECIkIqkoUjZ6ZIZTOZThyZoZQJpdFVVFVQqpKVI2emaEz0Uk6l+HImRk6E51kcllUFVUlpKpETdn35Ea1xrHhLGMHs4wdzHLshV2MDe9ibDhLSEQIiQiqSpSUfU9uVGscG84ydjDL2MEsx17YxdjwLsaGs4REhJCIoKpEkSocPTtDOpdBFUbPzpDJZUkPZFFVQqpKVHUmujh6doZ0LkNnoovRszNkclnSA1lUlZCqshnaeATSAxmOnp0hncuQHsgwenaGTC5LeiCLqhJSVaIqPZDh6NkZ0rkM6YEMo2dnyOSypAeyqCohVSWyRAgJIKxThaFEO0OJdi6eOsSNao2y7wlRJEJIAGGdKgwl2hlKtHPx1CFuVGuUfU+IoNEzM6RzGdK5DEfOzJDOZcjksqgqqkpIVYmq0TMzpHMZ0rkMR87MkM5lyOSyqCqqSkhViTQRhHUCqNKkDCXauXjqEDeqNcq+J0SVCMI6AVRpUoYS7Vw8dYgb1Rpl3xMesjYeFRGEdQKo0qQMJdq5eOoQN6o1yr4nRJUIwjoBVGlShhLtXDx1iBvVGmXfEyLo9qsvks5lUOD28ZdI5zKE3nx9mDdfH0aESLv96ot0Op0ocPv4S3Qmuwi9+fowb74+jAjRJkJIAGGdKgwl2hlKtHPx1CFuVGuUfU+IIhFCAgjrVGEo0c5Qop2Lpw5xo1qj7HtCBKUHMtx+9UUUSOcy3D7+EhvefH0YESJte6KT26++iALbnU5uH3+JDW++PowIm2YbmyxmxQsnDg1wsqufxs42Qie7nqKxs43QgWeziAgfTC9SC6pFIiZmxQsnDg1wsqufxs42Qie7nqKxs43QgWeziAgfTC9SC6pFIqYWVIu/8+4UfnZ4AFS539sGqogIiHDrs5s8//bvWfU9IYJqQbX4O+9O4WeHB0CV+71toIqIsPfEBT6YXuSD6UVWfU+IoJgVL9w+/hKNnW2ETnY9RWNnG6EDz2Y48GwWEeGD6UVqQbVIxMSseOH28Zdo7GwjdLLrKRo72wgdeDbDgWeziAgfTC9SC6pFIqYWVIvnLq8UfvrzHKgiIjR+JIgIiHDrs5s8//bvWfU9IYJqQbV47vJK4ac/z4EqIkLjR4KIgAi3PrvJ82//nlXfEzaB8AgkbVevToyjqogIqoqIoMCthWVGz84SKvueEEFJ29WrE+OoKiKCqiIiKHBrYZnRs7OEyr4nRJRju/qbju38KradYu0eG96o3yNU9j0hwhzb1d90bOdXse0Ua/d4o36PhYlxFNj72nnKvidEVNJ29erEOKqKiKCqiAi5184TEmDV94SIStquXp0YR1UREVQVEUGBWwvLHD07y6rvCRHm2K4+meyl8MVdBOHt2JMUa/d4o36Psu8JEeXYri5MjJN77TxPJnspfHEXQXg79iTF2j3eqN9jQ9n3hIdsG5vMsV1dmBgn99p5/v0vX7Dzo8+4Vfobx/9cofejRd5ZqnD5t2OcODzA1OWVQj2oFomYDiteeH96kd0f/53lP/yV/Kdr9H60yM0//JV3lipc/u0YJw4PMHV5pVAPqkUixrFdpenXyR18mMjwljwga7Vz1F9lYWKcE4cHmLq8UqgH1SIRFbPihV8nd/BhIsNb8oD3793luSe24fT2MDG9SC2oFomoWlAtTl1eKez++O8c/3OF3ulFjl76CwsT45w4PMD704vUg2qRiKoF1eLU5ZXC7o//zvIf/kr+0zV6P1rk3y79hQv/+T+UfU+IMMd2laaUu4+TPCBrtfNhIsNb8oD3790lZsUL9aBaJIJiVrzw3BPbuLRYJuXu4yQPyFrtfJjI8JY84OPHvubyb8c4cXiAqcsrhXpQLfIQtfEILHxyjVB3Ksvpvn2c3r2P7lSW0337CC18cg0UhOhxbFcXJsYJvbf7GU737cPesYvTffs43beP0MIn10BBiLbR7l5Co91pjsR7CS18cg0UhOgb7e4lNNqdJj34PK+ev8rgifOs+p6wBby3+xm6U1ne2/0MoYVProGCsDW8t/sZTvftw96xizfq91iYGOfqxDiO7SpbgIgw2t3LaHeaUO72TRYmxrk6MY5ju0oElX1PXj1/lQ2j3b2MdqcJHYn3Elr45BooCA/fNjZZPagWS8tfFWj6Wr+hUfuc4IvPsZ7oInTgX+7yq4+XmZheZNX3hIiJWfHCc09s49Jima/1Gxq1z2mPdRH61y+v8R+3P+fSYpmJ6UVWfU+IoHpQLcaseOFIV8B/P9bDP+4s06h9zoP6PS4tlpmYXmTV94QIi1nxQmcyTai6epPgi895PLadL+v3qAfVIhEXs+KFzmSa0D/uLPN4bDsXZm4wMb3Iqu8JERez4oXOZBoRIXR39RbPPbENp7eHielFakG1SETVg2oxZsULR7oC/mvtC9pjXYTurt7iuSe24fT2MDG9SC2oFomgelAtxqx44RuURu0uZe8Knck0Ie/mDS4tlpmYXmTV94SHTHhEHNvV/J4eJpfW+L6y7wkR5tiuCqBAvj/B5PUKG8q+J2wRju0q/5TvTzB5vULZ94Qt4Bc/PqCT1yt8X74/wbt/+lSIOMd2Nd+fYPJ6he8r+56wBTi2q/n+BJPXK2wQYNX3hC3AsV3ln/L9CSavVwgJsOp7QoT94scHdPJ6he/L9yd490+fCoZhGIZhGIZhGIZhGIZhGIZhGP93/wsP2jISIx0LvwAAAABJRU5ErkJggg==","w":64,"h":34,"frames":8},"farmer_act_left":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAAPWElEQVR4Ae3Bb2jUd57A8fcn22VxEgTjb/4VNibxN7ZTzGTkrClyix57N1u5QOVkN0bXoc8MLMct7rWCD8rkik8u9PooMD5NhJgnfeTSMgtHcoLkX8lorHrxFxNDL85MhrFukxlhu3zu95vsLKHso9Njwy/f1wvDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMAzDMF7OD9jBIpatLYH9mY1qZTASjGlzoDWzWa0MsktELFtbAvszG9XKYCQY0+ZAa2azWhnEMAzD8LWIZWtLYH9mo1oZjARj2hxozWxWK4O8Qk3scKP9CSKWrdfPJtiNRvsTRCxbr59NYBi7ScSyNWLFFFckGNOwZSu7SMSyNWLFFFckGNOwZSu7SMSyNWLFFFckGNOwZSu7zGh/gohl6/WzCf4//IAdKGzZ2hJozQjQ8kel2wqwVNigO9jM4+qPMs2B1sxmtTKIT4UtW1sCrRkBWv6odFsBlgobdAebeVz9UaY50JrZrFYG8bmIZWtLYH9mo1oZjARj2hxozWxWK4PsEhHL1pbA/sxGtTIYCca0OdCa2axWBtklWgKtmdH+bn73+A+Z6/3dfHavyGa1Msgu0RJozYz2d/O7x3/IXO/v5rN7RTarlUF2iZZAa2a0v5vfPf5D5np/N5/dK7JZrQzic2HL1pZAa0aAlj8q3VaApcIG3cFmHld/lGkOtGY2q5VBXgFhhwlbtqbjIVBAqEslo3hy82uAAMrIw3WKZUfwmbBlazoeAgWEulQyiic3vwYIoIw8XKdYdgQfClu24hJgtL+bC2N3uN7fzfmxOwigQLHsCD4VtmzFJcBofzcXxu5wvb+b82N3EECBYtkRfCps2YpLgAvxEKgCAgKjD0ooUCw7gk+FLVtxCXAhHgJVQEBg9EEJBYplR/CpsGUrLgEuxEOgCggIjD4ooUCx7Ag+FLZsTcdDoIBQl0pG8eTm1wABlJGH6xTLjvCShB0kbNmajodoSCWjbFFy80/5MxFQZeThOsWyI/hE2LI1HQ/RkEpG2aLk5p/yZyKgysjDdYplR/CRsGVrOh4CBYS6VDKKJze/BgigjDxcp1h2BJ8JW7am4yFQQKhLJaN4cvNrgADKyMN1imVH8JmwZWs6HgIFhLpUMoonN78GCKCMPFynWHYEnwlbtqbjIVBAqEslo3hy82uAAMrIw3WKZUfwmbBlazoeAgWEulQyiic3vwYIoIw8XKdYdgQfCVu2puMhGlLJKFuU3PxT/kwEVBl5uE6x7AgvoYkdRHCpgiqpZJSGXL5AnQjbCYKfCC5VUCWVjNKQyxeoE2E7QfCTsGVrOh6iTiCVjJJKRgElN7/GFgUR0m8GCVu24iNhy9Z0PESdQCoZJZWMAkpufo0tCiKk3wwStmzFR8KWrel4iDqBVDJKKhkFlNz8GlsUREi/GSRs2YqPhC1b0/EQdQKpZJRUMgooufk1tiiIkH4zSNiyFR8JW7am4yHqBFLJKKlkFFBy82tsURAh/WaQsGUrPiK4VEGVVDJKQy5foE6E7QThZb3GjiMgkJtfAxFQQHAJnplSjWPhANOlGv4kIJCbXwMRUEBwCZ6ZUo1j4QDTpRp+I7hU8aSOvE5DLl+gTgRUaRAEPxFcqnhSR16nIZcvUCcCqjQIgp8ILlU8qSOv05DLF6gTAVUaBMFPBJcqntSR12nI5QvUiYAqDYLgJ4JLFU/qyOs05PIF6kRAlQZB8B8Bgdz8GoiAAoJL8MyUahwLB5gu1XgVXmMHUWC6VKUnHAARtigodTOlFygwU6pRJ/iKAtOlKj3hAIiwRUGpmym9QIGZUo06wYcEBHLzayACCgguwTNTqnEsHGC6VMOfBARy82sgAgoILsEzU6pxLBxgulTDnwQEcvNrIAIKCC7BM1OqcSwcYLpUw58EBHLzayACCgguwTNTqnEsHGC6VMOfBARy82sgAgoILsEzU6pxLBxgulTDbxSYLlXpCQdAhC0KSt1M6QUKzJRq1Akv7TV2kGLZEcHWoXOHUaVOBFRxKWeAyzfu4xERVBU/KZYdEWwdOncYVepEQBWXcga4fOM+HhFBVfETBaZLVXrCARBhi4JSN1N6gQIzpRp1gq8oMF2q0hMOgAhbFJS6mdILFJgp1agTfEWB6VKVnnAARNiioNTNlF6gwEypRp3gKwpMl6r0hAMgwhYFpW6m9AIFZko16gRfUWC6VKUnHAARtigodTOlFygwU6pRJ/hKseyIYOvQucOoUicCqriUM8DlG/fxiAiqyst6jR2ovauD7otj5K/1I0Di4hh3r/WjCjr2FSKCquJX7V0ddF8cI3+tHwESF8e4e60fVdCxrxARVBW/KZYdEWwdOncYVepEQBWXcga4fOM+HhFBVfGTYtkRwdahc4dRpU4EVHEpZ4DLN+7jERFUFT8plh0RbB06dxhV6kRAFZdyBrh84z4eEUFV8ZNi2RHB1qFzh1GlTgRUcSlngMs37uMREVQVPymWHRFsHTp3GFXqREAVl3IGuHzjPh4RQVXxo/auDrovjpG/1o8AiYtj3L3Wjyro2FeICKrKq9DETiWCsEUAVVxKT2gP41d7WaxsUCw7gl+JIGwRQBWX0hPaw/jVXhYrGxTLjuBD7V0dnB6eoj3RQXtXB+8NT9GR6KS9qxNVxaOq+FV7Vwenh6doT3TQ3tXBe8NTdCQ6ae/qRFXxqCp+1d7VwenhKdoTHbR3dfDe8BQdiU7auzpRVTyqil+1d3VweniK9kQH7V0dvDc8RUeik/auTlQVj6riV+1dHZwenqI90UF7VwfvDU/RkeikvasTVcWjqviaCMIWAVRxKT2hPYxf7WWxskGx7AgvqYkdSBVWf/lzFFBg9cIvaPjNr3+KCL4UsWKKSxVWf/lzFFBg9cIvaPjNr3+KCL4UsWJKgwjCFgFUcSk9oT2MX+1lsbJBsewIfiWCsEUAVVxKT2gP41d7WaxsUCw7gl+JIGwRQBWX0hPaw/jVXhYrGxTLjuAjESumNIggbBFAFZfSE9rD+NVeFisbFMuO4BMRK6YRK6Y0iCBsEUAVl9IT2sP41V4WKxsUy47gExErphErprhUYfWXP0cBBVYv/IKG3/z6p4jwyvyAHSRixRSE7M0F3v9VAlQREWo/FkQERFhZWObkR19QKDuCj6jrXz/8Zy4cXCc5cIP3f5UAVUSE2o8FEQERVhaWOfnRFxTKjuAjESum+Wwf2Zv3GOjt4sq+OLW2JjxX9r1Fra0Jz/F3OhERsjfvsVGtDOIjESumT9cf0Rz/O/7laYFaWxOeK/veotbWhOf4O52ICNmb99ioVgbxiYgV05bA/gyugd4uruyLU2trwnNl31vU2prwHH+nExEhe/MeG9XKID4RsWKaz/aRvXmPgd4uruyLU2trwnNl31vU2prwHH+nExEhe/MeG9XKID4QsWKaz/Yx0HuY7M17DPR2cWVfnFpbE54r+96i1taE5/g7nYgI2Zv32KhWBvGBiBXTfLaPgd7DZG9+RfbmAu//KgGqiAi1HwsiAiKsLCxz8qMvKJQd4RUQdoiIFdN8to/wmY/xRIIx9kYOkPn2GwTh0uZzPmney6XN5xTLjuAj6mKb0TeO8kHlOXsjB/i2sErDJ817ubT5nGLZEXxCXbiiwUPks32sLCxzeniaO9f66b54g+3y186ycvcxp4enKZQdwUciVkyfri+yXTR4CE8+24eIoMDK3cecHp6mUHYEn4hYMc1n+/CEz3yMp/TZR6gqIoKqIiIosHL3MaeHpymUHcEnIlZM89k+VhaWWRx7yIeV59y51k/on/6NaPAQDflrZ1m5+5jTw9MUyo7gExErpvlsHysLyyyOPeTDynPuXOtHVUkOjNOQv3aWlbuPOT08TaHsCD4RsWKaz/YRPvMxnv/523/gb/57hb2RA2S+/QZBuLT5nE+a93Jp8znFsiO8IsIOoC7+gmjwEA1zbxxg8utneM4/+VLwCXXxPZNzS/SdehdByGf7+O7TKTyTXz/Dc/7Jl4IPqIttosFDbJfP9uH57tMpPJNfP8Nz/smXgs+oi22iwUPks314kgPjeD5p3ovn/JMvBR+JWDHNZ/sIn/mY7Q51/T3fFlZp+KR5L57zT74UfCRixTSf7SM5MM7T9UUaosFD5LN9eL77dIr/+vobPOeezAk+E7FiyjaKIgj5bB+e7z6d4r++/gbPuSdzgs+oi20iwRjtyZM8yU/imXvjAD+sCYnVZYplR3hFXuOvTF38BdHgIfLZPjzffTrFf64/42f7W0msLuMnk3NLnDh6kIbJuSU8gpDP9rGysMzi+jM8P9vfSmJ1Gb+YnFvixNGDeCbnliiUH4m6cEWDh/CsLCyzuP4Mz8/2t5JYXcYv1IVLXJNzS5w4epDvW1lYZu6NA3h+WBMSq8v4TaH8SJID43rjwPucOHoQz+TcEt8WVsln+/B89+kUP6wJidVl/KZQfiTJgXHFNTm3hOfE0YM0rCwss7j+jOHYEVbyE/hRofxI2CZs2cqfrCwss7j+jOHYEVbyE/iNuvie8c+/4OypU+SzfXhyVz5nuO0IrC7zKr3GX9nk3BInjh7EMzm3xImjB9luZWGZxfVnfFj5PcNtR2B1Gb9QF67JuSW2O3H0IA2nh2doGG47AqvL+MXJt22ZmHUU18m3bcE1ObeER1GSA+NsN9x2BFaX8YvJuSUaTr5ty8Sso/zJjc8/J3nqFJ5/b92LZ7jtCKwu40eF8iM5+bbNxKyjuPpOvYsgeFYWlllcf8Zw2xFYXcaPCuVHguvk2zYTs45Ozi3xdH2RaPAQDQfa2FWeri8SDR6i4UAbvjQ5t8SJowdpmJxbYruVhWU+rPyeA228csIOMDHrKH/B2VOnaFAUTzoeYujWbcEHJmYdxXXybVsmZh1lm99eSjP6YB2PojSk4yGGbt0WfO6DnxzXkQclvi8dDzF067bgUxOzjuL67aU0Iw9KeATBoyjpeIihW7cFn/vgJ8d15EEJQWhQlHQ8xNCt24LPTcw6yjZ9p97Fk46HGLp1W/C5D35yXP/xP0Y4cfQgnsm5JfpOvUs6HmLo1m3BZyZmHWWb315KM/KghCB4nq4vEgnGSMdDDN26LfjVxKyjE7OOYhiGsYtNzDo6Mesou9jErKMTs46yC0zMOjox6yjfMzHr6MSsoxiGYRiGYRiGYRiGYfyf/C9VNIcqo2Ei0QAAAABJRU5ErkJggg==","w":64,"h":34,"frames":8},"farmer_left":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAAPE0lEQVR4Ae3BQWhc953A8e9PTpvV0ySWRk/zZgy1ZsZPxgrRWM7BCg5dghV0si0vckKUxkNvceklJJSCA+nMwYc0UIpjk4jeJLO2L4YQHdop6wRKg6QtK1sRtnBfZa/LyprR68QmM28ch+S380ZVCDnuYhme/p8PhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmEYhmH8/2zDMB6RpO1qzOou1IJqMdnTpx1WvFAPqkW2iKTtaszqLtSCajHZ06cdVrxQD6pFDGMLSNquxqzuQi2oFpM9fdphxQv1oFpki0jarsas7kItqBaTPX3aYcUL9aBaZBO18QglbVeTdp/SlOzpU8d2FWNLmRrPkbRdPfdyjq1oajxH0nb13Ms5tpqk7WrS7lOakj196tiuYmwpU+M5krar517OsRVNjedI2q6eeznHo7CNRyhmxQtT43v54/JXhXPje7m0WKYeVItsEUnb1ZjVXagF1WKyp087rHihHlSLRJxjuxqz4gUB9nS2k7F+wJdffUMm9kOWg8cLHVa8UA+qRSLKsV2NWfGCALGvlb22xd9Wa+zt6WA5eLzQYcUL9aBaJOJiVrwwNb6XPy5/VTg3vpdLi2XqQbXIFpG0XY1Z3YVaUC0me/q0w4oX6kG1SMQ5tqsxK14QYE9nOxnrB3z51TdkYj9kOXi80GHFC/WgWiSiHNvVmBUvCBD7WtlrW/xttcbeng6Wg8cLHVa8UA+qRTaB8Ag4tqs0CXC8PwGqgIDA1PUKCpR9T4gox3aVfzo3vpfj569ybnwvPzl/FQEUKPueEEGO7Wq+PwEKCC0jgylCpfkVQABlcmmNsu8JEePYrub7E6CA0DIymCJUml8BBFAml9Yo+54QQY7tKk0CHO9PgCogIDB1vYICZd8TIsqxXaVJgKnxvRw/f5Vz43v5yfmrCKBA2feECHJsV/P9CVBAaBkZTBEqza8AAiiTS2uUfU+IGMd2Nd+fAAWElpHBFKHS/AoggDK5tEbZ94SHTNhkju1qvj8BCggtI4MpQqX5FUAAZXJpjbLvCRHj2K7m+xOggNAyMpgiVJpfAQRQJpfWKPueECGO7Wq+P8GGkcEU65TS/B2+JQKqTC6tUfY9ISIc29V8f4INI4Mp1iml+Tt8SwRUmVxao+x7QoQ4tqv5/gQoILSMDKYIleZXAAGUyaU1yr4nRIxju5rvT4ACQsvIYIpQaX4FEECZXFqj7HtChDi2q/n+BBtGBlOsU0rzd/iWCKgyubRG2feEiHBsV/P9CTaMDKZYp5Tm7/AtEVBlcmmNsu8JD1Ebm8ixXc33J2gRGBlMMTKYApTS/ArrFETI7+nBsV0lQhzb1Xx/ghaBkcEUI4MpQCnNr7BOQYT8nh4c21UiRGhSBVVGBlNsKF1ZpUWE7xKEKBGaVEGVkcEUG0pXVmkR4bsEIUoc29V8f4IWgZHBFCODKUApza+wTkGE/J4eHNtVIsSxXc33J2gRGBlMMTKYApTS/ArrFETI7+nBsV0lQoQmVVBlZDDFhtKVVVpE+C5BiBKhSRVUGRlMsaF0ZZUWEb5LEB62x9hEQpMqoZF9O9hQurJKiwioskEQokRoUiU0sm8HG0pXVmkRAVU2CEL0CAiU5ldABBQQmoTQXKXBfsdittIgmgQESvMrIAIKCE1CaK7SYL9jMVtpEDVCkyqhkX072FC6skqLCKiyQRCiRGhSJTSybwcbSldWaREBVTYIQvQICJTmV0AEFBCahNBcpcF+x2K20iCaBARK8ysgAgoITUJortJgv2MxW2mwGR5j0wkIlOZXQAQUEJqE0FylwX7HYrbSIJoEBErzKyACCghNQmiu0mC/YzFbaRA1CsxWAoYcC0RYp6C0zFXuo8BcpUGLECkKzFYChhwLRFinoLTMVe6jwFylQYsQQQICpfkVEAEFhCYhNFdpsN+xmK00iCYBgdL8CoiAAkKTEJqrNNjvWMxWGkSNArOVgCHHAhHWKSgtc5X7KDBXadAiRIoCs5WAIccCEdYpKC1zlfsoMFdp0CI8dI+xiRSYrQQMORaIsE5BaZmr3EeBuUqDFiFSFJitBAw5FoiwTkFpmavcR4G5SoMWIVLKvieCq+++8jSqtIiAKk3K3IVriAghEUFViZKy74ng6ruvPI0qLSKgSpMyd+EaIkJIRFBVokSB2UrAkGOBCOsUlJa5yn0UmKs0aBEiRYHZSsCQY4EI6xSUlrnKfRSYqzRoESKl7HsiuPruK0+jSosIqNKkjAG/vHCNkIigqkRJ2fdEcPXdV55GlRYRUKVJGQN+eeEaIRFBVXnY2thEZd+TG9Uax4azjB3MMnYwy7EXdjE2vIux4SzvvPwUIkJIRFBVoqTse3KjWuPYcJaxg1nGDmY59sIuxoZ3MTac5Z2Xn0JECIkIqkoUjZ6ZIZTOZThyZoZQJpdFVVFVQqpKVI2emaEz0Uk6l+HImRk6E51kcllUFVUlpKpETdn35Ea1xrHhLGMHs4wdzHLshV2MDe9ibDhLSEQIiQiqSpSUfU9uVGscG84ydjDL2MEsx17YxdjwLsaGs4REhJCIoKpEkSocPTtDOpdBFUbPzpDJZUkPZFFVQqpKVHUmujh6doZ0LkNnoovRszNkclnSA1lUlZCqshnaeATSAxmOnp0hncuQHsgwenaGTC5LeiCLqhJSVaIqPZDh6NkZ0rkM6YEMo2dnyOSypAeyqCohVSWyRAgJIKxThaFEO0OJdi6eOsSNao2y7wlRJEJIAGGdKgwl2hlKtHPx1CFuVGuUfU+IoNEzM6RzGdK5DEfOzJDOZcjksqgqqkpIVYmq0TMzpHMZ0rkMR87MkM5lyOSyqCqqSkhViTQRhHUCqNKkDCXauXjqEDeqNcq+J0SVCMI6AVRpUoYS7Vw8dYgb1Rpl3xMesjYeFRGEdQKo0qQMJdq5eOoQN6o1yr4nRJUIwjoBVGlShhLtXDx1iBvVGmXfEyLo9qsvks5lUOD28ZdI5zKE3nx9mDdfH0aESLv96ot0Op0ocPv4S3Qmuwi9+fowb74+jAjRJkJIAGGdKgwl2hlKtHPx1CFuVGuUfU+IIhFCAgjrVGEo0c5Qop2Lpw5xo1qj7HtCBKUHMtx+9UUUSOcy3D7+EhvefH0YESJte6KT26++iALbnU5uH3+JDW++PowIm2YbmyxmxQsnDg1wsqufxs42Qie7nqKxs43QgWeziAgfTC9SC6pFIiZmxQsnDg1wsqufxs42Qie7nqKxs43QgWeziAgfTC9SC6pFIqYWVIu/8+4UfnZ4AFS539sGqogIiHDrs5s8//bvWfU9IYJqQbX4O+9O4WeHB0CV+71toIqIsPfEBT6YXuSD6UVWfU+IoJgVL9w+/hKNnW2ETnY9RWNnG6EDz2Y48GwWEeGD6UVqQbVIxMSseOH28Zdo7GwjdLLrKRo72wgdeDbDgWeziAgfTC9SC6pFIqYWVIvnLq8UfvrzHKgiIjR+JIgIiHDrs5s8//bvWfU9IYJqQbV47vJK4ac/z4EqIkLjR4KIgAi3PrvJ82//nlXfEzaB8AgkbVevToyjqogIqoqIoMCthWVGz84SKvueEEFJ29WrE+OoKiKCqiIiKHBrYZnRs7OEyr4nRJRju/qbju38KradYu0eG96o3yNU9j0hwhzb1d90bOdXse0Ua/d4o36PhYlxFNj72nnKvidEVNJ29erEOKqKiKCqiAi5184TEmDV94SIStquXp0YR1UREVQVEUGBWwvLHD07y6rvCRHm2K4+meyl8MVdBOHt2JMUa/d4o36Psu8JEeXYri5MjJN77TxPJnspfHEXQXg79iTF2j3eqN9jQ9n3hIdsG5vMsV1dmBgn99p5/v0vX7Dzo8+4Vfobx/9cofejRd5ZqnD5t2OcODzA1OWVQj2oFomYDiteeH96kd0f/53lP/yV/Kdr9H60yM0//JV3lipc/u0YJw4PMHV5pVAPqkUixrFdpenXyR18mMjwljwga7Vz1F9lYWKcE4cHmLq8UqgH1SIRFbPihV8nd/BhIsNb8oD3793luSe24fT2MDG9SC2oFomoWlAtTl1eKez++O8c/3OF3ulFjl76CwsT45w4PMD704vUg2qRiKoF1eLU5ZXC7o//zvIf/kr+0zV6P1rk3y79hQv/+T+UfU+IMMd2laaUu4+TPCBrtfNhIsNb8oD3790lZsUL9aBaJIJiVrzw3BPbuLRYJuXu4yQPyFrtfJjI8JY84OPHvubyb8c4cXiAqcsrhXpQLfIQtfEILHxyjVB3Ksvpvn2c3r2P7lSW0337CC18cg0UhOhxbFcXJsYJvbf7GU737cPesYvTffs43beP0MIn10BBiLbR7l5Co91pjsR7CS18cg0UhOgb7e4lNNqdJj34PK+ev8rgifOs+p6wBby3+xm6U1ne2/0MoYVProGCsDW8t/sZTvftw96xizfq91iYGOfqxDiO7SpbgIgw2t3LaHeaUO72TRYmxrk6MY5ju0oElX1PXj1/lQ2j3b2MdqcJHYn3Elr45BooCA/fNjZZPagWS8tfFWj6Wr+hUfuc4IvPsZ7oInTgX+7yq4+XmZheZNX3hIiJWfHCc09s49Jima/1Gxq1z2mPdRH61y+v8R+3P+fSYpmJ6UVWfU+IoHpQLcaseOFIV8B/P9bDP+4s06h9zoP6PS4tlpmYXmTV94QIi1nxQmcyTai6epPgi895PLadL+v3qAfVIhEXs+KFzmSa0D/uLPN4bDsXZm4wMb3Iqu8JERez4oXOZBoRIXR39RbPPbENp7eHielFakG1SETVg2oxZsULR7oC/mvtC9pjXYTurt7iuSe24fT2MDG9SC2oFomgelAtxqx44RuURu0uZe8Knck0Ie/mDS4tlpmYXmTV94SHTHhEHNvV/J4eJpfW+L6y7wkR5tiuCqBAvj/B5PUKG8q+J2wRju0q/5TvTzB5vULZ94Qt4Bc/PqCT1yt8X74/wbt/+lSIOMd2Nd+fYPJ6he8r+56wBTi2q/n+BJPXK2wQYNX3hC3AsV3ln/L9CSavVwgJsOp7QoT94scHdPJ6he/L9yd490+fCoZhGIZhGIZhGIZhGIZhGIZhGP93/wsP2jISIx0LvwAAAABJRU5ErkJggg==","w":64,"h":34,"frames":8},"farmer_idle_right":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAkAAAAAiCAYAAAC3OWZOAAAPPklEQVR4Ae3BP2hcZ77H4c/XSSHbSZyMzswZGRaNxBFIBv1xY0H+VAqqjJzGxgPStAqkMWvSbJMQcGGWTRHsYlIFKWFwF5atplmbhUVSI2kCmqz3ZBOrsGbOHrRcofVUm9+dM+OB2LDVxcrl9fs8eJ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7neZ7n/b8UBpEV8xNGVzGYsGIQGS+RMIismJ8wuorBhBWDyHiJhEFkxfyE0VUMJqwYRIbneZ7nvDCIrJifMLqKwYQVg8j4FZ3iV/D19RmKQWTr5RleRl9fn6EYRLZenuFl9PX1GYpBZOvlGTzvZRIGkRXzE0ZXMZiwYhAZL5EwiKyYnzC6isGEFYPIeImEQWTF/ITRVQwmrBhExkvm6+szFIPI1ssz/NrECQmDyASsTBXA6DKQWG8mGH3tNBaOCoPIBKxMFcDoMpBYbyYYfe00Fo4Kg8gErEwVwOgykFhvJhh97TQWjguDyCTR+uffVQwmDIxWGouXRBhEJonWP/+uYjBhYLTSWLwkwiCyb8qzLNd2WS/PslLbpZXG4iURBpF9U55lubbLenmWldourTQWL4kwiOyb8izLtV3Wy7Os1HZppbFwXBhEJmBlqgBGl4HEejPB6GunsThh4gSEQWSVyTwgwFi8eJ5MfeeAHgMEa82EdhoLx4RBZJXJPCDAWLx4nkx954AeAwRrzYR2GgvHhEFklck8IMBYvHieTH3ngB4DBGvNhHYaCweFQWQCDPimPMtybZf18iwrtV2MvnYaC0eFQWQCDPimPMtybZf18iwrtV2MvnYaC0eFQWQCVqYKYHQZSKw3E4y+dhoLR4VBZAJWpgpgdBlIrDcTjL52GgtHhUFkAlamCmB0GUisNxOMvnYaCweFQWSVyTwgwFi8eJ5MfeeAHgMEa82EdhqLEyResDCIrDKZBwnMGFi8OAKITH3ngIG1ZkI7jYUjwiCyymQeJDBjYPHiCCAy9Z0DBtaaCe00Fo4Ig8gqk3mQwIyBxYsjgMjUdw4YWGsmtNNYOCQMIqtM5gEBxuLF82TqOwf0GCBYaya001g4Jgwiq0zmAQHG4sXzZOo7B/QYIFhrJrTTWDgmDCKrTOYBAcbixfNk6jsH9BggWGsmtNNYOCYMIqtM5gEBxuLF82TqOwf0GCBYaya001g4Jgwiq0zmAQHG4sXzZOo7B/QYIFhrJrTTWDgkDCKrTOZBAjMGFi+OACJT3zlgYK2Z0E5jcUJO8YIJ8QyJTH2nxcDi3AiYgRnCLUI8QyJT32kxsDg3AmZghnCLEM+QyNR3Wgwszo2AGZgh3BIGkVUm8yABRqa+/RgwFudGWJwbAdFTmSoQBpHhkDCIrDKZBwkwMvXtx4CxODfC4twIiJ7KVIEwiAyHhEFklck8SICRqW8/BozFuREW50ZA9FSmCoRBZDgkDCKrTOZBAoxMffsxYCzOjbA4NwKipzJVIAwiwyFhEFllMg8SYGTq248BY3FuhMW5ERA9lakCYRAZDhHiGRKZ+k6LgcW5ETADM8TJOsUJ2Ew6ZLaSDn0iU98+oL5zQH37MUiAcNFm0iGzlXToE5n69gH1nQPq249BAoSLNpMOma2kQ5/I1LcPqO8cUN9+DBIgXCPEMyQy9Z0WA4tzI2AGZgi3CPEMiUx9p8XA4twImIEZwi1CPEMiU99pMbA4NwJmYIZwixDPkMjUd1oMLM6NgBmYIdwixDMkMvWdFgOLcyNgBmYI92wmHTJbSYc+kalvH1DfOaC+/RgkQJy0V3nRRM9W0sGAraTDpfwQGE8JJDKbyRMMx4ieraSDAVtJh0v5ITCeEkhkNpMnGI4RPVtJBwO2kg6X8kNgPCWQyGwmTzDcs5l0mA/PsJV0uBSeAUSmvn0AAsxAAsNJm0mH+fAMW0mHS+EZQGTq2wcgwAwkMJy0mXSYD8+wlXS4FJ4BRKa+fQACzEACw0mbSYf58AxbSYdL4RlAZOrbByDADCQwnLSZdJgPz7CVdLgUngFEpr59AALMQALDPaJnK+lgwFbS4VJ+CIynBBKZzeQJxsl6lRfMzJBERhK3r1+gT0hgRo8E63c2aKexcIiZIYmMJG5fv0CfkMCMHgnW72zQTmPhEDNDEhlJ3L5+gT4hgRk9Eqzf2aCdxsIlomcr6WDAVtLhUn4IjKcEEpnN5AmGY0TPVtLBgK2kw6X8EBhPCSQym8kTDMeInq2kgwFbSYdL+SEwnhJIZDaTJxiOET1bSQcDtpIOl/JDYDwlkMhsJk8wHCN6tpIOBmwlHS7lh8B4SiCR2UyeYLjFzJBERhK3r1+gT0hgRo8E63c2aKexOEGvcgLMDEmYGaXpcSSYWa3RqJYxYG61xm61DGzgIjNDEmZGaXocCWZWazSqZQyYW62xWy0DG7jIzJCEmVGaHkeCmdUajWoZA+ZWa+xWy8AGrjEzJJGRxO3rF+gTEpjRI8H6nQ3aaSwcYmZIIiOJ29cv0CckMKNHgvU7G7TTWDjEzJBERhK3r1+gT0hgRo8E63c2aKexcIiZIYmMJG5fv0CfkMCMHgnW72zQTmPhEDNDEhlJ3L5+gT4hgRk9Eqzf2aCdxsIxZoYkzIzS9DgSzKzWaFTLGDC3WmO3WgY2OGmneMHaaayHh8fcu3WZ+cJpwDAD0Se6JFzVTmM9PDzm3q3LzBdOA4YZiD7RJeGqdhrr4eEx925dZr5wGjDMQPSJLgmXmRkZM6M0Pc7YzDhX7m5Qmh6jNDPGB3c3KE2P4SozI2NmlKbHGZsZ58rdDUrTY5Rmxvjg7gal6TFcZWZkzIzS9DhjM+NcubtBaXqM0swYH9zdoDQ9hqvMjIyZUZoeZ2xmnCt3NyhNj1GaGeODuxuUpsdwlZmRMTNK0+OMzYxz5e4GpekxSjNjfHB3g9L0GC5qp7EeHh5z79Zl5gunAcMMRJ/okvi1nOKESHDzxgID+yvXMMCA/eWrmOE0CW7eWGBgf+UaBhiwv3wVM5wmwc0bCwzsr1zDAAP2l69ihpPaaayHh8fcu3WZ+cJpwDAD0Se6JFzVTmM9PDzm3q3LzBdOA4YZiD7RJeGqdhrr4eEx925dZr5wGjDMQPSJLglXtdNYDw+PuXfrMvOF04BhBqJPdEm4qp3Genh4zL1bl5kvnAYMMxB9okvCdRLcvLHAwP7KNQwwYH/5Kmb8Kk5xAlpprNnVGj999yNISHD4zilElxn/evcV5j6s0Upj4aBWGmt2tcZP3/0IEhIcvnMK0WXGv959hbkPa7TSWDiolcaaXa3x03c/goQEh++cQnSZ8a93X2HuwxqtNBaOkuDmjQUG9leuYYAB+8tXMcNpEty8scDA/so1DDBgf/kqZjhNgps3FhjYX7mGAQbsL1/FDKdJcPPGAgP7K9cwwID95auY4TQJbt5YYGB/5RoGGLC/fBUznNVKY82u1vjpux9BQoLDd04husz417uvMPdhjVYaixMmTkAYRMZTn589xyevneOz4yMM49PX3+So9YhMO42Fw8Igss/PnuOT187x2fERhvHp629y1HpEO42F48Igss/PnuOT187x2fERhvHp629y1HpEO42Fw4pBZN9+NE9pZhwBZoYkzAxJzK7WaKWxcFQxiOzbj+YpzYwjwMyQhJkhidnVGq00Fo4qBpF9+9E8pZlxBJgZkjAzJDG7WqOVxsJRxSCybz+apzQzjgAzQxJmhiRmV2u00lg4qhhE9u1H85RmxhFgZkjCzJDE7GqNVhoLB4VBZDz1+dlzfPLaOT47PsIwPn39TY5aj8i001icsFd5wcIgst1qGQHXfvcn3j+b44vcKAuHjzCDL4ZHOWo9olEtM7Nas3YaC8eEQWR0fX72HP9NGETWTmPhoDCIjK7Pz57jvwmDyNppLBwTBpHR9Yez5/jhq+/5ge/55LVzfHZ8hGF8+vqbHLUekQmDyNppLBwSBpHR9Yez5/jhq+/5ge/55LVzfHZ8hGF8+vqbHLUekQmDyNppLBwTBpEZ8MNX3/MD3/PJa+f47PgIw/j09Tc5aj3CZWEQmQH/+OpvjA0nLOVG+ePhI8zgyvAoP+3cx2VhEJkB//jqb4wNJyzlRvnj4SPM4MrwKD/t3MdVYRDZbrWMgGu/+xPvn83xRW6UhcNHmMEXw6MctR7RqJaZWa1ZO43FCTrFCya6DBr398gs5UbJXBkucWV4lIHG/T1cFAaR7VbLNKplvhz6mfeHcwyPjLMw/BYLuRy54hiZRrVMGESGY8Igst1qmUa1zJdDP/P+cI7hkXEWht9iIZcjVxwj06iWCYPIcEgYRLZbLdOolvly6Gcy7w/nGB4ZZ2H4LRZyOXLFMTK71TKNapkwiAxHhEFku9UyjWqZL4d+JvP+cI7hkXEWht9iIZcjVxwjs1st06iWCYPIcEgYRLZbLdOolvly6GfeH84xPDLOwvBbLORy5IpjZBrVMmEQGY4Jg8h2q2Ua1TLVof+wlBsls5Qb5crwKAONapkwiAzHhEFku9UyjWqZ6tB/WMqNklnKjXJleJSBRrVMGESGY0SXQeP+Hpml3CiZK8MlrgyPMtC4v8ev4VVesFYaa+7Dmhl9pd/Q8+P2n3mjOMrAcm2XdhoLx4gug8aDPTJLuVEyS7lRfqlxfw8XiS6DxoM9Mku5UTJLuVF+qXF/D9eILoPGgz0yv/33/1CauEhmKTfKMwwaD/ZwiegyaDzYI/Pbf/8PpYmLZJZyozzDoPFgD9eILoPGgz0yS7lRMku5UX6pcX8PF4kug8aDPX7pp537vFEcZaBxfw8XiS6DxoM9fumnnfu8URxloHF/Dxe10lhzH9bM6Cv9hp4ft//MG8VRBpZru7TTWJwwcYI+fu9tW2smPK8yVeD3f/mrcFQxiMyAylSBtWbC8ypTBdaaCe00Fg4qBpEZUJkqsNZMeF5lqsBaM6GdxsIxxSAyA9pprI/fe9vWmgnPq0wVWG8mGNBOY+GQYhCZAe001sfvvW1rzYTnVaYKrDcTDGinsXBMMYjMgMpUgbVmwvMqUwXWmgntNBYOKgaRGVCZKrDWTHheZarAWjOhncbCQcUgMgMqUwXWmgnPq0wVWGsmtNNYOOzj9962tWbC8ypTBX7/l78Kz/M8z/M8z/M8z/M8z/M8z/M8z/P+r/4XQSdkxvlW8QQAAAAASUVORK5CYII=","w":64,"h":34,"frames":9},"farmer_walk_right":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAANwklEQVR4Ae3BT2ic953H8fdHG1hbdlaK/Mw8I5NYM+JRKxk0lnqwnEB3CypDC07cJcRYYM+xcjaXkNCLL7YDpoRCCq7CVrciOQy+teBDmUNSt2WRdNEfUqu4T+PYLZp5nj5W10bWZE/f1TOS2HXOa5l99Hu9cBzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcf4f8b3ACrkBY0vBG7CCFxj7iO8FVsgNGFsK3oAVvMBwnH3C9wIr5AaMLQVvwApeYOwjvhdYITdgbCl4A1bwAuM56mCP+V5ghdyAsaXgDVjBCwxnX7lxrkzBC2x2osx+dONcmYIX2OxEmf3G9wIr5AaMLQVvwApeYDj7yo1zZQpeYLMTZfajG+fKFLzAZifKPG9ij/leYJ9MnOB8bZnZiRNcqC3TTEKxT/heYJJo/u1PKngDBkYzCUXG+V5gAi4M5Xm5p5O/PnzCy94hfvz7LzG2RUkoMsr3AhNwYSgPxhYDidnVGGNblIQi43wvsE8mTnC+tszsxAku1JZpJqHYJ3wvMEk0//YnFbwBA6OZhCLjfC8wAReG8rzc08lfHz7hZe8QP/79lxjboiQUGeV7gQm4MJQHY4uBxOxqjLEtSkKxx8Qe8b3ABFwYyoOxxUBidjXG2BYlocgo3wtMgAGfTJzgfG2Z2YkTnK8tsytKQpFBvhdYdTAHCDAqo0dJ1ZcatBkgmFmNiZJQZIzvBVYdzAECjMroUVL1pQZtBghmVmOiJBQZ5HuBCbgwlAdji4HE7GqMsS1KQpFRvheYAAM+mTjB+doysxMnuFBbxtgWJaHIIN8LrDqYAwQYldGjpOpLDdoMEMysxkRJKDLG9wKrDuYAAUZl9Cip+lKDNgMEM6sxURKKPST2gO8FVh3MAQKMyuhRUvWlBm0GCGZWY6IkFBnje4FVB3OAAKMyepRUfalBmwGCmdWYKAlFhvheYNXBHEhgxq7KaC8gUvWlBrtmVmOiJBQZ4XuBVQdzIIEZuyqjvYBI1Zca7JpZjYmSUGSI7wVWHcwBAozK6FFS9aUGbQYIZlZjoiQUGeN7gVUHc4AAozJ6lFR9qUGbAYKZ1ZgoCUWG+F5g1cEcSGDGrspoLyBS9aUGu2ZWY6IkFBnhe4FVB3MggRm7KqO9gEjVlxrsmlmNiZJQ7JEOnjHfC6w6mAMJMFL1xTXAqIz0UhnpBdFWHcrje4GRIb4XWHUwBxJgpOqLa4BRGemlMtILoq06lMf3AiNDhHiKRKq+1GRXZaQXzMAMkS1CPEUiVV9qsqsy0gtmYIbIFt8LrDqYAwkwUvXFNcCojPRSGekF0VYdyuN7gZEhvhdYdTAHEmCk6otrgFEZ6aUy0guirTqUx/cCI0OEeIpEqr7UZFdlpBfMwAyRLUI8RSJVX2qyqzLSC2ZghthbHTxjQjxFIlVfarKrMtILZmCGyBYhniKRqi812VUZ6QUzMENkz3zcIrUQt9gmUvXFBvWlBvXFNZAAkUXzcYvUQtxim0jVFxvUlxrUF9dAAkTWCPEUiVR9qcmuykgvmIEZIluEeIpEqr7UZFdlpBfMwAyRPfNxi9RC3GKbSNUXG9SXGtQX10ACRBbNxy1SC3GLbSJVX2xQX2pQX1wDCRB77QX2wHzcYszvZCFucdLvBESqvtgAAWYggZFJ83GLMb+ThbjFSb8TEKn6YgMEmIEERvaItoW4hQELcYuTuQNg7BBIpObjTYyMEW0LcQsDFuIWJ3MHwNghkEjNx5sY2TMftxjzO1mIW5z0OwGRqi82QIAZSGBk0nzcYszvZCFucdLvBESqvtgAAWYggZE9om0hbmHAQtziZO4AGDsEEqn5eBMjY0TbQtzCgIW4xcncATB2CCRS8/Emxt56gWdNtC3ELQxYiFuczB0AY4dAIjUfb2JkjGhbiFsYsBC3OJk7AMYOgURqPt7EyBYzQxIpSaTeHO8HhARmtEkwOzVHlIQiQ8wMSaQkkXpzvB8QEpjRJsHs1BxREoosEW0LcQsDFuIWJ3MHwNghkEjNx5sYGSPaFuIWBizELU7mDoCxQyCRmo83MbLFzJBEShIfnjvONiGBGW0SzE7NESWhyBAzQxIpSXx47jjbhARmtEkwOzVHlIRiD73AM2ZmSCIliQ/PHWebkMCMNglmp+aIklBkiJkhiZQkPjx3nG1CAjPaJJidmiNKQpExZoYkzIxUqdzPvZV7vDE1x/L0BF+u3OPM1BxZZWZIwsxIlcr9/L35d/7l8q9Znp7gP5t/5zuXf00WmRmSSEki9eZ4PyAkMKNNgtmpOaIkFBliZkgiJYnUm+P9gJDAjDYJZqfmiJJQZIyZIQkzozjcjwTlyRq/eucUxXKJkckav3znFFllZkjCzCgO9yNBebLGbz/4Pl1+NyOTNW5/8H2ehw72gJmRMjOKw/2Uyv2c+XiO4nCJYrnEDz6eozhcIqvMjJSZURzup1Tu58zHcxSHSxTLJX7w8RzF4RJZFCWh7q5vcPPaacbyBxnLH8SMNgFih0QWRUmou+sb3Lx2mrH8QcbyBzGjTYDYIZFVZkbKzDAzSuV+iuUSb0zNUSyXKJZLnJmaI6vMjJSZYWaUyv0UyyXemJqjWC5RLJc4MzVHFkVJqLvrG9y8dpqx/EHAMAOxTWyRyKooCXV3fYOb104zlj8IGGYgtoktEs9LB89YlIS6u77BzWunGcsfBAwzENvEFomsipJQd9c3uHntNGP5g4BhBmKb2CKRdRK8/+447787TqpYLvHgwlkMKJZLPDj/FlkmwfvvjvP+u+Okugsv8eDCWQzo9rt5cP4tsihKQt1d3+DmtdOM5Q8ylj+IGW0CxA6JLIqSUHfXN7h57TRj+YOM5Q9iRpsAsUMiyyR4/91xdj24cJZiuYQBD86/RXG4RJZJ8P674+x6cOEsXX43Bjw4/xZd+W6eh39gDxzu7Lny9uvDvHqqxDZx6aXjtI51kLrUPUTrlQ5+futzNjbXr5Ixhzt7rrz9+jCvniqxTVx66TitYx2kLnUP0Xqlg5/f+pyNzfWrZMzG5vrVG5+uXfle3yG6Cz1IgBlf9XWAGZL45rWbNJNQZNDG5vrVG5+uXfn3W5/z81uf82+vD4MZX/V1gBmS+Oa1mzSTUGTQ4c6eK2+/Psyrp0q8dqofEAguvXSc1rEOUpe6h/jpyh/Y2Fy/SsYc7uy58vbrw7x6qsRrp/oBgeDSS8dpHesgdal7iJ+u/IGNzfWrZMzG5vrVG5+uXfle3yG6Cz1I0HpFSAIzvurrYORijWYSigza2Fy/euPTtSvf6ztEd6EHCVqvCElgxld9HYxcrNFMQrHHxB7wvcDY8qt3xiiW+xFgZkjCzJDEickazSQUGeR7gbHlV++MUSz3I8DMkISZIYkTkzWaSSgyyvcCY8tHh7rYdflwF1c3HvHek0dESSgyzPcCW56eQEB5ssZHh7q4fLiLqxuPeO/JI6IkFBlW8AIztq1MT2BmSMLMkMSJyRrNJBQZVfAC++U7YxTL/QgwMyRhZkjixGSNZhKKDPO9wD461MXlw118sPEYw7jyYjePm/eJklBklO8Fxo6PDnVx+XAXH2w8xjCuvNjN4+Z9VqYnKE/WiJJQ7KEXeMZ8L7Dl6QkEnL10ix/+4o9cPtzFBxuPMYwrL3bzuHmflekJypM1i5JQZIjvBbY8PYGAs5du8cNf/JHU5cNdXN14ROq9J4/IMt8LbHl6AgHlyRorx0qkrvf0Mf7wPjx5hO8FFiWhyCixxWDl9h1S3z3Sw/WePsYf3ocnj8g6A5anJxBQnqzx0aEuLh/u4urGI9578ogoCUWGNZNQZz7GYJ6PDnVx+XAXVzcekXrvySOiJBQZ5nuBseW7R3q43tPH+Pp9zOD6kT4eN+/je4FFSSgyxvcCW56eQMDZS7f47qEervf0Mb5+HzO4fqSPx837rPzmDs/DCzxjYovByu07pK4PjHIEuC5hZhyReNy8z8pv7pBFYovByu07pK4PjJLyJK6bIQkWP2NleoLyZM2iJBQZI7YYrNy+Q+qNnj4kgRlnjvTBX+6Rdc0k1MjFmhlQHPkOZyQw48yRPvjLPbJObDFYuX2H1M++8S2OmPEzCRY/I+t8L7Dl6QkElCdrlL7xLa6bIQkWPyPLfC+w5ekJBJQnaxR7+jhzpIiZIYksE1sMVm7fIfVGTx+pM0eKmBm7zteWiZJQ7LEXeMaaSaiRizUzoDqU57dsS9b+zP92vrZMlIQiY5pJqJGLNTO2VfN3+O0/HsfMeNj4gl0rv7lDVjWTUCMXa2Zse9j4gtSR3n7++b/u8CUQJaHIOANe9I/xsPEFkugplNgvmkmokYs1M+BF/xjJ2p850tuPmbEfiC0GK7fvsEsSZkbWiS0GK7fvsMvMeNj4gn/t+Yp7QJSEIoOaSaiRizUzthVfoe3e4mf8U6GPXVESiudA7CHfC4yvqQ7mmPnj34iSUOwDvhcYO6pDeWZWYwQYECWhyDjfC6w6lGdmNWZXlIRiH/jRt1+zmdWYr6sO5fnJ7/5DZJzvBcbXVIfyzKzGREkoMq7gBWb8j+pQnpnVmCgJRcYVvMCMbdWhPDOrMbuiJBT7wI++/ZrNrMZ8XXUoz09+9x/CcRzHcRzHcRzHcRzHcRzHcRzn/8Z/A+lPsjC6a0nkAAAAAElFTkSuQmCC","w":64,"h":34,"frames":8},"farmer_act_right":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAAPWklEQVR4Ae3BT2yTd5rA8e+T4QAmLGBexw7bEjt9QxM0TowKhCIxIE1ldTX0j1aaIZGKr6RCWrVl6QGpu85qOTCVkEYiUjitlMCkPnTbQ1dU3lFENKtRYrKKgUrRJM7w54DtN5aZso49Ug/P+rWxFKreyu5Eb36fD4ZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhGIZhbDBBy9ZQoEepC1k9GrJsZRMJWraGAj1KXcjq0ZBlK4ZhGIbnBS1bQ4EepS5k9WjIspUNrI3/A9eH+glZtk4O97MZXR/qJ2TZOjncj2FsJkHL1lCgR6kLWT0asmxlEwlatoYCPUpdyOrRkGUrm0jQsjUU6FHqQlaPhixb2WSuD/UTsmydHO5no/sJL0jQsnWHz59M9HWwkq8wYPlYKVa4W1pju8+fbPf5k2vV8igeFbRs3eHzJxN9HazkKwxYPlaKFe6W1tju8yfbff7kWrU8iscFLVt3bN+TrFTLoyGrR9t9/mSlWh5lkwhatu7YvidZqZZHQ1aPtvv8yUq1PMom0e7zJ28MD5D+03fJyeEBvvimSKVaHmWTaPf5kzeGB0j/6bvk5PAAX3xTpFItj7JJtPv8yRvDA6T/9F1ycniAL74pUqmWR/G4oGXrDp8/mejrYCVfYcDysVKscLe0xnafP9nu8yfXquVRNhjhBQhatiZ6A4AASvzgXlzpbJ4GBQQmFh2KpZzgMUHL1kRvABBAiR/ciyudzdOggMDEokOxlBM8KGjZKoACN4YHeG/qDpPDA5yZuoPSVCzlBI8KWrYKoMCN4QHem7rD5PAAZ6buoDQVSznBo4KWrQKc6esApU5BhMlFB6WpWMoJHhW0bBXgTF8HKHUKIkwuOihNxVJO8KigZasAZ/o6QKlTEGFy0UFpKpZyggcFLVsTvQFAACV+cC+udDZPgwICE4sOxVJO2ECEHylo2ZroDYAIqNISP9gJCK50Nk/LxKJDsZQTPCJo2ZroDYAIqNISP9gJCK50Nk/LxKJDsZQTPCRo2ZroDQACKPGDe3Gls3kaFBCYWHQolnKCxwQtWxO9AUAAJX5wL650Nk+DAgITiw7FUk7wmKBla6I3AAigxA/uxZXO5mlQQGBi0aFYygkeE7RsTfQGAAGU+MG9uNLZPA0KCEwsOhRLOcFjgpatid4AIIASP7gXVzqbp0EBgYlFh2IpJ3hI0LI10RsAEVClJX6wExBc6WyelolFh2IpJ2wQbfxIgvAcEVzpbIGWeKwTVEEVwVsE4TkiuNLZAi3xWCeogiqCtwQtWxO9ARABFFd64TGgxGOdxGOdIDQk+joIWrbiIUHL1kRvAEQAxZVeeAwo8Vgn8VgnCA2Jvg6Clq14SNCyNdEbABFAcaUXHgNKPNZJPNYJQkOir4OgZSseErRsTfQGQARQXOmFx4ASj3USj3WC0JDo6yBo2YqHBC1bE70BEAEUV3rhMaDEY53EY50gNCT6OghatuIhgvAcEVzpbIGWeKwTVEEVYWNp4wWYc2q4Mk6NJsGVXsiTzuZJLzwGEUDwojmnhivj1GgSXOmFPOlsnvTCYxABBK8RhOeI4EpnC7TEY52gCqoI3iIIzxHBlc4WaInHOkEVVBG8RRCeI4IrnS3QEo91giqoIniLIDxHBFc6W6AlHusEVVBF8BZBeI4IrnS2QEs81gmqoIrgPXNODVfGqdEkuNILedLZPOmFxyACCBvNFn4soSHj1FAg49Q4EtgKyjMCIrjmnCqKxwgNGaeGAhmnxpHAVlCeERDBNedUUbxnzqkxGPSRcWocCfoAwZVeyIMAqiACiifNOTUGgz4yTo0jQR8guNILeRBAFURA8aQ5p8Zg0EfGqXEk6AMEV3ohDwKogggonjTn1BgM+sg4NY4EfYDgSi/kQQBVEAHFk+acGoNBHxmnxpGgDxBc6YU8CKAKIqB4j9CQcWookHFqHAlsBeUZARFcc04VZWPZwo+kqogILhHh8tABmgQRUKVBBCavzlIs5QQPUVVEBJeIcHnoAE2CCKjSIAKTV2cplnKClwgNGaeGAhmnxpHAVlCeERDBNedUUTxGaMg4NRTIODWOBLaC8oyACK45p4riMUJDxqmhQMapcSSwFZRnBERwzTlVFI8RGjJODQUyTo0jga2gPCMggmvOqaJ4jNCQcWookHFqHAlsBeUZARFcc04VxVtUFRHBJSJcHjpAkyACqjSIwOTVWYqlnLCBbOEFUFVEBFUlHO1GBPrPTnH32jAKxM5OcefaMDCLF6kqIoKqEo52IwL9Z6e4e20YBWJnp7hzbRiYxWtUFRHBJSJcHjpAkyACqjSIwOTVWYqlnOAhqoqI4BIRLg8doEkQAVUaRGDy6izFUk7wEFVFRHCJCJeHDtAkiIAqDSIweXWWYikneIiqIiK4RITLQwdoEkRAlQYRmLw6S7GUEzxEVRERXCLC5aEDNAkioEqDCExenaVYygkeo6qICKpKONqNCPSfneLutWEUiJ2d4s61YWCWjaaNH6lYyslSuULq0ikGO7YBiioITUKdCF5VLOVkqVwhdekUgx3bAEUVhCahTgQvU1Vcqko42k2kv5t3xmYJRyOE+yO8OzZLOBrBq1QVl6oSjnYT6e/mnbFZwtEI4f4I747NEo5G8CpVxaWqhKPdRPq7eWdslnA0Qrg/wrtjs4SjEbxKVXGpKuFoN5H+bt4ZmyUcjRDuj/Du2CzhaASvUlVcqko42k2kv5t3xmYJRyOE+yO8OzZLOBrBi4qlnCyVK6QunWKwYxugqILQJNSJsFG18YKIwPkPfk7LozO/QgEFHr33S1TxNBE4/8HPaXl05lcooMCj936JKg0hq0fxkGIpJ0vlCqlLpxjs2AYoqiA0CXUitISsHsVDiqWcLJUrpC6dYrBjG6CogtAk1IngVcVSTpbKFVKXTjHYsQ1QVEFoEupE8KpiKSdL5QqpS6cY7NgGKKogNAl1IrSErB7FQ4qlnCyVK6QunWKwYxugqILQJNSJ0BKyejRk9SgeIwLnP/g5LY/O/AoFFHj03i9RpSFk9WjI6lE2iJ/wAlSq5dHr04+Tb3ZtZ1fIjwjUXhZEBFT5S1cbsZEpQGj37UlWquVRPKRSLY9en36cfLNrO7tCfkSg9rIgIqDKX7raiI1MkR0f4p//7QuSdaN1eES7z598/60orx+N0CRc3H2A2r42XBd39VF7uY3xr74hOz7E9el8slItj+IR7T5/8v23orx+NEKTcHH3AWr72nBd3NXH33zwr/zjx//AtbHfJivV8ige0u7zJ99/K8rrRyM0CRd3H6C2rw3XxV191F5uY/yrb2j37Um2+/YkK9XyKB7R7vMn338ryutHIzQJF3cfoLavDdfFXX3UXm5j/KtvyI4PcX06n6xUy6N4RLvPn3z/rSivH43QJFzcfYDavjZcF3f1UXu5jfGvviE7PsTIqZ9yfTqfrFTLo3hApVoevT79OPlm13Z2hfyIQO1lQURAlb90tREbmQKE7PhpRk79lOvT+WSlWh7lr0x4gYKWrVe27+T82lOubN+JoiR37OJp4SGF1WVcxc8/ITaSolBaFjwmaNl6ZftOzq89pWVHaB9PCw/51L+TM3+cZz2pwyNClq1fnhsk3N9N7OxnrHfn2hADZ6f48twg4WiE2EiK/OoSLqnDA0KWrV+eGyTc340AqkpsJIUrv7rEep2B/RRKy4KHhCxbvzw3SLi/GwFUFRFBVREROv7+X3AVP/8EV2wkRaG0LHhEyLL1y3ODhPu7iZ39jJb86hLOv/8TA2en+LV/J/uHewlHI8RGUhRKy4JHhCxbvzw3SLi/m9jZz2jJjp9GRBg4O8Wv/TvZP9xLOBohNpKiUFoWPCRo2Xpl+07Orz3lyvadKEpyxy6eFh7y36+G+dv/+k9cxc8/ITaSolBaFv7KhBfoRtdrSt2Jl3Zz6I8PacmvLvFDpA4PudH1mlJ34qXduLZ8eJTYSApFSd38mhOHXuH7pA6PuNH1mlJ34qXduLZ8eBRXbCTFevnVJdaTOjzgRtdrSt35tae4suOnccVGUuRXl1hP6vCYG12vKXXn157SsiO0j6V7v2O94uefEBtJUSgtCx7y265DSt3PXtrFlg+P4oqNpMivLtHSGdhPdvw0sZEUhdKy4CG/7Tqk1P3spV1s+fAorthICkURhPUKpWXBY4KWrXf3Rfhum3Lojw9xdcVO8CB7i8LqMutJHRtAGy/QR2vf8sYeP9OrT5h/tYvs+Gmy46fpDOznh2gdHvLR2re8scfP9OoTplef8ODefbLjpxEE18z8CuvNzK/gJR+tfcsbe/xMrz5hevUJD+7dpyW/ukR+dYlCaVlm5ldomZlfwSs+WvuWN/b4mX+1i/lXu3hw7z4/ZGZ+BZc+g0d8tPYtb+zxM/9qF9nx02THT/M/hUfMzK/QMjO/QmwkRaG0LHjMh2t/5jc9MaZXn/Dg3n3Wm5lfYWZ+BVdsJEWhtCx4zIdrf+Y3PTGmV5/w4N591iuUlqVQWpZCaVkKpWXBo972dzG9+oTs+Gmy46d5mJ0hdfNrvk/r2AC28IK97e/i4aMH/BrYf+8+4WiE9WbmVzhx6BVcM/MreM3b/i4ePnpAw1iG7HgE14lDrzAzv8LM/AotJw69gtZJHR7xtr+Lh48e0DCWATIoysz8Ci0nD9ty63ZOqTt52BY85G1/F+ceLeD6eOwhkOGzmzeZmV+h5eRhW6ibmV/Ba972d3Hu0QL7790nHI3gOv13b5K6+TWuk4dtweM+Lj+FsQyQIb+6xMz8Cq6Th21hE/i4/BTGMkCG/OoSoUAPm8nH5afsv3efcDRCy8z8CicOvULLzPwKG4HwAl04fkwnFh1cgtDy2c2b/JCTh23BQy4cP6YTiw4tguA60xfgF1cmWO/kYVtu3c4pdScP24IHXDh+TCcWHb4v0dfBp7//g+BxF44f04lFB0FwKYor0dfBL65M4Dp52BY86sLxYzqx6CAILYqS6Ovg09//QfC4C8eP6cSigyt182vWO3nYFjzuwvFjOrHokLr5NScOvYJrZn6F//gowae//4PgcReOH9OJRYfC6jKdgf24FCXR18Evrkyw3snDtrCZ3Lqd01u3c4phGMYmcOt2Tm/dzimb0K3bOb11O6dsQrdu5/TW7ZzyPbdu5/TW7ZxiGIZhGIZhGIZhGIbx/+p/AQvBO2sO9eIlAAAAAElFTkSuQmCC","w":64,"h":34,"frames":8},"farmer_right":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAANwklEQVR4Ae3BT2ic953H8fdHG1hbdlaK/Mw8I5NYM+JRKxk0lnqwnEB3CypDC07cJcRYYM+xcjaXkNCLL7YDpoRCCq7CVrciOQy+teBDmUNSt2WRdNEfUqu4T+PYLZp5nj5W10bWZE/f1TOS2HXOa5l99Hu9cBzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcRzHcf4f8b3ACrkBY0vBG7CCFxj7iO8FVsgNGFsK3oAVvMBwnH3C9wIr5AaMLQVvwApeYOwjvhdYITdgbCl4A1bwAuM56mCP+V5ghdyAsaXgDVjBCwxnX7lxrkzBC2x2osx+dONcmYIX2OxEmf3G9wIr5AaMLQVvwApeYDj7yo1zZQpeYLMTZfajG+fKFLzAZifKPG9ij/leYJ9MnOB8bZnZiRNcqC3TTEKxT/heYJJo/u1PKngDBkYzCUXG+V5gAi4M5Xm5p5O/PnzCy94hfvz7LzG2RUkoMsr3AhNwYSgPxhYDidnVGGNblIQi43wvsE8mTnC+tszsxAku1JZpJqHYJ3wvMEk0//YnFbwBA6OZhCLjfC8wAReG8rzc08lfHz7hZe8QP/79lxjboiQUGeV7gQm4MJQHY4uBxOxqjLEtSkKxx8Qe8b3ABFwYyoOxxUBidjXG2BYlocgo3wtMgAGfTJzgfG2Z2YkTnK8tsytKQpFBvhdYdTAHCDAqo0dJ1ZcatBkgmFmNiZJQZIzvBVYdzAECjMroUVL1pQZtBghmVmOiJBQZ5HuBCbgwlAdji4HE7GqMsS1KQpFRvheYAAM+mTjB+doysxMnuFBbxtgWJaHIIN8LrDqYAwQYldGjpOpLDdoMEMysxkRJKDLG9wKrDuYAAUZl9Cip+lKDNgMEM6sxURKKPST2gO8FVh3MAQKMyuhRUvWlBm0GCGZWY6IkFBnje4FVB3OAAKMyepRUfalBmwGCmdWYKAlFhvheYNXBHEhgxq7KaC8gUvWlBrtmVmOiJBQZ4XuBVQdzIIEZuyqjvYBI1Zca7JpZjYmSUGSI7wVWHcwBAozK6FFS9aUGbQYIZlZjoiQUGeN7gVUHc4AAozJ6lFR9qUGbAYKZ1ZgoCUWG+F5g1cEcSGDGrspoLyBS9aUGu2ZWY6IkFBnhe4FVB3MggRm7KqO9gEjVlxrsmlmNiZJQ7JEOnjHfC6w6mAMJMFL1xTXAqIz0UhnpBdFWHcrje4GRIb4XWHUwBxJgpOqLa4BRGemlMtILoq06lMf3AiNDhHiKRKq+1GRXZaQXzMAMkS1CPEUiVV9qsqsy0gtmYIbIFt8LrDqYAwkwUvXFNcCojPRSGekF0VYdyuN7gZEhvhdYdTAHEmCk6otrgFEZ6aUy0guirTqUx/cCI0OEeIpEqr7UZFdlpBfMwAyRLUI8RSJVX2qyqzLSC2ZghthbHTxjQjxFIlVfarKrMtILZmCGyBYhniKRqi812VUZ6QUzMENkz3zcIrUQt9gmUvXFBvWlBvXFNZAAkUXzcYvUQtxim0jVFxvUlxrUF9dAAkTWCPEUiVR9qcmuykgvmIEZIluEeIpEqr7UZFdlpBfMwAyRPfNxi9RC3GKbSNUXG9SXGtQX10ACRBbNxy1SC3GLbSJVX2xQX2pQX1wDCRB77QX2wHzcYszvZCFucdLvBESqvtgAAWYggZFJ83GLMb+ThbjFSb8TEKn6YgMEmIEERvaItoW4hQELcYuTuQNg7BBIpObjTYyMEW0LcQsDFuIWJ3MHwNghkEjNx5sY2TMftxjzO1mIW5z0OwGRqi82QIAZSGBk0nzcYszvZCFucdLvBESqvtgAAWYggZE9om0hbmHAQtziZO4AGDsEEqn5eBMjY0TbQtzCgIW4xcncATB2CCRS8/Emxt56gWdNtC3ELQxYiFuczB0AY4dAIjUfb2JkjGhbiFsYsBC3OJk7AMYOgURqPt7EyBYzQxIpSaTeHO8HhARmtEkwOzVHlIQiQ8wMSaQkkXpzvB8QEpjRJsHs1BxREoosEW0LcQsDFuIWJ3MHwNghkEjNx5sYGSPaFuIWBizELU7mDoCxQyCRmo83MbLFzJBEShIfnjvONiGBGW0SzE7NESWhyBAzQxIpSXx47jjbhARmtEkwOzVHlIRiD73AM2ZmSCIliQ/PHWebkMCMNglmp+aIklBkiJkhiZQkPjx3nG1CAjPaJJidmiNKQpExZoYkzIxUqdzPvZV7vDE1x/L0BF+u3OPM1BxZZWZIwsxIlcr9/L35d/7l8q9Znp7gP5t/5zuXf00WmRmSSEki9eZ4PyAkMKNNgtmpOaIkFBliZkgiJYnUm+P9gJDAjDYJZqfmiJJQZIyZIQkzozjcjwTlyRq/eucUxXKJkckav3znFFllZkjCzCgO9yNBebLGbz/4Pl1+NyOTNW5/8H2ehw72gJmRMjOKw/2Uyv2c+XiO4nCJYrnEDz6eozhcIqvMjJSZURzup1Tu58zHcxSHSxTLJX7w8RzF4RJZFCWh7q5vcPPaacbyBxnLH8SMNgFih0QWRUmou+sb3Lx2mrH8QcbyBzGjTYDYIZFVZkbKzDAzSuV+iuUSb0zNUSyXKJZLnJmaI6vMjJSZYWaUyv0UyyXemJqjWC5RLJc4MzVHFkVJqLvrG9y8dpqx/EHAMAOxTWyRyKooCXV3fYOb104zlj8IGGYgtoktEs9LB89YlIS6u77BzWunGcsfBAwzENvEFomsipJQd9c3uHntNGP5g4BhBmKb2CKRdRK8/+447787TqpYLvHgwlkMKJZLPDj/FlkmwfvvjvP+u+Okugsv8eDCWQzo9rt5cP4tsihKQt1d3+DmtdOM5Q8ylj+IGW0CxA6JLIqSUHfXN7h57TRj+YOM5Q9iRpsAsUMiyyR4/91xdj24cJZiuYQBD86/RXG4RJZJ8P674+x6cOEsXX43Bjw4/xZd+W6eh39gDxzu7Lny9uvDvHqqxDZx6aXjtI51kLrUPUTrlQ5+futzNjbXr5Ixhzt7rrz9+jCvniqxTVx66TitYx2kLnUP0Xqlg5/f+pyNzfWrZMzG5vrVG5+uXfle3yG6Cz1IgBlf9XWAGZL45rWbNJNQZNDG5vrVG5+uXfn3W5/z81uf82+vD4MZX/V1gBmS+Oa1mzSTUGTQ4c6eK2+/Psyrp0q8dqofEAguvXSc1rEOUpe6h/jpyh/Y2Fy/SsYc7uy58vbrw7x6qsRrp/oBgeDSS8dpHesgdal7iJ+u/IGNzfWrZMzG5vrVG5+uXfle3yG6Cz1I0HpFSAIzvurrYORijWYSigza2Fy/euPTtSvf6ztEd6EHCVqvCElgxld9HYxcrNFMQrHHxB7wvcDY8qt3xiiW+xFgZkjCzJDEickazSQUGeR7gbHlV++MUSz3I8DMkISZIYkTkzWaSSgyyvcCY8tHh7rYdflwF1c3HvHek0dESSgyzPcCW56eQEB5ssZHh7q4fLiLqxuPeO/JI6IkFBlW8AIztq1MT2BmSMLMkMSJyRrNJBQZVfAC++U7YxTL/QgwMyRhZkjixGSNZhKKDPO9wD461MXlw118sPEYw7jyYjePm/eJklBklO8Fxo6PDnVx+XAXH2w8xjCuvNjN4+Z9VqYnKE/WiJJQ7KEXeMZ8L7Dl6QkEnL10ix/+4o9cPtzFBxuPMYwrL3bzuHmflekJypM1i5JQZIjvBbY8PYGAs5du8cNf/JHU5cNdXN14ROq9J4/IMt8LbHl6AgHlyRorx0qkrvf0Mf7wPjx5hO8FFiWhyCixxWDl9h1S3z3Sw/WePsYf3ocnj8g6A5anJxBQnqzx0aEuLh/u4urGI9578ogoCUWGNZNQZz7GYJ6PDnVx+XAXVzcekXrvySOiJBQZ5nuBseW7R3q43tPH+Pp9zOD6kT4eN+/je4FFSSgyxvcCW56eQMDZS7f47qEervf0Mb5+HzO4fqSPx837rPzmDs/DCzxjYovByu07pK4PjHIEuC5hZhyReNy8z8pv7pBFYovByu07pK4PjJLyJK6bIQkWP2NleoLyZM2iJBQZI7YYrNy+Q+qNnj4kgRlnjvTBX+6Rdc0k1MjFmhlQHPkOZyQw48yRPvjLPbJObDFYuX2H1M++8S2OmPEzCRY/I+t8L7Dl6QkElCdrlL7xLa6bIQkWPyPLfC+w5ekJBJQnaxR7+jhzpIiZIYksE1sMVm7fIfVGTx+pM0eKmBm7zteWiZJQ7LEXeMaaSaiRizUzoDqU57dsS9b+zP92vrZMlIQiY5pJqJGLNTO2VfN3+O0/HsfMeNj4gl0rv7lDVjWTUCMXa2Zse9j4gtSR3n7++b/u8CUQJaHIOANe9I/xsPEFkugplNgvmkmokYs1M+BF/xjJ2p850tuPmbEfiC0GK7fvsEsSZkbWiS0GK7fvsMvMeNj4gn/t+Yp7QJSEIoOaSaiRizUzthVfoe3e4mf8U6GPXVESiudA7CHfC4yvqQ7mmPnj34iSUOwDvhcYO6pDeWZWYwQYECWhyDjfC6w6lGdmNWZXlIRiH/jRt1+zmdWYr6sO5fnJ7/5DZJzvBcbXVIfyzKzGREkoMq7gBWb8j+pQnpnVmCgJRcYVvMCMbdWhPDOrMbuiJBT7wI++/ZrNrMZ8XXUoz09+9x/CcRzHcRzHcRzHcRzHcRzHcRzn/8Z/A+lPsjC6a0nkAAAAAElFTkSuQmCC","w":64,"h":34,"frames":8},"farmer_idle_up":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAkAAAAAiCAYAAAC3OWZOAAAJEUlEQVR4Ae3BsW9U2dnA4d/xh2Q+zbIRM2fuuRTRADqWuDRAu9JWpjb1rDJ325RRYHuoI6XdnS3vLbbM9x/EECkFTeIpfIrcEESxmnu48ickexCrhTeeREjEEmArsnd15n0elFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRSSimllFJKKaWUUkoppZRS6mfJWS/5cEM4lNsNya0XVoizXvLhhnAotxuSWy+sEGe95MMN4VBuNyS3XlBKKZU8Z73kww3hUG43JLde+Amt8ROYXBuSWy+TYsgqmlwbklsvk2LIKppcG5JbL5NiiFKrxFkv+XBDOJTbDcmtF1aIs17y4YZwKLcbklsvrBBnveTDDeFQbjckt15YMZNrQ3LrZVIM+akZzoizXgwwKTKOqkJkqe0aQ6Kc9WKASZFxVBUiS23XGBLlrBcDTIqMo6oQWWq7xpA4Z70YY5g//5vJ7YaAMO8aw4pw1osxhvnzv5ncbggI864xrAhnvZRFRh0ikyKjDpF51xhWhLNeyiKjDpFJkVGHyLxrDCvCWS9lkVGHyKTIqENk3jWGxDnrxQCTIuOoKkSW2q4xnDHDGXDWS1lkfEwVIm3XGBLjrJeyyPiYKkTarjEkxlkvZZHxMVWItF1jSJCzXgwwKTKW6hCZFBlLVYgstV1jSJSzXgwwKTKW6hCZFBlLVYgstV1jSJSzXgwwKTKOqkJkqe0aQ6Kc9WKASZFxVBUiS23XGBLlrBcDTIqMo6oQWWq7xpAgZ72URcbHVCHSdo3hDBlOmbNeyiLjuKoQabvGkAhnvZRFxnFVIdJ2jSERznopi4zjqkKk7RpDQpz1UhYZH1OFSNs1hsQ466UsMj6mCpG2awyJcdZLWWR8TBUibdcYEuOsl7LI+JgqRNquMSTGWS9lkfExVYi0XWNIiLNeyiLjuKoQabvGcEbWOGUGw0kY0mIwnIQhLQbDSRjS4qyXssg4jrLIcNYLCXHWS1lkHEdZZDjrhYQ466UsMo6jLDKc9UJCnPVSFhnHURYZznohIc56KYuM4yiLDGe9kBCD4SQMZ2sNpdSpMRhOwpAWg+EkDGkxGE7CkBaD4SQMaTEYTsKgztIap81wIkJiDCciJMZwIoJSSqkkGE5EOFtrnDIR4bjqEGm7xpAQEeG46hBpu8aQEBHhuOoQabvGkBLDiQiJMZyIkBjDiQiJMZyIkBjDiQhpERGOqw6RtmsMZ2gNpdSpERGOqw6RtmsMCRERjqsOkbZrDAkREY6rDpG2awwJERGOqw6RtmsMCRERjqsOkbZrDOrMrHHK2q4xdYisqrZrTB0iq6rtGlOHiFJKqdXSdo2pQ+Tnag2l1Klpu8bUIbKq2q4xdYisqrZrTB0iq6rtGlOHyKpqu8bUIaJ+ntY4A/OuMXWIfEgdIvOuMSRo3jWmDpEPqUNk3jWGBM27xtQh8iF1iMy7xqCUUioZ864xdYh8SB0i864xnLH/4Qw464VDO90BX748x9evP+GL5wvyFz/yzZsLPH76PUsHi70HJGp/sffg74v1+1++PMfXrz/hi+cL8hc/8s2bCzx++j1t1xgStr/Ye/D3xfr9L1+e4+vXn/DF8wX5ix/55s0FHj/9nrZrDInaX+w9eLJYv39j2ON96hCZd40hQfuLvQdPFuv3bwx7vE8dIvOuMSRof7H34Mli/f6NYY/3qUNk3jWGBO0v9h48WazfvzHs8T51iMy7xpCg/cXegyeL9fs3hj3epw6RedcYEuSsFw7tdAd8+fIcX7/+hC+eL8hf/Mg3by7w+On3LB0s9h5wxtY4Zc562ZmOmU3HXBtc4Pagz+DSVTYHF9ns9+nnV1iaTcc464UEOevFWS+/7/2C93HWC4ly1ouzXn7f+wXv46wXEuSsF2e9TIqMD5kUGc56ITHOenHWy6TI+JBJkeGsFxLkrBcBbj57xc1nr/jD3nluPfuBm89e8X///79UISKky1kvAtx69gP3Dno8Wr/OvYMed/d7PFq/ThUiQrqc9SLArWc/cO+gx6P169w76HF3v8ej9etUISKkyVkvO9Mxs+mYa4ML3B70GVy6yubgIpv9Pv38Ckuz6RhnvXDG1jhlhkMCs+1dlrb6I5buDC5zZzDirdn2Lily1svOdMxsOubb82+4PegzuHSVzcFFNvt9+vkVlmbTMc56ITHOetmZjplNx3x7/g23B30Gl66yObjIZr9PP7/C0mw6xlkvJMRZLzvTMbPpmMfxJTefveLeQY9H69e5d9Dj7n6PR+vXqULk7m82mU3HOOuFRDjrZWc6ZjYd8zi+5OazV9w76PFo/Tr3Dnrc3e/xaP06VYjc/c0ms+kYZ72QEGe97EzHzKZjvj3/htuDPoNLV9kcXGSz36efX2FpNh3jrBcS46yXnemY2XTM9Pxrtvojlrb6I+4MRrw1m45x1guJcdbLznTMbDpmev41W/0RS1v9EXcGI96aTcc464XEGA4JzLZ3Wdrqj1i6M7jMncGIt2bbu/wUznHK5l1jbv76OxH+7fIv+Zd//OWPfJqPeOtX3+3Qdo0hMYZDArOHuyxt9UcsbfVHvGu2vUuKDIcEZg93Wdrqj1ja6o9412x7l9QYDgnMHu6y9NuDF1zeuMXSVn/EfxCYPdwlJYZDArOHuyz99uAFlzdusbTVH/EfBGYPd0mN4ZDA7OEuS1v9EUtb/RHvmm3vkiLDIYHZw13e9fSv23yaj3hrtr1LigyHBGYPd3nX079u82k+4q3Z9i4pmneNufnr70T4t8u/5F/+8Zc/8mk+4q1ffbdD2zWGM2Y4Q199/plUIXJUWWT87k9/NiQqt14EKIuMKkSOKouMKkTarjEkKLdeBCiLjCpEjiqLjCpE2q4xJCa3XgRou8Z89flnUoXIUWWRUYeIAG3XGBKSWy8CtF1jvvr8M6lC5KiyyKhDRIC2awyJya0XAcoiowqRo8oiowqRtmsMCcqtFwHKIqMKkaPKIqMKkbZrDAnKrRcByiKjCpGjyiKjCpG2awwJ++rzz6QKkaPKIuN3f/qzQSmllFJKKaWUUkoppZRSSin13/one87AndMPR9gAAAAASUVORK5CYII=","w":64,"h":34,"frames":9},"farmer_walk_up":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAAHX0lEQVR4Ae3BsY8cVx3A8e/vhIRTBCm772bWBbFjvUMeimgNHRIIdK5jUZ7ETht3WCT8B3R0UF07U1zp1DSJQaKgie6Q7iHlxYaNRGZeXhyBhODS/LjFWKAT8t1J3Abe/j4fjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGPM/5HaeZ1t7yinZm5HZ84rG6R2XmfbO8qpmdvRmfOKMRuidl5n2zvKqZnb0ZnzygapndfZ9o5yauZ2dOa88gXaYs1q53W2vaOcmrkdnTmvmI2yuL3NzHldNNtsosXtbWbO66LZZtPUzutse0c5NXM7OnNeMRtlcXubmfO6aLbZRIvb28yc10WzzRdNWLPaeW2bij4kFk1FHxJDjsKGqJ1XEWH45AOZuR0FZchRKFztvAqwaCrO6kJiZcxRKFTtvAqwaCrO6kJiZcxRKFztvLZNRR8Si6aiD4khR2FD1M6riDB88oHM3I6CMuQoFK52XgVYNBVndSGxMuYoFKp2XgVYNBVndSGxMuYorJmwJrXzKsCiqTirC4mVMUehULXzKsCiqVjpQ2LRVKx0IbEy5igUqHZe26biPF1IjDkKhamd17apOE8XEmOOQoFq51WARVNxVhcSK2OOQqFq51WARVOx0ofEoqlY6UJiZcxRKFDtvLZNxXm6kBhzFApTO69tU3GeLiTGHIU1Etagdl7bpuI8XUiMOQqFqZ3Xtqk4TxcSY45CQWrntW0qLqoLiTFHoRC189o2FRfVhcSYo1CQ2nltm4rzdCEx5igUpnZe26biPF1IjDkKBamd17apuKguJMYchULUzmvbVFxUFxJjjsKabHHFaue1bSouom0qaueVgtTOa9tUXETbVNTOKwURhMsQyiIIlyGUpXZe26biItqmonZeKUjtvLZNxUW0TUXtvFIQQbgMoSyCcBnCem1xxQThMoSyCMJlCMaUQxAuQyiLIFyGYMz6bGHMVRIuRSmMcCmKMQURLkUpjHApynptcdWES1EKI1yKUhZV5aL6kBhzFAqiqlxUHxJjjkJJhEtRCiNcilIWVeWi+pAYcxQKoqpcVB8SY47CGm1xxVSVi+pDYsxRKIiqclF9SIw5CsYUQlW5qD4kxhyFgqgqF9WHxJijYMyabGHMFRpzlD4kNtWYo/QhYcwmGnOUPiQ21Zij9CHxv2qLKzbmKH1IbKoxR+lDwphNNOYofUhsqjFH6UPCmP9FWxhzxYYcpQ+JF+lDYshRKNCQo/Qh8SJ9SAw5CsYUZshR+pB4kT4khhyFAg05Sh8SL9KHxJCjsGZbrIFyvj4khhyFAinn60NiyFEolAJdSMyXJ8yXJ8yXJzx8eo358oQuJIYchYIp8NaDXd5+sEsXEvPlCQ+fXmO+PKELiSFHoVBDjtKHxIv0ITHkKBRoyFH6kHiRPiSGHIVCDTlKFxLz5QkPn17jzvJz5ssT3vnsJbqQGHIUClU7rwp0ITFfnvDw6TXuLD9nvjzhnc9eoguJw/09aueVNdviitXO6+H+Hm8/2OU36a/Mlyc8fHqNO8vPmS9PeOezl+hC4nB/j9p5pTC189o2FedRylU7r4f7exzt7/Gjv/yJu9MJd6cTptdvsTuZsFI7rxRMOKVw9N4xK3enE6bXb7E7mbAJFHjrwS5vP9ilC4n58oSHT68xX57QhcSQo1CwIUfpQuI/6UJiyFEoWO28curudML0+i12p6+wO5kwmb3GSu28UqDaeT3c3+Nof4/b05e5O50wvX6L3ekr7E4mTGavsXL03jFfhC9xxYRTCkePjln52c4dpsDPRFBVpiL8efgDR+8dUyIB3vrhLr99dMxPfvGYv331m6yICKqKiPDk/Xc52t/j9TcPdMxRKIxwSuHo0TErb0xuICKgyr3pDfjoCaUbcpT5/QNV4Ob8u9wTAVXuTW/AR08onXBK4ejRMSs//9o3mKrycxF4/11KVzuvh/t7CPD6mwe8dud7qCoiAiRKVjuvh/t7CPD6mwfcnNzg3vQmqoqIUDLhlMLRo2NW3pjcYOXe9CaqynM/ODhkzFFYsy9xxYYcZX7/QBVom4pf8kz+44f8ux8cHDLmKBRmyFHm9w9Ueaatjvnll7+OqvLpx4957ui9Y0o15Cjz+weqPPPpx49ZmV6/xXdOjvk9MOYoFE6Bl+tX+fTjx4gIk9lrbIohR5nfP1AFXq5fJf/xQ6bXb6GqbALhlMLRo2OeExFUldIJpxSOHh3znKry6ceP+f7kbzwBxhyFAg05yvz+gSrP3Pwq//Dk/Xf5yuwGz405Cl8AYY1q55Uz2tvbdL/7hDFHYQPUziv/1DYVXUgIoMCYo1C42nltm4ouJJ4bcxQ2wI+//S3tQuKstqn46a9+LRSudl45o20qupAYcxQKN3NelX9pm4ouJMYchcLNnFflmbap6ELiuTFHYQP8+Nvf0i4kzmqbip/+6teCMcYYY4wxxhhjjDHGGGPMf8ffAVuuNtijkzfmAAAAAElFTkSuQmCC","w":64,"h":34,"frames":8},"farmer_act_up":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAAJpUlEQVR4Ae3BQWhc+X3A8e9fcVCrkUkzfvPeSwrVGr+x95UaecG6mBoLsYWWbU3AB106sym5LOQgYq+XHmfYnmQw5GCYUw8zW4hvPaR4S8HVaKuFSkMjbMID640s62DNe/M6ir0zz+wS/O+8UIExAY2wmyr/+X0+CCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEOKYcSxPu4WiZsi1itq1PM0YcSxPu4WiZsi1itq1PI0QQgjjOZan3UJRM+RaRe1anuYYm+D/QOndAq7l6ZJfYByV3i3gWp4u+QWEGCeO5Wm3UNQMuVZRu5anGSOO5Wm3UNQMuVZRu5anGSOO5Wm3UNQMuVZRu5anGTOldwu4lqdLfoHj7lu8JY7l6ZNT+UrZt8nMFnJkZgs52ulkZXoqXxmkvSqGcixPn5zKV8q+TWa2kCMzW8jRTicr01P5yiDtVTGcY3n6ZO5UpZ/2qq5V1NNT+Uo/7VUZE47l6ZO5U5V+2qu6VlFPT+Ur/bRXZUxMT+UrZd9mO52slHybB8mAftqrMiamp/KVsm+znU5WSr7Ng2RAP+1VGRPTU/lK2bfZTicrJd/mQTKgn/aqGM6xPH1yKl8p+zaZ2UKOzGwhRzudrExP5SuDtFflmFG8BY7l6bJvc5h6EBMlocIwjuXpsm9zmHoQEyWhwkCO5WkFlHybTCOIKfk2mXoQk4mSUGEox/K0Akq+TaYRxJR8m0w9iMlESagwlGN5WgEl3+Z19SAmEyWhwlCO5WkFlHyb19WDmEyUhApDOZanFVDybV5XD2IyURIqDORYni77NoepBzFREiqOEcUbcixPl32bUdWDmCgJFYZwLE+XfZtR1YOYKAkVBnEsT5d9m8PUg5goCRWGcSxPl32bw9SDmCgJFYZxLE+XfZvD1IOYKAkVhnEsT5d9m8PUg5goCRWGcSxPl32bw9SDmCgJFQZxLE+XfZtR1YOYKAkVx8QEb0ihOAqFWRSKo1CYxbE8XfZtRlH2bRzL0xjEsTxd9m1GUfZtHMvTGMSxPF32bUZR9m0cy9MYxLE8XfZtRlH2bRzL0xjEsTxd9m1GUfZtHMvTGEShOArF8TKBEG9AoTgKhVkUiqNQmEWhOAqFWRSKo1CYRaE4CoU4TiZ4U4oj0RhGcSQaIYQQRlAcieZ4meANaa0ZVSOIiZJQYRCtNaNqBDFREipMojgSjWEUR6IxjOJINIZRHInGMIoj0ZhFa82oGkFMlISKY2QCId6A1ppRNYKYKAkVBtFaM6pGEBMlocIgWmtG1QhioiRUGERrzagaQUyUhAqDaK0ZVSOIiZJQIY6NCd5QlISqEcSMqygJVSOIEUIIMV6iJFSNIOb31QTid6bk27hWUWOQKAlVI4gZRcm3ca2ixiBREqpGEDOuoiRUjSBmXEVJqBpBzChKvo1rFTUGiZJQNYKYUZR8G9cqatcqasZQybdxraJ2raLmmJjgLegkoWoEMYcp+TauVdQYppOEqhHEjGKv+wg9xJgq+QVcq6gZQyXfxrWKmjFV8m1cq6hdq6gZU5u1RVyrqBlTm7VFNmuLuFZRY4hOEqpGEDOKzdoim7VFXKuoOQa+xVvST3vVdjpZ+fDFCW493eeHL76N++zX1F6eZH3nKf8abPIXf/cjSmdiPru/V+mnvSoG6ae9ajudrHz44gS3nu7zIEl5kKQ8PmGxvvOUv315go//6z85UBmqDmGAftqrbqeTldlCjlE8SFK+Gvx3JVMd4vdcP+1Vt9PJymwhx2FmCzm20z+o9NNeFUP00151O52szBZyHKb+D3/DR3/9Z3x2f6/ST3tVDNBPe9XtdLIyW8hxmO/n4O9/9Od8dn+v0k97VQzQT3vV7XSyMlvIcZjv5+CPnO9S+/kv6ae9Kobop71qO52sfPjiBLee7vPDF9/GffZrai9Psr7zlH88VeDaFytM/+kCg+Dfqf38l/TTXpX/ZxO8Rbdz3yHTOjfD9cEzbgye81Vnl053iwPOtU/Z6z5CD2GY27nvkGmdm6F1bobN2iJfdXbJ/Mk/3eV1eghDdJJQMYJG0GWv+4gDeggDdJJQMaK97iNM00lCdWH3ay7sfk0j6NIIujSCLv+8/4csr66xvLrG8uoazrVPMVEnCdV7u9/w3u43LL2c4sbSAjeWFmgEXZZX11heXWN5dY0f3FnHRJ0kVO/tfsN7u9+w9HKKG0sL3FhaoBF0qQcxjaBLI+jygzvrXPjoLp1kS2Gg90/laZ2b4frgGTcGz8m7p8n88X/8Gweca5/SSbYUx8AEb9H1wTPeP5Xnfnef1rkZNmuLbNYW+V7hLL+NHsIg1wfPeP9Unvvdfe5399l5+JjN2iIKRabZavOqZquNSepBzMeDHOejrzkffc21hdPcWFqgEXRZXl1jeXWNTrKlmq02B5qtNqaoBzEfD3IsvZxi6eUU1xZOc2NpgUbQZXl1jeXVNZZX12i22mT0/8IQ1wfPeP9Unta5GTZri2zWFvmqs0uz1eZAs9Xmwkd36SRbCsP8ZPArflq8wP3uPjsPH/OqZqtNs9Umc+Gju3SSLYVhfjL4FT8tXuB+d5+dh495VSfZUp1kS3WSLdVJthSGupqf4X53n83aIpu1RZ5sNrl773Nep4c4Bk7wll3Nz/Bkd4dl4OzDx7xz/jSvarbaXLl4hkyz1cY0V/MzPNnd4TfurLNZO03mysUzNFttmq02B65cPIMeUkMY4mp+hie7O/zGnXVgHY2m2WpzYH7OUysboWZofs5TGORqfoYf7/6CzCd3ngDr/OzePZqtNgfm5zzFULPVxjRX8zP8ePcXnH34mHfOnyaz+Fd/yd17n5OZn/MUhvuk9xzurAPr7HUf0Wy1yczPeYox8EnvOdxZB9bZ6z7CLRQZJ5/0nnP24WPeOX+aA81WmysXz3Cg2WpzHCjeopuXL+l6EJNRKA787N49fpv5OU9hkJuXL+l6EHNAociU/AIf3K7zqvk5T61shJqh+TlPYYCbly/pehDzurJvc+uLLxWGu3n5kq4HMQpFRqPJlH2bD27XyczPeQpD3bx8SdeDGIXigEZT9m1uffGlwnA3L1/S9SAmc/fe57xqfs5TGO7m5Uu6HsTcvfc5Vy6eIdNstfmX62VuffGlwnA3L1/S9SCm093ie4WzZDSasm/zwe06r5qf8xTjZGUj1CsboUYIIcbAykaoVzZCzRha2Qj1ykaoGUMrG6Fe2Qg1r1nZCPXKRqgRQgghhBBCCCGE+J36H5MjIwvE5/10AAAAAElFTkSuQmCC","w":64,"h":34,"frames":8},"farmer_up":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAAHX0lEQVR4Ae3BsY8cVx3A8e/vhIRTBCm772bWBbFjvUMeimgNHRIIdK5jUZ7ETht3WCT8B3R0UF07U1zp1DSJQaKgie6Q7iHlxYaNRGZeXhyBhODS/LjFWKAT8t1J3Abe/j4fjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGPM/5HaeZ1t7yinZm5HZ84rG6R2XmfbO8qpmdvRmfOKMRuidl5n2zvKqZnb0ZnzygapndfZ9o5yauZ2dOa88gXaYs1q53W2vaOcmrkdnTmvmI2yuL3NzHldNNtsosXtbWbO66LZZtPUzutse0c5NXM7OnNeMRtlcXubmfO6aLbZRIvb28yc10WzzRdNWLPaeW2bij4kFk1FHxJDjsKGqJ1XEWH45AOZuR0FZchRKFztvAqwaCrO6kJiZcxRKFTtvAqwaCrO6kJiZcxRKFztvLZNRR8Si6aiD4khR2FD1M6riDB88oHM3I6CMuQoFK52XgVYNBVndSGxMuYoFKp2XgVYNBVndSGxMuYorJmwJrXzKsCiqTirC4mVMUehULXzKsCiqVjpQ2LRVKx0IbEy5igUqHZe26biPF1IjDkKhamd17apOE8XEmOOQoFq51WARVNxVhcSK2OOQqFq51WARVOx0ofEoqlY6UJiZcxRKFDtvLZNxXm6kBhzFApTO69tU3GeLiTGHIU1Etagdl7bpuI8XUiMOQqFqZ3Xtqk4TxcSY45CQWrntW0qLqoLiTFHoRC189o2FRfVhcSYo1CQ2nltm4rzdCEx5igUpnZe26biPF1IjDkKBamd17apuKguJMYchULUzmvbVFxUFxJjjsKabHHFaue1bSouom0qaueVgtTOa9tUXETbVNTOKwURhMsQyiIIlyGUpXZe26biItqmonZeKUjtvLZNxUW0TUXtvFIQQbgMoSyCcBnCem1xxQThMoSyCMJlCMaUQxAuQyiLIFyGYMz6bGHMVRIuRSmMcCmKMQURLkUpjHApynptcdWES1EKI1yKUhZV5aL6kBhzFAqiqlxUHxJjjkJJhEtRCiNcilIWVeWi+pAYcxQKoqpcVB8SY47CGm1xxVSVi+pDYsxRKIiqclF9SIw5CsYUQlW5qD4kxhyFgqgqF9WHxJijYMyabGHMFRpzlD4kNtWYo/QhYcwmGnOUPiQ21Zij9CHxv2qLKzbmKH1IbKoxR+lDwphNNOYofUhsqjFH6UPCmP9FWxhzxYYcpQ+JF+lDYshRKNCQo/Qh8SJ9SAw5CsYUZshR+pB4kT4khhyFAg05Sh8SL9KHxJCjsGZbrIFyvj4khhyFAinn60NiyFEolAJdSMyXJ8yXJ8yXJzx8eo358oQuJIYchYIp8NaDXd5+sEsXEvPlCQ+fXmO+PKELiSFHoVBDjtKHxIv0ITHkKBRoyFH6kHiRPiSGHIVCDTlKFxLz5QkPn17jzvJz5ssT3vnsJbqQGHIUClU7rwp0ITFfnvDw6TXuLD9nvjzhnc9eoguJw/09aueVNdviitXO6+H+Hm8/2OU36a/Mlyc8fHqNO8vPmS9PeOezl+hC4nB/j9p5pTC189o2FedRylU7r4f7exzt7/Gjv/yJu9MJd6cTptdvsTuZsFI7rxRMOKVw9N4xK3enE6bXb7E7mbAJFHjrwS5vP9ilC4n58oSHT68xX57QhcSQo1CwIUfpQuI/6UJiyFEoWO28curudML0+i12p6+wO5kwmb3GSu28UqDaeT3c3+Nof4/b05e5O50wvX6L3ekr7E4mTGavsXL03jFfhC9xxYRTCkePjln52c4dpsDPRFBVpiL8efgDR+8dUyIB3vrhLr99dMxPfvGYv331m6yICKqKiPDk/Xc52t/j9TcPdMxRKIxwSuHo0TErb0xuICKgyr3pDfjoCaUbcpT5/QNV4Ob8u9wTAVXuTW/AR08onXBK4ejRMSs//9o3mKrycxF4/11KVzuvh/t7CPD6mwe8dud7qCoiAiRKVjuvh/t7CPD6mwfcnNzg3vQmqoqIUDLhlMLRo2NW3pjcYOXe9CaqynM/ODhkzFFYsy9xxYYcZX7/QBVom4pf8kz+44f8ux8cHDLmKBRmyFHm9w9Ueaatjvnll7+OqvLpx4957ui9Y0o15Cjz+weqPPPpx49ZmV6/xXdOjvk9MOYoFE6Bl+tX+fTjx4gIk9lrbIohR5nfP1AFXq5fJf/xQ6bXb6GqbALhlMLRo2OeExFUldIJpxSOHh3znKry6ceP+f7kbzwBxhyFAg05yvz+gSrP3Pwq//Dk/Xf5yuwGz405Cl8AYY1q55Uz2tvbdL/7hDFHYQPUziv/1DYVXUgIoMCYo1C42nltm4ouJJ4bcxQ2wI+//S3tQuKstqn46a9+LRSudl45o20qupAYcxQKN3NelX9pm4ouJMYchcLNnFflmbap6ELiuTFHYQP8+Nvf0i4kzmqbip/+6teCMcYYY4wxxhhjjDHGGGPMf8ffAVuuNtijkzfmAAAAAElFTkSuQmCC","w":64,"h":34,"frames":8},"clerk_idle":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAkAAAAAiCAYAAAC3OWZOAAAPPklEQVR4Ae3BP2hcZ77H4c/XSSHbSZyMzswZGRaNxBFIBv1xY0H+VAqqjJzGxgPStAqkMWvSbJMQcGGWTRHsYlIFKWFwF5atplmbhUVSI2kCmqz3ZBOrsGbOHrRcofVUm9+dM+OB2LDdtXJ5/T4Pnud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud5nud53v8HYRBZMT9hdBWDCSsGkfESCYPIivkJo6sYTFgxiIyXSBhEVsxPGF3FYMKKQWR4nud5zguDyIr5CaOrGExYMYiMX9EpfgVfX5+hGES2Xp7hZfT19RmKQWTr5RleRl9fn6EYRLZensHzXiZhEFkxP2F0FYMJKwaR8RIJg8iK+QmjqxhMWDGIjJdIGERWzE8YXcVgwopBZLxkvr4+QzGIbL08w69NnJAwiEzAylQBjC4DifVmgtHXTmPhqDCITMDKVAGMLgOJ9WaC0ddOY+GoMIhMwMpUAYwuA4n1ZoLR105j4bgwiEwSrX/+XcVgwsBopbF4SYRBZJJo/fPvKgYTBkYrjcVLIgwi+6Y8y3Jtl/XyLCu1XVppLF4SYRDZN+VZlmu7rJdnWant0kpj8ZIIg8i+Kc+yXNtlvTzLSm2XVhoLx4VBZAJWpgpgdBlIrDcTjL52GosTJk5AGERWmcwDAozFi+fJ1HcO6DFAsNZMaKexcEwYRFaZzAMCjMWL58nUdw7oMUCw1kxop7FwTBhEVpnMAwKMxYvnydR3DugxQLDWTGinsXBQGEQmwIBvyrMs13ZZL8+yUtvF6GunsXBUGEQmwIBvyrMs13ZZL8+yUtvF6GunsXBUGEQmYGWqAEaXgcR6M8Hoa6excFQYRCZgZaoARpeBxHozwehrp7FwVBhEJmBlqgBGl4HEejPB6GunsXBQGERWmcwDAozFi+fJ1HcO6DFAsNZMaKexOEHiBQuDyCqTeZDAjIHFiyOAyNR3DhhYaya001g4Igwiq0zmQQIzBhYvjgAiU985YGCtmdBOY+GIMIisMpkHCcwYWLw4AohMfeeAgbVmQjuNhUPCILLKZB4QYCxePE+mvnNAjwGCtWZCO42FY8IgsspkHhBgLF48T6a+c0CPAYK1ZkI7jYVjwiCyymQeEGAsXjxPpr5zQI8BgrVmQjuNhWPCILLKZB4QYCxePE+mvnNAjwGCtWZCO42FY8IgsspkHhBgLF48T6a+c0CPAYK1ZkI7jYVDwiCyymQeJDBjYPHiCCAy9Z0DBtaaCe00FifkFC+YEM+QyNR3Wgwszo2AGZgh3CLEMyQy9Z0WA4tzI2AGZgi3CPEMiUx9p8XA4twImIEZwi1hEFllMg8SYGTq248BY3FuhMW5ERA9lakCYRAZDgmDyCqTeZAAI1PffgwYi3MjLM6NgOipTBUIg8hwSBhEVpnMgwQYmfr2Y8BYnBthcW4ERE9lqkAYRIZDwiCyymQeJMDI1LcfA8bi3AiLcyMgeipTBcIgMhwSBpFVJvMgAUamvv0YMBbnRlicGwHRU5kqEAaR4RAhniGRqe+0GFicGwEzMEOcrFOcgM2kQ2Yr6dAnMvXtA+o7B9S3H4MECBdtJh0yW0mHPpGpbx9Q3zmgvv0YJEC4aDPpkNlKOvSJTH37gPrOAfXtxyABwjVCPEMiU99pMbA4NwJmYIZwixDPkMjUd1oMLM6NgBmYIdwixDMkMvWdFgOLcyNgBmYItwjxDIlMfafFwOLcCJiBGcItQjxDIlPfaTGwODcCZmCGcM9m0iGzlXToE5n69gH1nQPq249BAsRJe5UXTfRsJR0M2Eo6XMoPgfGUQCKzmTzBcIzo2Uo6GLCVdLiUHwLjKYFEZjN5guEY0bOVdDBgK+lwKT8ExlMCicxm8gTDPZtJh/nwDFtJh0vhGUBk6tsHIMAMJDCctJl0mA/PsJV0uBSeAUSmvn0AAsxAAsNJm0mH+fAMW0mHS+EZQGTq2wcgwAwkMJy0mXSYD8+wlXS4FJ4BRKa+fQACzEACw0mbSYf58AxbSYdL4RlAZOrbByDADCQw3CN6tpIOBmwlHS7lh8B4SiCR2UyeYJysV3nBzAxJZCRx+/oF+oQEZvRIsH5ng3YaC4eYGZLISOL29Qv0CQnM6JFg/c4G7TQWDjEzJJGRxO3rF+gTEpjRI8H6nQ3aaSxcInq2kg4GbCUdLuWHwHhKIJHZTJ5gOEb0bCUdDNhKOlzKD4HxlEAis5k8wXCM6NlKOhiwlXS4lB8C4ymBRGYzeYLhGNGzlXQwYCvpcCk/BMZTAonMZvIEwzGiZyvpYMBW0uFSfgiMpwQSmc3kCYZbzAxJZCRx+/oF+oQEZvRIsH5ng3YaixP0KifAzJCEmVGaHkeCmdUajWoZA+ZWa+xWy8AGLjIzJGFmlKbHkWBmtUajWsaAudUau9UysIGLzAxJmBml6XEkmFmt0aiWMWButcZutQxs4BozQxIZSdy+foE+IYEZPRKs39mgncbCIWaGJDKSuH39An1CAjN6JFi/s0E7jYVDzAxJZCRx+/oF+oQEZvRIsH5ng3YaC4eYGZLISOL29Qv0CQnM6JFg/c4G7TQWDjEzJJGRxO3rF+gTEpjRI8H6nQ3aaSwcY2ZIwswoTY8jwcxqjUa1jAFzqzV2q2Vgg5N2ihesncZ6eHjMvVuXmS+cBgwzEH2iS8JV7TTWw8Nj7t26zHzhNGCYgegTXRKuaqexHh4ec+/WZeYLpwHDDESf6JJwmZmRMTNK0+OMzYxz5e4GpekxSjNjfHB3g9L0GK4yMzJmRml6nLGZca7c3aA0PUZpZowP7m5Qmh7DVWZGxswoTY8zNjPOlbsblKbHKM2M8cHdDUrTY7jKzMiYGaXpccZmxrlyd4PS9BilmTE+uLtBaXoMV5kZGTOjND3O2Mw4V+5uUJoeozQzxgd3NyhNj+Gidhrr4eEx925dZr5wGjDMQPSJLolfyylOiAQ3bywwsL9yDQMM2F++ihlOk+DmjQUG9leuYYAB+8tXMcNpEty8scDA/so1DDBgf/kqZjipncZ6eHjMvVuXmS+cBgwzEH2iS8JV7TTWw8Nj7t26zHzhNGCYgegTXRKuaqexHh4ec+/WZeYLpwHDDESf6JJwVTuN9fDwmHu3LjNfOA0YZiD6RJeEq9pprIeHx9y7dZn5wmnAMAPRJ7okXCfBzRsLDOyvXMMAA/aXr2LGr+IUJ6CVxppdrfHTdz+ChASH75xCdJnxr3dfYe7DGq00Fg5qpbFmV2v89N2PICHB4TunEF1m/OvdV5j7sEYrjYWDWmms2dUaP333I0hIcPjOKUSXGf969xXmPqzRSmPhKAlu3lhgYH/lGgYYsL98FTOcJsHNGwsM7K9cwwAD9pevYobTJLh5Y4GB/ZVrGGDA/vJVzHCaBDdvLDCwv3INAwzYX76KGU6T4OaNBQb2V65hgAH7y1cxw1mtNNbsao2fvvsRJCQ4fOcUosuMf737CnMf1milsThh4gSEQWQ89fnZc3zy2jk+Oz7CMD59/U2OWo/ItNNYOCwMIvv87Dk+ee0cnx0fYRifvv4mR61HtNNYOC4MIvv87Dk+ee0cnx0fYRifvv4mR61HtNNYOKwYRPbtR/OUZsYRYGZIwsyQxOxqjVYaC0cVg8i+/Wie0sw4AswMSZgZkphdrdFKY+GoYhDZtx/NU5oZR4CZIQkzQxKzqzVaaSwcVQwi+/ajeUoz4wgwMyRhZkhidrVGK42Fo4pBZN9+NE9pZhwBZoYkzAxJzK7WaKWxcFAYRMZTn589xyevneOz4yMM49PX3+So9YhMO43FCXuVFywMItutlhFw7Xd/4v2zOb7IjbJw+Agz+GJ4lKPWIxrVMjOrNWunsXBMGERG1+dnz/HfhEFk7TQWDgqDyOj6/Ow5/pswiKydxsIxYRAZXX84e44fvvqeH/ieT147x2fHRxjGp6+/yVHrEZkwiKydxsIhYRAZXX84e44fvvqeH/ieT147x2fHRxjGp6+/yVHrEZkwiKydxsIxYRCZAT989T0/8D2fvHaOz46PMIxPX3+To9YjXBYGkRnwj6/+xthwwlJulD8ePsIMrgyP8tPOfVwWBpEZ8I+v/sbYcMJSbpQ/Hj7CDK4Mj/LTzn1cFQaR7VbLCLj2uz/x/tkcX+RGWTh8hBl8MTzKUesRjWqZmdWatdNYnKBTvGCiy6Bxf4/MUm6UzJXhEleGRxlo3N/DRWEQ2W61TKNa5suhn3l/OMfwyDgLw2+xkMuRK46RaVTLhEFkOCYMItutlmlUy3w59DPvD+cYHhlnYfgtFnI5csUxMo1qmTCIDIeEQWS71TKNapkvh34m8/5wjuGRcRaG32IhlyNXHCOzWy3TqJYJg8hwRBhEtlst06iW+XLoZzLvD+cYHhlnYfgtFnI5csUxMrvVMo1qmTCIDIeEQWS71TKNapkvh37m/eEcwyPjLAy/xUIuR644RqZRLRMGkeGYMIhst1qmUS1THfoPS7lRMku5Ua4MjzLQqJYJg8hwTBhEtlst06iWqQ79h6XcKJml3ChXhkcZaFTLhEFkOEZ0GTTu75FZyo2SuTJc4srwKAON+3v8Gl7lBWulseY+rJnRV/oNPT9u/5k3iqMMLNd2aaexcIzoMmg82COzlBsls5Qb5Zca9/dwkegyaDzYI7OUGyWzlBvllxr393CN6DJoPNgj89t//w+liYtklnKjPMOg8WAPl4gug8aDPTK//ff/UJq4SGYpN8ozDBoP9nCN6DJoPNgjs5QbJbOUG+WXGvf3cJHoMmg82OOXftq5zxvFUQYa9/dwkegyaDzY45d+2rnPG8VRBhr393BRK40192HNjL7Sb+j5cfvPvFEcZWC5tks7jcUJEyfo4/fetrVmwvMqUwV+/5e/CkcVg8gMqEwVWGsmPK8yVWCtmdBOY+GgYhCZAZWpAmvNhOdVpgqsNRPaaSwcUwwiM6Cdxvr4vbdtrZnwvMpUgfVmggHtNBYOKQaRGdBOY3383tu21kx4XmWqwHozwYB2GgvHFIPIDKhMFVhrJjyvMlVgrZnQTmPhoGIQmQGVqQJrzYTnVaYKrDUT2mksHFQMIjOgMlVgrZnwvMpUgbVmQjuNhcM+fu9tW2smPK8yVeD3f/mr8DzP8zzP8zzP8zzP87z/c/8Lui5kxtzls5AAAAAASUVORK5CYII=","w":64,"h":34,"frames":9},"clerk_work":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAAiCAYAAAApg2HuAAAPVklEQVR4Ae3BTWibd57A8e/Pk0OiOJtEeWTJ2TaW3MepHUa2QpM4DWQTmCK6TPrCwkxsaHSNS2Bpm00Pge7Ky+aQKQQGYnBOC3Yyrg7d9tAlRbuYmFkGW/Fi5QXM2PLk5RBJj4UyzcrSQA+/1SNF4JQeNy77+P/5YBiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRiGYRjG/zNBy9ZQoEepC1k9GrJsZRMJWraGAj1KXcjq0ZBlK4ZhGIbnBS1bQ4EepS5k9WjIspWfUBs/getD/YQsWyeH+9mMrg/1E7JsnRzuxzA2k6BlayjQo9SFrB4NWbayiQQtW0OBHqUuZPVoyLKVTSRo2RoK9Ch1IatHQ5atbDLXh/oJWbZODvfzU/sZGyRo2brD508m+jpYyVcYsHysFCvcLa2x3edPtvv8ybVqeRSPClq27vD5k4m+DlbyFQYsHyvFCndLa2z3+ZPtPn9yrVoexeOClq07tu9JVqrl0ZDVo+0+f7JSLY+ySQQtW3ds35OsVMujIatH233+ZKVaHmWTaPf5kzeGB0j/6fvk5PAAX90vUqmWR9kk2n3+5I3hAdJ/+j45OTzAV/eLVKrlUTaJdp8/eWN4gPSfvk9ODg/w1f0ilWp5FI8LWrbu8PmTib4OVvIVBiwfK8UKd0trbPf5k+0+f3KtWh5lgwkbIGjZmugNAAIo8YN7caWzeRoUEJhYdCiWcoLHBC1bE70BQAAlfnAvrnQ2T4MCAhOLDsVSTvCgoGWrAArcGB7gg6k7TA4PcGbqDkpTsZQTPCpo2SqAAjeGB/hg6g6TwwOcmbqD0lQs5QSPClq2CnCmrwOUOgURJhcdlKZiKSd4VNCyVYAzfR2g1CmIMLnooDQVSznBo4KWrQKc6esApU5BhMlFB6WpWMoJHhS0bE30BgABlPjBvbjS2TwNCghMLDoUSzlhAwkvWdCyNdEbABFQpSV+sBMQXOlsnpaJRYdiKSd4RNCyNdEbABFQpSV+sBMQXOlsnpaJRYdiKSd4SNCyNdEbAARQ4gf34kpn8zQoIDCx6FAs5QSPCVq2JnoDgABK/OBeXOlsngYFBCYWHYqlnOAxQcvWRG8AEECJH9yLK53N06CAwMSiQ7GUEzwmaNma6A0AAijxg3txpbN5GhQQmFh0KJZygscELVsTvQFAACV+cC+udDZPgwICE4sOxVJO8JCgZWuiNwAioEpL/GAnILjS2TwtE4sOxVJO2CBtvGSC8AIRXOlsgZZ4rBNUQRXBWwThBSK40tkCLfFYJ6iCKoK3BC1bE70BEAEUV3rhCaDEY53EY50gNCT6OghatuIhQcvWRG8ARADFlV54AijxWCfxWCcIDYm+DoKWrXhI0LI10RsAEUBxpReeAEo81kk81glCQ6Kvg6BlKx4StGxN9AZABFBc6YUngBKPdRKPdYLQkOjrIGjZiocELVsTvQEQARRXeuEJoMRjncRjnSA0JPo6CFq24iGC8AIRXOlsgZZ4rBNUQRVhY7WxAeacGq6MU6NJcKUX8qSzedILT0AEELxozqnhyjg1mgRXeiFPOpsnvfAERADBawThBSK40tkCLfFYJ6iCKoK3CMILRHClswVa4rFOUAVVBG8RhBeI4EpnC7TEY52gCqoI3iIILxDBlc4WaInHOkEVVBG8RRBeIIIrnS3QEo91giqoInjPnFPDlXFqNAmu9EKedDZPeuEJiADCRtvCyyY0ZJwaCmScGkcCW0F5TkAE15xTRfEYoSHj1FAg49Q4EtgKynMCIrjmnCqK98w5NQaDPjJOjSNBHyC40gt5EEAVREDxpDmnxmDQR8apcSToAwRXeiEPAqiCCCieNOfUGAz6yDg1jgR9gOBKL+RBAFUQAcWT5pwag0EfGafGkaAPEFzphTwIoAoioHjSnFNjMOgj49Q4EvQBgiu9kAcBVEEEFO8RGjJODQUyTo0jga2gPCcggmvOqaJsrC28ZKqKiOASES4PHaBJEAFVGkRg8uosxVJO8BBVRURwiQiXhw7QJIiAKg0iMHl1lmIpJ3iJ0JBxaiiQcWocCWwF5TkBEVxzThXFY4SGjFNDgYxT40hgKyjPCYjgmnOqKB4jNGScGgpknBpHAltBeU5ABNecU0XxGKEh49RQIOPUOBLYCspzAiK45pwqiscIDRmnhgIZp8aRwFZQnhMQwTXnVFG8RVUREVwiwuWhAzQJIqBKgwhMXp2lWMoJG2gLG0BVERFUlXC0GxHoPzvF3WvDKBA7O8Wda8PALF6kqogIqko42o0I9J+d4u61YRSInZ3izrVhYBavUVVEBJeIcHnoAE2CCKjSIAKTV2cplnKCh6gqIoJLRLg8dIAmQQRUaRCByauzFEs5wUNUFRHBJSJcHjpAkyACqjSIwOTVWYqlnOAhqoqI4BIRLg8doEkQAVUaRGDy6izFUk7wEFVFRHCJCJeHDtAkiIAqDSIweXWWYikneIyqIiKoKuFoNyLQf3aKu9eGUSB2doo714aBWTZaGy9ZsZSTpXKF1KVTDHZsAxRVEJqEOhG8qljKyVK5QurSKQY7tgGKKghNQp0IXqaquFSVcLSbSH83743NEo5GCPdHeH9slnA0glepKi5VJRztJtLfzXtjs4SjEcL9Ed4fmyUcjeBVqopLVQlHu4n0d/Pe2CzhaIRwf4T3x2YJRyN4lariUlXC0W4i/d28NzZLOBoh3B/h/bFZwtEIXqWquFSVcLSbSH83743NEo5GCPdHeH9slnA0ghcVSzlZKldIXTrFYMc2QFEFoUmoE+Gn0sYGEYHzH/2Clsdnfo0CCjz+4Feo4mkicP6jX9Dy+MyvUUCBxx/8ClUaQlaP4iHFUk6WyhVSl04x2LENUFRBaBLqRGgJWT2KhxRLOVkqV0hdOsVgxzZAUQWhSagTwauKpZwslSukLp1isGMboKiC0CTUieBVxVJOlsoVUpdOMdixDVBUQWgS6kRoCVk9iocUSzlZKldIXTrFYMc2QFEFoUmoE6ElZPVoyOpRPEYEzn/0C1oen/k1Cijw+INfoUpDyOrRkNWjbJCfsQEq1fLo9eknybe7trMr5EcEaq8KIgKq/KWrjdjIFCC0+/YkK9XyKB5SqZZHr08/Sb7dtZ1dIT8iUHtVEBFQ5S9dbcRGpsiOD/FP//oVybrROjyi3edPfvhOlDePRmgSLu4+QG1fG66Lu/qovdrG+Df3yY4PcX06n6xUy6N4RLvPn/zwnShvHo3QJFzcfYDavjZcF3f18Vcf/Qv/8Onfc23sd8lKtTyKh7T7/MkP34ny5tEITcLF3Qeo7WvDdXFXH7VX2xj/5j7tvj3Jdt+eZKVaHsUj2n3+5IfvRHnzaIQm4eLuA9T2teG6uKuP2qttjH9zn+z4ENen88lKtTyKR7T7/MkP34ny5tEITcLF3Qeo7WvDdXFXH7VX2xj/5j7Z8SFGTv2c69P5ZKVaHsUDKtXy6PXpJ8m3u7azK+RHBGqvCiICqvylq43YyBQgZMdPM3Lq51yfzicr1fIoL5mwgYKWrVe27+T82jOubN+JoiR37OJZ4RGF1WVcxS8/IzaSolBaFjwmaNl6ZftOzq89o2VHaB/PCo/43L+TM3+cZz2pwyNClq1fnxsk3N9N7OwXrHfn2hADZ6f4+twg4WiE2EiK/OoSLqnDA0KWrV+fGyTc340AqkpsJIUrv7rEep2B/RRKy4KHhCxbvz43SLi/GwFUFRFBVREROv7un3EVv/wMV2wkRaG0LHhEyLL163ODhPu7iZ39gpb86hLOv/0jA2en+I1/J/uHewlHI8RGUhRKy4JHhCxbvz43SLi/m9jZL2jJjp9GRBg4O8Vv/DvZP9xLOBohNpKiUFoWPCRo2Xpl+07Orz3jyvadKEpyxy6eFR7x36+H+ev/+g9cxS8/IzaSolBaFl4yYQPd6HpDqTvxym4O/fERLfnVJX6M1OEhN7reUOpOvLIb15aPjxIbSaEoqZvfcuLQa/yQ1OERN7reUOpOvLIb15aPj+KKjaRYL7+6xHpShwfc6HpDqTu/9gxXdvw0rthIivzqEutJHR5zo+sNpe782jNadoT2sXTvP1mv+OVnxEZSFErLgof8ruuQUvc3r+xiy8dHccVGUuRXl2jpDOwnO36a2EiKQmlZ8JDfdR1S6v7mlV1s+fgorthICkURhPUKpWXBY4KWrXf3Rfh+m3Loj49wdcVO8DB7i8LqMutJHRugjQ30ydp3vLXHz/TqU+Zf7yI7fprs+Gk6A/v5MVqHh3yy9h1v7fEzvfqU6dWnPLz3gOz4aQTBNTO/wnoz8yt4ySdr3/HWHj/Tq0+ZXn3Kw3sPaMmvLpFfXaJQWpaZ+RVaZuZX8IpP1r7jrT1+5l/vYv71Lh7ee8CPmZlfwaXP4RGfrH3HW3v8zL/eRXb8NNnx0/xP4TEz8yu0zMyvEBtJUSgtCx7z8dqf+W1PjOnVpzy894D1ZuZXmJlfwRUbSVEoLQse8/Han/ltT4zp1ac8vPeA9QqlZSmUlqVQWpZCaVnwqHf9XUyvPiU7fprs+GkeZWdI3fyWH9I6NsAWNti7/i4ePX7Ib4D99x4QjkZYb2Z+hROHXsM1M7+C17zr7+LR44c0jGXIjkdwnTj0GjPzK8zMr9By4tBraJ3U4RHv+rt49PghDWMZIIOizMyv0HLysC23bueUupOHbcFD3vV3ce7xAq5Pxx4BGb64eZOZ+RVaTh62hbqZ+RW85l1/F+ceL7D/3gPC0Qiu03/7Nqmb3+I6edgWPO7T8jMYywAZ8qtLzMyv4Dp52BY2gU/Lz2AsA2TIry4RCvSwmXxafsb+ew8IRyO0zMyvcOLQa7TMzK+wEYQNdOH4MZ1YdHAJQssXN2/yY04etgUPuXD8mE4sOrQIgutMX4BfXplgvZOHbbl1O6fUnTxsCx5w4fgxnVh0+KFEXwef//4PgsddOH5MJxYdBMGlKK5EXwe/vDKB6+RhW/CoC8eP6cSigyC0KEqir4PPf/8HweMuHD+mE4sOrtTNb1nv5GFb8LgLx4/pxKJD6ua3nDj0Gq6Z+RX+/ZMEn//+D4LHXTh+TCcWHQqry3QG9uNSlERfB7+8MsF6Jw/bwmZy63ZOb93OKYZhGJvArds5vXU7p2xCt27n9NbtnLIJ3bqd01u3c8oP3Lqd01u3c4phGIZhGIZhGIZhGMb/qf8Fouk7a0fi6cQAAAAASUVORK5CYII=","w":64,"h":34,"frames":8},"crop_beetroot":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAUCAYAAAByKzjvAAAE6UlEQVR4Ae3BcWhUdQDA8e9zd7OcvazNvKIcG75bC29jCaLVfuX1z2tCWhD9c/h3Iv0REQv85w4UfH+kgwn6x/4JjiKClTwlBbsXh4dioXCHV75XzNkDX+g8ONfa7rRf92KLM263WxjEus+Hpqampqb/LYWmf4UwdEmFlythJ1MKi2ih6YEThi41EaS9s4XSrMLq0Mb4VHYiQQ0Bmv4SjkUlVexkSqEiHItKqtjJlMIihKFLTQTxOekySwnQ9KdwLCoH97Vxv6ikYnBfG/eLSjuZUljC8PlXMLZ/Qz0Bmv7ipMucvvU8776ZwxeKtFJtdDyC3nGJWoShSyq8XAlNBFng5UrYyZTCIgKsQOFYVFJhJ1MKFeFYVFJhJ1MKS9A7LvHce5soH5lEE0EWBN/rRH/jErUIQ5eaCOLTRBAnXcbLlQh6LmyirhZWGGHocuCth+jc2sqvc0/H2/u64oP72ujc2soj4e745NkfE9QwlZ1IrA5tjN+4OMfvu+4QGunm6ppb3J78ndBIN/k3fsQxZyiXJHYypTBPGLrURJBq+ZOz+Lpur+e3n2wmp7wEiwiwAo2OR3j3zRyhSCsLRscj6B2XqMdOphT+JKQTyLLriz58JwJZMOHGubRy4xw1Oekyw+dfwfRcotzv1O5Dknmm53L8wlGFeS2sMKXZp+JfDdwiNNLNzd7b+EIj3RzZcgXHnGH6+mSCOk7tPiSP9G+gb3Yz9nQR3wdPbOFI/wZeeGJn/JMfziaosjq0MV6aVfBlnrlG7q7HxOM3+e0nm5uzP/PcYy/yzgB0tc/R1T5Ha2k96rpn49+5FxNUKKxAT74kJBW77vbhOxHI4rtxLq1Qx6ndh+QOrUg9lqOy88sPFaqEY1HJPDuZUpgnegbk6ddf4+8sR8X0XI5fOKoE+A8Shi6pSA+fVqgQhi6pSA+fVmjAWMcQPtNz8Y11DOHbSZqlWI7KDq1ILZajUoudTCnUMNz7NlCknlUsIjXUL1ND/TI11C/5B4ShS+YJQ5c0SBi61EQQTQQJx6IyHItKTQTRRBBh6JIG7dCKHB5UOTyoskMr0gjTc/FZjsrfWY6Kz/RcGmV6LpajUs1yVKqtoob3xXZJRTj2KuHYq6SG+iXLEI5FpSaCCEOXwtClJoKEY1FJA7xcidHxCL5QpJVQpBXf6HgEL1eiEabnYjkqCyxHxfRclpIvZDA9F5/lqFiOiuWoWI6Kz/Rc8oUMy2U5KpajYjkqC/KFDL4Wanih85n4y88/yuTZK7T3dTOVneBj55cEDWrv64pf/7bM2g0t+PInZ/FNZScSLGEqO5H4vDsY3/Spxs3e2/hCI90Mt17GTqYUGrCmrRwv3FvHmetznLk+hz1dJF/IMDnlJahjcspLrGkrxwv31mFPF+lZq+IzPRd7uki+kCF99bJCg75zLybUdc/Ge9aqVDM9l/UPb2RNWzm+ijqe3NyBnfya5Rrr7eHOtbs45gyOOcOda3cZ6+2hUWO9PZwIZHHMGRxzhhOBLGO9PTTqwJ5t5AsZFuQLGQ7s2UYjDuzZRr6QwWd6Lqbn4ssXMhzYs43lOn7hqGJ6LqbnYnouxvefUU1hEe+L7ZJ5H6XPKyxT+uBeSRWx/5jCMqQP7pVUEfuPKSxD+uBeSRWx/5hCg9IH90pqEPuPKTwAomdAUpG+eln5A88dAmNaCIzcAAAAAElFTkSuQmCC","w":16,"h":20,"frames":6},"crop_cabbage":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAUCAYAAAByKzjvAAAFxElEQVR4Ae3BUWgb5wHA8f8h2wdB+whxRY5wi0mJqnjQJ5ng0VjdGcoERkEqhLz0ZRBQAu5Dn2LIy4kSkGCwwrzFBkNfjF8Gs+EmyIo5DUE7E+yHWURxJIEccuDDxir9ptBZmXvzrXJQM8V2IOwh6Pejp6enp6enp6en5/9Poed/5JNZzwhL5LiOT9gOhapgYmlK4Q0L0PMT+WTWi6YF33wFW2t7bK3tsdlQiaYFxrMxc2FjOcMbpNDzQj6Z9aJpgbAdClVBJyMskeM6a7OSiaUphSPkk1nPCEvkuI5P2A6FqmBiaUrhJX28pfLJrBdNC3xrs5KJpSmFY1iug2ELClVBNC3oVJgFAwfLlRwln8x60bSgMAtUJT8SRNOCPFlvYmlKoUOAt1A+mfWiacHarGRrbY9oWmA8GzMXNpYzdBHLxb2hjy6aoY0zDLRCGGGJWpfsXRD4hO1wYXCPQlVQaUpOfXrGHProovlkuZahQz6Z9aJpgbAdNhsqnS7JHQavhTCejZkLG8sZ2gK8RWK5uPfH4A0zmhYI22GzoeK7JHcYvBbCeDZmOr/pM58s1zK0xXJxLxzrZ3AoQOCvp4kEBRcG9/CpdYlalxzabKhUmpLT6X8yOBTgZ++9az5ZrmVoE6cvmVd/2KNQFUTTgnMjKudGVM6NqHzzFVySO/y+vMOq8yBDWx9vWCwX92gr3r6vcCCWi3u0FW/fVzihfDLrcWBiaUrhGLFc3AvH+rEWHQxbUKgKommBrzALBg6WKwnH+iEX94q37yt06P9siISmY7kOoOMzwhJfoSrwWa5DQtOxPoPnv3tCN4WqwAhLsCVyXMcnbAcjDIWqACSd+niDYrm4F47180Iu7nEgHOvnhVzcK96+r3CMfDLrRdMCX56sN7E0pXAEt9QiHOvHV6gKjLBEIvAZYUmhKgCJzy21OOSWWvh+wY8Smo7lOiQ0nUJVcMhyHRKazqFq8TluqcVRhO1wnD5eIZ/MerRNLE0pvIaPcx/gy/3yb/g+zn2A78+3v+Ykbo5OekZYUpjlv6JpwU130ptZmVY4QrX4HFI1WOSAjoGDr1AVWK5DOVWDIl2VUzVYhISmk9B0LNehU0LT8VmuQzlV42U3Rye9hKZjuQ6g4zPCEl+hKvBZrkNC02F00ptZmVY4EKCLfDLrGWHJ4LUQ50ZUjGdj5sLGcoZjqNp5c+jyAI+uPOXRladoX7xLaOMMDz8v8ejKU3zlv/yL3fV6hld475Nx70IjxEArhBGWDF4LsTYrqTQl8ldBc3e9nqGL3fV6RtXOm8GzAXaGG3y72sdAK8RmQ8VyHcqpGj631KIybyu07a7XM6p23gyeDbAz3ODb1T4iQUEkKKg0Jb6EpuOzXIdyqobPLbWozNsKbSP6ZTMSFESCAst1iAQFmw2VzYaKz3IdEpqOr9KUrDoPMhzoowvLdTDCgtdVmbcVGPdo01I1fO4fWhyqzNsKxyinaiT+ruMTtgMIyqkalDjS3HCEG6XHaO8PUE7VsEtlfFpqAJ9bajE3HCGGTafKvK3wybinvT+AfbEMNX7Cch3si2W4CBoDuKUWlXlbocPMyrTC6KSX0HQSmo7lOnRKaDo+y3WYWZlWaAvQxYh+2fz1kIpal6h1yWZDZWFjOcMJ7K7XM4vX4+bV0DssPNymub3P3HCEq6F3+O0Xf1I4xuL1uLnwcJt/RJ8yf2qL+VNbfP3zTdxSi7nhCF/aqxle4Ut7NbN4PW4uPNymub3Poeb2Ps3tfeaGI8Tu3FPoYne9nlG18yYHvv/wO3aGG5T+7VI/s8P3H35H8GyA5vY+ze19KvO2QherzoOMOH3JjAQFkaCg0pT4EpqOz3IdZlamFToovMLN0UmPtpmVaYXXVLx7y6ND7M49hRMq3r3l3Xj0mE5zwxFid+4pnEDx7i2PLmJ37ikco3j3lnfj0WO6mRuOELtzT+EYN0cnPbqYWZlWeMl/AI+qbbZ6HfhRAAAAAElFTkSuQmCC","w":16,"h":20,"frames":6},"crop_cauliflower":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAUCAYAAAByKzjvAAAEcElEQVR4Ae3BUYjbZAAH8H/u1gzkNpDBGodcd/OScpNMKNzT7Ce2iBlFkcEyhMIY+JKHsRfZZOdDAstDX4ShW14OyuCYqA9KRC/gETFzD2LYQ8KdrISVjsHaQA+RFUq8u08DVyil12sYA5n9/TAxMTExMTExMTEx8b/DYGIoR1co+pAlg0ECjq5Q9CFLBoMhpvECE8oFeuTUnNr26hoScHSFCjkRJy+qyORLyORLKLKhWrVdDWNwdIUKOREnL6rI5EvI5EsosqFatV0NA6bxghLKBYpdR07NqW2vrmEMjq5QISciLSnol8mXUGRDtWq7GkZwdIUKORFpSUG/TL6EIhuqVdvV0GcaLyBHV+jH776NT658jktnL+DS2QsosqFatV0NIzi6QoWciNjM/CIGZfIlFNlQrdquhiEcXaFCTkRsZn4RgzL5EopsqFZtV8OuKfyHkYpESUWiSIBUJCrkRAzKX7sFUpEonkHLMvAsWpaBQQfwnLz35WWKPt9/eINBAqQi0V+urCL2Fs5Q56rFYB+kIlHsoWUZiJGKRJ2rFoN9tCwDaUlBT8sykETLMpCWFPS0LAPDTOM5IBWJzr7xFzp/vozY0eMPcUg4oTbWAg1jIBWJfn3qfczMLyJ28XQZP7/0m9pYCzSMkHlnXsW/vmk9wLl0Fp3ARSdw0QlcyJ6JnsZaoGGIe8cOq6sIcC6dRawTuOgELjqBi5jsmbizHqLt1TUMce/YYXUVAc6ls4h1AhedwEUncBGTPRN31kO0vbqGXVPYg6Mr1NEV6ugKRUJNP0Ls6PGHOHr8IWJNP8I4SEWiPEkh1rIMxFqWAZ6kQCoSxRh4koLsmeiRPRM8SWEUoVygnMiCJynInolBsmeCJylwIguhXKAYIJQLlBNZ8CQF2TMxSPZM8CQFTmQhlAsUu6YwhKMrVMiJyF+7hfy1W3B0hSKB2orN3L3ZQc/dmx3UVmwGCdTu+4i1LAO1+z6S4kkKsmdC9kzwJIUkeJKC7JnokT0TPElhXDxJQfZM9MieCZ6kMMw0hjgvvqpy869hZn4RsUd3f0DVdjUk8O15Sf3ixyd49PvfWF7Iomq7GsbQWAu0Q8IJ9c56iNNb22g/CfHRHw8QdRk4Vy0GIzTWAu0gN6tGXQabjR00/QhPw21EXQabjR00/Qj3P/uJwRBtr64d5GbVqMtgs7GDph+h6m+g6m/gabiNqMtgs7GDph+htmIzGND26tpBblaNugw2Gzto+hGq/gaq/gaehtuIugw2Gzto+hFqKzaDXVMYoWUZaFkGknJ0hWKAoysUY7q+NQdOZHG78Bi3C4/BiSyub81hHMsLWTT9CDFOZMGJLGJNP8LyQhajLC9k0fQjxDiRRQ8nsog1/QjLC1nspbZiM00/QowTWfRwIotY049QW7EZ9GGwB+vyBxS7pBvfMUjI0RWKPmTJYJCAoyv00wN1xK5vzYEsGQzG5OgKxRBkyWCwD0dX6PnVdQzz1ZnXQZYMBvt45U1CMcSTXx0GA/4BRdLeT/3fLD8AAAAASUVORK5CYII=","w":16,"h":20,"frames":6},"crop_carrot":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAUCAYAAAByKzjvAAAEI0lEQVR4Ae3BT2hadwDA8e8v05Z2iNAyaaANEtBdKimSiwl7FQuNBGQhlxEo7JJDpYfHLr3kEg8essNKDlk8LIxAQQYjDAISGMj6pNURCLjnIfOB3UoYJuAbTebC0za/5ZUIncsfDWyM4udDT09PT09PT09PT8//QiytylhalRyJpVUZS6uSf4Gg529iaVV6vBVshtbE5lOc2HZ+GWR1al5wilhalRxZnZoXnMFBzz8YWhOf4sSnOGkxtCbuAU6lzEWlx1vBlluo0wnBOyqWVuXLFz9jcw98yOrUvKBD/nsReS1wAZ/ixGZoTap6g/LjrOAEsbQqPd4KhtbEpzjJLdRJmTVaIpmi4Bh9vINiaVV6vBV8ihOf4sTjrRBLq5IObU7uUtUbGFoTQ2tS1RtsTu7SCZ/ixHYtcIH7V64SXgoSXgqSHR+SHKOPd5ShNWkxtCadOlgZloQCpMwaVb1BVW+QMmsQCnCwMiw5RW6hTm6hjqE1sW1O7kJexxa6uUd2fEjSRnCMNXVCciQ6/53gnGJpVXJodWpecA6xtCo5tDo1L+iS/15EfvTgfWy5hTrlx1nBGfYfDsqLn92GvI7th6+a2MLTTt4IBbAePeHS5xXBCbLjQ/L+latsTu7SYhVMWvIlF5FMUXCkjzZr6oTk0K3oXS57+llTJyTnoMxFpcdbweOtoMxFJV1S5qLS463g8VZQ5qKSLhysDMuUWSO3UCe3UCdl1jhYGZacIV9yYT16Qkt4KUh4KUiL9egJ+ZKLs2xO7tJiFUxO00ebC8ZzbkXvUt7Q8QcDXPb0s6ZOSLpU1Ru0VPUG3arqDVqqeoNO7T8clIQChKedpMwaKbNGeNoJoQD7DwclHbAKJu2sgkm3rIJJu9DNPbLjQ5Ij79HmU9+12d+dF/EHA5Q3dPzBALu7f/JJ4Prs4x83E3So9tPzhMs/OGv+esDGF98LunCwMixvPv2DL0sOXqw3SZk1vp67MZv45rcEZ7jjHpjtr5RxXL+E98EtvB/3w9YO1reb5Esulo3tBCdYNrYTd9wDszc8DV5v7eNgD7Z2sAomtnzJRSRTFJxi2dhO3N77YLa/8ZKTbO1cZNnYTnCojzaRTFG8evqM8oaOPxigvKHjDwbolpaMy6reoKo30JJxSResgkl42knKrJEya4SnnVgFk044RkewWQWTFqtgYnOMjvBfiGSKIl9y0Yk+jhHJFMWrp88ob+j4gwHKGzrd0JJxSRstGZd0aN09hlUwCS8FCS8FsQom6+4xOqHMLIp19xhv5HXI69jW3WMoM4uCMzhGR8iXXLTLl1w4RkfoVCRTFPmSi3zJxWkEp8iOD0mORDJFQRe0ZFzyFmVmUdAFLRmXvEWZWRR0QUvGJW9RZhYFHdKScckxlJlFwTlkx4ckbSKZouDQX4iewfUKrpSDAAAAAElFTkSuQmCC","w":16,"h":20,"frames":6},"crop_kale":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAUCAYAAAByKzjvAAADVElEQVR4Ae3BMWojSRSA4b/MlhJdQOGyUBgHuoBBL3JQ0cBEcwOD0QE6cOygDiAMgw/SwURPMOFM0JNVorBzoaRLUKsCNzReeS0LPCxLfx+j0Wg0Go1Go9FoNPq9DKOjJPjMgFa14R0k+MyAVrXhCMPoHyT47MQyFDWhVW04gQSfnViGoia0qg0vGP7HJPjMgVa14Q0SfGbAiSVqonBiiZoY0qo2DEjwmQEnlqiJwoklamJIq9pwYPgPk+AzB1rVhhNJ8JlnTixF1ERPq9rwggSfnViKqIm26Vgsp0RNFE4s69WO2XyCE0sRNaFVbTiQ4LMTSxE10TYdi+WUqInCiWW92jGbT3BiKaImtKrNBR9Igs8SfOYMEnx2YnFikeAzJ5DgsxOLE8tLTixOLBJ85oioicKJpYia6EVNFE4sRdTES1EThRNLETXRi5oonFiKqIneBR9Egs9OLE4sEnzmHST47MQSNRE14cQiwWdOEDVRtE1Hr206iqiJY7SqDQdRE1ETr4maiJootKoNz7SqDQdRE1ETr4maiJootKoNB3/wiuub28yz79++Gs4QNXGuqAknliJq4hRa1UaCz+vVjiJqorde7ZjNJ2hVG17RNh1DTixF1ETRNh3FbD7hmLbpGHJiKaImirbpKGbzCb0Ljri+uc1/ur/4/OUTn7984vrmNnMGJxYnlnM4sfScWE4hwWcnlsVyStE2HW3TUSyWU5xYJPjMCxJ8dmJZLKf02qaj1zYdvcVyihOLBJ95JsFnJ5bFckqvbTp6bdPRWyynOLFI8JmDCz5I23T02qbjPdqmo4iaiJoo2qbjVFETxXazZ7vZU0RNvCVqYjafUGw3e6Imoia2mz3FbD4hauI1UROz+YRiu9kTNRE1sd3sKWbzCVETQxf8i58/fvHzxy/O8XR1yXq1Y73a8XR1yXs8XV2yXu3orVc7nq4ueYtWtYmaKLabPb3tZk8RNaFVbXhBq9pETRRt07Hd7CnapqNtOortZk/bdBRRE1rVhmda1SZqomibju1mT9E2HW3TUWw3e9qmo4ia0Ko2HBhecX1zm3n2/dtXwxn04S5zIPePhnfSh7vMgNw/Gt5BH+4yA3L/aHiDPtxlTiD3j4Y3SPCZAa1qwxF/A0/5t+UN02waAAAAAElFTkSuQmCC","w":16,"h":20,"frames":6},"crop_potato":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAUCAYAAAByKzjvAAAEK0lEQVR4Ae3BPUwbZwAG4PfDcJADN4Mrc6kAx4m4qFWwTQYEqFylYyBygxjabKewVK2sDB0YWe6keMjAiFgiVUhWO3UiMCDlhkskt5mC8XQnxXEU6cCy3cHHATbwlYtw5SJ+7qLQRsjPg6ampqampqb/B0HTP3hJpGigp1SCC+ZD03u8JFJugMHg/Q6EhhiEhhhs7fbIpUxOwQVqRdO/GFoN/UIb6nhJpGigp1SCj8iHpvdKmZzSzvXJVmEf1R2Ccv4AVmEfYw87ERpiEBpiUN0haOf65FImp+AjacUlxEsixRE9pRK4pKdUgkOVrwWKQ/2TLOoMrYaLQHDJ8JJIuQEG/UIbHM/nt6CnVAKPeEmk3ACDuo31Khx6SiU4hxqPUjQQV9YITtGKS8rQaqjjJZHikJ5SCTwylmw4zBcagQszwgi9dpuFwx+LwqECVFxZIziBD58gXhJpIBKWA5GwXMrkFHhQyuSUdq5PNl/uoqzXEBrrwOD9DlR3CNq5PrmUySk4hxqP0qdXWFiFffxy8Bfmn70kcGFGGKHfdtmwCjb8QRblTA7+m70IRG7g3rYtLxqbCo7x4RPDSyLlBhgM3u9AaIjB1m6PXMrkFHhQyuQU621e+UK4KXd1+1DOH8BhFfZRyuQUnGFGGKHf3LmKH8dimO7nwBxU0OHj5HT+nYJzjIZ6ZZ6pweEPsqhu1YBKGe0ch0DkBu5t2/KisamggQ+nUONROt3PydP9nLxobCr4AJO//UxvfT8s67//qcClQCQsd3X7UM4foJw/gFXYRyASlgORsFzK5BS4pMaj9OkVFl3dPhhLNmpVCj2lEpxhRhihPwyzcLRzHBzVjU3c6WlDh4+T0/l3Cs4wGuqVeaYGhz/Igulsg6OcyQGVMvxBFt9d/UxeNDYVHGnBCdR4lPLSOHhpHLw0DjUepfBIeHyXBq+/RvD6awiP71K4pKdUsrFehbFkw1iywQ0wGHvYCW6AAS+JFC7MCCP02u3PocZj+LX3K6ijbZh8uw03zGwRDnM1DXM1DYeZLcIrM1uEGy04Q+XVGiqv1sBL41DjUYr/iJ5SiflCIzhiaDV8CHM1DXM1Da/MbBF1ZrYIt+a0NFm2WNSZ2SIcXUEWp2mBC0xkGF492gvj+fwWns9v4dFeGB9qY70KY8nGxnoVekolcMnMFlFnZovwqlKwUSnY8GpOS5Nli0WdmS3CzBZhZotwLFssGrXgBOLKGtFTz+CPRRF48BO80pIJikOVN3uovNmDQ0smKDzQkgmKBk++vAW3piZicFQKNioFG46piRjOMzURw7LF4rhli8XURAxuzWlpsmyxOO7JHzbmtDRBA4IzqPEoxRFxZY3AAy2ZoGggzC4QeKQlExRHhNkFAg+0ZIKigTC7QOCClkxQnECYXSDwaEYYoWgwp6UJjvkbME2uJe0UxWkAAAAASUVORK5CYII=","w":16,"h":20,"frames":6},"crop_pumpkin":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAUCAYAAAByKzjvAAAFXUlEQVR4Ae3BQWhb9wHA4d+TkEOfJVRonbhLlggzy3Vj15kTQjzwcxAskS2Md8htKm1HcQk2uDBy8kU6mCGKj8aHihWDwQx2K29gU2TzvPGU0R0miXnWC25iMiLbraiqJ62SGv+7BxYTqmzZ2Q6l6PtoaWlpaWlpaWlp+S9v0Ce8QZ/gBXmDPuEN+gRN2Gn5Hm/QJ4an2rlys41C6VLoy8TnYc7AG/SJ4al2rtxso1C6FPoy8XmYY9hoacjQKliGp9rxBn2CMzK0CpbhqXa8QZ/gGDZ+5F5/f1S8/v6o4AzSyzEpkyxjaBVeRHo5JmWSZQytQjN2fuSuTV4N3fyVzNficuiLvz0K00RsbEC8+lpXKO124LxgJ/vkEHP/Oe+83Bmau/pKaMnYC3OC2NiAePW1rlDa7cB5wU72ySHm/nPeebkzNHf1ldCSsRemhp0fMCXiF1d++bPQk08fhTmjhxPXxeWfdof+UrZTfg5fP3vOny65Qx9tPwtzjNjYgBjqy/PSVzakA4mLRomLRome3Ld8+EEFz6CdkXxHaMnYC9NAbGxADPXleekrG9KBxEWjxEWjRE/uWz78oIJn0M5IviO0ZOyFOWLnB0qJ+EW34uDe+ChfuEXoyaePwpzSw4nrYqA3hzNno31PwvOPb/jDrwv85Od2Av++EPpo+1mYOrGxATHUl8fydP8cbw9mGb13jju3Drlz65CNaAXPoB3PoJ2RfEdoydgLUyM2NiCG+vJYnu6f4+3BLKP3znHn1iF3bh2yEa3gGbTjGbQzku8ILRl7Yf7DRgNKxC+UiF8oEb/gBYyvzIjxlRnBkfGVGTG+MiM4JSXiF5lkGct6Yo1MsowS8QtO4eHEoBjozWGRgAc3/sXsdJnPPi5jufFuG3+duC44hp5yMdSXx1KKZ6m6/Z6DjWiFZvSUi6G+PJZSPEvV7fccbEQr1LNRxxv0iT8GfkO34qBbcaBE/IIzUCJ+cd6zw3nPDuMrM2J8ZUac9+xw3rODEvELmvAGfWJyOkBPoB9Dq2BoFXoC/UxOB/AGfYKmJCx/33LzZm+OqhvvtvHZx2X+V6V4lv8nGw3cU39PVbfiQIn4BaeUSZapyu1uk9vdpiqTLHMa64k1LJPTASanA1jWE2s0o0T84sEvOqhXjh9Qjh8ggHL8AMH3qaZMI6V4lnqqKXNapXiWWqV4llo2jmFoFaq6FQdKxC84hfRyTNpcKLC5UKBqc6HA5kKB9HJM4hQ2FwrkdrdZT6yxnlgjt7tNM0rEL7oVB92KgzefXuYtl5vElpuqxJabtaKTxD/drBWdNKKnXKimjJ5yUasUz7IRraCaMnrKRSOqKWNRTRk95aJWKZ5lI1pBNWUsqilTZaNOejkmGZ8UsRhahReRXo5J0d4eMskymWSZaG8P6eWYRBPeoE8MT7XT2d9GJllm/3EX+4+7sOw/7iLa20MzmwsFOvvb6OxvI+hyk9hyk9hys1p0clc2WS04Gbn9BvXmNV1STZmAs4hqyugpF3rKhZ5yoadcqKZMwFlENWXmNV2iAT3lIuAsopoyesqFnnKhp1zoKReqKRNwFtFTLmrZaODZnzXJ+KSIxdAq/M71Fmehzd0X1NHm7gtOwdAqVOV2t8ntbpNJlnmwU0aZXZQ4weZCgc7+NmqtFpysFpxYVotORm6/gTK7KNHAxN1rqKaMRTVlqlRTxqKaMhN3r9HIvKZLqimjmjIW1ZSpUk0Zi2rKqKbMvKZLHJE4gTfoExxJL8ckzkCbuy+oocwuSjThDfoER6K9PdRSZhclTuAN+gR10ssxiTPS5u4LTqDMLkqc4LfKkOAE85ouUeM7n6tJJMOXnvsAAAAASUVORK5CYII=","w":16,"h":20,"frames":6},"crop_radish":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAUCAYAAAByKzjvAAAEO0lEQVR4Ae3BQUhbdxzA8e/PxYwaZNhOSHcYesgrhWXtCIiW+gZv7DLoYNfxSC9exGPpLu6goIcePIqXnMKjlx5KW1roYe/wV2YZlLDabuQ9hsIYEa21xWohL8t/edWU1EZ98bCNks+Htra2tra2tv+G0PaGYVuaBp7jCjWGbWkaeI4rNGHYlqaB57hCjWFbmgae4wp7hLbXDNvSyXSclNlJ3fzsNqHhsQR1vgpYXSrjOa7QwLAtnUzHSZmd1M3PbhMaHktQ56uA1aUynuMKNR20vcVXAXXJdJxkOk6drwKO4quAumQ6TjIdp85XAft10PYOXwWEUmYnKbOTkK8CovJVQChldpIyOwn5KqAZoe0Nw7b01kqF1KUumvHv7NDdF8NzXKEJw7b01kqF1KUumvHv7NDdF8NzXGGP8B4ybEtT4zmuUGPYlqbGc1whgtMXTU1Nd1+M0NZKhVBpQQkRnL5oampSl7oI+Xd2CJUWlLCP8J4xbEsPjyUIzc9uExoeSxCan93Gc1whgtMXTd3dFyO0tVKhtKCECPJGRlu9PYS+/zZG6PrtCiF3fZOs91Bo0MF7yFcBoWQ6TjIdJ+SrgKjyRkZfW9um7traNnkjozlC3shoq7eHuuu3K1y/XSF08sIAVm8PeSOjafAB/0OGbelTn/dPbDxanqTGsC196vP+iY1Hy5McYePR8uSHyU8nntx4RVDWvFz7myc3XhGUNZ7jCkfIGxlt9fbQnzjB5efC5edC5usvST57xvkTPRM3N0qTHOC7U59M9CdO0MyrP//i5IUBfiv+wc2N0iR7Yhzg9x++0rkHO4Rm1KLQIsO2NA08xxUiMGxLD48l2GVpaobHEuyytOe4whE8x5W8kdFTfR8Rura2TXbhoXBMz37+hZMXBuDWfQ6TkyqsbxKyento5K5vwq375KRKoxhNuN+c093nzzHCr+wa0jNqUYjIsC09PJbgbZb2HFeIwFcBKbOTZDpOna8CosobGW319mAts6u3hzwZnfUeCkfISRXWN3nHrfvkpEpU7vomUXTQxN2XXXjOT9SNDHZxxRzStMBXAXW+CojKc1xZXSpz7+oLVpfKrC6VuXf1BatLZTzHFY7h5IUB/g2qWJCcVDlITqqoYkFoEOMQpcdPOf3Zx7TKc1zBtvTqUpk6z3GFiDzHFV4zNTWlBSWlBSLLSRXWN3nj1n1yUiWKqewgP+YfMKI7aJSTKlPZQczxAodRxYJw5gtNzYjuIJSTKiFVLAj7dNDEjFqUuy+7CJUeP+U4cmfPsLVSYWulQu7sGVqlpkc1e9T0qKYFU9lB9pvKDhKFOT4nU9lB9pvKDmKOzwkRqGJBVLEgOamSkyqqWBBVLAhNCIe4Yg5p9syoRaFFanpUU2OOzwnHoKZHNTXm+JzQIjU9qmlgjs8JLVDTo5oG5vic0KIr5pCmZkYtCgf4B65MtHOhvJpnAAAAAElFTkSuQmCC","w":16,"h":20,"frames":6},"crop_parsnip":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAUCAYAAAByKzjvAAAEZUlEQVR4Ae3B0WsTdwAH8O+vjTfwsAwCWx4K0gdPBBN9kl7rHXhs+OAG/gGHjCGs5R4k5MGHPuwi9EUIlUJshe5FDxxkIAwU95Bj/jK4+NZczNC7h+ioeDNkCDF1XtTf7rAZNcYmkW2M7T4fRCKRSCQSifwvEUTeIqgKQ8AxTIKAoCoMAccwCQYQVIVhi2OYBAMQRN4gqAqTNB6hUr6NkKTxCJXybTiGSfAOgqowSePRVcq34RgmwQ7GEPmToCpM0nh0JZIcEkkOXZLGQ1AVhj4EVWHYxqUdDCOGyFtc2oFX9ZFIcgiV8m0kkhz2ybvQj6AqTNJ4hFzaQcir+nAMk2AAgsgbBFVhCCSSHLbzqj5CjmES9BBUhUkaj5BLOwh5VR+hz395hlCOWgR9jCHyBscwyXJ8Al7VR5dX9bEcn4BjmAQ7cGkHXtWHV/UhaTwSSQ5nL6Zx9mIaGVlk6GMc/0GCqrB4akpv2vUsAoKqsHhqSm/a9SwGuHnmJDt+4RoOfrOEb1sf4Onjl1j9rYlPrvwI8UlFN27fzaJH065n288n9aePX8IxTBJPTen+7wTfnfgSXUdPiHh1Z0O3Hmxksc04/oUEVWHx1JTetOtZBARVYfHUlN6061kMIKgKkzQee49waD+f1OOpKV3SeOw9wqH9fFJv2vUs3uHmmZPs+IVraNQK+OhTGUe+/wGfPXuGg+cXsNn4GalT5yA+qejG7btZ9Gja9WzTrmcR+OLDhP51fBwx8gIvf93A+MeTCB09IeLVnQ3derCRxZYYdpCRRYZAjloEIxJUhWEbxzAJhiCoCpM0Hq8pDAFJ4/GawhzDJBiCSztIJDmEXNrBPnkXBuHcOh5ezYBLTSN07Po6Qo1aAaGHVzPg3DqG1VqvIH7qK/h2GVxqGv2M4R0yssjScyLScyIyssgwAkFVmKTxkDQeksZD0ngIqsIwApd2kEhySCQ5uLSDYTmGSUr5Nryqjy6v6qOUb8MxTIIh+HYZvXy7jGHlqEXWypsINS9fApeahm+XEUrPicjIIsOWMfSRkUWWnhPRWq+gtV5Bek5ERhYZRuTSDlzawSgcwySlfBte1UeXV/VRyrfhGCbBEJbjE7h3pQj91iPotx7h3pUiluMTGES5USGOUUTIt8to1Apo1Arw7TJCjlGEcqNCMIQctchaeROh5uVLCPl2Gb1i+Bs4hkkAhWGLV/XhGCbBkBzDJAi0jsoMgUc/UYIRcG4djVoBx66vI9SoFcC5dfzTctQigMgQOI0K9hw+hF5j6CNHLbK0amHP4UPYc/gQllYt5KhFMIK1A/vRuv8CrfsvsHZgP0ZFF+cZttDFeYYRxGZn4NtlNGoFNGoF+HYZsdkZDCM2OwPHKKKXYxQRm53BqHLUIjlqkbXyJpZWLSytWjg9vRsZWWQIEOwgI4sMgRy1CN4DXZxnCMgLKwTvgS7OMwTkhRWCEdHFeYZt5IUVgiHRxXmGPuSFFYK/QEYW2enp3Thwvkj+AOD34zzjlpDMAAAAAElFTkSuQmCC","w":16,"h":20,"frames":6},"crop_sunflower":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAUCAYAAAByKzjvAAAGm0lEQVR4Ae3BX2gb9wHA8e8vOssC20XMQ5Eg2ElBzsLmiIHptoDP6MhAFbQhLGMtmD7kwVhE0JdRm4YW3YPbiO5hZepiTCgE1LVjBdOVGT+Y07hAAqmT1VICqTQinGREOaokaxSi6Y9/s4ouUzXFf6BjW/Dnw47/LsGOjoxwQNKkLawI/kMEO77BCAck64Lzg9hSR1dp0BZWBN8yBzseM8IBGUzcx3ejiqJ5sPmu3sL/5iPGcntjZ3N3dL5Fgh1fM8IBGUzcx1ZbFihBD7WUhTIisaWibrSFFcEmjHBA0qQtrAieQGHHY+VZB67JOrVlwXTCBwnW+TgVvY0yIinPOtiMEQ5I1gXnB7EZR5Gs0xZWBG0c7MAIB2RwfhBF81BLWUwnfLRautiHtqeEMzLMvpfcjF12xc7m7ui0McIBGUzcx3ejiqJ5sPmu3sL/5iPGcntjZ3N3dFrs4ik1NK7JoXFNDo1rkm1Qgh46UYIeNmKEAzKYuE+Da7JO7ZM0fFWg9kka12SdhmDiPkY4IGmxi6fQ0LgmR0/0MHqih9ETPQyNa5ItqqUsOqmlLDZTnnXQUFsWTCd8/PJnDqYTPmrLgobyrIN2Dp4yQ+Oa9A476R90YKuUBd3egVgxndfp4Gzujj522RXzXb2F88U1tD0lli72YTsVvY0yIim/8yXnfvMIbWFF0MIIB2RwfhBF81BLWUwnfLRautiHtqeEMzLMvpfcjF12xc7m7uisU3hK5cwqfrWLnFllq1yTdRqUEcmp6G2UoIdaykIZkTS4JusQZUNK0AMJ/o0S9NDJLv5PqPGQVOMhyTbkzCpbpS2siFTUTUN51oFy5CA840U5cpDyrIOGVNSNtrAi2EAtZdFJLWXRieB/iBoPSZrMqUVBkxoPSb/aRUPOrGJOLQo2MDSuSdZ5h50UMhUaRk/00JAzq5hTi4InMMIBybrg/CC21NFVGj54Y4CcWcWcWhS0McIB+ZMfPMA1Wae2LJhO+LCdit5GGZGUZx1cuNKHtrAiaFLo4NDhCUnT+aU5wTa88OGrkqZPX35XsO6FD1+VNH368ruCDtR4SPrVLh6Lh6Q5tSjUeEj61S5yZpWGQqbCk6jxkKSpkKlQyFRoGD3RQ86s0lDIVHgSNR6SMZqOrmL74I0BcmYVzCqFTIUncU3WaVBGJKeit1GCHmopC2VE0uCarEOUb3DQ5tDhCbnX/yzBn47yyvgRsvly7Ob1SzpboMZDciDwFT3ue/S477Hn8POx/cd+HPPsvU6P+x497nv0DT0bW136q06bbu9ArFIW3F1do3/Qwd3VNbq9A7He3Q7urq5hK1l1ium8Ths1HpJ+tYv+QQf9gw5ufFbFO+ykZNWplAW2klWnmM7rtFHjIelXu+gfdNA/6OC3VxSWn3Pz0YNuKmWBrWTVKabzOi3UeEj+7ZXv0Df9D/aFy5RnHTgjw9Ddy67v7ab8zpcoI5JU1I22sCJoodDBxPFjzL3/MQ1vvf0ar4M8vzQn2EQhU8GvdmH7+40vaPDs7cJWyFTYTM6s0qqQqWDLJg1BB4VMBZtf7aJVIVPBlk0agg4KmQo2v9pFq0Kmgi2bNARtCpkKDbExH0T5WpB/uXClD6IQG/OhjvmkObUoaFLo4LPPrzFx/Bhz739Mw1tvv8brIM8vzQk2kE0aAjRJk3fYScO59x5iyyYNQQfZpCEY1yQtvMNOCpkK2aQh2IacWcU77MSWTRqCbciZVbzDTmzZpCHYotiYj0KmwuzRVWyxMR9+tQs/TfGQNKcWBesctLl5/ZL+8FFv7Jnv9vPi8yp/Wvgza2IX165+wc3rl3Q2UUzn9WI6r8//IhT73VWLklXnzIH9/OrXfxDFdF5nA8V0Xi+m83oxndf7D+6L9e52ULLqFNN5nU0U03m92zsQK1l1SladklWnd7eDklWnmM7rbKKYzuvd3oFYyapTsuqUrDq9ux2UrDrFdF5nA8V0Xu/2DsRKVp2SVSebNMSFH30/tvycm48edPPDn7toyJlV7q6uUchUKKbzOut20cH5pTkx//s/8tnn15g4foy/XL7CdpgzEUkbcyYi2SJzJiJpYc5EJFuQTRoimzTEmQP7aWXORCRbkE0aIps0xJkD+7GdObCfrcgmDZFNGiKbNARtzr33kJxZpRPBBg4dnpA0nV+aE2yDORORtFBPnhZsgzkTkTSpJ08LtsmciUia1JOnBdtkzkQkTerJ04JtGhrXpHfYSSFTIZs0xNC4JmnKJg1B0z8BNuvJaHRd0BMAAAAASUVORK5CYII=","w":16,"h":20,"frames":6},"crop_wheat":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAUCAYAAAByKzjvAAAFpklEQVR4Ae3BsWsbWQLA4d/TvDESAkOWLBiSxoLRshDtuXitHkRg0DbZ8lgQpBWoV7HiwCJOIZFWaIoFc8TdFvcfqBiR3WY6X+UBGZbc4mpzjdDgGc07v8MmgyPJ3rtwhJy/j3v37t27939LcO/fFt2K4UppOBOLbsVwpTSciUW3YrhSGs4EH4ngHotuxRTbS67FvkOxveRa7DsU20uuxb5DaTgTfASSz0S11TBcOT2eiGqrYbhyejwR1VbDcOX0eCK4IQ0FUhnSUGCloUAqQxoKrDQUSGVIQ8HHJPkMVFsNU++Uea9h6p0y7zVMvVPmvYY5PZ4IcqQypKFAKkMaglSGNBRIZUhDkMqQhgKpDGnIBxbdiiGnNJwJ7qDAZyIKEqwoSLCiIMGKggQrChKsKEhYJQ0FUhli38GKfQepDLHvYMW+g1SGNBTctOhWTLG9pNheIlVGsb1k0a0Y7qDAZ8LTLlGQ4GkXy9MuUZDgaRfL0y5RkOBpl1WkMsS+Q7G9pNheUmwviX2HYntJsb2k2F4S+w5SGe5q0a0YblHgE1JtNQw51VbDkFNtNQxrREGCp12moznWdDTH0y7T0RxrOprjaZcoSLipNJyJ2Hew0lBgpaHASkOBlYYCK/YdSsOZ4IY0FKSh4JpUGcX2kkW3YtigwCei2mqYeqdMtdUwXKq2GqbeKVNtNQyXqq2GqXfKVFsNwwqedpmO5tQ7ZeqdMvVOmeloTr1Tpt4pU++UmY7meNplFakyLKkMaSiQymBJZUhDgVQGS6qMVaQySGWQynDTolsxrFHgE1RtNQw51VbDsMHp8URMR3OsKEiwoiDBioIEKwoSrOlozunxRLBGGgqkMqShwEpDgVSGNBSsUxrOROw7xL5DGgrSUHBNqoxie8miWzGsUOAj0oOmIUcPmoYcPWgaNoiCBKveKWNFQYJV75SxoiBhnZ3aFpanXaIgwdMulqddoiDB0y7WTm2LTaQypKFAKoMllSENBVIZNikNZ4JLUhmkMkhluIsCayy6FbPoVsyiWzHcgR40jadd9KBpuKQHTeNpFz1oGi7pQdN42kUPmoY1PO2S52mXPE+73CYKEjztEgUJVhQkeNolChJuU3zxhNh3kN99Q+w7FF88IfYd5HffEPsOxRdP2KQ0nInYd4h9hzQUpKHgNgVWWHQrhktSZUiVsehWDH+AHjQNOXrQNNxip7bFtShIyIuChGs7tS028bRLFCR42sXytEsUJHja5S6kyrCkyrCkyrCkyriL0nAmuCSVQSqDVAYe/Yl1CqwhVUYaFrCkylh0K4Y78rRLnqdd/ghPu+R52uUu6p0y09EcT7tMR3PqnTLT0RxPu0xHc+qdMv8LpeFMxL5D7DvEvkP8l78jVcaiWzHcINlAqow0LCBVxm3OTy6wzk8u8LTL+ckF1vnJBZ52OT+5wDo/uWCVw3QXJhDVzrB2als8nzwmqp1h7dS2eD55jKX50GG6y195y05tC2untoW1U9vC2qltYR2mu2g+9Ev0LXX+wW1+ib4FxtymNJwJchbdipEqY9GtmNJwJrhSYIXScCbSsIAlVcZd/Pj1Vxymu+QdprvkHaa7/Pj1V6yie2Ohe2NBju6NBTm6Nxa6NxasoHtj8XzymLznk8fkPZ88RvfGghV0byymrx6RN331iLzpq0fo3ljwHygNZyINC0iVsehWDFcc1nj55l3/h90vDrLfBNlvAuvlm3d91jiahP2jSdj/25+bB3tn2zz78iHWsy8fsne2zbMvH6J7Y3E0Cfts8Prp/sHe2TaN7AFHk7D/+un+wd7ZNo3sAUeTsM8GR5Ow//rp/sHe2TaN7AG6Nxavn+4f7J1t08geoHtjwQZHk7C/v/f9wa8/b/P2dw/dG4v9ve8Pfv15m7e/e+jeWPBfePnmXf+H3S8OpMp48dM/+1z6F2mQWWQV8Z+DAAAAAElFTkSuQmCC","w":16,"h":20,"frames":6},"soil":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAMCAYAAABr5z2BAAABNUlEQVR4AaXBoW4bQRCA4X8vdqTbKCBkpYF3j9HIoAoo9msYGRsFGQf5NYICjP0C4ZV24UhDGjRLKm3PUsDJShqQ7wutNS4dt+vGx8Kvp2fmFlw4btctJmEceuZyqbhpO27X4fp34efLK2cL3p32m+amxCSMQ8+lcejJCG7aFvc/OO03YbU70DE57TfNTYlJGIeez4xDT0yCmzJpp/2Gq4dra25KTMLZ3d2S//nz9pflzS1uyvLm9rFjZhx6vjIOPXMd39QBISbBTcml8pVcKm5KTMIkdEzcNMQkuCm5VD6TS8VNiUlw0+CmdKvdgZgENw0xCW5KLpVcKrlUcqnkUsml4qbEJLhp4F3HZLU7EJPgpiEmwU1xU9wUN8VNcVNiEtw0MLPggpuGmKTxscAkJmG1O3D2DzbDlo/VIxfSAAAAAElFTkSuQmCC","w":16,"h":12,"frames":1},"soil_wet":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAMCAYAAABr5z2BAAABhUlEQVR4AW3BMW/TQBiA4fdCWslXsp50YqjsOXsEKANioGv/BWQKayYWspYpyr9gYuhKhgp1YWAC6Twg+tFvz+dKDTpsqYNl9Xlczpmhy+V55nHuzafP9I0ZuFyeZx8iVVnQl+oGU8mXy3N3/Kvm1ZfvdMY82K0X2VTwIVKVBRfbK/rev31OImIqefzyBbv1ws1XG0a0dutFNhV8iFRlwcX2iqGL7RVVWeBDxFRo5d16wZPXx5pNBR8inT8/f5P+7rm+veNmf+Bmf+Bmf+DZ0zGTf/ccnUw4OplgKhydTD6M6KnKgs717R1D17d3dKqyoG/EwHRWsTo7ZWh1dsp0VjHkvn58RyubCj5EqrKg8+Nbom86q+ikusFU8CHScmNapuJ8iNlUSESqsmA6qxhKdYOp4EPEVByt0Xy1wYeIqTgfIqZCqhtS3ZDqhlQ3pLoh1Q2mgg8RU3E8GNGarzb4EDEV50PEVDAVTAVTwVQwFXyImIqjZ8yAqTgfYuZxjpYPkflqQ+c/MQ61rwO643IAAAAASUVORK5CYII=","w":16,"h":12,"frames":1},"water_tile":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABGdBTUEAALGPC/xhBQAAAXVJREFUeAHtwbGR3AYABMHR1hXCQASXMPOCJw9hwJEyeFpf9+RM9z/8+vc/ojWiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ojaiNqI2ovY6r4dPut8Hn3ReD590vw++03k9fGVEbURtRG1EbURtRG1E7cWHndeD2Xk9fNKI2ojaiNqI2ojaiNqI2ut+H8RrRG1EbURtRG1EbURtRG1EbURtRG1EbURtRG1EbUTtdV4PP9n9Psj3GVEbURtRG1EbURtRG1F78cOd18NX7vfBJ53Xw59sRG1EbURtRG1EbURtRO3FD3e/Dz7pvB7+ZiNqI2ojaiNqI2ojaiNqL37jfh+Y3e+Dr5zXw59sRG1EbURtRG1EbURtRO1/PckfWewuDfMAAAAASUVORK5CYII=","w":128,"h":128,"frames":1},"grass_tile":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAe0lEQVR4AeXBAQEAIAyAME4/UxjWWD4I29x3PmESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESJ3ESt3EeAvbL9rhnAAAAAElFTkSuQmCC","w":64,"h":64,"frames":1},"basket":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAA/ElEQVR4AY3BMUsDMRiA4feOm5JFoYHeYqdeh656CE46xrlLcak/zEnuJ2TUvXSsQzsUdLmhBZGSrDGftNDhkD5PFmPkqDRVpFvWbteIgoPSVPH9+You9y9fEchICk60yx3TeeBUUytEaSra7ZqcpDRV3MwmVD8GsZlNWIwGiNvxI4vRgCSWpiLr94ZxMRog3rbfdHkwl4jr1ScFyf4uIm64oMueyJ8VFCTtcse5CpLpPPA07vGf148dIidpaoXVAWF1wOqAsDpgdUA0tULkHDivsDognFdYHRDOK6wOHOUkziusDgjnFVYHhPMKqwPCeYXI+r0hSeQMTa2yX8GtUWCF2Z4dAAAAAElFTkSuQmCC","w":12,"h":12,"frames":1},"plant":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAALCAYAAABGbhwYAAAAtklEQVR4AY3BsWnEMBSA4f+JeIMY4vqw0BReQGicm+LqTCK0gLOEsEntwnUqF+8kcuJMSHHfJ6pKNfRWeZJtXzgTVWXorfroaFLIFEKx7QuVGXqrPjqqdT6ofHQUyonhRYYXGUBSyJylkHnQobdU8vE+8qA+OlLIVD46qhQyhZhtX2i+Pn+o7PXCOh+s84GPjkINxbYvNPZ6YZw6xqljnDoawx/L7ZsUMk0KmULe+J+kkJVfQnEH5lc/H+NujuEAAAAASUVORK5CYII=","w":10,"h":11,"frames":1},"seed":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAAKCAYAAABi8KSDAAAA+UlEQVR4AW3BsUrEMBgH8P8XD+SCiLsvcI9QM5jFSbi3KPgAZvfcP9xcpJNv4NDFRbOEzpLVUeMQboqdCrHBFor4+1HOGUarjAlbRxgZrTImbB0ZrUDX52e5riRmTdejqCuJWdP1YOtI4I+6kvhIA5bqSsJolQVGwUcEHzH7/B4QfETwEUuCraM2SRTBR1w97VHs3gWK4COargdbRwfp5Rls3e39w+PudU/gyxNsN2tsN2vcvQ34wiHYOjJaQWDh5uIYS6dHK7B1ZLRCscI/go/4JbEkMDJaga2jpusRfETRJgm2joxWmAlMjFZg66hNEm2SYOvIaIWlH3F1aGCDFmkWAAAAAElFTkSuQmCC","w":11,"h":10,"frames":1},"egg":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAALCAYAAABGbhwYAAAA90lEQVR4AW3BsUrDQACA4T9ncHIzEBy6yW0HcuDoUBwa8EmSR3ByytzJju46dCq4OYR2krNwuBxuGUprVjuVnDlooJR+X+S9Z/0+Ic1yqrLwHLh7fI7YE3TSLKcqCy+1QmqF1AqpFVVZePYEnaosvNSKQAwS0iwnkFpRlYWnE3OkrRvW9YRjZ/fnGy+1opdmORfXt/z9fBJcXqV8vb48CQ6IQUJPDBIOxdvNClD0fr/fOEXQccYStHVDr60bAmcs280KwZ4zlqCtG9q6IXDG0hOj8TTazRcEzlicsThjccYS7OYLRuNpFNMZzpbRx8ON54ThbBnR+QfWeV3K2VyrPgAAAABJRU5ErkJggg==","w":10,"h":11,"frames":1},"milk":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAMCAYAAABbayygAAAA5ElEQVR4AY3BMUvDQBiA4fdiHNq/4JZuxcWsdtTJUSeziVRMVqFruhlwyFQQHOzQXUQnZ8mWIpSCHBw3SKnQvZN8XpyiFMnzKBGhEsWZsMFkNFA4Hk4UZ5InAVYbrDZYbbDakCcBUZwJjk/NQ37AfB1S6bZK6rbSNOX4qDfsp0/p59cOi+WKxXLF28c294/vTEYDhePhRHEm/bMT/toLd4niTHDU6eW15EnAfB1S122VVMZFm2k5w8cZF22uzjv81uFH8UzFoyGPhjwa8q02VG7u2GhazrDaoESE/cML4R+vL7fqG24IUztVNvkHAAAAAElFTkSuQmCC","w":10,"h":12,"frames":1},"fish":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAYAAACprHcmAAABG0lEQVR4AW3BMWvCQBgG4PdLp2ZsoJMuVS6UZtY9NJNCwaVbCw5CCs3orF2EjukQkO7dCg6dDpwd7HZQLvUneMEpHb96oHCDz0PMjDBKGA6tJOEEEje3XGYFXCJPoZUkmm/AozaOPByIPAWP2rDKrEAYJcyjNlweDrSScJVZgTBKGI6z4PJqYrp9TL8rvL284/z3B3/iGpbp9vHxeD95fnqYYs/TSpLIU1h+EMMPYjRWO5xCzAwrjBIuswIXX5+wqt4AlshTHHnYo/kGWkkSeYqqN0DVG8BqrHbYthLUnRnqzgzEzHCFUcI42LYS+EGM2ixhFmPy4AjuXqGVJK0kYc8PYtRmCbMYU3O4hgeHH8RoDtdwmcWYmsM1rH90mGg77ReGbgAAAABJRU5ErkJggg==","w":11,"h":11,"frames":1},"itemdisc":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAATCAYAAACdkl3yAAABvklEQVR4Aa3BL4jbUADA4d9Ly2A2N/YnKixjM1MjahxETZ28urjCKqLOxeZkoOKpmNRmMFO1qKqIg4NmW0UZLSMiJmImchyDveWxlpWj3Z3o9wmlFPv4QazYT2RJyG19bvGDWNHJkpB9/CBWfhDTEXSyJEQz2OEHsRoNB2RJyCFZEjIaDugodvSiKMIPYqb5lRoNB3iug1aUFXXTUjctddNSNy1102JbJrZl8ujJMz5//RZN86vL87NTDP5So+EAz3XQirLikKKs0DzXYTQc0FF+EGOw4bkOWlFW3KUoKzTPddjqff/xUGVJiFaUFfdVNy22ZXJ+dso0v4oMjsTgSAyOxOBIejc/iW4enPD2zUtsy6RuWu7Dcx208STn08cPGGwUZYXmuQ538VwHrSgrtnonj59ffrm+jp7aL/j1u4dtmdiWSd207OO5DlpRVswXK1Ip6Yg+O+aLFZrnOniuwyFFWTFfrNhlrJczOiKVEm2+WDGe5BwynuTMFyu0VEo6Yr2c0ecfkUqp3l9coI0nOf+TSklHsGHQWS9nbIhUSlIpOSSVklRKOoLOejlDE0optl69fscOxX6CjfVyxtYfHPGtBT0IQXYAAAAASUVORK5CYII=","w":18,"h":19,"frames":1},"sandtimer":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAALCAYAAABCm8wlAAAAwElEQVR4AX3BoU4DQRSG0e+SVRjMbTJbUdNMRQOukqSpnDfYUFfBQxFS3TdY2QpEA5IqgqroCmowa39m3ZJQzrHgUfyjINuuRjSHM33lrbNYHynInvctcM0v+5aOBY9k2tQ1fVVKLKduV2TLqVuVEvPZmPlsTJUSm7o2OpIIHpFE8KjgUcEju7dPgkdMEp1yMNHp/Z7O8O6FzJqvD0wS5WCi09MNfcPHbzKz4FHb1Yi/LNZHCrLmcOaSguzhteWSH5EMPHgXwbayAAAAAElFTkSuQmCC","w":8,"h":11,"frames":1},"stopwatch":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAMCAYAAABbayygAAABS0lEQVR4AW3BMUsCYQCA4ffUlqMtjzoanLqhJYiQkkBoaGlUh3KIFPwFYUNBJ9TQFkRBVkLDnUE6NIibW0uNV0JuEWZwFyHVLQ5fJykc0fNIQgj8VEUT/JI6douhAD6qoomrep2reh2PUBWNoRB/FEsV/hPUdZ3NeIz1/IEwozKz3Qdmuw8kJkeotnv6W61cWN7IEsJjNB1hRmXOI6vkMkn6iqUKJmXW7hxhKJoUPD02hRmVOY+sYpxssTAzz9HhLomVRXZuu+yPPlFt9/QAA7lMEj9V0chlkgwF8NS+ZPxURaNjt+irfcn0hRgolirE57bo2C2GiqUKKr+Co/JYwbJdPcYLl/cO4XGV59cPtvfOUB9vMJoOHkmaCE+Rng5jNB2Rng7jZzQdllJZqXF9QfDz+531/AGegmW7umW7WLaLZbsspbJS4/qCvh9DsHxPx9rbfwAAAABJRU5ErkJggg==","w":10,"h":12,"frames":1},"plan":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAA7ElEQVR4AX3BMWrDMBiA0e838ZI5geQACjpBR19AqGfqJXqD0gsIha51z1AQ9thBgzsV0g4eVAlkAibte5JS4rg/Ja6ELE4Dt8hhp5JxmoW3gUziNHBLQzX2M4Vxmiwd9yduaahU1zL2M4Vxmiwd9yfW5LBTZMk4TTH2M6pr8TaQCZC4EjnsFFUyTlO8PV4ovl4+ME6z8DbQxGmgEm8D3gYWxmmKsZ9ZNGRxGqiElbGfUV3LouEfYz+jupbC20AmDVWcBrL0fLdl8fAa8TbgbSATsg0r58uW+8sPxZkt8E0mVBtWnt4/+UucBn4BKW1VCtM7E04AAAAASUVORK5CYII=","w":12,"h":12,"frames":1},"dirt_patch":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA1CAYAAAADOrgJAAAFi0lEQVR4AdXBzWsb6QHA4d87M3I1UIjfLFGTIGLPWIm8rXaXstS6dB3wZU1qXYwvormVLYhidOihRtAyIiWsj8KF/AMFnXwSLHVxF1JfKuhlt6ZVbHkG6SB3D60U3HaCkfLWBhsGkdj6srN6HkZhfn2RVDFL0IPHC4ouDx4vKAJSxSzz64uMgmAEvnz0kXIe3hF0uXEvTild4FSqmOVl/QXdnOeHauGLrwRDEgxpfn2RXCOs6DKx73HKeXhHcMJ5fqg4cXzfotvTu6/En3/1B4YhGEKqmOUXf6mpRNLmTXbLLkGJpM2b7JZdJvY9Fr74SjAgnQHNry/yy3/8VyWSNm8TiUoiUUkkKolEJW8TiUoOfagvT+dr21UGoTOA+fVFco2wSiRtRiUSlcQrR059eTpf267SL50+pIpZbs9Jco2wSiRtRi0SlcQrR059eTr/4c9+wt5mmV7p9OjB4wUVCrfyuUZYJZI2l3E9n2arTbPVptlqI2WIXkSiknjlyNl+/U3+O7fvqX997eXpgU6PfvDTeN55fqjef/Qxl3E9n27NVhspQ/QiEpV8UPra+evcpKhtV+mFRh+O71tcl+P7Fv3Q6EGqmKUftmXSzbZMBpEqZumF4BKpYpaX9RfkGmGVSNpcp92yy9O7r8SNe3FK6QIXEbzBg8cL6vYHE4IzuUZYJZI278Ju2eXp3VeCM//827Ha+/2Xgi6CLqlilpf1FzjPD9XxfYtTiaRNP1zP55xtmQxrt+xyamLfw3l4R9y4F6eULhCk0+X2nCTXCKv3H31MJCqJRCX9cD2foGarjZQhhhGJSiJRyXsf2sQrR87262/yte0qQToB8+uL5BphlUjaDErKEM1Wm3O2ZTJKkagkXjly6svT+dp2lXM6Z+bXF8k1wiqRtBmWlCGkDCFliKsQiUrilSOnvjydr21XOaVzYn59kVwjrBJJm3ERiUrilSOnvjydr21XEfPri+QaYZVI2oyj3bLLxL6HkWuEVSJpM64SSZtdQNNuRRh32q0I2saMKRhzGzOmMOiD6/kE2ZbJt4VBj1zPp5vr+diWSTfX8wmyLZOrpjFirufTzfV8rpq2euAremBbJt1sy+TbYPXAV3rrsx/nl9AceiBlCClDSBlCyhBvImWIZqtNkG2ZXKXf3NSFVkoXuIwhYxgyhiFj9MK2TGzLxLZMbMtkUIaMYcgYhoxxkVK6gMYlDBkjyJAxroMhYwQZMsZFtFQxy0XazSpB7WaV69BuVglqN6u8TaqYRfzxtz9X37e/yzj7u/sftI0ZU3DG9Xxcz8f1fMbJxowpNM64nk+Q6/mME40ztmUSZFsm48QgwLZMxpX+ux9+pG7JCcaZ7f7P0Z4YNcGYe2LUhDY5Ncu4m5yaRd/bLLO/MpdfQnMYQxnREaV0AZ0Te5tl9lfm8ktoDmMkIzqilC5wSufM3maZ/ZW5/BKaw4AMGUMzb6KZN3n96t9cpYzoiFK6wDmNLhnREQzAkDGCDBnjqmRER9BF0OWTzz9lcmqWc8+UruiRIWOcazerjFJGdARnWrUKO2tbBAku8MnnnzI5NcszpSveoYzoiFatws7aFm+jc4H69gHf+9Ekf5p8L7+E5vAOZERHtGoVdta2uIjGJXbWthgVQ8YwZAxDxujHztoWl9G4JoaMEWTIGKOk0YNWrUJGdARDaDerBLWbVS6TER3RqlXohUYPdta2OJURHcEQ2s0q7WaVdrPKZTKiIzixs7ZFLwR9ShWzPFO64gplREeU0gX6odOnvc0y+ytz+SU0hyuQER1RShfol84A9jbL7K/M5ZfQHEYoIzqilC4wCMEQUsUsrVqFX7en1MaMKQhYPfDVxowpSukCp1LFLKsHvtqYMQUBqwe+emLUxOTULKV0gUH9H5+F4fidZXVNAAAAAElFTkSuQmCC","w":50,"h":53,"frames":1},"dirt_patch_round":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAA0CAYAAADMk7uRAAAFqElEQVR4AdXBvWtc2RnA4d+58p0M53Kx05z1McQfA7Y3CyZVgkGsHNSsCAwEdwK3rlJMEUzEVKPGrJhKRf6DwFSuBMsKxIKjJm4CS4pYtmMzU8zrHAy2QPMiJJwbXdDAMMzHHcnyap+H01pYW6LaqjHo1oPFjCG3HixmDKi2aiysLXFahlP64Q+/yRr3vGHIxau32VheJ1dt1djt7DCs8VSyxe9+NJyC4RQW1paod8sZQ0ov35Br3POGI42nknHk4OYNhj2+sm/+/pfvOSnDCVVbNf70j3ZmnWcUDcIg6zyjaBBKL9+w+N2PhhOY4wQW1pb48797mXWeceIkJU5S4iTlsLdHnKSMEicp++ULdO5fX21vvWJWc8xoYW2JerecWecpKk5SJomTlLtv9xud+9dX21uvmIWhoGqrxm5nh3q3nFnnOQsahMdX9s3Fq7fZWF6niIgCbj1YzHY7O9S75cw6z1mxzlPvlrPdzg63HixmFBBRwOU7JdN4Kpl1npPSIBRhnafxVLLLd0qGAiIKOrh5g5PSIOQ0CEUc3LxBURFTVFs1BmkQxtEgaBCGWefJWeeZRbVVYxrDBNVWjd3ODvVuObPOM4kGYZB1nllpEHLWeTQIj6/sm4tXb7OxvM44hiG3Hixml++UDMfq3XJmnWcaDcIg6zyz0iDkrPPkNAiPr+wbjr3910H24m8/GAYYBlRbNXY7OzSeSnZw8wY56zxFaRBy1nmm0SBY55lGg5ArvXxD4543F6/eZmN5nb45Blz+3S+pd8vZL379FYe9PXJxklJUnKTESUoRcZJSRJykxElKdPVX3H2739j6339X21uv6Jvj2MLaEvVuObPOkzvs7ZGLk5TzQINgnefu2/1G5/711fbWK3JzHFlYW6LeLWfWefriJCVOUs4DDULusLeHdZ67b/cbnfvXV9tbrzALa0vUu+XMOs95pkGwztOnQXh8Zd+Y72t/zKzz5DQI1nlOSoNgnacIDULOOs9JaRAi6zx91nlOwzrPaWkQirLOc4GfiHWeUazzzCLiM9AgaBDOQsQQDcKnpEHo0yCMo0EYR4MwTsQQ6zyz0iCchgYhp0EYxTrPOBEFaRA0CKNY5xnHOk+fdZ5RrPPkrPPM6gKfgXWeaazznETECBqEYdZ5rPOcNxEjWOf5uYg4pkH4FDQIGoRxNAhFaRA0CJNEHNEg5DQIZ0mDkNMgfCoRR6zz5KzzTKJB0CBMYp3HOs8o1nly1nkGaRBGsc5jnWeSiGPWeSbRIPRpEE7KOs8w6zxFaBCGRYygQdAgnDfWeYZFHNEgTGOdp886z3lxgSPWeQZZ5xnFOs+sNAjWec5KxBmzznOWIn7mIs4xDcI0UbNSMkygQTgtDcKsNAg5DcI4zUrJzL148ox3D+dX599/bGgQ4iSlT4OQO+ztEScpJ6FByB329oiTlKLiJOWwt4d1nj4NQpyk5JqVktlYXmeOIy+ePOPdw/nV3x/YBgPiJOWwt4d1npwGIU5SRtEgHPb2iJOUQXGSctjbwzrPrOIkZVCcpOSalZLZWF4nFzGgWSkZhljn6bPOM4oGoU+DMMw6zzQaBA3CNM1KyTDAMODrb7/h0rUv6Xv0+iCjAA3CIOs8s9Ig5KzzDGtWSoZjH9rP2V7ZpM8wxtfffsOla1/y6PVBRgEahJx1nmk0CNZ5imhWSuZD+znbK5uMMscYna3/8MVvL/HPG1+szr//2GCKOEmJk5Qi4iSliGalZD60n7O9ssk4ERNsr2zyU9te2WSSiJ+5iCk+tJ/TrJQMn1mzUjIf2s+ZJmKK7ZVNcs1KyTCBBqEoDYIGYZxmpWQ4sr2yyTSGGVRbNR69Psg4JQ1CzjrPIA3CX+9eMxvL6xRlmFG1VePR64OMM9CslMzG8jqzmGNGL548493D+dX59x8bfELNSslsLK8zq/8D2JMm+PRVywYAAAAASUVORK5CYII=","w":48,"h":52,"frames":1},"tree_big":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABTCAYAAAAfpxDKAAAKe0lEQVR4Ae3BQWhbeWLA4d97sizvkxQ78eqN9Zqd2AqTMe3WmFlshRmYSUJgSFLdevEcVJhDKAGhY2FP9mXp1RR00GHohnZ0kZmDKy1Dy8IIZqk3sF3S9SBL4JE8HVtIkZOXyLJkyXr1n1rwKmxHtmUvTt73SZyRQCxsYLI4My8FYmEDk8WZeSkQCxuYLM7MS+wJxMIGJosz81IgFjYwWZyZlwKxsIHJ4sy8xJ5ALGxgsjgzLwViYQOTxZl5KRALG5gszsxLnAGJHgvEwgZ7JsbLFGo6bZlvdvj4Uw9mqa9L3Pikn7aRgUGepocRJsbLFGo6bZlvdvj4Uw9mqa9L3Pikn7aRgUGepocRJsbLFGo6bZlvdvj4Uw9mqa9L3Pikn7aRgUGepocRFmfmJXpIoocCsbAxMV6mUNO5yEYGBnmaHmZxZl6iR2z0SCAWNibGyxRqOhddpVnn+kiLoVu3ZzMLS3P0gI0eCMTCxsR4mUJN501Rada5PtJi6Nbt2czC0hynJHNKgVjYeJFPU6jpvGkKNZ0X+TSBWNjglCROIRALG+roKm+DYs7H4sy8xAnZOKFALGyoo6u8LZxDz7l6995sZmFpjhOQOIZALGyw50U+zY1P+nkbZb7ZYejaOMLizLxElyS6FIiFjYnxMkKhpvM2GxkYRHiaHmZxZl6iCza6EIiFjYnxMoWaTqVZ521XadapNOtcH2kxdOv2bGZhaY7XkLGciz668CKfpjDaj+X/K9R0XuRLdMPGawRiYePdyZdYDjY8auPq3XuzmYWlOY5g4wiBWNhQR1exHM059Jyrd+/NZhaW5jiEjUMEYmFDHV3F0h3n0HOu3r03m1lYmuMANg4QiIUNdXQVy/E4h55z9e692czC0hwdZDoEYmHjRT6N5WRe5NMEYmGDDjZMArGwMTFexnG1ieVkhkdtXB9pMXTr9mxmYWmOfTb2BWJhY2K8TKGmYzmdSrPO9ZEWQ7duz2YWlubYY2NPIBY2JsbLFGo6lt6oNOtcH2kxdOv2bGZhaU5mX6GmY+mtQk2nTcZyLmQs50LGci5k9hVzPiy9Vcz5aJPZo6+toI6uYuktdXQVfW0FQQrEwsbEeJlCTcfSeyMDgzxNDyOzp1DTsZyNQk1HkLGcC5k9IwODWM7GyMAggi2zsDQn+bTZ4Ws2LL33X7+t8O9//6+SzJ7Bd9+nmPNh6a1izsfgu+8jyOxTR1ex9JY6ukqbjOVcyFjOhYzlXMjs0ddWsJwNfW0FQWZPKJ4mm2pg6a1sqkEonkaQ2ReKp8mmGlh6I5tqEIqnaZPZY5+eRAjF02RTDSynk001CMXTCPbpSQSZffUxDSEUT5NNNcimGliOJ5tqkE01CMXTCPUxjTYZk/qYhhCKpxGKOR+W7hRzPoRQPI1QH9Mwk9lnVxSE+piGMJXQ0ddWWE5cwnK05cQl9LUVphI6Qn1MQ7ArCm0y+xxOF231MY2b2xtMJXT63WUsR+t3l5lK6Nzc3qA+ptHmcLpokzlEfUzj5vYGlu7c3N6gPqZxGJkj1Mc0hGLOh+VgxZwPoT6mcRQZE7ui0CkUT6OvrWA5mL62QiieppNdUTCTMXE4XZi5PCpCKJ4mm2pQzPmw/J9izkc21SAUTyO4PCpmDqcLM5k9Ub/GYezTkwiheBp9bYVsqkE21WA5cYm3zXLiEtlUg2yqgb62QiieRrBPT3KYqF9DkNh3//Ej4+HSOpVSEcHlUTFr/P6PtP3nT7w8eTDI4Lvvo46u8jYo5nzoaytMJXRubm/QZp+exKxSKiK4PCpRv0YyGJHYY2Nf9qsncy9Dd2b/OlNA6Hc6Mdvul9m97Gb3spvR0gbG93ZW36mwmW8xfM3GmyybalDXy0wldG5ub1Af09i97Gb3spt+pxOzneoWwj/feY9kMCKxz4ZJ9qsnc7V/CMx+8D8v6evvx8zAoNVoIOxedjNa2sD/3TN+/5c/ZfiajTfZZr5FKJ7marNCfUyjza4o9PX3Y2Zg8C+f/hXJYETCROIA9x8/Mh4urWNW36rQqFYxc3y/jvBPfzvOex/b6ZVizsdpqKOr9Eo21SAUTyPUxzTM7IqCw+nCLOrXSAYjEh1sHCD71ZO5l6E7s7/48RVtff397FS3MPvJjeu0fizg/+4Zv3FeYfiajV7IfbtLtVSlWqoy4N7CaFYxmlWMZhWjWcVoVjGaVYxmFaNZxWhWKWe2qZaqVEtV1Bt1eiGbahCKpxHs05PsVLcwU4YuYxb1aySDEYkDyBwiGYxIUb/GYVweFcE+PYkQiqfJphoI2VSDYs6H2XLiEp2WE5cwK+Z8ZFMNTiubalDM+TBbTlyi03LiEmbFnI9sqoGQTTUIxdMI9ulJBJdH5TBRv0YyGJE4hI0jZL96MvcydGf2Fz++QtipbtHW73TSZvuLEVo/FvB/94zfOK8wldBZfafCZr7FZr7FZr6FzbHNrvEezqHnCMWcj2btBzbzLTbzLTbzLep6mamEzg/XLiPY3TIOp0E3mk0brR0D4eZ/FFh9p8JmvsVmvsVmvoXNsc2u8R7OoecIxZyPZu0HNvMtNvMtNvMt6nqZqYTOfzvshOJpBPv0JGY71S3a+p1OhKhfIxmMSBxBogv3Hz8yHi6tUykVEVwelU6VUhHH9+sIw55BOiUqCsKTB4MIUwkd4YGrSqdffvBzBLtbxu3ZpRuvSjYar1oIv/rDn+iUqCgITx4MIkwldIQHriqdyiUdoT6m4fKodKqUigguj0rUr5EMRiReQ6JL9x8/Mj77tz8iuDwqnSqlIoLj+3WGPYOcxi8/+DnCFZ/BcWyuSgi/+sOfOI1ySac+piG4PCqdKqUiwpd/M0kyGJHogsQx3H/8yPi732ZwOF10qm9VaFSrCD/1qpgpqheh+e3vMOv76EOEanEDs1m3E+GKz+A4NlclhNlXW5gpqheh+e3vMOv76EOEanEDs2cbRQS7ouBwuuhU36rw6zs3SAYjEl3q4xiSwYjE40fGw6V1OjmcLhrVKkfp++hD/pz6PvqQ43A4XRzk13dukAxGJI5B5piSwYgU9Wt0S1G9vI6ieulkd8scl90t00lRvbyOonrpVtSvkQxGJI5J5gSSwYgU9Wu8baJ+jWQwInECMieUDEakqF/jKIrqpVuK6sXM7dnluNyeXcwU1Uu3FNXLUaJ+jWQwInFCMqeQDEakqF+jza4ovCnsikJb1K+RDEYkTkHmlJLBiBT1awgOp4s2RfVyXIrqRbC7ZU7K7pYRFNXLcSmqlzaH04UQ9WskgxGJU+qjB5LBiMTjR8bDpXV6we3ZJfn5lxIncP+LzwzW6YmoXyMZjEj0gEyPJIMRKerXEBTVy0kpqpfk519KnFDy8y8lRfVyUorqRYj6NZLBiESP9NFDyWBE4vEjgz+zf/yZxKn8bJJkMCLRQxJnIBALG1xgizPzEj3WxxkoLT+j7YrP4CLYXJU4SzKWcyFzhuxumYvC7pY5SzKWcyFzhtyeXS4Kt2eXsyRjORcylnMhc0bsbpmLxu6WOSsylnMhc0bcnl0uGrdnl7MiYzkXMmfA7pa5qOxumQvj/hefGVxQ97/4zOAM/C+74u5iG8bNJQAAAABJRU5ErkJggg==","w":90,"h":83,"frames":1},"tree_fruit":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAiCAYAAABBY8kOAAAFKUlEQVR4AZXB72sb9wHA4c9JQlLcKKfamKuMfzXGSeZUpCoOJCAuZCxQVKQxwgg1fuXSd30TNi/Db2a/WCAT7B8YWd+IwgZp4I6ZwloHDi8eValLRdxSoTWWVCuKUKPLZY4irGr6Ut24aSc3fR6J53T5htrBxa1rhsRzkPgBl2+oHbreVi/i5k/GHYRb1wyJQ0gMcPmG2qHrp6rMDK9xmAKfsmGYCLeuGRIuJFxcvqF25ia8vPTyUWwzvIabAp9ie/D1E1Y+20U48od/STh46XNi8XTn4nwI4eiLfmyPqPCICr+4/SHTX37Oxk/aPKKC05NGi5+9+So+LH47FVz9/T8erdHjweHE4ulONDqCbcMwcVq6fY/A1QsEzg2zdPseThuGifC7O/cRzuxN4+ThEHMTXjYMkw3DRDizNw1bOYQze9MIG4bJhmEyN+HF9sv8EFDFSaLnxOLpTjQ6QqZeRrj+6hRu/rIuIVxJdBhkp9RGyOXqfJW5J9HlwSFTLxO4eoHAuWFWPtvFzZVEhyuJDoPslNq48dJ1YvF0JxodYa0wzDuhEsIrHyu8MsuPslNqY6sVGrx8apj2S0dX65/X1nz0OfX+MWw7pTbC3IQX206pjTA34cW2U2rjVCs06OfDIRo9wFYrNIAwwk6pTb+dUhunTL2MsDgyzuhMmH4euqyiHze1QoPnkamXCVy9QODcMJl6GSer6EfwMMDoTJjRmTBOtUKDWqFBrdCgVmhgO353HLZyCMfvjuNGiqixTmiyhRCNjiBk6mWExZFx+tUKDYTRmTC2XM6Hdf8AITTtIxo9QMjl6ghW0Y83NBVZDchthIcPn1L4eIjf/DGGD4uf56u8P3QMpxeGg7wwHMRJUb5j4iRMnIRSvsxe0aJutrC1TC8e+oSmfbCVQzh+d5wfaz4+hhuJroga64QmW3xPwbp/gBCa9hGNHvDJ5h62+fgYQqZeRjj1hYf5+Bi2XK6Ok1X0UzG2JYmeiBrrhCZbDPLMfMZ8fAwhUy8TuHoBtnI8++e3nNk7ghur6KdibEt0eel5svtgzR8eX22ZXgJym36+oI+HD5+iKEP8+qNj/GriG4Spv44QCD/FySr6aZleKsa2RI+Ei4ga64QmWwymYN0/QAhN+4AqNqvop2JsS/Tx4uLJ7oM1f3h8NSC3sVlFPwG5zff+TSD8lNbjNgH5MTar6KdibEu4kOgTiatJbB5Lo2eBIO/RJDTZQrCKfhYI8h5N/uu7UIqeyqah4+DBIRJXkzjMVuHd2BQLBBEWCGIV/VhFPwsEERYI8m5sitkq/yMSV5M4eOiJxNUkDrM1S1t5fYp+CwRZIEi/ldenmK1ZGg6RuJqkR6IrEleTOMwmh7SVvSB/365iy1abnFWCOGWrTc4qQWyXYgrXx5rk9f0UDpVNQ/cwwPUPdslWmwjZahPbpZjCpZiCLVttImSrTa5/sMsgHroSaVnDIa/vp/KjoRRLCtlqkx+SrTZhSSE/Gkrl9f0UXYm0rCXSspZIyxpd0ltbyQ4O68tmij6zySGNP1c5qwRxylabsKSQ1/dTuEikZY2um+d1yYPD+rKZwkVe30+xpPB/lhTy+n6KAdaXzRQ9Eg6RuJrkELPJIe3s30yE7BsyeX0/xQCJtKzdPK9L9Ej0icTVJD2JtKytL5spDpFIy9r6spnCIZGWNXpuntclujz0qWwaemXT0BNpWaMrkZY1BkikZY2uRFrW6KlsGjoufDyHyqahR+JqkkNUNg2dnpvndYk+/wEPHuWF/VlZJgAAAABJRU5ErkJggg==","w":26,"h":34,"frames":1},"tree_fruit2":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAiCAYAAABBY8kOAAAETUlEQVR4AZ3B72sadwDA4c+dwVx/uHMNhzVgQpGEYRDmSAYBOWihUBz6Ju8krzL2J4RCXyVvCsE/YWR9M/qub+5YKGxkcAiDGRqozMHEF1XITQ6J7kZmwpzzCzput9NkfR6JG9o60IcEePXUkrgBiWtsHehDRr7QHxLkS+t7hFdPLYkZJKbYOtCHjDzSVZJ8wiwN3nBs9RBePbUkAoQIsHWgD1OJEOmPP0A4x+YecYI0eIPwYFnh1l9/on26tPfzd+/28Qnhs7q9Nny4HkG4+2GYiXNszrE5x+Ycm3NszrHx+r17habK/Hrrzl7nrbOPRwiP1e21YTq9gKbKCD9W/+DBssJNHFs9NFVGkBWFwf27e523zj5jc8yQSoQ4tnoIj3SVIMdWDyGVCDGLxNjq9townV5ASCVCTFNrDRBSiRDT1FoDhGq1wy9f/yQxIhOg1howTSoRIpUIMU2tNSBIiJHV7bVhOr2A0+hy556C4Pw2RFNl/o9aa8CE0+jy4KN7DO7f3eu8dfbn8HEaXbRkFKHWGiCkEiEmaq0BQioRYqLWGuDlNLr4zeGhJaNMOI0uWjKKUGsN8Ku1Bvg5jS5aMoqWjOInM+I2wwRxGl1uyml0CeI2wwhzTKElo/g5jS5eWjLKhJaMMosU1zPDyNIVQjq9wHWcRhdBS0a5TrXaQXCbYebwqFY7XPYuEdaziwTRklFmOSmfIcyr83jJBFjPLvK+1rOLBJEYieuZYWTpCq90eoGJk/IZE+vZRYST8hkT69lFJqrVDl5uM4xtnUoSY3E9M4wsXTHNZe+S9ewiXiflM+bVeaZxm2Fs61RiRMIjrmeGjESWrpgmnV5AqFY7TOM2wwi2dSoxJhEgrmeGkaUr3ofbDGNbpxI+MgFs61Rym2G83GYYP7cZxstthrGtU4kAEj7xrJ5nQnYNxooovKRPZOkKwW2GKaLwkj7/+CtSYMwuWyYeMh7xrJ7HY6UNLzLLFFEQiii4zTBuM0wRBaGIwovMMitt/iWe1fN4yIzFs3oejxXHNZ49WcaviEIRBb9nT5ZZcVwDj3hWzzMmMRLP6nk8VvK3jWdnCt+etpmotPtsxBS8Ku0+GzGFiceZGM8X+9TNiwIedtkyZaZ4/vodlXYfodLuM/E4E+NxJsZEpd1HqLT7PH/9jmlkRnIl1cCjbl4U6lqkwE6MSrvPdSrtPuzEqGuRQt28KDCSK6lGrqQauZJqMCJ9/kN+iMfRbq+Az0r+tsFXbTZiCl6Vdh92YtTNiwIBciXVYORw05RkPI52ewUC1M2LAjsx/mMnRt28KDDF0W6vwJiERzyr55lhJX/b2Pimh1D5TKVuXhSYIldSjcNNU2JMwiee1fOM5UqqcbTbKzBDrqQaR7u9Ah65kmowdrhpSozI+Nhly7TLlpkrqQYjuZJqMEWupBqM5EqqwZhdtkwCzHEDdtky41k9zwx22TIZO9w0JXz+Bpkfi2dW/g9qAAAAAElFTkSuQmCC","w":26,"h":34,"frames":1},"tree_orange":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAiCAYAAABBY8kOAAAEOElEQVR4AZ3B0WsadwDA8e/vYnJZMjlTJ+q21Awx9CWwrmQlcNxDoBAc+geEPGV/Qyj0qX0pBP+GrC+lf8AdC4GNPhwHowgdNG91UoNsRg6J7lan0dbdDWXH7TRpPx/BNWmHOyNCmPdPBNcguIJ2uDPCtafdJcxT8wUe8/6JYAbBFNrhzghXTpvnLt8wywteUjEHeMz7J4IQc4TQDndGidU+X3z9CZ7fafAlacK84CWeeGaOufd/k/j21sOzn397RIAgYH1ve7SRH+GJffUpH6L95i88p8eC10+fC3zm8Fnf2x6lNhZYVt7hqZ8K4pk5rqNiDlhW3uGRFmXk1M2HrVdvHjEWYYbEap+Kyb9y2jxhKuYAT2K1zyyCsfW97VFqYwFPYrXPNHZdxpNY7TONXZfxnJ9e8vrpc4FLIoRdl5kmsdonsdpnGrsuE2YO1/re9ii1sUC72mLxxhKe7p8RlpV3fAi7LjPRrrb47FYUOXXzYevVm0cSAe1qiwm7LmPXZfzsuoxdl/Gz6zJ2XWaiXW0RFMEnlo0z0a62iGXjeOy6TJBdlwlqV1vEsnFi2ThBEi6nNiRMu9riutrVFmGc2hBPhCli2ThB7WoLv1g2zkQsG2cWkVa1UXQtgie1scBV2tUWnlg2zlXOTy/xOLUhEXzOTy/pd97iyagrhIll48xyZl3gkZVl/CRCZNQVPlZGXSGMwJVWtVF0LYJfamOBiTPrgomMuoLnzLpgIqOuMHF+eomfUxvSsEwhGEur2ii6FmGafuctGXUFvzPrAllZZhqnNqRhmQKXwCetaiNc0bUI06Q2FvCcn14yjVMb4mlYpmBMECKtaqPoWoSP4dSGNCxTECARomGZwqkN8XNqQ4Kc2hA/pzakYZmCEIKAtKoV+I/O2K404Nn7eaJrETxObciuNODZ+3l8iow1LNPAR8InrWoFfHK2w5M7N9iVBnh2pQFObYhTG7IrDfDsSgOe3LlBznbwS6taAR+JsbSqFfDJ2Y7+YCdD0K40YFcaEPRgJ0POdnR80qpWYEzgSqtaAZ9cYUl/8MciP/3aZKLc7LGZXMSv3OyxmVxk4t7tJI8/71ExukV8GpZpSEzx+OSMcrOHp9zsMXHvdpJ7t5NMlJs9POVmj8cnZ0wj4cqXFB2fitEtVhLRIvtJys0eVyk3e7CfpJKIFitGt4grX1L0fEnR8yVFxyW+/6Uwwuf4oFMkIFdY0vmhyWZyEb9yswf7SSpGt0iIfEnRcR1tGULC5/igUyRExegW2U/yP/tJKka3yBTHB50iYwKftKoVmCFXWNI3f+zgKX+nUDG6RabIlxT9aMsQjAkC0qpWYCxfUvTjg06RGfIlRT8+6BTxyZcUnbGjLUPgkghoWKbRsEwjX1J0XPmSojNFvqTouPIlRWesYZkGISJcQ8MyjbSqFZihYZkGY0dbhiDgH0Q0j2kiU233AAAAAElFTkSuQmCC","w":26,"h":34,"frames":1},"bush":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAVCAYAAACzK0UYAAACrklEQVR4AaXBQWvbVgDA8b9s1y+dGK9e5mCzpWYrDb0ERhkbBaFDyCEYrE+QWz9DKOSUXAbBn6G3fQIZQg+lB2EovfQQ35qFEESwmTHyG2jbe5mnScMGYWzHY7+fxZrcs4OEBYJXbyzuYXEP9+wgIfXUfcCPPCfvAx+5DO7IBK/eWCxRZAX37CCpbmu++u4hmVv6fE2dzAc+ktlsFCn+/QfVH56d3Lz95ZQFiiyxc7iXfPP9X2Q2KmVmbulzS5+8P8cGW06YPPz2ZHRxfcqcIgvsHO4ltd0ytpyQCXsWm40ii1wGd9hyQqawIRC1xyeji+tTckqsobqtuQz411P3AZnL4I5MdVtzH4s5O4d7SW23TKa6rfkvhqEgM+gZPv38zmKqwArDULCuYShYpkjOzuFeUtstM74asfHFZ2R+/62ELSesMgwFM+OrEV8++xxRe3wyurg+JVVgifHViJlhKBiGgnnDUDAMBTPjqxGLlMjRKgbKPHqyySLDULDKoyebzGgVM1Ngqu64LVKDnuH/GvQMmbrjtkiVSNUdt0XOoGfQKibTcCqs46YbkRHSJq/uuK0CKzScCutqOBWWKZFqtqV/fqQ8coS0GfQMtd0yMzfdiLyGU2Fm0DMIaZPXbEuflPXyfSsh5+1PvyKkzTJaxWSEtFlGqxgTCa/Zlj6pAjnnR8ozkfC0itEqZhEhbYS0WUSrGK1iTCQ8UudHyiNlkVN33BY55Yr2mRLSZhGtYmZMJDymmm3pv37RsUgVyOl3gw45+8dbmEh4JhKeVjFaxWgVo1WMVjFaxewfb2Ei4ZlIeEw129In9fJ9KyFVYE6/G3T63aDTbEufVLMtfVImEp6JhGci4ZlIeCYS3v7xFplmW/pM9btBhzkl1tDvBp2647ZYod8NOky9ftGxyPkHHyQGS9YPDVIAAAAASUVORK5CYII=","w":25,"h":21,"frames":1},"berry_bush":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAVCAYAAACzK0UYAAADeElEQVR4AZXB70sbZwDA8W9+9J5mGV5F4s4NI6NM9iYgKxQKIZTgUMJyYeCr4TvzB+yNFGQvIh0DyYv9A82Llb2fyw0prPRFCNqlsOF8M+tGMQ4iO5rz7E6980d6z5awQ6J2n0+IN5RZmu4UKybSg7kEPbV7j0JcIcQVMkvTHXzFislMYYr2aoMnpsXRN5/wEz+zVTtGqt17FOICES6RWZruJEZd3puIYT91mWiaSMsDZ/zxsY00NBYhcnZI4vaHpe3Hvy/SR4gLjM9mO6lcB+nG+29zmb0XfyNtrIR4/u2TEOdE6GN8NtvRUgpx9RRpZyPE0FiEfrZqx8TVU6TwdYHQkqWXv75YJCBKH180bGjA96UBpMSoy1aNf3yQuYa0VTtGSoy6XCXCOQ/Hb3VmClNo7TZixWbzrkCKq6fE1VOO9jyO9jw++9rio18O2Lwr6DnYj/L5D20+HXq39N3L1iJdYc5Z1xTaqw2kdU2hn0Jpn5nCFNnEIIXSPpK5IyhWTGYKU2QTgzwcv9WhK0LA+Gy281y9RvvVAU/DxxjJGOHrgrh6SpD7W4eJpom0PHDG1jtxpEjrhImmibQ8cMba9p+L+KKco6UUfnzrFZJ2U0EydwRSYtRFMpIxaDpIRjKGxr+MZAyaDpKRjNETJcC1HUDhxs0h+jF3BJKWgmcpBUnjP1pK4VlKQXLrFj1hukbSmTy+3Q2P/6tYMSlWTHp2NzykkXQmjy+KbySdyROwu+Hh2g7S/c0TpAdzCfopVkxmClO0VxtQMfnytkrQSDqTD3OJ+5snzBSmyCYGKVZM+lnXFNqrDaR1TaGfKL5cWa2uzNs6AUKNs64dkl1tIK1rCtt1i6Cx9CBGMgZNB8lIxgjKldUqvtDcWr5DwOOv/kKocXryzUMkIxlDcm0HSahxLuLaDp4l9FxZreILE7Ayb+ueJXTXdnBtB8lIxjCSMXqEGkeocfpxbQfXdvAsoeNbmbd1fCECRtKZPAHKoFulS6hx+nFthx7PEjpdubJardwxQvjCBLTqNYOAyYVhPEvoniV013ZwbQfXdnBtB9d2cG2HyYVhPEvoniV0unJltYpvbi3fwRfmnFa9ZrTqNSNXVqv4cmW1is+zhO5ZQvcsoXuW0D1L6JMLw0i5slqlq1WvGZwT5Q206jVjJJ3Jc4lWvWbQVbljhAh4DV/dW6Gw63+oAAAAAElFTkSuQmCC","w":25,"h":21,"frames":1},"stump":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAYCAYAAADkgu3FAAACoElEQVR4Aa3BwWrbZgDA8f9nq1Y3z1ieZrDZXHuIhl4MY4f1InTIKewZ/B65Jse8R55h5DB6ELrk0kN9ayYiI4YMQkTd13bYUab5GxEIITlJ2e8neCTn7Cinhnt8IXgEwQOcs6OcnYXzmjrn7iWKe3wh2EPQwDk7ytl56TzjNT+zzyVvuXJvUdzjC0GNNjWcs6N8ONnw/U9fofxJxA+MqXPJWxRz2qb9z98Mf3l1svr9j1MqBBUHi8N8/muOYvz4DU+RXn9EWf4meH/+RlDSpuRgcZiP5h26/TuUcCkwp20e48q9pdu/Q2k919FHL06Sd9en3NPYYzjZcOXyn5fOM+pcubcow8mGfQT3DhaH+WjeQRlONjSJQx1lONnQJA51lPVyy/vzN4KdFjXiUKfJcLJhONnQJA516rTZOVgc5qN5h9RPeP7t1yif/9Lo9u94ijjUKaR+wneveuijFyfJu+vTFhWpn1CIQ5041CmLQ5041CmLQ5041CmkfkKVRolhmRRSP8GwTJQ41KmKQ52q1E8wLBPDMqlqsSODjDqpn/BYqZ9QRwYZikYDwzKpSv2EMsMyKRiWyT5ibDt5b6ahjOYdHpL6CYphmTxkvdyiyCBDo2S93LL58Allag+oY1gm+6y8GxS936WsRY2pPeBLTe0BdQQ7Y9vJezONstG8Q2Hl3VCY2gOUlXdDYWoPKKyXW8pkkBF5rhDcG9tO3ptpNNl8+MTUHlC28m7Q+12ayCAj8lzBjqBkbDs5O72ZRpPRvIOyXm5pIoMMJfJcwT1BjbHt5L2ZxpeQQUbkuYKKFjUizxUyyCiTQUaVDDLKZJARea6gRosGkecKGWTIIEMGGZHnChlkFGSQEXmukEGGDDJkkBF5ruD/MradfGw7OU/0LyN1Adjjl+33AAAAAElFTkSuQmCC","w":26,"h":24,"frames":1},"pond":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAABFCAYAAAAFBsWPAAAIpElEQVR4Ad3BX2gb9wHA8e/vFN9qy41TEp9jBncrZpGJrrikXhsEdnEGtcEVe7EpGmEPgyYwV9a6rkQvZQqhzN7wqKqmYA/2MEpFiPKwamURlIbGISxbVppNNnI2r9H1IbNS06ir4/VS66Yf+IYQtiv/yWLn82GrdI/2OcFkxKHCgaNHHKocOHrEoUIwGXG6R/sctohgC3SP9jmxD24Se7qVak26j3QoLigLJiNO0ZqhWuyDm8SebuXiifOCTRJsUjAZcX7wq9+xt7mJ1cSebkWKfXCT1czfKvLbn3yPdCgu2ATBJnSP9jnhVA5pb3MTmzF/q4iUGGjn4onzgg0SbFD3aJ8TTuWQSj6Dpr2PsBL17x9Tyf72o6ykOP8ZykweKTHQzsUT5wUbIFinYDLiFK0ZwqkcUslnIDXtfYTVNGitSHcKN1lNcf4zJGUmj5QYaKdJ95EOxQXr4GEdDhw94tQ9dJtwKodU8hm4HmqoZyUNWiuuOu/D3F34gpV8ufgfJGffHsR8kaemP+XiNwXf2K/H5v/68UlqpLAO+x9TCadySJ5DB7lXPIcOIoVTOfY/prIeChtQ8hnUokFrpVqD1kotSj6DjVCoUTAZcSgr+Qwk1dvIvaJ6G5FKPgMpmIw41EihBsFkxClaM4RTOSrVeb2spkFrZTUNWiurqfN6qRRO5ShaMwSTEYcaCFZx4OgRZ/9jKq5wKodU8hlIXq0FaaEwR090iGb/ILemziJ9+Ou3adBaWcudwk0OPf99pGb/ILemznJh5DRerQVpoTCHpMzkkRID7bj+9Teb62+9L1iBYAXBZMQpWjOEUzkqlXwGkldrwfXkDwfoHPfzRf73SA17j/DhSx8jNfsHWcmtqbNIh8Ye5c78+0iNxrNcPT7Fn36TwrVQmENSZvJUSgy006T7SIfigiq7WEHRmiGcylGp5DNYSbN/EJim0XgW16GxR7kz/z7wC1bTsPcISmMDjY3P4mr2DwIpqpV8BspMHlc4lSMxwIoEVbpH+5xwKodU8hmsxKu1IPWPncEYnmYr5V8/yLsvPYe0UJhjJcpMHikx0M7FE+cFFRQqdI/2OeFUDslz6CBr6R87gzE8zVYzhqfpHzvDWjyHDiKFUzm6R/scKnhY1j3a54RTOaSSz8CjqpTu3qVaT3SIx4/+DGN4mlpZpkpR81DUPDQVlqhkmSpFzUNTYQnXa3+4xZuv/QjN5+XGpT9TzaOqLO1uQMwXeWr6U+Yih2P59/5xkjJBWfdonxNO5ZBKPgPJq7WwUJijUk90iM5xP9UsU8WlZ21clqmyHnrWptrV41NcGDlNJa/WwkJhDkmZySMlBtq5eOK8EMFkxBn6Y55/X/6Iks/A5dVasBe+4O7CAlJPdIjOcT/VLFNlK+lZm2pXj09xYeQ0Up3Xi+ptZKEwh0uZyfNw4HFOHzZQKFOaNUo+g2qqtxGpJzpE57ifapapstUsU6Va57ifnugQkuptpFrJZ6A0a0gKZYm2eip5tRZcPdEhOsf9uCxTxTJVLFPlXrFMFctUsUwVV+e4n57oEC6v1kKlRFs9kpIOxQVraPYP4rJMlf83y1RxNfsHWUs6FBcKa+gfO4MxPI1kmSr3i2WqSMbwNP1jZ1iLwir6x85gDE8jWabK/WaZKpIxPE3/2BlWI7pGep1XvjL4LDeD1BMdotk/iDE8jcsyVbYDPWvjyr9+kFtTZ7kwchrpkXYfp3blEZQFkxHn6Lsf0RMdonPcTzXLVNkO9KxNtavHp7gwcpq3+h8nHYoLD2XXz105+ebbv4x1jvupZpkq20VR89BUWKLSxF80fv7jb/H8d38qKFNY1jnup5plqmw3lqlSrXPcj0uhLJiMOFSxTJXtyjJVqgWTEYcyT9dIr/PyvJd3Fg7jskyV7a6oeWgqLOF61b7EjWf2xZTJaEYk2uqppGdtdppEWz2T0YxQeMAoPGBEMBlxKLt2+Rguy1TZKfSsjdQRmEBSKAvPLrLThWcXkRSqWKbKTqFnbaoplCXa6tnpEm31SEo6FBdU0LM2O4GetamWDsWFwgNG4QHj6RrpdV6e9/LOwmFcRc3DdlfUPDQVlnC9al/ixjP7YspkNCMSbfW4LFNlJ0q01TMZzQiFsnQoLtiBLFPFlQ7FBWUKDxiFsmAy4rBMz9rsRMFkxKHM0zXS67w87+WdhcO4ipqHnUDP2rhetS9x45l9MWUymhGJtnoq6VmbnSbRVs9kNCMUHjAKDxgRTEYcyq5dPobLMlV2Cj1rI3UEJpAUysKzi+x04dlFJIWyU7vyuCxTZSc6tSuPpKRDcbHHaMelZ212Cj1r49pjtJMOxYWHsuvnrpzsfrEuNvfJE0hNhSWKmoftTM/auDoCE6RDcUGZh2XXz1052f1iXWzukyeQmgpLFDUP25GetXF1BCZIh+KCZR4qXD935WT3i3WxuU+eQCpqHrajpsISUkdggnQoLqigsIKOwASSnrXZbvSsjdQRmGAlghV0jfQ6e4x2XOnPX2A7CO5+A9ftfI7JaEZQRfA1ukZ6nT1GO+nPX+B+Cu5+g9v5HJPRjGANHr6G9d7syZbv7Il1tPyT618+yf0Q3P0Gt/M5JqMZwddQqMFkNCO4zyajGUENdrEOetbGZZkq95KetfmfADVTqNHtfI6OwAQuPWtzr+hZG1dHYILb+Ry1UqjRZDQjKOsITODSszZbTc/auDoCE0iT0YygRoINCCYjzrXLx3BZpsp66Fkbl2WquPSsjasjMEE6FBesk2CDgsmIc+3yMVyWqSLpWZtKlqni0rM2tegITJAOxQUbINiEYDLiXLt8jK3UEZggHYoLNkiwScFkxLmdz/HKVwaJtnoqhWcXSbTVkw7FBWXBZMQJzy6SaKunUnh2kVO78uwx2kmH4oJNEGyBYDLisCwdiguWdY30OpPRjKBC10ivMxnNCJYFkxGHZelQXLBJ/wXeUflZozxHdwAAAABJRU5ErkJggg==","w":52,"h":69,"frames":1},"rock_small":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAKCAYAAACE2W/HAAAA60lEQVR4AYXBIYvCYBwH4N+7rVguXDQN4RCOK55gGLK0g5UTBOFg0fDC4PqMW9s+gWAwmvwACwvH6h3qcQZBERWzGCxa/veGCWNs+jwMOSzbJ2SM+j2GFAUZlu0T73aQg0b9HkNCRopl+8S7HeSp155xUcru30/kQZCQ0AxOtdcX3LJZrnElQdAMTu2PFu5RnyrQDE4QJD0wCSnfswXyDIZjpDEIemDS++MnrqaTOYpslmsobzvIELbRyjs3D2611MB0Msctp/ovYidkMhLbaOWdmwf34aiiyF79QuyEDAJDhh6YhAKxEzIk/gEu/UcK5Ss1kgAAAABJRU5ErkJggg==","w":14,"h":10,"frames":1},"rock_big":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAYAAAB24g05AAABPklEQVR4AY3BQUvCYAAG4PdzuxYrOkSJDKHL6LJ2kxoGDnYpCIzAo4eB0F2P2839AqFDR0/9AEEP4rWcQR7CbH5OoVvEThbC14QNhqj1PARLCqUqQ6heqxD8gUNMoVRlRjEPRZagyBJ++APz5allYQMOoUKpyoxiHnGKLGEwmpkTt2thjQQCmZzB5JNjrCIepZHJGQxrJFRbZwg9Pr8i7u7+ARHV1hlWIAiots4udm/Rc/pYZSq2kaRZROq1CkGIQ2DcGlrfp5/m9peIZVOxjSTNwijmocgSFFnCYDQzJ27XQoBDaNwaWjvXvOkLFL5A4QsUvkAxb6Zwrp3hcH8PkXfvA1tC2py4XYtgA9XW2byZwtXNJRZ6Th8R+uaC1zwksEGn3CC85mGh5/QRx2seOuUGIfgH1dYZlnTKDYLAL1mGbRsfsBQ/AAAAAElFTkSuQmCC","w":16,"h":11,"frames":1},"flower_patch":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAOCAYAAABO3B6yAAAC8klEQVR4AbXBsU8bVwDA4d8zHLKhNHIHXkiURrYiyBAQh7CEQb3NwhIDQ+cuniJvyK1OZbIXI4sitqoTC38B2yFnOqn1cJXM0CUitXVSGvKoIhgSfFGorjyJi07OJc3S7xMkqFnFkAS7bkfwGWpWMSTBrtsRDBEMqVnFcGNtgSSHR8fsuh3BJ9SsYrj5uEiSvV867LodQcwIMTWrGG6sLaAdHh3z9Zch79685t2b1xgTkzx8cJuvrox6x3/eIEHNKoabj4tovf6A84srzi+uOL+4Ips1KC7dQ/xNveM/b3BjhBvWrBlWv11COzw6ZmNtAWNiEmNiEmNiksuzU4yJSR4+uM2ff/1T91+9bBBjzZrhT99/g9brD8jnMmSzBtmsQTZr0OsPyGYNikv3+P2PoO6/etngWooE619cMmzspM//IUXMzOIc2ujqCpdnp1yenXJ5dsrVr78xurqCNrM4x8eMzS+j5XMZev0Bvf6AXn9Arz8gn8ugjc0vE5ciZmf7gJnFObTxqWnGp6YZn5pmdHUFbWZxjp3tAz6mVd1jbH4ZLZ/LkM9lyOcy5HMZtLH5ZVrVPeIE16xZM9wq36fdVWg//PgdSXa2D9BKpqTp+LhPu4Jr1qwZbpXv0+4qNPvnTZK0qntoJVPSdHzcp10hrFY53HqRpt1VRDwVUJBp4jwVUJBpIiVT0rwToG29SNPuKiKeCijINHGeCijINJGSKWneCUhxren4eCpA81RApGRKSqYk4qkAzVMBTccn0nR8PBWgeSogUjIlJVMS8VSA5qmApuOjCW5YrXLIviJSkGlKpkRrdxWeCnivInFtRxBjtcoh+4pIQaYpmRKt3VV4KuC9isS1HcE1wRCrVQ7ZVxRkmjhPBVCRuLYj+ASrVQ7ZVxRkmjhPBVCRuLYjiEkxxLUdQUXygYrEtR3Bf3BtR1CRfKAicW1HMGSEBP6TZw2j+qh+9+Qtmrd+C9d2BJ/Jf/KsYVQf1e+evEXz1m/h2o4gwb+HwBrvevtZ1wAAAABJRU5ErkJggg==","w":32,"h":14,"frames":1},"grass_tuft":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAQCAYAAAB3AH1ZAAAC8ElEQVR4AbXBT2hcRQDA4d/E/GkHoqSHqQOBNoFVD1lUsNC1MEpAXIRA6EUEjx768LDk2newObxzyOnl4DEQeykBIUSEogO6kRwkbA7BQOLJaQYM2JRpklXHfSHCY32WHprv4yLMrLTizEorcm5mpRVnVlqRCoIXbGalFdX1PQq7tkuhZoYo+F8n+fqTRUHJABdg13Yp1MwQNTNEYdd2qSK4AK99Oh1frQ9TM0MUdm2XR51Tfll+KOgzSIX11mykQnNxVfAcdm4/5o0HL/OvR51Tdm4/ZmCZ/3iJPuut2SiV5vUphRofQ42PocbHeNK9xMf18XvLP+3M8wx/P3gn0qgzdX+Pr45GeOL/Yunwd65//hZf3Bq8N3//t3lKBOdslsTgHVJpJicus7DUpmzuToO9/acE75BKY9JcUGKzJN744xtG5t6DdofCd192Kbz/2RBnGnVOFr5n85UPMWku6BH02CyJwTuk0kxOXGZhqU2VuTsN9vafErxDKo1Jc0GPzZIYvGN4d5/G1BEjN69wplHnTLtD4WTjkPb2KKe1CaTSmDQXwmZJDN4hlaYQvOPbnw/YPDim7MbVS3zw9lWk0hSCd0ilKQTvkErz5w8/0pg6ojBy8wo06pxpdzjZOKTQ3h5l8Na7BO+QSjNAiUlzQc/mwTH9Ng+OKZg0F/yP6bUt0d4epXCycQjtDrQ7nGwcUmhvjzK9tiUoGaBPc3FV3G1eo9/d5jWai6uCF0zQY7MkBu+QSmPSXNCz3pqNlDQXVwU9Nkti8A6pNCbNBT02S2LwDqk0Js3Fw4/ejKe1CcqGd/eZXtsSNkti8A6pNCbNheCczZIYvEMqjUlzQQWbJTF4h1Qak+aCEpslMXiHVBqT5oIKNkti8A6pNCbNBT2CEpslMXiHVJoqwTuk0pg0F1SwWRKDd0ilqRK8QyqNSXPBOUEfmyUxeEcVqTQmzQXPYLMkBu+oIpXGpLmgRFDBZkmkgklzwXOwWRKpYNJc0Ocf3rc3Sx8fzWwAAAAASUVORK5CYII=","w":32,"h":16,"frames":1},"stone_wall":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAAAQCAYAAACm53kpAAACoElEQVR4AeXBMWvjVgDA8b84JfkAuaE31RgCbxD0SfCgS79AyejBmFCKB1PdByj+BK3WDsWgQUMJJoPGjB6KbzmQkd4RBR44uB56ZEmHfoCgWoNABCWxFeeW/n4WezDwg4IWppOxxSsZ+EHBE6aTscWGxQsN/KBwPQclBbsKo5jpZGzxwMAPChpMJ2OLBgM/KHjA9RyUFDRJtCFLc6aTsWWzMfCDgprpZGzRYOAHBTXTydhiQ0nBSwz8oKDG9RyUFNQl2oAfFNRMJ2Nr4AeF6zkoKSgl2lBSUvAYJQVZmlOyBn5QuJ6DkoJSog1ZmtPE9RyUFJQSbcjSHNdzUFLQRqINWZrjeg5KCkqJNigpaJJog5KCUqINWZrjeg5KCiqJNpSUFDwl0YYszbHZUFJQUVLwGCUFFSUFWZqzD0oKdqWkYB/sxXzGaNijjcV8xnq5Iktz2lgvV9zdrhgNe+xbGMU8Zb1ccXe7wuaF3thvaOvudkWTMIp5TJbmVBbzGW/fdcnSnOeMhj0qYRTTOelyd7vCZiOMYupcz6FJGMU85qx/St35xSXbePuuSxjFbGM07FG3mM8orZcrOiddnpJoQxP74PCIh7I0ZxsHh0dU9PUNry3Rhiadky5tHBweYbPx6eMHvvn2O55z1j+l7tPHD2xjNOxRCaOYun//+QwnXc76p9SdX1zSxln/lLrzi0tKWZrTxGbj9/A36sIopom+vqGNRBueo69v2Ad9fcMubDYSbXip/Mrw2rI0p7KYz6islys6J13asPkCsjRnX0bDHqXRsMfox58o/fLrz5TCKGZXNhtZmrON/MrwWvIrwzYSbXgo0YZKfmXYhX3cv4c1rRz374G/YP01bXz1gw3cw5ov7u/Onxx3wPr+j/cF/2P/AVwoAAMqo8TzAAAAAElFTkSuQmCC","w":64,"h":16,"frames":1},"fence":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEYAAAA7CAYAAADGkvybAAAJKklEQVR4Ae3BsWvj+ILA8a88josfPlQ4HBf2wYG5ExwnJFgYUBofRDwwUuqrxFwTGEgXAlaRxi5cOBDSBQJpHF6zf4CCiz0VamwQr0hQcZyXha1MwCkWhMym+Z2VrMHPZDO2M3cxx3w+ClPHtV3pljNyQSo4i/oKKziu7Uq3nJELUsFZ1FdYUeiYkqm9m1uFNYSOKZnau7lVWEPomJKpvZtbhakCU245Q/NsNM/GLWesyi1naJ6N5tm45YxVhY4pNc9G82xCx5SsKHRMqXk2mmcTOqZkRaFjSs2z0Tyb0DElUx9Cx5SaZzNTMarsT7Jmd3jfYgmhY0rNs5mpGFX2J1mzO7xvsYTQMaXm2cxUjCr7k6zZHd63WELomFLzbGYqRpX9SdbsDu9bLCF0TKl5NjMVo8r+JGsWg1SgGxaPdwNyJcMiSPssK0gFumHxeDcgVzIsgrRPLnRMyZy9m1uFBUEq0A2Lx7sBuZJhEaR9XhI6pmTO3s2tEqQC3bB4vBuQKxkWQdpnWUEq0A2Lx7sBuZJhEaR9ikwljTb66Qm5pNEGBKtIGm300xNySaMNCI5ru1I/PeJv3Pw7L0kabfTTE3JJow0IXqKfnjDvOD2XTCWNNvrpCbmk0QYEq0gabfTTE3JJow0Iivzu4fqSt3i4vmTegSV4uL5kWQ/Xl3zJw/Ul8w4swdUgI/dwfclbPFxfMq/IhhglY95ilIx5i1EyZl6BqSAVzASpIFfr1CVfUOvUJVNBKpgJUkHuc2WLq0HG1SDjapBxNchYVOvUJVNBKtjRt9nRtwlSQa7WqUsWXA0yrgYZV4OMq0HG58oWuSAV7Ojb7OjbBKlgVUEq2NG32dG3CVJBrsjvRsmYZ4J1jJIxzwQzsavyNyL+UOXTZ54MzvkjsavyRyqfPvNkcM46Kp8+82RwTq4QuyqLYlcl8nsKXxD5PSV2VRbFrsoyIr+nxK7KothVifyewhJiV2VR7KosK3ZVFsWuisJUrVOXzIn8nsIKap26ZE7k9xRWcFzblf7FEbnO4TlnUV9hBce1XelfHJHrHJ5zFvUVVnBc25X+xRG5zuE5Z1FfKTIV+T2FN4j8nsL/MwW+eVGBb16ksAGOa7vSvzgi1zk85yzqK7yzIhvi4fqSTVLkd6FjSqb2bm4V1hA6pmRq7+ZWYQ2jZMwzwTpCx5RM7d3cKqwhdEzJ1N7NrcLUB6ZCx5SaZ1MxquxPsmZ3eN9iBaFjSs2zqRhV9idZszu8b7GC9r9WmppnUzGqVP7rv+kO71usIHRMqXk2FaPK/iRrdof3LVYQOqbUPJuKUWV/kjW7w/vWh9AxpebZzFSMKvuTrNkd3rdYQuiYUvNsZipGlf1J1uwO71ssIXRMqXk2MxWjyv4ka3aH9y2WEDqm1DybmYpRZX+SNbvD+xZLCB1Tap7NTMWosj/JmsUgFeiGxePdgFzJsAjSPrnQMSWv2Lu5VYJUoBsWj3cDciXDIkj75ELHlLxi7+ZWCVKBblg83g3IlQyLIO2TCx1T8oq9m1slSAW6YfF4NyBXMiyCtE8udEzJK/ZubpUgFeiGxePdgFzJsAjSPspxbVe65Qz99IRc0mgTpIKcf3HEazqH5+TccoZ+ekIuabQJUkHOvzjiNZ3Dc3JuOUM/PSGXNNoEqSDnXxzxms7hOTm3nKGfnpBLGm2CVJDzL454TefwnJxbztBPT8gljTZBKlCOa7vSLWfs6NvkRsmYIBUcWIJlXA0y3HLGjr5NbpSMCVLBgSVYxtUgwy1n7Ojb5EbJmCAVHFiCZVwNMtxyxo6+TW6UjAlSwYElWMbVIMMtZ+zo2+RGyZggFRTZEKNkzCZRjmu7kqkDS5C7GmSs48AS5K4GGcuKXZWPwa/kDixB7mqQsY4DS5C7GmSs48AS5K4GGbkivxslY54JcrGrsoyPwa/kRsmYZ4Jc7KqsovLpM08G5+RiV2UZH4NfyY2SMc8EudhVWcbH4Fdyo2TMM0GuELsqi2JXZVmxq7IodlWWFbsqi2JXZVmxq7IodlWWFbsqi2JXpRj5PYVOXcaozER+T2EVnbqMUZmJ/J7CCj7WdiVzIr+nsIpOXcaozER+T2EVnbqMUZmJ/J6isAGOa7vSvzgi1zk85yzqK7yzAt+8qMA3LyrwzYuKbIiH60s2SZE1hY4pmdq7uVX4CkbJmGeCdYSOKZnau7lV+AoKrCF0TKl5NppnEzqm5I3ccobm2WiejVvOWFXomFLzbDTPJnRMyVfwgRWFjik1z2amYlTZn2TN7vC+xZzQMeV//PM/NLvD+xavCB1Tap7NTMWosj/Jmt3hfYslhI4pNc9mpmJU2Z9kze7wvsUbFFhRkApKhsVMybAIUsG80DGl5tlonk3omJJXBKmgZFjMlAyLIBUsK0gFJcNipmRYBKngrQqsIWm0KRkWJcMiabSZFzqm1DybGc2zCR1T8oqk0aZkWJQMi6TRZlVJo03JsCgZFkmjzddQZE0P15e8JEgFumHxeDcgVzIsgrTPlzxcX/IWD9eXfE0F/hckjTYlw6JkWCSNNssYJWNGyZhN8YEV1Dp1+d3wN4aPW3z/py1yP/zMk61DvfmPf/6n5nfD3xg+bvEvD3dMbv/KDz/zZOtQb/7y408t5tQ6dfnd8DeGj1v82/cqf/f3gh9+5snWod785cefWryi1qnL74a/MXzc4vs/bZH74WeebB3qzV9+/KnFmoqsaZSMeSZ4ySgZ80ywjMqnzzwZnLOOUTLmmeBrKLCCyO8psauyKHZVIr+nRH5PiV2VRbGrEvk9hQWR31NiV2VR7KpEfk/hCyK/p8SuyqLYVYn8nsIbKKyh1qlL5kR+T2FOrVOXzIn8nsIrjmu70r84Itc5POcs6iusoNapS+ZEfk/hjYqsIfJ7Cq+I/J7C/6HI7yl8ZQW+eVGBb15U4JsXFdkQD9eXbJIiG2KUjHkm2ARFNoBbztA8myd/+U/OeH8feGehY0rNs5mpGFX2J1mzO7xv8Y4KvLMgFZQMi5mSYRGkgvdWYAMkjTYlw6JkWCSNNpugyIZ4uL5kkxT45kUF3lGtU5dMBalgJkgFuVqnLnlHRTbEKBnzTLAJCryjyO8psauyKHZVIr+n8I4UNkCtU5fMifyewjv7H1AJquLDPI/SAAAAAElFTkSuQmCC","w":70,"h":59,"frames":1},"cow":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAAAgCAYAAADaInAlAAAE4UlEQVR4nO1aPWgjVxD+JHIggRGHpQNDVKwKbym47lY2HCiVc92pEKRxcBo1SeM6ELhaBK5ykwU1Byk2nXERzpXQpjkCKtVouVNh8AmCimi7TbGax+zP211J1kmO3gdC2r83883MmzfzVoCCgoKCgoKCgoKCgoKCgoKCgsKqOKuUvLNKyZMd/9/xmPjnNzVw70ITxHsXmjj/JYyxCw54LPw3FgDPnjcBAIZWEL/PKiXv8tQTxtmUbGC7DgAeD/+v1hUUR+Ty1BNKAMD7339D76IGALi6vUNdX1dqOnyjm8wBpnBAXa/h3HS8m8+z3Lpy0vgPR+Od5p8aAGmRamgFNKpz1PVa4Pz937cAgOFoLL7reg2248I2ndVYZdTvIR2wLn/CrvKXBgANfHnqYTApwnZcqRJ1vYar2zvYjguKMHI8x9XtHQBgmZm3LQfsC//YADirlLzgwGPYTlRnQyvAdlx0ADSqcwBFAPMA+W4/JyIyyYhxOgDbccA+8ZdmAB5Vdb0GY3IXUIIM1KgC56YDIAfABVBcGCMehlYAAC+sCMcuOGBf+EcCgBcKlDYAoNM8QoMd07XhaCyN0sGkuDCKb8TeYu1pjMb4pv0Dvv3RlBZi23LAvvGXGoAIkFASSAqREegeuu6TRuy6RO0QALzpvoPtuBEnyBxA8uIcwHXletI5Go+Ps3CAVP6+8I8IX0QIGtU5uv1gfBhaAZ3mUSTF8OtkhLABnj1v4k33HX6+/E6c2zUH7CP/yEZQozpPXCvDxQUZLMu9WcgbWkGQ4HrYjovBpCiinsame+i6LP2RA+J04dg3/tIicDApwtDSCydah3zMxTkaYzDxK0/bNAPPJa193X6OjRlEnANkOoZTaJoDOPaFf2z6C6edpMiKA93PU1iW3pfSX7efQ1gXrs8yehDCRpLNPn7vQ/HP2vdvg38gA3BnUR/KycQJ50Louu24aFQpneYyO99PfwDginWNKmx/7Gzkua7LOGBT/LPgIflzvdL4iwBIS4f8OwwyHE9by84aPs4yDuB6cQf4PXF2PFb+cQFIY/nFZBEApO2mtAZYPBBJi0kIK1nXa0DfSX2OyYuVn9UB1AP3LrRFbwzY01krkwLx+qzFfwV5EfDKPmsA0v4D6ZOUhZJeBomnaJD2wbG4ePKyjF9uPuD6ftoCAKNcssJKdRa/n+bw+h8PfyTIioDvgYfrCRlo5td1fwuVWrRV5OMB+JNDVpQfQBp3Qyugrvstqu24FPhWp5k8CZf+P8DJyzIABMjLQLtkYeNkBa9wO80jHOafoH1wjLevXqB9cIzD/BPY01mLZjnd77/xqiWOvSqW4Q9gLf7Uy9uOi/bBsfi8ffUiwp13HhzD0RiGVpC+VMoUAGTMP/91xLeMPDe83wYttxYTbj7P8uT8waSI4WiMX7//Gh8rn/DT9V8RHezprMV7YiJulEvWurPvS/MnZ9FLHkJc8BnlkkU7ffRCiCMtc6b+H4Cvadf30xZuPlgy8oEixI/OtOETwdZvq9MMEozTQWSCcsnKsmRkwTb5E197Omsd5h3rBOXY4KP9Bpb6hQ4ALEBeYyQFgKhCaTMDiDd8WJEwVpyBImXZ01nr3HQsfpz0ICe+ahGILfKnLoAHsCz40rja01krSX6mJvVpDq+zKs+xbupV8jcv/z8Jq/mlVtWhtwAAAABJRU5ErkJggg==","w":32,"h":32,"frames":4},"goat":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAAAgCAYAAADaInAlAAAFEklEQVR4nO1av2siWxT+8nyFnWCagMi0y26nbCcEhsfaGZNGLK0CwoKF/f4DrxACki7FQgYJqBl48LIsQmA27BK0TD8MQpoIdjbiK2bOeO/1zg9nX9ZsZr5qnJx7zvnu+e7PCZAgQYIECRIkSJAgQYIECRJER7WQW1ULuVXY968Nvxv/P57D6WB8D5ZstZBbDcb3zxFqAy+hAL8Tf6kA/o/OquSzrp9KPsv5/hm/YfCzBYgT/z/FF9VCbtWpZ9DS5lsFpYCVfBawugCATj0DABgZAKyu+xvAajiZ7gX58rMJgtPpK+bZ9R0UO078NwQAAErtBNAuQgejTlNqJwCAi4/XUEtL+3e+iUYbgNWF0v5qdwT6gEcnvIQCxIm/VABMY8/pihyI5AGgcXa0NnSSoWez1w/s4F0WgBAX/lIBUJKDdpP/g0PG7NkOuISFtpRI4+wIyDfdtiMjBdVOwBe7LECc+G8IwHG8slXS5xwj33QIAx300dLm3PoCAC1tjkHNftatGRpsW6sL3ZoBBt9GxC4LEDf+oY6BTkDbCeOoU89wanPtvOB0oFpaepoMJ9O9ljaH2evD/PuvdUyra7fPN6G0v7rrmawABN2abcTWrRlGRso/TwGvmb+nAMiIFMWSo2dReeKIGAwd/dM0ZHUxGDb4URUCGwWwus9WAEJc+HtuAsUExE4AgOMqv45W8lnvznU64eLjNQC7c46rF54bsZGRglpacrGp4+w8UtsVwJkG3XdbbLJeM3+pAGgdVJFxg4vk1dJyYy0j8mKybKJqaYmWNocapFYGYgGU2glgXD9bAeLEP/BCRIRsJHiBVyykZ1uvEcDubr3iiWs5S96rADRS6KwdFF/G6TXx9xWAr6J8QIm5Z1EHdD4dGSno1sz3puslFCAO/EMJgNYjlhxB7CDZDpvdjQ7G9zguvg+85nwJBYgDf89NIK2DMLJcIxaVfJbrHALZEQFds/1F/RAStQAjIwUY11zejfY9dC24AHHhH3gKoIsL3ZrhYKHgsLgPALgdP0G3TNtGY8gywVwFOjvO4WS6d1x873sFK5Ij8lELQIhagF3xjyJA2hyy/OnZi3/gRRA7DR0W96G+fYPb8RMOi/s4WCgYTqZlsqXpht7JzrtRvnAR+YOFgtq7AmrvCjhYKNCtmXuxQbHETmqcHbmfZp0CbJXDrvkTH7W09OTf0ubctE9QS8uNQSDy9xPAB3JCRG7HT2vnb99wxiHWqg9BBgRa/5TayeaoEgogiz2cTMvDybSsWzOYvT53WbJFAXbGnyCK6zFt+gqQ7Fg4a71rI/IPnAFYh+cPd+XTq0s8pk2cXl3i/OFuQ/0swu5WZRDXPJEoFYCEAoCOdZwdte/UM5H+GWNX/CERTKeewenVJQBegCR2Ao16Yb8gFaCXANJ+mYn3z14YGSn34iEs2NFv9vqcgs8f7sqfPn/DY9rEP9//tUcEc/kigp0Ftrz/3xl/Mf5wMi3T8U2pnbixP33+xgkQWPcB9Yk4+mXw2gQuWKeyaUWEn11QEiK8drwAWNI3ZKM6X+ZkcZx3N1vmsVP+bHzWv40UHtPmhk/i6Xzr5zaAfgg8BdBRQggUxe5HYDaMLxV96Ja8qOS/WsjdhPm86vj4AWC7f7PBbviLoOJuM/NIii+N7yeAL4Bc7TIE2H0J5QTr44+uhbJdi8AfoeOLbX41f6ENt24H5cLOdsxv3/hhdsRb714ZRCGexP+F8f8DK80QXSXN7rsAAAAASUVORK5CYII=","w":32,"h":32,"frames":4},"pig":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAAAgCAYAAADaInAlAAAEYUlEQVR4nO1aMY/iOhD+9sS/SIWuOQnRbJFfEKStKBZdZSQe5ZNOojvatCmRTroyuxJUp2xB9STyCyjSrJBoEFV+R15BxgyOkxDCHrD4awK28cw3Mx6PHQADAwMDAwMDAwMDAwMDAwMDAwODO4OAlQhYyaX1uBTukX+DPghYyQzxg84AvI2P6dhtAMBi+S776ihD89ad51TZ98i/wQWTEVSFvGEXABCutsASiTfswnIegW9fAQCD9QZxGAH+XLt6aE7VkHzMJR1wz/wbfFKVfMduYzDq7YiuN8BqC5U81htpHG/YRbjaYrF8zxgNwP63ACDcRDXMRzvgxX6S/f8s/3vg/efgP525eJ0EV8tfF4AN3sAHZMgDcFrNPQFGPg4jDEY9xGEkyVs/vgPrDRymyNifo7Pawmk1Mwqe2wEduy2fXqubjP05nFYT4WqLwe+fwL9IdEFQhz+Aq+F/bAA2dIp07PZeyVRABnntgCT/OgngtJrScE7YxNify5Slk03f6zhgOnOBb1/lyghXW3Ts9s4Bdhvxrz+FOtw6/yoB+CWXhY4YEx6HkbadFCPylvMo++mZt1dRex0HdOy2NNrrJACwM9xg1IM37GKxfMfYn5dR1eIW+AOHAQgU89cGgJqitEJU0ik6dlsah8bEYYS+cBGHEbxhFy/2U3JKwfLRDiDcE//SDMAFFbVxASFLM5SCaf+xfnzHYNTDi/2U8KKMo44DuH7ncEAV/oRL8q8agA3dJJxAkaEJcRjJcbQXcRy0rTe7/XnUQ1+4leYuasvTX3UA1QaY7AojXgjqfv/Z+WsD4JzQKRr/+lO4D1+TA+ri2vlntoAZ4geqUnmqo8/qU+3P63udBOgLVxqdjikfjTwH5Dn/3vjn1gDhaqudiLfHYZS7H6pFitNq7s7kwy7G/jx3BVyLA+6FvzYAypQgI6hPXnzoDMiLmxnih6JCrKoD1PGnOoB0uzX+Ko7lX3gKUIlxo3HyTqsp+7jgvtjdTFEEkuCyCvwaHPBZ+VM78S9S5FnACqh6jMNIkqSXEBx07cqNTO8FOLEi4hzqjZzlPKIvXK1scgClNVotfeEepPpjjM9wk/z50Y9uPsnxi+V7RoejTwGp8XoCVqC7ygR2Rji4rkyjje7lq2CGuIclApqPopsMzaGuRho7nbkHxV6d16w3wx+HGYDk6pwPnHgMJEIzxAdnDgEr4EqQsoNRDwtRzQBAagR/HnjpfEhXYJED5F04M5qqZ138Lf7A3qlVAlBXF3jDLuDPMxdgRQHwRh9oQp4SB+gBwg24EShqAciXEJTCpjP34BXoEXgD8AzsjcChc6qAFdBLHy9tS4kHJ6z+i/InLry+IPBU3xeutIUMwFZTBqiAJbPI1HnM6FCaAWhCSqdjfy5XYh64wL5wS8cfAz5f3ormDiC9eeY4BZfkn5kH+6yYN6fi7KBsfGk0qv9QOSadCliB8puz/FXqEjp8dtlVFXuuMPatfEhlGPlnlv8/2KvGFxDmvikAAAAASUVORK5CYII=","w":32,"h":32,"frames":4},"sheep":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAAAgCAYAAADaInAlAAAD4ElEQVR4nO1ZMUgjQRR9OawFi4OTdCfYHFdYWYQQWw0kaG8lpDNwRVIdHh5WSSHE5ghYHXaiKKhtwrJF4CAHIcWF5LqwB1cIFlZCrtC//p3dmd3VeBuz8yDs7O7f/9/7/+/MuAIaGhoaGhoaGhoaGhoaGhoaGhpeWM9kRuuZzEh2Pu2IrX4S2m8djUa3/ZHs/H/xkJ2/dNzY6ReFjm77jjH/9VtHL5aIqAow7foTfkGrlQIWPi6HcjrotFAq13HabCr9BwGJ4jwGnZYnJ4oLYGyxp12/1Gg9kxmlU0l8+vz1CbSdZIgQ79AgBKMsQFz0z6hu5vJZ26Efif29HRjm0HHt5OrQHm+sbtliNla3/HjZBQgrHgAWPi6jWgFQhiPhYQsQB/2eDUDBgWDiB50WDHPoELy/t+OwObk6fBAe/M2MqgBx0v9GdMTFn59d2AT4kYOTG3Ra2N/bsQOIz5FfPzynAPQTY51cHaJUrmNjdUtZgLjpdzUAB3UgJ8JF8WvVSgGlct3Vhdw+l88inUpCtVudhALESb/nm0CbDwAO0Spwu/OzC0fy+Pna5i4+zM9L30KeAO6Dx+Cx+JhvutKppOt54mKYQ99ZIC76XSRUBMSAQbG2uYvL718cz6t2qZNagDB8OCZZv3IJoCmIQyTjZcOviff91jQqgDj9EWTPcjuxcN+Of9jjXz8vUa0UlNOwjLsXn9eu39UAp81mgtYxsYu8QDZ0Xzzm8lm7+73IqhBFAeKmP/AMIArlY5pixGClct117fzsQppMYHILMK36PRuAkxCdikLFgBzpVBKGOXQkIpfPunbKMkRRACBe+pUzgOjcMIeuoABcguicjg2zXaRErG3uomtZyl34pBQgDvqln4IbZrsIoMY3JCK8rhvm0A4s+ru+uzmQxZNBLADgTgbFlHEgLYZZR9eyAAC9Xk/5NS4u+n1nAJlTfhQF0zjshxcOemtIrBeCFOBBPBpmu3jabCZ6vV7Cr/heeK36uT8v/YEaQJzqZEeyo6R7/R0dFqJvvwJUKwXXG/FcRKmf/ARpQJFnkBxIl4Dru5uDhtkGgFouD9uhYQ5tgRwrqaWaeI13aNjpj+KvpJZqNPWJn1u9j492nOdT4yNC/fexH9d8le5qpWDbNcx2kfg85KIm23Mo/x3MhXQtC91jy9eOEMQ+CGjNSuOxm70K8Pb9u/sCmAAVbFwgXfyDisoOGJ9+WuMbZrtoawTw9/cfOwcrqaUatwPuc9S1rJofZ9+1cHFx0f5ixoOKkJF7ysZHxNzM7LbMvx+P58aPUv9zYweJH2ozNDczux3UdhyF1/FfPv4/bH+WH/d8e0kAAAAASUVORK5CYII=","w":32,"h":32,"frames":4},"expr_working":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAJCAYAAAD+WDajAAAAe0lEQVR4AX3BIQ7CMBSA4f9VIFEk4FDULL3FLoPZYTA7x3TDLWo6hyGpRcw+3kIbFgTfJ77r2VBAqBxfmlPEKJXjQ3f3iVAWcooYxTj+cIDOw8hWThGjjh+hLDSOKk1PmlAWVuK7HqPzMNL42xUjcjpcWO2PZ6V6lYdg3lc4I59ODoxcAAAAAElFTkSuQmCC","w":7,"h":9,"frames":1},"expr_chat":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJCAYAAADgkQYQAAAAl0lEQVR4AXXBIQ7EIBAF0D/N3oSkCJB4DNwDRTgSQXGPKjyypoKzzEKyNZv2PWJmSO0Z74h25bjUDGsE/rU+EEPChskagSfWCCwbfqT2WKT2WKT2uNGuHF/ngTdSe2yYWh940vrAQrtymBjTdR5ofSCGhFupmT7XeaD1QTEkbn0ghoRSM1kj0PrAQrty+GFMpWbCFEPC7QuilTX8FBNCZAAAAABJRU5ErkJggg==","w":9,"h":9,"frames":1},"expr_love":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAICAYAAAArzdW1AAAAnElEQVR4AY3BoQ6CQBzA4d8fLVarWQiQCY504woP4DP4GGewmJ2zOh/DTiARLM5McmMXbSc3dOJm8PvEOYcXJdrRE8DRk+vlzMgYQ5RoVxcpy3vD8YGpi5TVfMbh1pjd/rSWMM5dXaRMthuaTONNFyltWeEpC2M6bVlBpnlry4qhgD8EgCjLT8riSUBPlOWLsnhCR8I4Z8DxIbw8AXQqLUQkRBtuAAAAAElFTkSuQmCC","w":9,"h":8,"frames":1},"expr_happy1":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAAWElEQVR4AWXBwQ2AIAxA0V/ihUX0oCtww006Ftt0qB6rJJAYfE8iguO6gz+R/axRWmZl6iQGU6czdabEUFqmKy0zJQZTpzN1psSHqfO1MZSWWcl+Vl7BnzyjQhgK5uvtMgAAAABJRU5ErkJggg==","w":7,"h":8,"frames":1},"expr_happy2":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAAU0lEQVR4AX3BwQ2AIAxA0V/iGr0qCY5Rt+4gvTNIlQQumvieZCbHeSVfInuzDFfeqnUKU7XOUK2zFKZwZQhXlsKPjalaZwlXho0pXHmTvRmP5EtuNVgVgXx3emsAAAAASUVORK5CYII=","w":7,"h":8,"frames":1},"expr_happy3":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAAWklEQVR4AWXB0Q2AIAxAwVfiAEyBJDoGjsVXl+wY3aBKAonRO4kI9vMK/kTK0cLU+ao9k5hqzwy1Z5bEZOoMps6yMdWeWUydIfFi6rwlJlNnMHUWKUfjEfzJDY0RGq8CeSB1AAAAAElFTkSuQmCC","w":7,"h":8,"frames":1},"expr_happy4":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAATklEQVR4AX3B0QmAMAxAwZfgAJ1CP+oUoa7dmbJBlBL6E/BOIoLrfoJK5OwjZqMwByWZs5izKWk2MIfZ2JRkzmLOpvw4SLNRyNkHn6CSF/wxEjJrfJ6AAAAAAElFTkSuQmCC","w":7,"h":8,"frames":1},"expr_alert":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAJCAYAAAAVb42gAAAAUUlEQVR4AV3BQQ2AMAxA0U8zAVNBlmADJfjYabIQgAA4DAcc62C0CUvI3pvmZW38CKYW5b52nPBpz4YTuuPECYOASTnSCaYWpRbFCYOASTnSvdFxEED38Bs6AAAAAElFTkSuQmCC","w":4,"h":9,"frames":1},"expr_confused":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAKCAYAAAB4zEQNAAAAgUlEQVR4AW3BPQrCMBiA4Tchi4uTUDdB/BnskCkn0CXXEDyU4DVyiEw5QCk4urp0jA2kED58HrXdHFl3u4zw/byVOl2uOXnHYnXYw+POub+hEaZhhOeLQtOwIVJMw0hhmNkQ+ccACsjJOySDYENkYahsiDQUM02VvCN5R8tQ2RCRfpREHPzKVmkCAAAAAElFTkSuQmCC","w":7,"h":10,"frames":1},"expr_stress":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAHCAYAAADEUlfTAAAAcElEQVR4AXXBsQ2DMBBA0X+e4KYgBSmoGMAiDQPTWLqSwhWFG5ZA3uBi3CUS74m783p/nD9nSSLDuDjNsc5MW+ZYZ6Ytcws0pnDtmdu1Z0zpZBgX50GgMQVTOlMwpQs0sfIjVrpwliQ0sdLFSneWJF/YPiObmMtAmQAAAABJRU5ErkJggg==","w":7,"h":7,"frames":1},"bar_green":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAAAHCAYAAAALfGMQAAABaUlEQVR4Ae3Bva2dMBiA4dfRnSIDmMIMQBOlMS1TsMLZghE8BRKnwQ2iYQBc4AHozwSOiW4kktyf81GlyPMoMm1sQigGr8i0sQmhGLwi08YmhGLwikwbmxCKwSsybWxCKAavyLSxCaEYvCLTxiaEYvBKaWPTto5IFWXNYVtHpIqy5rCtI1JFWXPY1hGpoqw5bOuIVFHWHLZ1RKooaw7bOiJVlDUvvPr67TvP2ueJs3ZpONxvDz6zzxNn7dJwdr89eM8+T5y1S8Nb7rcHf9rnibN2afjI/fbgl32eOGuXhmfcbw/2eeKsXRqe5aqewxf+++e98GqfJ65yVc9PM2Ku6vnNzNNc1fOmmU+5qudDM+9yVc9TZv7iqh6pF7LODVzVuYGrOjdwVecGrurcwFWdG7iqcwNXKDJtbEIoBq/ItLEJoRi8ItPGJoRi8IpMG5sQisErMm1sQigGr8i0sQmhGLwi08YmhGLw6geicY8OLgR4nQAAAABJRU5ErkJggg==","w":15,"h":7,"frames":7},"bar_blue":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAAAHCAYAAACIuForAAABQElEQVR4Ae3Bv42eMBjA4d8bfS2ZApnCFBnCrEKZSahcUCDWoMJDUOACiylYwDHRnURO9+czxVV5HiFR2kQyBe+ERGkTyRS8ExKlTSRT8E5IlDaRTME7IVHaRDIF74REaRPJFLwTUdrEbZ3JVdUNp22dyVXVDadtnclV1Q2nbZ3JVdUNp22dyVXVDadtnclV1Q0PXvz89ZtnHYvlSoadU9FbvnIslisZdq6K3vKRY7FcybDznqK3vHUslisZdj5T9JZXx2K5kmHnGUVvORbL6Qf/fYsHL47FcldsS/5qLbliW/KP1vKs2Ja8q7V8JbYln2otH4ltyVNay6sHSTdO3NWNE3d148Rd3ThxVzdO3NWNE3cIidImkil4JyRKm0im4J2QKG0imYJ3QqK0iWQK3gmJ0iaSKXgnJEqbSKbgnfwBbUZ5rcXgJssAAAAASUVORK5CYII=","w":15,"h":7,"frames":6},"bar_red":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAAAHCAYAAAALfGMQAAABYklEQVR4Ae3BPa6cMBSA0c/R7ILeRDJVaqQ09iZmTSyBbVDZDRI1FZbAPd3MGhwjvUgoeT9zqVLkHEWhjc0IpRgUhTY2I5RiUBTa2IxQikFRaGMzQikGRaGNzQilGBSFNjYjlGJQFNrYjFCKQSltbN4Wj1TdOA7b4pGqG8dhWzxSdeM4bItHqm4ch23xSNWN47AtHqm6cRy2xSNVN44bb35+/8GrxnXmbG8dh/vjyVfGdeZsbx1n98eTj4zrzNneOt5zfzz507jOnO2t4zP3x5PfxnXmbG8dr7g/nozrzNneOl5VTZ7DN/775914M64zV1WT5zAiV02es5HXVZPnPSNfqybPZ0Y+Vk2eV4z8rZo8UjeKrh+4qusHrur6gau6fuCqrh+4qusHrur6gSsUhTY2I5RiUBTa2IxQikFRaGMzQikGRaGNzQilGBSFNjYjlGJQFNrYjFCKQVFoYzNCKQb1C0kFj3mH+I50AAAAAElFTkSuQmCC","w":15,"h":7,"frames":7},"font_black":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAAAyCAYAAADLLVz8AAAGWUlEQVR4Ae3BwW0kVxIE0IgG/UgkMAakFzqOG7JHpzFCF3kSBghIhCW5H9h/KBSqW00OxeEu+B6+/Bxiy6jBQVvEllGDk7aIg4waHLRFbBk1OGmLOMiowUFbxEFGDQ7aIg4yanDSFrFk1GBpi1gyarC0RWwZNThoi9gyanChLd6wZNTgJKMGD2TUYMuowUlGDR7IqMGWUYOTjBpsGTU4yajBllGDX+QFB20RS0YNLrRFLBk1uNAWsWTU4EJbxJJRgwttEUtGDS60RSwZNbjQFvFGbTGjBktbxEFbxJZRg6UtYnnBK2TU4AltEW+QUYOlLeJCRg2Wtog7MmqwtEV8gBccZNTgSW0Rn1hGTVvEQUYN3iCjBktbxMkNr9AW2yKWjBrckVGTUYNXaottMaMmowYnbbEt4oG2iA/0goO2iCWjBhcyavBARg0eyKjBAxk1+AkZNXigLWLJqMFJRg22jJq2iJOMGpzc8EZtEVtbxElbxANtEVtbxElbxJPaIk7aIt5JW8RBW8SXL58CsWTUYGmLWDJqsLRFLBk1WNoiLmTUYGmLWDJqsLRFLBk1WNoilowaLG0RW0YNDtoiDjJqcNAWcZBRg4O2iIOMGhy0RRxk1OCgLWLLqMGFtnjDSUYN3iijJqMGd2TU4EJGDU4yarBl1OAkowZbRg1OMmqwZdTgJKMGW0YNTjJq8IQbDjJqsLVFfLC22BZxR1tsi7ijLbZF3NEW2yIeaIs4+fH9G398/0ZsbbEtYrnhQlvEK7VFbG0Rd2TU4JNpi9gyatpiW8T22x9/4rc//sSVF7yTjJq2iCWjBv+CjBr8hIwa3NEWM2qwZNS0RTzhhgsZNXggoyajBq/UFvFO2iIeaIt4oC1iy6jJqGmL2DJq8IQbDtoitowanGTUZNTgX5JRk1GDO9piW2yLuJBRk1GDJaMGJ20RW0YNTjJq8Eo3nLRFPKEt4g3aIk7aIk7aIp7UFrG1RTzQFnHSFnHSFvHly6dHLBk1WNoilowaLG0RS0YNlraIJaMGS1vEklGDpS1iyajB0haxZNRgaYtYMmqwtEUsGTVY2iKWjBosbRFLRg0utEX8Yi/4QBk1+D9zwwdoizhpi3hSW2yLbRGfzA0fpC1ia4t4g4wabG0Rn8ALXiGjBne0xYwaLG0xowavlFGDOzJqsLVFfBI3PKEt4qQt4iCjBltGDU4yarBl1OCgLeKkLWLLqMHWFvGJ3HCQUZNRg3eWUYOTjBoctEVsbRF3ZNRk1GTU4BO4YWmLOGmLOGiL2NoiLrTFtog72mJbxJcvX94JsWXU4KAt4iSjBktbxElGDQ7aIg4yanDQFnFHRg2WtoglowYX2iK2jBqctEUsGTW40BaxZdTgoC3iIKMGB20Ryw1LRg1OMmpwkFGDOzJqcJJRgy2jBicZNbiQUYNXyqjBT8iowUlGDbaMGpxk1GB5wUFbxJJRg4OMGjyhLWLJqMGFtoglowYXMmqwtUVcaIu4oy3iQlvEQUYNLrRFLBk1uNAWsWTUYHvBSUYNXqktYsuowUlbxJZRgwsZNdjaIg7aYkYNlowaLG0RJxk12NoiLmTU4KQtZtRk1GBrizjJqMHJDQcZNW0RJ22xLeIfZNRga4t4UkYNth/fvzGjJqMGB22xLWLLqMEDGTU4yajB1haxZdTgJKMGW1vEHTcctEW8UUYNtraIg4yajBosbREP/P7X34OTjJqMGixtEXe0xbaICxk12NoiLrTFtogLbbEttkUcvOAgowYXMmpwkFGDpS1iyajBQUYNlraIg4wa/ISMGjyQUYN/0BZxR0YNLmTU4I4blraIk7aId9IWcdIWsbXFttgW2yJO2iJO2iK2toiTtogntUWctEU80Bbx5csvR3yQjBoctEWcZNRga4s4yajB1hZxkFGDrS3ig9zwjjJqMmpwklGDk4wavEJGDZ6UUYMLGTUZNXhHL/hAbRFLRg3eqC3iQlvEklGDD/SCd9QWcaEtYsuowQfLqMFBRg2WtoglowYX2iL+wQ0fKKMGW1vEHW0R/yNe8AoZNVjaIt7gx/dvxPLbH3/iSlvEv6AtYsmowdIWcdAW8UYvOMiowdIW8QYZNVjaIi78/tffg/8iLmTUYGmLuCOjBktbxEFGDX6BG56UUYOlLeIXaIt4UlvEhbbYFvHl8/gPZ2SsX61aPCgAAAAASUVORK5CYII=","w":80,"h":50,"frames":1},"font_white":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAAAyCAYAAADLLVz8AAAD0UlEQVR4Ae3B0a1TWRZF0bksx1ZEQBzEUqRRREByq2dL++Po6F5jm1fmdctj8PZ7wqhYRIyKTcSiYhExKjYRi4pFxKJiEbGo2ESoQhGqUMSoWESMigPRBVVsKm6oGBWbihsqRsWmYlRsKkbFH3JlEaGKAxGqOBChigMRqjgQoYoDEao4EPGkqEIRi4hRoQhdeUDFHSKeUKGIAxWKOFGhiBe4sqi4U8QnVkUsKp5QoYjNhQdkoIoTHTwoo4NNBjdEvNCVRYQqDlTcUHFDxQ0Vv6HihghVbCpGFbGp2Fx4UsSI2ETcEDEiNhF3ithEfJCIRcTb26cQVKEIVShCFYo4UKEIVShCFYpQhSJGxSJiUbGIWFQsIhYVi4hFxSJiVByILmwqntTBiYoDFZuKUbGpGBWbilGxqRgVm4o7XFhUjIgXy+BEBicyOJHBDRGbn9++5ue3r2FkoAsHIh4UMSJOVHwyEaPKYHz5/oMv339w5MoHqSJU8S+o+A0VJ6IKVRF3uHCg4oYOHhTxQSJuiLghYnREjIo7XFhEjIpNB/+SDk5kwYEOVLGJGBWbigdd2ETcIeIJEZuITcSdIkbEDRGbiE3E29unF1ShCFUoQhWKUIUiVKEIVShCFYpQhSJUoQhVKEIVByL+sCsvVPF/5sILRGwi7pQFn8yFF4kYEU+oGBGfwJUHVJyIKhRVPKjiRMWI+CQu3CFiE7GoGBWbilGxiNhEjIoR8YlcWHTwwSo2FYuIEXGiCz6BC4rYRCwiRsSBDE5k8Pb29kHCqFhEbCoUsalYRCwqFhEnKhShigMRo2IToYoDEaNiEbGoWETogio2FYuKExWbilGxqThQ8aCK31CxqRgVmwpdWUSoYlFxhwhVHIhQxYGKEXEg4kTEgYhFxYEIVRyIUMW4sql4UMSo2ESMigMVI2IRVahCEZuKEXGgYhN1MCI2FZsLiypik8EvVIyIO1WMn9++poNFBqPihopNxYgYFZuKEXHiwiLiSRUjYtGBIm746+9/yqYDRZzI4EDFiDiQwYEsWFxZVByoWFQoQhWLCkUsKn5DxQ0VvxBxouJAxYkLithEfJCITcTIhk3EJmJEbCLuFLGJuCHi7e2PCy9SsYjYVIyITcWIWFSMiBe58IE62FRsKh5QcaeKAx18oCsvFKGKJ0UciFDFC135QBEHIkbFi1UsKhShigMRv3DhhSpGxImI/xFXHlChiCf8/PY16Mv3HxyJ+BdEqEIRi4gnXVlUKOIJFYo48Nff/5T/+p5woEIRJyoUsaj4Ay7cqUIRf0DEnSIOZPD2efwH0L+ovgR1XigAAAAASUVORK5CYII=","w":80,"h":50,"frames":1}}
  var CROPS = [{"key":"beetroot","name":"甜菜根","sprite":"crop_beetroot"},{"key":"cabbage","name":"甘蓝","sprite":"crop_cabbage"},{"key":"cauliflower","name":"花椰菜","sprite":"crop_cauliflower"},{"key":"carrot","name":"胡萝卜","sprite":"crop_carrot"},{"key":"kale","name":"羽衣甘蓝","sprite":"crop_kale"},{"key":"potato","name":"土豆","sprite":"crop_potato"},{"key":"pumpkin","name":"南瓜","sprite":"crop_pumpkin"},{"key":"radish","name":"萝卜","sprite":"crop_radish"},{"key":"parsnip","name":"欧防风","sprite":"crop_parsnip"},{"key":"sunflower","name":"向日葵","sprite":"crop_sunflower"},{"key":"wheat","name":"小麦","sprite":"crop_wheat"}]
  var FONT = {"chars":"ABCDEFGHIJKLMNOPQRSTUVWXYZ\u0001\u0001\u0001\u00010123456789.,:?!()+-","cols":10,"rows":5,"cw":8,"ch":10,"black":"font_black","white":"font_white"}

  // ------------------------------------------------------------------
  // 小工具
  // ------------------------------------------------------------------
  function $(sel, scope) { return (scope || document).querySelector(sel) }
  function h(tag, attrs, children) {
    var el = document.createElement(tag)
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k]
      if (v === undefined || v === null || v === false) return
      if (k === 'style' && typeof v === 'object') Object.assign(el.style, v)
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v)
      else if (k === 'text') el.textContent = v
      else el.setAttribute(k, v === true ? '' : String(v))
    })
    if (children) [].concat(children).forEach(function (c) {
      if (c === null || c === undefined || c === false) return
      el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c)
    })
    return el
  }
  function sprite(name, frame) {
    var meta = SPRITES[name]
    var box = h('div', { class: 'dsf-spr' })
    if (!meta) return box
    box.style.width = meta.w + 'px'
    box.style.height = meta.h + 'px'
    box.style.backgroundImage = "url('" + meta.src + "')"
    box.style.backgroundPosition = (-(frame || 0) * meta.w) + 'px 0px'
    return box
  }
  function setFrame(el, name, frame) {
    var meta = SPRITES[name]
    if (!meta || !el) return
    if (el.__spriteName !== name) {
      el.__spriteName = name
      el.style.backgroundImage = "url('" + meta.src + "')"
      el.style.width = meta.w + 'px'
      el.style.height = meta.h + 'px'
    }
    el.style.backgroundPosition = (-(frame || 0) * meta.w) + 'px 0px'
  }
  function ico(name) {
    return h('span', { class: 'dsf-ico dsf-ico-' + name })
  }
  /** 土地格子：直接使用 SunnysideWorld 的方形 / 圆形泥土贴图（按地块奇偶交替）。 */
  function dirtEl(cls, w, hgt, round) {
    var el = h('div', { class: 'dsf-spr ' + (cls || '') })
    var meta = SPRITES[round ? 'dirt_patch_round' : 'dirt_patch'] || SPRITES.soil
    if (!meta) return el
    el.style.backgroundImage = "url('" + meta.src + "')"
    el.style.backgroundRepeat = 'no-repeat'
    el.style.backgroundSize = '100% 100%'
    el.style.width = w + 'px'
    el.style.height = hgt + 'px'
    return el
  }
  function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v }
  function rand(lo, hi) { return lo + Math.random() * (hi - lo) }
  function pad2(n) { return n < 10 ? '0' + n : '' + n }
  function todayKey() { var d = new Date(); return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) }
  function clampText(s, n) { s = String(s || ''); return s.length > n ? s.slice(0, n - 1) + '…' : s }
  function fmtShort(sec) {
    sec = Math.max(0, Math.round(Number(sec) || 0))
    if (sec >= 3600) return Math.floor(sec / 3600) + 'h' + pad2(Math.floor(sec % 3600 / 60)) + 'm'
    if (sec >= 60) return Math.floor(sec / 60) + 'm' + pad2(sec % 60) + 's'
    return sec + 's'
  }
  function fmtLong(sec) {
    sec = Math.max(0, Math.round(Number(sec) || 0))
    var hh = Math.floor(sec / 3600)
    var mm = Math.floor(sec % 3600 / 60)
    var ss = sec % 60
    if (hh) return hh + ' 小时 ' + mm + ' 分'
    if (mm) return mm + ' 分 ' + ss + ' 秒'
    return ss + ' 秒'
  }

  function hashKey(name) {
    var hash = 2166136261
    for (var i = 0; i < name.length; i++) {
      hash ^= name.charCodeAt(i)
      hash = Math.imul(hash, 16777619)
    }
    return Math.abs(hash)
  }
  var LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')
  var PLOT_COUNT = 26
  var KEY_ROWS = [
    ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
    ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
    ['Z', 'X', 'C', 'V', 'B', 'N', 'M'],
  ]
  var CONTROL_KEY = /^(F\d{1,2}|Enter|Backspace|Escape|Delete|Insert|Home|End|PageUp|PageDown|ArrowLeft|ArrowRight|ArrowUp|ArrowDown|Shift|Control|Alt|Meta|CapsLock|NumLock|ScrollLock|Tab|ContextMenu|OS|Fn|Process|Unidentified|Dead|Spacebar|NumpadEnter)$/

  /** 把任意可打印输入落到 A–Z：字母直接映射，中文/符号按哈希。控制键忽略。 */
  function letterForKey(raw) {
    var s = String(raw === undefined || raw === null ? '' : raw)
    if (!s) return null
    if (s.length === 1) {
      var up = s.toUpperCase()
      if (up >= 'A' && up <= 'Z') return up
      if (s === ' ' || s === '\n' || s === '\t' || s === '\r') return null
      if (s.charCodeAt(0) < 32) return null
      return LETTERS[hashKey(s) % PLOT_COUNT]
    }
    if (s.length > 4) return null
    if (CONTROL_KEY.test(s)) return null
    if (/^[a-z]$/i.test(s)) return s.toUpperCase()
    return LETTERS[hashKey(s) % PLOT_COUNT]
  }
  function cropForLetter(letter) { return CROPS[hashKey(String(letter)) % CROPS.length] }
  function plotIndex(letter) { return LETTERS.indexOf(String(letter || '').toUpperCase()) }
  /** 3 次成熟映射到素材的 6 帧：0 → 0，1 → 2，2 → 4，收割瞬间 → 5。 */
  function cropFrame(stage, harvesting) {
    if (harvesting) return 5
    if (stage >= 3) return 4
    if (stage === 2) return 2
    return 0
  }

  // ------------------------------------------------------------------
  // 位图字体：素材包 8×10 字库只覆盖 ASCII，中文继续用系统字体
  // ------------------------------------------------------------------
  var FONT_CHARS = (FONT && FONT.chars) || ''
  var FONT_COLS = (FONT && FONT.cols) || 10
  var FONT_CW = (FONT && FONT.cw) || 8
  var FONT_CH = (FONT && FONT.ch) || 10
  var FONT_BLACK = (FONT && FONT.black) || 'font_black'
  var FONT_WHITE = (FONT && FONT.white) || 'font_white'

  function glyphIndex(ch) {
    var i = FONT_CHARS.indexOf(String(ch).toUpperCase())
    return i
  }
  function appendBText(parent, text, opts) {
    opts = opts || {}
    var meta = SPRITES[opts.white ? FONT_WHITE : FONT_BLACK]
    var str = String(text === undefined || text === null ? '' : text)
    var lastText = null
    for (var i = 0; i < str.length;) {
      var code = str.codePointAt(i)
      var ch = String.fromCodePoint(code)
      i += ch.length
      // emoji 的变体选择符（U+FE0F / U+FE0E）跟着前一个字符走，不能单独成格
      if (code === 0xFE0F || code === 0xFE0E) {
        if (lastText) lastText.textContent = (lastText.textContent || '') + ch
        continue
      }
      if (ch === '\n') {
        var br = h('br')
        br.textContent = '\n'
        parent.appendChild(br)
        lastText = null
        continue
      }
      if (ch === ' ') {
        var space = h('span', { class: 'dsf-glyph-space' })
        space.textContent = ' '
        parent.appendChild(space)
        lastText = space
        continue
      }
      var idx = glyphIndex(ch)
      if (idx < 0 || !meta) {
        var cjk = h('span', { class: 'dsf-cjk' }, ch)
        parent.appendChild(cjk)
        lastText = cjk
        continue
      }
      var g = h('span', { class: 'dsf-glyph' })
      // 真正的字形是背景图；保留透明文本给读屏、复制与测试使用
      g.textContent = ch
      g.style.backgroundImage = "url('" + meta.src + "')"
      g.style.backgroundPosition = (-(idx % FONT_COLS) * FONT_CW) + 'px ' + (-Math.floor(idx / FONT_COLS) * FONT_CH) + 'px'
      parent.appendChild(g)
      lastText = g
    }
  }
  function btext(text, opts) {
    var el = h('span', { class: 'dsf-btext' + (opts && opts.class ? ' ' + opts.class : '') })
    appendBText(el, text, opts)
    return el
  }
  function setBText(el, text, opts) {
    if (!el) return
    el.innerHTML = ''
    appendBText(el, text, opts)
  }

  // ------------------------------------------------------------------
  // 存档（v5：26 块固定地）
  // ------------------------------------------------------------------
  var COIN_PER_MINUTE = 6
  var HARVEST_COINS = 4
  var KEY_PER_HARVEST = 3
  var HELPER_EVERY = 300
  var HELPER_MAX = 4
  var HELPER_IDLE_RESET = 900
  var DESIGN_W = 300
  var DESIGN_H = 370
  // 农场容器：7×4 格；前 21 格铺满前三行，第四行 5 格居中，左右两个空格放水塘和记录员
  var FIELD = { w: 262, h: 166, x0: 10, y0: 18, dx: 36, dy: 36, cell: 32 }

  function makePlots() {
    return LETTERS.map(function (letter) { return { key: letter, stage: 0, harvestAt: 0 } })
  }

  var state = {
    day: todayKey(),
    coins: 0,
    farmSeconds: 0,
    onlineSeconds: 0,
    keys: {},
    plots: makePlots(),
    helpers: 0,
    helperSeconds: 0,
    lastWorkAt: 0,
    todos: [],
    selectedTask: -1,
    selectedTaskKey: '',
    allTasksDone: false,
    busy: false,
    turns: 0,
    settings: { scale: 1.5, position: 'bottom-left', collapsed: false, autoScale: true, tab: 'farm' },
  }

  function normalizeKeys(src) {
    var out = {}
    if (!src || typeof src !== 'object') return out
    Object.keys(src).forEach(function (raw) {
      var letter = letterForKey(raw)
      if (!letter) return
      var r = src[raw]
      if (!r) return
      var rec = out[letter] || (out[letter] = { n: 0, harvests: 0, name: cropForLetter(letter).name, lastRaw: '' })
      rec.n = Math.max(rec.n, Number(r.n) || 0)
      rec.harvests = Math.max(rec.harvests, Number(r.harvests) || 0)
      if (r.name) rec.name = String(r.name)
      if (r.lastRaw) rec.lastRaw = String(r.lastRaw)
    })
    return out
  }

  function applyPlots(list) {
    if (!Array.isArray(list) || !list.length) return false
    var next = makePlots()
    var used = false
    if (list.length === PLOT_COUNT) {
      list.forEach(function (p, i) {
        if (!p) return
        next[i].stage = clamp(Math.floor(Number(p.stage) || 0), 0, 3)
        next[i].harvestAt = 0
        used = true
      })
    } else {
      list.forEach(function (p) {
        if (!p) return
        var letter = letterForKey(p.key)
        var idx = plotIndex(letter)
        if (idx < 0) return
        next[idx].stage = clamp(Math.floor(Number(p.stage) || 0), 0, 3)
        next[idx].harvestAt = 0
        used = true
      })
    }
    if (used) state.plots = next
    return used
  }

  var saveTimer = null
  function serialize() {
    return {
      v: 5, day: state.day, coins: state.coins, farmSeconds: state.farmSeconds,
      onlineSeconds: state.onlineSeconds, keys: state.keys,
      helpers: state.helpers, helperSeconds: state.helperSeconds, lastWorkAt: state.lastWorkAt,
      plots: state.plots.map(function (p) { return { key: p.key, stage: p.stage } }),
      settings: state.settings, turns: state.turns,
    }
  }
  function persist() {
    try { localStorage.setItem(LS_KEY, JSON.stringify(serialize())) } catch (e) { /* 忽略 */ }
    if (saveTimer) return
    saveTimer = setTimeout(function () {
      saveTimer = null
      fetch(PREFIX + '/api/mutate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: serialize() }),
      }).catch(function () { /* 宿主不可达也不影响本地 */ })
    }, 1000)
  }

  function loadLocal() {
    var raw = null
    try { raw = localStorage.getItem(LS_KEY) } catch (e) { raw = null }
    if (!raw) {
      try { raw = localStorage.getItem(LS_KEY_V4) } catch (e) { raw = null }
    }
    if (!raw) return
    try {
      var d = JSON.parse(raw)
      if (!d) return
      if (d.day !== state.day) {
        state.coins = Math.max(state.coins, Number(d.coins) || 0)
        return
      }
      state.coins = Math.max(state.coins, Number(d.coins) || 0)
      state.farmSeconds = Number(d.farmSeconds) || 0
      state.onlineSeconds = Number(d.onlineSeconds) || 0
      state.helpers = clamp(Math.floor(Number(d.helpers) || 0), 0, HELPER_MAX)
      state.helperSeconds = clamp(Number(d.helperSeconds) || 0, 0, HELPER_EVERY)
      state.lastWorkAt = Number(d.lastWorkAt) || 0
      if (state.lastWorkAt && Date.now() - state.lastWorkAt > HELPER_IDLE_RESET * 1000) {
        state.helpers = 0
        state.helperSeconds = 0
        state.lastWorkAt = 0
      }
      state.keys = normalizeKeys(d.keys)
      applyPlots(d.plots)
      if (d.settings && typeof d.settings === 'object') Object.assign(state.settings, d.settings)
      if (typeof d.turns === 'number') state.turns = d.turns
    } catch (e) { /* 坏档当新的一天 */ }
  }

  function rollover() {
    var today = todayKey()
    if (today === state.day) return
    state.day = today
    state.farmSeconds = 0
    state.onlineSeconds = 0
    state.keys = {}
    state.plots = makePlots()
    state.selectedTask = -1
    state.selectedTaskKey = ''
    typingUntil = 0
    workUntil = 0
    actionQueue.length = 0
    claims = {}
    clearHelperJobs()
    persist()
    say('新的一天！昨天的收成入库了', 3200, 1)
    renderKeys(); renderPlots(); renderHeader(); renderUsageView()
  }

  /** 服务端存档是跨浏览器/桌面端的权威副本；同一天时合并进当前状态。 */
  function applySnapshot(d) {
    if (!d) return false
    if (Number.isFinite(Number(d.coins))) state.coins = Math.max(state.coins, Number(d.coins))
    if (d.day !== state.day) { renderHeader(); return false }
    if (Number.isFinite(Number(d.farmSeconds))) state.farmSeconds = Math.max(state.farmSeconds, Number(d.farmSeconds))
    if (Number.isFinite(Number(d.onlineSeconds))) state.onlineSeconds = Math.max(state.onlineSeconds, Number(d.onlineSeconds))
    if (Number.isFinite(Number(d.helpers))) state.helpers = clamp(Math.max(state.helpers, Math.floor(Number(d.helpers))), 0, HELPER_MAX)
    if (Number.isFinite(Number(d.helperSeconds))) state.helperSeconds = Math.max(state.helperSeconds, Number(d.helperSeconds))
    if (Number.isFinite(Number(d.lastWorkAt))) state.lastWorkAt = Math.max(state.lastWorkAt, Number(d.lastWorkAt))
    var remoteKeys = normalizeKeys(d.keys)
    Object.keys(remoteKeys).forEach(function (letter) {
      var local = state.keys[letter]
      if (!local) { state.keys[letter] = remoteKeys[letter]; return }
      local.n = Math.max(local.n || 0, remoteKeys[letter].n || 0)
      local.harvests = Math.max(local.harvests || 0, remoteKeys[letter].harvests || 0)
      if (!local.name) local.name = remoteKeys[letter].name
    })
    applyPlots(d.plots)
    if (d.settings && typeof d.settings === 'object') Object.assign(state.settings, d.settings)
    if (typeof d.turns === 'number') state.turns = d.turns
    renderHeader(); renderPlots(); renderKeys(); renderTasksView(); renderUsageView(); applySettings()
    return true
  }

  // ------------------------------------------------------------------
  // 气泡 / 粒子 / 忙碌判定
  // ------------------------------------------------------------------
  var bubbleEl = null
  var heraldEl = null
  var heraldText = null
  var heraldTimer = null
  var heraldTypeTimer = null
  var heraldSeq = 0
  var heraldScaleSaved = null
  var heraldScaleTimer = null
  var audioCtx = null
  var lastDoneAnnounceAt = 0
  var bubbleText = ''
  var bubbleUntil = 0
  var bubblePosAt = 0
  var sparks = []
  var sparksLayer = null
  var typingUntil = 0
  var workUntil = 0
  var clerkWorkUntil = 0
  var lastTypingBubbleAt = 0
  var lastFarmBubbleAt = 0
  var workBubbleUntil = 0
  var lookTimer = 0

  function say(text, ms, priority) {
    var p = Number(priority) || 0
    var now = Date.now()
    if (now < workBubbleUntil && p < 2) return false
    if (p >= 2) workBubbleUntil = 0
    bubbleText = String(text || '')
    bubbleUntil = now + (ms || 3000)
    renderBubble()
    return true
  }

  function sayWork(text, ms) {
    var now = Date.now()
    workBubbleUntil = now + (ms || 3000)
    bubbleText = String(text || '')
    bubbleUntil = workBubbleUntil
    renderBubble()
  }

  function ensureAudio() {
    try {
      var AC = window.AudioContext || window.webkitAudioContext
      if (!AC) return null
      if (!audioCtx) audioCtx = new AC()
      if (audioCtx.state === 'suspended' && typeof audioCtx.resume === 'function') {
        audioCtx.resume().catch(function () { /* 浏览器未授权时静默 */ })
      }
      return audioCtx
    } catch (e) {
      return null
    }
  }

  /** 任务完成的小音效：E5 → G5 → C6，短三角波，不占资源。 */
  function playChime() {
    var ctx = ensureAudio()
    if (!ctx) return
    try {
      var notes = [659.25, 783.99, 1046.5]
      var start = ctx.currentTime + 0.02
      notes.forEach(function (freq, i) {
        var t = start + i * 0.12
        var osc = ctx.createOscillator()
        var gain = ctx.createGain()
        osc.type = 'triangle'
        osc.frequency.setValueAtTime(freq, t)
        gain.gain.setValueAtTime(0.0001, t)
        gain.gain.exponentialRampToValueAtTime(0.11, t + 0.025)
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.22)
        osc.connect(gain)
        gain.connect(ctx.destination)
        osc.start(t)
        osc.stop(t + 0.24)
      })
    } catch (e) { /* 音频失败不影响 UI */ }
  }

  /**
   * 任务 / 软件切换时，小人从床头的木牌后跳出来，举牌把新内容写出来。
   * kind = task | app；牌子文字逐字显示，几秒后跳回去。
   */
  function showHerald(kind, text, ms) {
    if (!heraldEl || !heraldText) return
    var label = (kind === 'task' ? '任务' : '软件') + '：' + clampText(text || '', 20)
    if (DESKTOP && window.dsfDesktop && typeof window.dsfDesktop.showHerald === 'function') {
      // 主进程会把透明窗口向右扩宽给小人腾位置；先把缩放锁住，避免窗口一变宽农场跟着放大
      if (!window.dsfDesktop.selfTest) {
        if (!heraldScaleSaved) {
          heraldScaleSaved = { autoScale: state.settings.autoScale, scale: state.settings.scale }
          state.settings.autoScale = false
          state.settings.scale = currentScaleValue
          applySettings()
        }
        if (heraldScaleTimer) clearTimeout(heraldScaleTimer)
        heraldScaleTimer = setTimeout(function () {
          heraldScaleTimer = null
          if (!heraldScaleSaved) return
          state.settings.autoScale = heraldScaleSaved.autoScale
          state.settings.scale = heraldScaleSaved.scale
          heraldScaleSaved = null
          applySettings()
        }, (ms || 3800) + 700)
      }
      window.dsfDesktop.showHerald(kind, label, ms || 3800, Math.ceil(frameEl.getBoundingClientRect().width) + 260)
    }
    var seq = ++heraldSeq
    if (heraldTimer) { clearTimeout(heraldTimer); heraldTimer = null }
    if (heraldTypeTimer) { clearInterval(heraldTypeTimer); heraldTypeTimer = null }
    heraldEl.classList.remove('dsf-herald-on', 'dsf-herald-out')
    // 强制重排，保证同一个元素可以连续播放两次跳出动画
    void heraldEl.offsetWidth
    heraldEl.classList.add('dsf-herald-on')
    heraldText.textContent = ''
    var chars = Array.from ? Array.from(label) : label.split('')
    var i = 0
    heraldTypeTimer = setInterval(function () {
      if (seq !== heraldSeq || !heraldText) {
        clearInterval(heraldTypeTimer)
        heraldTypeTimer = null
        return
      }
      i += 1
      heraldText.textContent = chars.slice(0, i).join('')
      if (i >= chars.length) {
        clearInterval(heraldTypeTimer)
        heraldTypeTimer = null
      }
    }, 34)
    heraldTimer = setTimeout(function () {
      if (seq !== heraldSeq) return
      heraldEl.classList.add('dsf-herald-out')
      setTimeout(function () {
        if (seq !== heraldSeq) return
        heraldEl.classList.remove('dsf-herald-on', 'dsf-herald-out')
        if (heraldText) heraldText.textContent = ''
      }, 450)
    }, ms || 3800)
  }
  function sparkle(x, y) { sparks.push({ x: x, y: y, life: 1 }) }

  function renderSparks() {
    if (!sparksLayer) return
    while (sparksLayer.firstChild) sparksLayer.removeChild(sparksLayer.firstChild)
    sparks = sparks.filter(function (s) { s.life -= 0.06; return s.life > 0 })
    sparks.forEach(function (s) {
      var el = h('div', { class: 'dsf-spark' }, '✦')
      el.style.left = Math.round(s.x - 4) + 'px'
      el.style.top = Math.round(s.y - 8 - (1 - s.life) * 10) + 'px'
      el.style.opacity = String(clamp(s.life, 0, 1))
      sparksLayer.appendChild(el)
    })
  }

  function workingNow() {
    // 待办全部完成就视为这一轮收工，不再自动种地/提示忙碌
    if (state.allTasksDone) return false
    if (host.busy || host.harness) return true
    if (Date.now() < typingUntil || Date.now() < workUntil) return true
    var app = host.workApp || (host.usage && host.usage.current)
    return !!(app && !app.ignored)
  }

  // ------------------------------------------------------------------
  // 宿主状态（SSE 推送）
  // ------------------------------------------------------------------
  var host = {
    ready: false, busy: false, attention: null, todos: [], activeId: null,
    lastAssistant: null, usage: null, workApp: null, harness: false,
    harnessNames: [], source: 'dsh', totalPending: 0, todosFallback: false,
  }
  var lastAttentionKey = ''
  var lastBusy = false
  var lastHarness = false
  var lastSwitchAt = 0
  var lastAppKey = ''
  var lastTaskKey = ''
  var taskInitialized = false
  var introShown = false
  var headerCoins = null
  var headerCoinsText = null
  var lastStatusKey = ''
  var lastUsageKey = ''

  function applyHostState(payload) {
    if (!payload || payload.ok !== true) return
    host.ready = true
    var nextActive = payload.activeSessionId || null
    if (nextActive !== host.activeId) {
      // 不要重置 lastTaskKey：从任务页/另一个会话切回来时，
      // 只要当前任务真的变了，也要能举牌。
      host.todos = []
    }
    host.activeId = nextActive
    var sessions = Array.isArray(payload.sessions) ? payload.sessions : []
    var active = null
    for (var i = 0; i < sessions.length; i++) {
      if (sessions[i].id === host.activeId) { active = sessions[i]; break }
    }
    if (!active && sessions.length) active = sessions[0]

    host.harness = !!payload.harness
    host.harnessNames = Array.isArray(payload.harnessNames) ? payload.harnessNames : []
    host.source = String(payload.source || 'dsh')
    var nextName = String(payload.userName || '').trim().slice(0, 16)
    if (nextName !== hostUserName) {
      hostUserName = nextName
      renderFarmTitle()
    }
    host.usage = payload.usage && typeof payload.usage === 'object' ? payload.usage : null
    host.workApp = payload.workApp && typeof payload.workApp === 'object'
      ? payload.workApp
      : (host.usage && host.usage.current ? host.usage.current : null)
    host.totalPending = Number(payload.totalPending) || 0

    if (active) {
      host.busy = !!active.busy || !!host.harness
      host.lastAssistant = active.lastAssistant || null
      // 当前会话还没写过 todo/write（null）时，退回最近一轮有待办的会话；
      // 如果它是明确的空数组，说明用户清空了待办，不要拿旧会话的待办回来。
      var todoSession = active
      var fallback = false
      if (todoSession && todoSession.todos === null) {
        for (var s = 0; s < sessions.length; s++) {
          if (Array.isArray(sessions[s].todos) && sessions[s].todos.length) {
            todoSession = sessions[s]
            fallback = true
            break
          }
        }
      }
      if (todoSession && Array.isArray(todoSession.todos)) {
        host.todos = todoSession.todos.map(function (t) {
          return { content: clampText(t.content, 200), status: String(t.status || 'pending') }
        }).filter(function (t) { return t.content })
        host.todosFallback = fallback && todoSession.id !== active.id
        noteTaskSwitch(host.todos)
        renderPlots()
        renderTasksView()
      } else if (active) {
        host.todos = []
        host.todosFallback = false
        renderTasksView()
      }
    } else {
      host.busy = !!host.harness
    }

    state.attention = payload.attention || null
    var key = state.attention ? (state.attention.kind + '|' + state.attention.at + '|' + state.attention.text) : ''
    if (state.attention && key !== lastAttentionKey) {
      lastAttentionKey = key
      lookTimer = 9
      say('老乡，有个事要你处理…\n' + clampText(state.attention.text, 40), 9000, 3)
      renderBadge()
    }
    if (!state.attention) { lastAttentionKey = ''; renderBadge() }

    var current = host.usage && host.usage.current
    var switchAt = Number(current && (current.switchedAt || current.since)) || Number(host.workApp && host.workApp.at) || 0
    if (switchAt && switchAt !== lastSwitchAt) {
      lastSwitchAt = switchAt
      if (!(current && current.ignored)) {
        workUntil = Date.now() + 3000
        clerkWorkUntil = Date.now() + 3000
        sayWork('工作中', 3000)
      }
    }
    // 用软件名变化做兜底：有些宿主只更新 workApp / current.name，不更新 switchedAt。
    var appNow = current || host.workApp || null
    var appLabel = appNow ? String(appNow.name || appNow.process || '') : ''
    var appIgnored = !!(appNow && appNow.ignored)
    var appKey = appLabel + (appIgnored ? '|ignored' : '')
    if (appLabel && !appIgnored && appKey !== lastAppKey) {
      lastAppKey = appKey
      workUntil = Date.now() + 3000
      clerkWorkUntil = Date.now() + 3000
      sayWork('工作中', 3000)
      showHerald('app', appLabel, 3200)
    }

    if (host.harness && !lastHarness) {
      // 新一轮 harness 开工：即使上一组待办已经全部完成，也重新进入工作状态
      state.allTasksDone = false
      if (!bubbleText) say('检测到 harness，开工！', 3000, 2)
      workUntil = Date.now() + 3000
    }
    lastHarness = host.harness

    if (lastBusy && !host.busy) {
      if (!state.allTasksDone) {
        lookTimer = Math.max(lookTimer, 3)
        var tip = host.lastAssistant && host.lastAssistant.text ? clampText(host.lastAssistant.text, 36) : ''
        say(tip ? '这轮忙完啦：' + tip : '这轮忙完啦，来看看结果～', 4200, 2)
      }
    }
    lastBusy = host.busy
    state.busy = host.busy && !state.allTasksDone

    if (!introShown && host.todos.length) {
      introShown = true
      setTimeout(showIntro, 400)
    }
    renderHeader()
    renderUsageView()
  }

  /** 所有待办都完成，或一轮任务真正结束时，统一喊「任务完成了」并播放音效。 */
  function announceTaskDone() {
    var now = Date.now()
    if (now - lastDoneAnnounceAt < 8000) return
    lastDoneAnnounceAt = now
    state.allTasksDone = true
    actionQueue.length = 0
    lookTimer = Math.max(lookTimer, 4)
    say('老乡，任务完成了！', 6000, 3)
    showHerald('task', '任务完成', 4500)
    playChime()
  }

  /** 当前任务从「进行中」换到下一项时，小人提醒老乡。 */
  function noteTaskSwitch(todos) {
    var current = null
    for (var i = 0; i < todos.length; i++) {
      if (todos[i].status === 'in_progress') { current = todos[i]; break }
    }
    if (!current) {
      for (var j = 0; j < todos.length; j++) {
        if (todos[j].status !== 'completed') { current = todos[j]; break }
      }
    }
    var allDone = todos.length > 0 && todos.every(function (todo) { return todo.status === 'completed' })
    var wasAllDone = state.allTasksDone
    state.allTasksDone = allDone
    var key = current ? (current.status + '|' + current.content) : ''
    if (!taskInitialized) {
      taskInitialized = true
      lastTaskKey = key
      return
    }
    if (allDone) {
      if (!wasAllDone) announceTaskDone()
      lastTaskKey = ''
      return
    }
    if (key && key !== lastTaskKey) {
      lookTimer = Math.max(lookTimer, 3.2)
      say('老乡，我该做下一步了\n' + clampText(current.content, 30), 4200, 2)
      showHerald('task', current.content, 4200)
    }
    lastTaskKey = key
  }

  function pollState() {
    fetch(PREFIX + '/api/state', { cache: 'no-store' })
      .then(function (r) { return r.json() })
      .then(applyHostState)
      .catch(function () { /* 宿主重启中 */ })
  }

  /** SSE 推送：待办/忙碌/提问/软件切换一发生就推；断线才退回 1 秒轮询。 */
  var sse = null
  var sseRetry = 0
  var fallbackTimer = null
  function startStream() {
    if (typeof EventSource !== 'function') { startFallback(); return }
    try {
      sse = new EventSource(PREFIX + '/api/events')
    } catch (e) { startFallback(); return }
    sse.onmessage = function (event) {
      sseRetry = 0
      try { applyHostState(JSON.parse(event.data)) } catch (e) { /* 坏帧忽略 */ }
    }
    sse.onerror = function () {
      sseRetry += 1
      if (sseRetry > 6) {
        try { sse.close() } catch (e) {}
        sse = null
        startFallback()
      }
    }
  }
  function startFallback() {
    if (fallbackTimer) return
    pollState()
    fallbackTimer = setInterval(function () { if (!document.hidden) pollState() }, 1000)
  }

  // ------------------------------------------------------------------
  // 玩法：26 块固定地
  // ------------------------------------------------------------------
  function onKey(raw) {
    rollover()
    var letter = letterForKey(raw)
    if (!letter) return
    var now = Date.now()
    typingUntil = now + 3000
    if (now > lastTypingBubbleAt + 1400 || !bubbleText) {
      lastTypingBubbleAt = now
      say('干活中', 3000, 1)
    }
    var crop = cropForLetter(letter)
    var rec = state.keys[letter] || (state.keys[letter] = { n: 0, harvests: 0, name: crop.name, lastRaw: '' })
    rec.n += 1
    rec.name = crop.name
    rec.lastRaw = String(raw)
    rec.lastAt = now

    var idx = plotIndex(letter)
    var plot = state.plots[idx]
    if (!plot) return
    if (plot.harvestAt) { renderKeys(); renderPlots(); persist(); return }
    if (plot.stage >= 3) {
      harvestPlot(idx, 'manual')
    } else {
      plot.stage = clamp(plot.stage + 1, 0, 3)
      if (plot.stage >= 3) harvestPlot(idx, 'manual')
      else {
        sparkleAtPlot(idx)
        enqueueAction(idx, 'visit', false)
      }
    }
    renderKeys(); renderPlots(); renderHeader(); renderUsageStats(); persist()
  }

  /** 自动劳动到地后推进一阶段；成熟时立刻结算金币。 */
  function advancePlot(idx, source) {
    var plot = state.plots[idx]
    if (!plot || plot.harvestAt) return false
    if (plot.stage >= 3) return harvestPlot(idx, source)
    plot.stage = clamp(plot.stage + 1, 0, 3)
    if (plot.stage >= 3) return harvestPlot(idx, source)
    var crop = cropForLetter(plot.key)
    sparkleAtPlot(idx)
    if (source === 'auto' && Date.now() > lastFarmBubbleAt + 4200) {
      lastFarmBubbleAt = Date.now()
      say('给 ' + crop.name + ' 浇了点水', 1600)
    }
    renderPlots(); renderKeys(); renderHeader(); renderFieldStats(); persist()
    return true
  }

  /** 收割：金币立刻到账，地保留 0.9 秒成熟动画后由 tickHarvest 清空。 */
  function harvestPlot(idx, source) {
    var plot = state.plots[idx]
    if (!plot || plot.harvestAt) return false
    var crop = cropForLetter(plot.key)
    plot.stage = 3
    plot.harvestAt = Date.now() + 900
    state.coins += HARVEST_COINS
    var rec = state.keys[plot.key]
    if (rec) rec.harvests = (rec.harvests || 0) + 1
    if (Date.now() > lastFarmBubbleAt + 1000) {
      lastFarmBubbleAt = Date.now()
      // 手动收割是玩家动作，优先盖过「工作中」这类后台提示
      say('收获 ' + crop.name + ' +' + HARVEST_COINS + ' 金币', 2200, source === 'manual' ? 2 : 0)
    }
    sparkleAtPlot(idx)
    renderPlots(); renderKeys(); renderHeader(); renderFieldStats(); persist()
    return true
  }

  function sparkleAtPlot(idx) {
    var c = plotCenter(idx)
    sparkle(c.x, c.y - 4)
  }

  function plotPos(idx) {
    var col = idx % 7
    var row = Math.floor(idx / 7)
    // 第四行只有 V–Z 五块，往中间挪一格，左右对称各留一个空格
    if (row === 3) col += 1
    return { x: FIELD.x0 + col * FIELD.dx, y: FIELD.y0 + row * FIELD.dy }
  }
  function plotCenter(idx) {
    var pos = plotPos(idx)
    return { x: pos.x + FIELD.cell / 2, y: pos.y + FIELD.cell / 2 }
  }

  // ------------------------------------------------------------------
  // 角色状态机：walk → arrive → act（完整 8 帧）→ happy（1 秒）→ pause
  // ------------------------------------------------------------------
  var ACT_DUR = 0.72
  var HAPPY_DUR = 1.0
  var PAUSE_DUR = 0.14
  var WALK_FRAME = 0.085
  var ACT_FRAME = ACT_DUR / 8
  var IDLE_FRAME = 0.26
  var HAPPY_NAMES = ['expr_happy1', 'expr_happy2', 'expr_happy3', 'expr_happy4']
  var HELPER_NAMES = ['cow', 'goat', 'pig', 'sheep']

  function makeActor(kind, index) {
    return {
      kind: kind, index: index,
      x: 120, y: 160, tx: 120, ty: 160,
      dir: 'down', phase: 'idle', phaseT: 0, frame: 0, frameT: 0,
      moving: false, onArrive: null, job: null, nextAt: 0,
      speed: kind === 'farmer' ? 34 : 30,
      el: null, emoteEl: null, emoteVisible: false,
    }
  }
  var farmer = makeActor('farmer', 0)
  farmer.x = 112; farmer.y = 158; farmer.tx = 112; farmer.ty = 158
  var helperActors = []
  var helperEls = []
  var helpersLayer = null
  var farmerEl = null
  var clerkEl = null
  var clerkLabel = null

  function dirFor(a, dx, dy) {
    if (a.kind === 'helper') {
      if (Math.abs(dx) > 1) return dx > 0 ? 'right' : 'left'
      return a.dir === 'right' || a.dir === 'left' ? a.dir : 'right'
    }
    var ax = Math.abs(dx)
    var ay = Math.abs(dy)
    if (ax < 1.5 && ay < 1.5) return a.dir
    // 斜着走时优先保持纵向：往上/下走就用人物的背面/正面，
    // 不要因为横向分量只多一点就切成左右帧，看起来像“反着走”。
    if (ay >= ax * 0.72) return dy >= 0 ? 'down' : 'up'
    return dx >= 0 ? 'right' : 'left'
  }

  function startJob(a, idx, auto, kind) {
    if (!a || idx < 0 || idx >= PLOT_COUNT) return false
    var c = plotCenter(idx)
    a.job = { idx: idx, auto: !!auto, kind: kind || 'auto' }
    claimPlot(idx, a)
    a.tx = clamp(c.x + rand(-2, 2), 16, FIELD.w - 16)
    a.ty = clamp(c.y + 12, 8, FIELD.h - 10)
    a.dir = dirFor(a, a.tx - a.x, a.ty - a.y)
    a.phase = 'walk'
    a.phaseT = 0
    a.frame = 0
    a.frameT = 0
    a.moving = true
    return true
  }

  function finishAct(a) {
    var job = a.job
    if (job && job.auto && job.idx >= 0 && job.idx < PLOT_COUNT) {
      advancePlot(job.idx, a.kind === 'helper' ? 'helper' : 'auto')
    }
    if (job) releasePlot(job.idx, a)
    a.job = null
    var shown = showEmote(a)
    if (shown) {
      a.phase = 'happy'
      a.phaseT = 0
      a.frame = 0
      a.frameT = 0
    } else {
      a.phase = 'pause'
      a.phaseT = 0
    }
    a.nextAt = Date.now() + (a.kind === 'helper' ? rand(700, 1900) : rand(400, 1000))
  }

  function showEmote(a) {
    if (!a || !a.emoteEl) return false
    var name = a.kind === 'farmer'
      ? HAPPY_NAMES[Math.floor(Math.random() * HAPPY_NAMES.length)]
      : (SPRITES.expr_love ? 'expr_love' : null)
    if (!name || !SPRITES[name]) { a.emoteVisible = false; return false }
    setFrame(a.emoteEl, name, 0)
    a.emoteEl.style.display = 'block'
    a.emoteVisible = true
    return true
  }
  function hideEmote(a) {
    if (!a || !a.emoteEl) return
    a.emoteVisible = false
    a.emoteEl.style.display = 'none'
  }

  function updateActor(a, dt) {
    if (!a) return
    if (a.phase === 'walk') {
      var dx = a.tx - a.x
      var dy = a.ty - a.y
      var dist = Math.sqrt(dx * dx + dy * dy)
      if (dist > 0.5) {
        var step = Math.min(dist, a.speed * dt)
        a.x += dx / dist * step
        a.y += dy / dist * step
        a.moving = true
        // 方向在起步时按整段位移定好，走路过程中不再按单帧 dx/dy 反复翻面
      } else {
        a.x = a.tx
        a.y = a.ty
        a.moving = false
        a.phase = 'act'
        a.phaseT = 0
        a.frame = 0
        a.frameT = 0
        var cb = a.onArrive
        a.onArrive = null
        if (cb) cb()
      }
    } else {
      a.moving = false
    }

    if (a.phase === 'act') {
      a.phaseT += dt
      if (a.phaseT >= ACT_DUR) finishAct(a)
    } else if (a.phase === 'happy') {
      a.phaseT += dt
      if (a.phaseT >= HAPPY_DUR) {
        hideEmote(a)
        a.phase = 'pause'
        a.phaseT = 0
      }
    } else if (a.phase === 'pause') {
      a.phaseT += dt
      if (a.phaseT >= PAUSE_DUR) {
        a.phase = 'idle'
        a.phaseT = 0
        a.frame = 0
        a.frameT = 0
      }
    }

    a.frameT += dt
    var dur = IDLE_FRAME
    var count = 9
    if (a.phase === 'walk') { dur = WALK_FRAME; count = 8 }
    else if (a.phase === 'act') { dur = ACT_FRAME; count = 8 }
    if (a.kind === 'helper') count = 4
    while (a.frameT >= dur) { a.frameT -= dur; a.frame = (a.frame + 1) % count }
  }

  function drawActor(a) {
    if (!a || !a.el) return
    var name
    if (a.kind === 'farmer') {
      if (a.phase === 'walk') name = 'farmer_walk_' + a.dir
      else if (a.phase === 'act') name = 'farmer_act_' + a.dir
      else name = 'farmer_idle_' + a.dir
      setFrame(a.el, name, a.frame % 9)
      // 左右帧在素材阶段已按朝向生成（原画脸朝右），页面不再翻转；只整体放大一点
      a.el.style.transform = 'scale(1.3)'
      a.el.style.left = Math.round(a.x - 32) + 'px'
      a.el.style.top = Math.round(a.y - 30) + 'px'
      a.el.classList.toggle('dsf-acting', a.phase === 'act')
      a.el.classList.toggle('dsf-looking', lookTimer > 0)
    } else {
      name = HELPER_NAMES[a.index]
      setFrame(a.el, name, a.frame % 4)
      a.el.style.transform = a.dir === 'left' ? 'scaleX(-1)' : 'none'
      a.el.style.left = Math.round(a.x - 16) + 'px'
      a.el.style.top = Math.round(a.y - 28) + 'px'
    }
    if (a.emoteEl) {
      a.emoteEl.style.left = Math.round(a.x - 7) + 'px'
      a.emoteEl.style.top = Math.round(a.y - 46) + 'px'
    }
  }

  // 地权：同一块地同时只让一个角色干活，避免小人和帮手抢同一格
  var claims = {}
  function claimPlot(idx, a) {
    var now = Date.now()
    claims[idx] = { by: a, at: now }
  }
  function releasePlot(idx, a) {
    var c = claims[idx]
    if (!c || c.by === a) delete claims[idx]
  }
  function claimedByOther(idx, a) {
    var c = claims[idx]
    if (!c) return false
    if (Date.now() - c.at > 30000) { delete claims[idx]; return false }
    return c.by !== a
  }

  var actionQueue = []
  function enqueueAction(idx, kind, auto) {
    if (idx < 0 || idx >= PLOT_COUNT) return
    var last = actionQueue[actionQueue.length - 1]
    if (last && last.idx === idx && last.kind === kind && !!last.auto === !!auto) return
    actionQueue.push({ idx: idx, kind: kind, auto: !!auto })
    if (actionQueue.length > 8) actionQueue.shift()
  }
  function clearHelperJobs() {
    helperActors.forEach(function (a) {
      if (a.job) releasePlot(a.job.idx, a)
      a.job = null
      a.phase = 'idle'
      a.phaseT = 0
      a.moving = false
      hideEmote(a)
    })
  }

  function processActions() {
    if (farmer.phase !== 'idle' || farmer.moving) return
    if (!actionQueue.length) return
    var item = actionQueue.shift()
    startJob(farmer, item.idx, item.auto, item.kind)
  }

  var harvestCheck = 0
  function tickHarvest(dt) {
    harvestCheck -= dt
    if (harvestCheck > 0) return
    harvestCheck = 1
    var wall = Date.now()
    var changed = false
    state.plots.forEach(function (plot, idx) {
      if (plot.harvestAt && wall >= plot.harvestAt) {
        plot.harvestAt = 0
        plot.stage = 0
        changed = true
      } else if (plot.stage >= 3 && !plot.harvestAt && workingNow()) {
        harvestPlot(idx, 'auto')
        changed = true
      }
    })
    if (changed) { renderPlots(); renderKeys(); renderHeader(); persist() }
  }

  /** 自动劳动选地：先收成熟，再种空地，最后照顾生长中的地；跳过别人已经占住的。 */
  function pickAutoPlot(owner) {
    var mature = []
    var empty = []
    var growing = []
    state.plots.forEach(function (plot, idx) {
      if (!plot || plot.harvestAt) return
      if (claimedByOther(idx, owner)) return
      if (plot.stage >= 3) mature.push(idx)
      else if (plot.stage <= 0) empty.push(idx)
      else growing.push(idx)
    })
    var pool = mature.length ? mature : empty.length ? empty : growing
    if (!pool.length) return -1
    return pool[Math.floor(Math.random() * pool.length)]
  }

  /** 工作 5 分钟解锁一只小动物，最多 4 只；900 秒不工作清零。 */
  function updateHelpers(dt) {
    var now = Date.now()
    if (workingNow()) {
      state.lastWorkAt = now
      state.helperSeconds += dt
      var unlocked = false
      while (state.helperSeconds >= HELPER_EVERY && state.helpers < HELPER_MAX) {
        state.helperSeconds -= HELPER_EVERY
        state.helpers += 1
        unlocked = true
        var idx = state.helpers - 1
        var actor = helperActors[idx]
        if (actor) {
          actor.x = 18 + idx * 13
          actor.y = 178
          actor.tx = actor.x
          actor.ty = actor.y
          actor.phase = 'idle'
          actor.nextAt = now + rand(300, 900)
          if (actor.el) {
            actor.el.classList.add('dsf-helper-pop')
            setTimeout(function (el) {
              return function () { el.classList.remove('dsf-helper-pop') }
            }(actor.el), 900)
          }
        }
        say('第 ' + state.helpers + ' 只小动物来帮忙啦！', 3000, 1)
        renderFieldStats()
      }
      if (unlocked) persist()
    } else if (state.lastWorkAt && now - state.lastWorkAt > HELPER_IDLE_RESET * 1000
      && (state.helpers > 0 || state.helperSeconds > 0)) {
      state.helpers = 0
      state.helperSeconds = 0
      state.lastWorkAt = 0
      clearHelperJobs()
      say('小动物们回去休息了…', 2600, 1)
      renderFieldStats()
      persist()
    }

    for (var i = 0; i < HELPER_MAX; i++) {
      var a = helperActors[i]
      if (!a) continue
      var on = i < state.helpers
      if (a.el) a.el.classList.toggle('dsf-helper-on', on)
      if (!on) {
        if (a.job) releasePlot(a.job.idx, a)
        a.job = null
        a.phase = 'idle'
        a.moving = false
        hideEmote(a)
        continue
      }
      if (a.phase === 'idle' && !a.moving && now >= a.nextAt) {
        var target = state.allTasksDone ? -1 : pickAutoPlot(a)
        if (target >= 0) {
          startJob(a, target, true, 'helper')
        } else {
          a.tx = clamp(rand(20, FIELD.w - 20), 16, FIELD.w - 16)
          a.ty = clamp(rand(60, FIELD.h - 14), 30, FIELD.h - 10)
          a.dir = dirFor(a, a.tx - a.x, a.ty - a.y)
          a.phase = 'walk'
          a.phaseT = 0
          a.moving = true
          a.nextAt = now + rand(1400, 3000)
        }
      }
      updateActor(a, dt)
    }
  }

  function drawHelpers() {
    for (var i = 0; i < helperActors.length; i++) {
      if (i < state.helpers) drawActor(helperActors[i])
    }
  }

  /** 让小人走到某点；已经在目标点时立即回调，避免队列卡死。 */
  function walkFarmerTo(x, y, cb) {
    farmer.tx = clamp(x, 14, FIELD.w - 14)
    farmer.ty = clamp(y, 8, FIELD.h - 8)
    farmer.dir = dirFor(farmer, farmer.tx - farmer.x, farmer.ty - farmer.y)
    farmer.phase = 'walk'
    farmer.phaseT = 0
    farmer.frame = 0
    farmer.frameT = 0
    farmer.moving = true
    farmer.onArrive = cb || null
    if (Math.abs(farmer.tx - farmer.x) < 0.6 && Math.abs(farmer.ty - farmer.y) < 0.6) {
      farmer.x = farmer.tx
      farmer.y = farmer.ty
      farmer.moving = false
      farmer.phase = 'idle'
      var done = farmer.onArrive
      farmer.onArrive = null
      if (done) setTimeout(done, 0)
    }
  }

  function drawClerk(now) {
    if (!clerkEl) return
    var working = Date.now() < clerkWorkUntil
    var name = working ? 'clerk_work' : 'clerk_idle'
    var frames = working ? 8 : 9
    setFrame(clerkEl, name, Math.floor(now / (working ? 120 : 260)) % frames)
  }

  /** 气泡现在挂在整块面板上：农场页跟着小人，其它页固定在面板上方中间。 */
  function updateBubblePosition() {
    if (!bubbleEl || !frameEl) return
    var scale = currentScaleValue || 1
    var frameRect = frameEl.getBoundingClientRect()
    var frameW = frameEl.clientWidth || 300
    var frameH = frameEl.clientHeight || 400
    var maxW = clamp(frameW - 16, 72, 124)
    bubbleEl.style.maxWidth = maxW + 'px'
    var width = bubbleEl.offsetWidth || Math.min(maxW, 110)
    var height = bubbleEl.offsetHeight || 24
    if (width > frameW - 8) width = frameW - 8
    if (height > frameH - 8) height = frameH - 8

    var left
    var top
    var arrow
    var onFarm = state.settings.tab === 'farm'
    if (onFarm && fieldBody) {
      var fRect = fieldBody.getBoundingClientRect()
      var borderL = 0
      var borderT = 0
      try {
        var cs = window.getComputedStyle(frameEl)
        borderL = parseFloat(cs.borderLeftWidth) || 0
        borderT = parseFloat(cs.borderTopWidth) || 0
      } catch (e) { /* 假 DOM 没 border */ }
      var fieldLeft = (fRect.left - frameRect.left - borderL) / scale
      var fieldTop = (fRect.top - frameRect.top - borderT) / scale
      var fieldW = (fRect.width || frameW * scale) / scale
      var fieldH = (fRect.height || frameH * scale) / scale
      var cx = farmer.x
      left = fieldLeft + cx - width / 2
      top = fieldTop + farmer.y - 40 - height
      left = clamp(left, fieldLeft + 2, Math.max(fieldLeft + 2, fieldLeft + fieldW - width - 2))
      top = clamp(top, fieldTop + 2, Math.max(fieldTop + 2, fieldTop + fieldH - height - 2))
      arrow = Math.round(clamp(cx - (left - fieldLeft), 8, width - 8))
      bubbleEl.classList.remove('dsf-bubble-floating')
    } else {
      left = (frameW - width) / 2
      var contentTop = 78
      var viewEl = views[state.settings.tab]
      if (viewEl) {
        try {
          var vRect = viewEl.getBoundingClientRect()
          var borderTop = 0
          var cs2 = window.getComputedStyle(frameEl)
          borderTop = parseFloat(cs2.borderTopWidth) || 0
          contentTop = (vRect.top - frameRect.top - borderTop) / scale + 28
        } catch (e) { /* 假 DOM 用默认值 */ }
      }
      top = Math.max(72, contentTop)
      left = clamp(left, 6, Math.max(6, frameW - width - 6))
      top = clamp(top, 42, Math.max(42, frameH - height - 6))
      arrow = Math.round(width / 2)
      bubbleEl.classList.add('dsf-bubble-floating')
    }
    bubbleEl.style.left = Math.round(left) + 'px'
    bubbleEl.style.top = Math.round(top) + 'px'
    bubbleEl.style.setProperty('--dsf-bubble-arrow', arrow + 'px')
  }

  // ------------------------------------------------------------------
  // 界面
  // ------------------------------------------------------------------
  var root = null
  var frameEl = null
  var fieldBody = null
  var plotsLayer = null
  var decorLayer = null
  var keysList = null
  var keysSummary = null
  var tasksList = null
  var usageView = null
  var tabBar = null
  var views = {}
  var badgeEl = null
  var statusEl = null
  var fieldStats = null
  var titleEl = null
  var workStatText = null
  var helperStatText = null
  var coinStatText = null
  var hostUserName = ''
  var panelHost = null
  var cssInjected = false
  var currentScaleValue = 1.5
  var hitRectsFrame = 0

  function farmTitle() { return hostUserName ? hostUserName + ' 的农场' : '老乡的农场' }
  function renderFarmTitle() {
    // 用户名保留原始大小写，标题走系统字体；其它 ASCII 仍用位图字库
    if (titleEl) titleEl.textContent = farmTitle()
    if (panel) {
      var head = panel.querySelector('.dsf-panel-title')
      if (head) head.textContent = farmTitle()
    }
  }

  function reportHitRects() {
    if (!DESKTOP || !window.dsfDesktop || typeof window.dsfDesktop.setHitRects !== 'function') return
    if (hitRectsFrame) return
    hitRectsFrame = requestAnimationFrame(function () {
      hitRectsFrame = 0
      var rects = []
      function add(el) {
        if (!el) return
        var r = el.getBoundingClientRect()
        if (r.width > 1 && r.height > 1) rects.push({ x: r.left, y: r.top, w: r.width, h: r.height })
      }
      add(frameEl)
      if (panelHost && panelHost.classList.contains('dsf-panel-open')) add(panel)
      add(document.querySelector('.dsf-resize-grip'))
      add(introEl)
      if (root && root.classList.contains('dsf-collapsed')) add(document.querySelector('.dsf-openbtn'))
      window.dsfDesktop.setHitRects(rects)
    })
  }

  function injectCss() {
    if (cssInjected || document.getElementById('dsh-stardew-css')) return
    cssInjected = true
    var style = document.createElement('style')
    style.id = 'dsh-stardew-css'
    style.textContent = DSF_CSS
    document.head.appendChild(style)
  }

  function currentTab() { return state.settings.tab || 'farm' }

  function switchTab(tab) {
    state.settings.tab = tab
    if (tabBar) {
      Array.prototype.forEach.call(tabBar.children, function (btn) {
        btn.classList.toggle('dsf-tab-on', btn.getAttribute('data-tab') === tab)
      })
    }
    Object.keys(views).forEach(function (name) {
      views[name].classList.toggle('dsf-view-on', name === tab)
    })
    if (tab === 'keys') renderKeys()
    if (tab === 'tasks') renderTasksView()
    if (tab === 'usage') renderUsageView()
    if (tab === 'balance') renderBalanceView()
    if (bubbleText) updateBubblePosition()
    if (state.settings.autoScale) requestAnimationFrame(applySettings)
    reportHitRects()
    persist()
  }

  function tabIcon(name) {
    var wrap = h('span', { class: 'dsf-tab-ico' })
    var meta = SPRITES[name]
    var sp = sprite(name)
    if (meta) {
      var scale = Math.min(1, 14 / Math.max(meta.w, meta.h))
      if (scale < 1) sp.style.transform = 'scale(' + scale.toFixed(2) + ')'
    }
    wrap.appendChild(sp)
    return wrap
  }

  function statText(text) {
    return btext(text)
  }

  function statIcon(name, cls) {
    return h('span', { class: 'dsf-stat-ico ' + (cls || '') }, [sprite(name)])
  }

  function buildUI() {
    injectCss()
    root = h('div', { class: 'dsf-root' })
    frameEl = h('div', { class: 'dsf-frame dsf-panel-paper' })

    headerCoinsText = h('span', { class: 'dsf-coins-text' })
    headerCoins = h('span', { class: 'dsf-coins' }, [sprite('itemdisc'), headerCoinsText])
    titleEl = h('span', { class: 'dsf-title' })
    var headerEl = h('div', { class: 'dsf-header' }, [
      h('span', { class: 'dsf-logo' }, [btext('FARM', { class: 'dsf-logo-text', white: true })]),
      titleEl,
      headerCoins,
      h('button', { class: 'dsf-iconbtn', title: '尺寸 / 停靠 / 详细设置', onclick: function (e) { e.stopPropagation(); openPanel('settings') } }, [h('span', { class: 'dsf-system-ico' }, '☰')]),
      h('button', { class: 'dsf-iconbtn dsf-collapsebtn', title: '收起（Alt+Shift+F）', onclick: function (e) { e.stopPropagation(); setCollapsed(true) } }, [h('span', { class: 'dsf-system-ico' }, '▾')]),
    ])
    renderFarmTitle()
    frameEl.appendChild(headerEl)
    if (DESKTOP) {
      headerEl.addEventListener('mousedown', function (e) {
        if (e.button !== 0) return
        var tag = e.target && e.target.tagName
        if (tag === 'BUTTON' || tag === 'INPUT') return
        e.preventDefault()
        if (window.dsfDesktop && window.dsfDesktop.startDrag) window.dsfDesktop.startDrag()
      })
      window.addEventListener('mouseup', function () {
        if (window.dsfDesktop && window.dsfDesktop.endDrag) window.dsfDesktop.endDrag()
      })
    }
    statusEl = h('div', { class: 'dsf-statusbar' })
    frameEl.appendChild(statusEl)

    // 页签：统一 14px 素材图标 + 两字中文，不夹 emoji，保证 5 个等宽不溢出
    tabBar = h('div', { class: 'dsf-tabbar' })
    ;[
      ['farm', '农场', 'basket'],
      ['keys', '键盘', 'seed'],
      ['tasks', '任务', 'plan'],
      ['usage', '工时', 'sandtimer'],
      ['balance', '余额', 'itemdisc'],
    ].forEach(function (pair) {
      tabBar.appendChild(h('button', {
        class: 'dsf-tabbtn', 'data-tab': pair[0],
        onclick: function (e) { e.stopPropagation(); switchTab(pair[0]) },
      }, [tabIcon(pair[2]), h('span', { class: 'dsf-tab-label' }, pair[1])]))
    })
    frameEl.appendChild(tabBar)

    // ---- 页 1：农场（土地 + 底部状态栏，避免工时牌浮在土地上） ----
    plotsLayer = h('div', { class: 'dsf-plots' })
    decorLayer = h('div', { class: 'dsf-decor' })
    farmerEl = h('div', { class: 'dsf-farmer', title: '点我：让小人去田里干活' })
    farmerEl.addEventListener('click', function (e) { e.stopPropagation(); startTending() })
    farmer.el = farmerEl
    farmer.emoteEl = h('div', { class: 'dsf-emote' })
    bubbleEl = h('div', { class: 'dsf-bubble' })
    bubbleEl.addEventListener('click', function (e) { e.stopPropagation(); switchTab('tasks') })
    sparksLayer = h('div', { class: 'dsf-sparks' })
    fieldBody = h('div', { class: 'dsf-fieldbody' }, [decorLayer, plotsLayer, farmerEl, farmer.emoteEl, sparksLayer])
    fieldStats = h('div', { class: 'dsf-fieldstats' })

    workStatText = statText('已工作 0s')
    clerkLabel = workStatText
    helperStatText = statText('帮手 0/4')
    coinStatText = statText('金币 0')
    var railWork = h('div', { class: 'dsf-stat', title: '今日工时：点开工时页' }, [statIcon('stopwatch', 'dsf-stat-ico-clock'), workStatText])
    railWork.addEventListener('click', function (e) { e.stopPropagation(); switchTab('usage') })
    var railHelper = h('div', { class: 'dsf-stat', title: '帮手工时：每工作 5 分钟来一只' }, [statIcon('cow', 'dsf-stat-ico-cow'), helperStatText])
    var railCoin = h('div', { class: 'dsf-stat', title: '今天的金币' }, [statIcon('itemdisc', 'dsf-stat-ico-disc'), coinStatText])
    var fieldRail = h('div', { class: 'dsf-fieldrail' }, [railWork, railHelper, railCoin])

    var field = h('div', { class: 'dsf-field' }, [
      h('div', { class: 'dsf-fieldhead' }, [
        h('div', { class: 'dsf-sec-label' }, '土地 · 26 块 A–Z'),
        fieldStats,
      ]),
      fieldBody,
      fieldRail,
    ])
    views.farm = h('div', { class: 'dsf-view dsf-view-farm' }, [field])
    buildDecor()

    // ---- 页 2：键盘农场 ----
    keysSummary = h('div', { class: 'dsf-keysummary' })
    keysList = h('div', { class: 'dsf-keylist' })
    views.keys = h('div', { class: 'dsf-view dsf-view-keys' }, [
      h('div', { class: 'dsf-sec-label' }, 'QWERTY 26 键 · 每块地一个字母'),
      keysSummary,
      keysList,
      h('div', { class: 'dsf-keyhint' }, '按键盘上的字母，农场里同一块地就会长作物；每 3 次成熟 +4 金币。'),
    ])

    // ---- 页 3：任务 ----
    tasksList = h('div', { class: 'dsf-tasklist dsf-panel-paper' })
    views.tasks = h('div', { class: 'dsf-view dsf-view-tasks' }, [
      h('div', { class: 'dsf-sec-label' }, '今日待办（实时同步）'),
      tasksList,
    ])

    // ---- 页 4：工时 ----
    usageView = h('div', { class: 'dsf-view dsf-view-usage' })
    views.usage = usageView

    // ---- 页 5：余额 ----
    views.balance = h('div', { class: 'dsf-view dsf-view-balance' })

    Object.keys(views).forEach(function (name) { frameEl.appendChild(views[name]) })
    // 气泡挂在整块面板上：任务/工时页也能显示，位置按当前页重新算
    frameEl.appendChild(bubbleEl)

    badgeEl = h('div', { class: 'dsf-badge' }, [ico('face_exclaim'), h('span', { class: 'dsf-badge-text' }, '有个事要你处理')])
    badgeEl.addEventListener('click', function (e) { e.stopPropagation(); switchTab('tasks') })
    frameEl.appendChild(badgeEl)
    root.appendChild(frameEl)

    // 举牌小人挂在 root 上，不属于农场页，所以切到任务/工时页也能从右侧跳出来
    heraldText = h('span', { class: 'dsf-herald-text' })
    heraldEl = h('div', { class: 'dsf-herald', 'aria-hidden': 'true' }, [
      h('div', { class: 'dsf-herald-bed' }),
      h('div', { class: 'dsf-herald-actor' }, [sprite('farmer_idle_down', 0)]),
      h('div', { class: 'dsf-herald-sign' }, [heraldText]),
    ])
    root.appendChild(heraldEl)

    var openBtn = h('button', { class: 'dsf-openbtn' }, [sprite('basket'), h('span', null, '农场')])
    openBtn.addEventListener('click', function (e) { e.stopPropagation(); setCollapsed(false) })
    root.appendChild(openBtn)

    document.body.appendChild(root)
    if (DESKTOP) {
      panelHost = h('div', { class: 'dsf-panel-host' })
      document.body.appendChild(panelHost)
      buildResizeGrip()
    }

    renderHeader(); renderPlots(); renderKeys(); renderTasksView(); renderUsageView()
    switchTab(currentTab())

    bindKeyboard()
    bindDesktopKeys()
    applySettings()
    reportHitRects()
    window.addEventListener('resize', function () { applySettings(); reportHitRects() })
    setInterval(reportHitRects, 1000)
    requestAnimationFrame(function () { lastNow = performance.now(); tick(lastNow) })
    startStream()
  }

  function buildDecor() {
    decorLayer.innerHTML = ''
    helperEls = []

    // 装饰只放在顶部留白和第四行左右两个空格里，均匀、不压地块
    var props = [
      ['pond', 15, 129, .42, 1],
      ['flower_patch', 70, 1, .35, 1],
      ['flower_patch', 132, 1, .35, 1],
      ['flower_patch', 194, 1, .35, 1],
      ['grass_tuft', 100, 2, .4, 1],
      ['grass_tuft', 164, 2, .4, 1],
    ]
    props.forEach(function (p) {
      var el = sprite(p[0])
      if (!el) return
      el.classList.add('dsf-prop')
      el.style.left = p[1] + 'px'
      el.style.top = p[2] + 'px'
      el.style.transform = 'scale(' + p[3] + ')'
      el.style.zIndex = String(p[4])
      decorLayer.appendChild(el)
    })

    // 帮手：4 只 side-view 小动物，各自带独立状态机
    helpersLayer = h('div', { class: 'dsf-helpers' })
    helperActors = []
    HELPER_NAMES.forEach(function (name, i) {
      var el = sprite(name, 0)
      el.classList.add('dsf-helper', 'dsf-helper-' + i)
      var item = makeActor('helper', i)
      item.el = el
      item.x = 18 + i * 13
      item.y = 182
      item.tx = item.x
      item.ty = item.y
      item.dir = 'right'
      item.emoteEl = h('div', { class: 'dsf-emote dsf-emote-helper' })
      item.emoteEl.style.display = 'none'
      el.style.left = item.x + 'px'
      el.style.top = item.y + 'px'
      helpersLayer.appendChild(el)
      helperEls.push(item)
      helperActors.push(item)
      fieldBody.appendChild(item.emoteEl)
    })
    // 帮手必须放在 fieldBody 的独立图层里，不能塞进 z-index:1 的装饰层，否则会被土地盖住
    fieldBody.appendChild(helpersLayer)

    // 工时记录员：站在右下角空地上，不再挂浮动工时牌（工时改到底部状态栏）
    clerkEl = h('div', { class: 'dsf-clerk', title: '工时记录员：点我看今天用了哪些软件' })
    clerkEl.addEventListener('click', function (e) { e.stopPropagation(); switchTab('usage') })
    fieldBody.appendChild(clerkEl)

    fieldBody.style.backgroundImage = SPRITES.grass_tile
      ? "url('" + SPRITES.grass_tile.src + "'), linear-gradient(#8fcc57, #6aae3b)"
      : 'linear-gradient(#8fcc57, #6aae3b)'
    if (SPRITES.grass_tile) fieldBody.style.backgroundSize = '64px 64px, auto'
  }

  // ------------------------------------------------------------------
  // 键盘：keydown 为主动作，输入法/粘贴等用 input 兜底
  // ------------------------------------------------------------------
  var lastKeydownAt = 0
  var composing = false
  var recentKeys = {}

  function countKey(key, source) {
    if (!key) return
    var letter = letterForKey(key)
    if (!letter) return
    var now = Date.now()
    var rec = recentKeys[letter] || (recentKeys[letter] = {})
    var from = source || 'page'
    var other = from === 'global' ? 'page' : (from === 'page' ? 'global' : '')
    if (other && now - (rec[other] || 0) < 45) return
    rec[from] = now
    onKey(key)
  }

  function onKeyDown(ev) {
    if (!root || root.classList.contains('dsf-collapsed')) return
    if (ev.altKey && ev.shiftKey && (ev.key === 'F' || ev.key === 'f')) {
      setCollapsed(!state.settings.collapsed)
      return
    }
    if (CONTROL_KEY.test(String(ev.key || ''))) return
    lastKeydownAt = Date.now()
    if (ev.isComposing || composing || ev.key === 'Process' || ev.key === 'Unidentified' || ev.key === 'Dead') {
      return
    }
    countKey(ev.key, 'page')
  }

  function onInput(ev) {
    if (Date.now() - lastKeydownAt < 60) return
    var data = ev && ev.data
    if (typeof data !== 'string' || !data.length) return
    if (composing) return
    for (var i = 0; i < data.length; i++) {
      var ch = data[i]
      if (ch.trim() === '') continue
      countKey(ch, 'input')
    }
  }

  function bindKeyboard() {
    window.addEventListener('keydown', onKeyDown, true)
    // 浏览器自动播放限制：用户第一次按键/点农场时解锁音频，任务完成音效才响得出来
    window.addEventListener('keydown', ensureAudio, true)
    window.addEventListener('pointerdown', ensureAudio, true)
    document.addEventListener('compositionstart', function () { composing = true }, true)
    document.addEventListener('compositionend', function (ev) {
      composing = false
      lastKeydownAt = 0
      var data = ev && ev.data
      if (!data) return
      for (var i = 0; i < data.length; i++) {
        var ch = data[i]
        if (ch.trim() === '') continue
        countKey(ch, 'composition')
      }
    }, true)
    document.addEventListener('input', onInput, true)
  }

  function bindDesktopKeys() {
    if (!DESKTOP || !window.dsfDesktop || typeof window.dsfDesktop.onKey !== 'function') return
    window.dsfDesktop.onKey(function (key) {
      if (key) countKey(String(key), 'global')
    })
  }

  // ------------------------------------------------------------------
  // 渲染
  // ------------------------------------------------------------------
  function renderHeader() {
    if (!headerCoins) return
    setBText(headerCoinsText, ' ' + Math.floor(state.coins))
    headerCoins.title = '今日耕种 ' + Math.round(state.farmSeconds) + ' 秒 · 收割 ' + totalHarvests() + ' 次'
    renderStatus()
    renderFieldStats()
  }

  function statusLabel() {
    if (host.busy) return '干活中'
    if (host.harness) return 'harness'
    if (Date.now() < typingUntil) return '打字中'
    if (Date.now() < workUntil) return '干活中'
    return '空闲'
  }

  function renderStatus() {
    if (!statusEl) return
    var pending = host.todos.filter(function (t) { return t.status !== 'completed' }).length
    var totalTodos = host.todos.length
    var todoLabel = totalTodos ? ('待办 ' + pending + '/' + totalTodos) : '待办 0'
    var total = host.usage ? host.usage.totalSeconds : state.onlineSeconds
    var app = host.workApp && host.workApp.name ? clampText(host.workApp.name, 8) : ''
    var label = statusLabel()
    if (app && !(host.workApp && host.workApp.ignored) && (Date.now() < workUntil || (host.usage && host.usage.current))) {
      label = app
    }
    var key = [state.day, label, pending, totalTodos, Math.floor(total / 60), DESKTOP ? 'd' : 'w', host.harness ? 'h' : ''].join('|')
    if (key === lastStatusKey) return
    lastStatusKey = key
    statusEl.innerHTML = ''
    statusEl.appendChild(h('span', { class: 'dsf-status-item', title: state.day }, [btext(state.day.slice(5))]))
    statusEl.appendChild(h('span', { class: 'dsf-status-item' + (workingNow() ? ' dsf-status-busy' : '') }, [btext(label)]))
    statusEl.appendChild(h('span', { class: 'dsf-status-item' }, [btext(todoLabel)]))
    statusEl.appendChild(h('span', { class: 'dsf-status-item' }, [btext('工时 ' + fmtShort(total))]))
    if (DESKTOP) statusEl.appendChild(h('span', { class: 'dsf-status-item dsf-desktop-badge' }, [btext('桌面')]))
  }

  function renderFieldStats() {
    if (!fieldStats) return
    var mature = 0
    state.plots.forEach(function (plot) { if (plot && plot.stage >= 3) mature += 1 })
    setBText(fieldStats, '成熟 ' + mature + ' · 收割 ' + totalHarvests())
    fieldStats.title = '今日耕种 ' + Math.round(state.farmSeconds) + ' 秒 · 26 块地固定 A–Z'
    var total = host.usage ? Number(host.usage.totalSeconds) || 0 : state.onlineSeconds
    if (workStatText) setBText(workStatText, '已工作 ' + fmtShort(total))
    if (helperStatText) setBText(helperStatText, '帮手 ' + state.helpers + '/' + HELPER_MAX)
    if (coinStatText) setBText(coinStatText, '金币 ' + Math.floor(state.coins))
  }

  function totalHarvests() {
    var n = 0
    Object.keys(state.keys).forEach(function (k) { n += state.keys[k].harvests || 0 })
    return n
  }

  function renderPlots() {
    if (!plotsLayer) return
    plotsLayer.innerHTML = ''
    state.plots.forEach(function (plot, idx) {
      var pos = plotPos(idx)
      var cell = h('div', { class: 'dsf-plot', 'data-letter': plot.key })
      cell.style.left = pos.x + 'px'
      cell.style.top = pos.y + 'px'
      var soil = dirtEl('dsf-soil', 30, 30, idx % 2 === 1)
      cell.appendChild(soil)
      cell.appendChild(h('span', { class: 'dsf-plot-letter' }, [btext(plot.key)]))
      var crop = cropForLetter(plot.key)
      if (plot.stage > 0) {
        var plant = sprite(crop.sprite, cropFrame(plot.stage, !!plot.harvestAt))
        plant.classList.add('dsf-plant')
        cell.appendChild(plant)
        if (plot.stage >= 3) cell.classList.add('dsf-ready')
      } else {
        cell.classList.add('dsf-empty')
      }
      var pips = h('div', { class: 'dsf-pips dsf-pips-plot' })
      for (var p = 0; p < 3; p++) pips.appendChild(h('span', { class: 'dsf-pip' + (p < plot.stage ? ' on' : '') }))
      cell.appendChild(pips)
      cell.setAttribute('title', plot.key + ' 地：' + (plot.stage > 0
        ? crop.name + (plot.stage >= 3 ? '（成熟，马上收割）' : '（生长 ' + plot.stage + '/3）')
        : '空地，按 ' + plot.key + ' 种上'))
      cell.addEventListener('click', function (e) { e.stopPropagation(); onKey(plot.key) })
      plotsLayer.appendChild(cell)
    })
  }

  function renderKeys() {
    if (!keysList) return
    keysList.innerHTML = ''
    var mature = state.plots.filter(function (p) { return p.stage >= 3 }).length
    if (keysSummary) {
      keysSummary.innerHTML = ''
      keysSummary.appendChild(sprite('basket'))
      keysSummary.appendChild(btext('26 键 = 26 块地 · 成熟 ' + mature + ' · 今日收割 ' + totalHarvests() + ' 次 · 每 3 次 +' + HARVEST_COINS + ' 金币'))
    }
    KEY_ROWS.forEach(function (row) {
      var rowEl = h('div', { class: 'dsf-keyrow' })
      row.forEach(function (letter) {
        var idx = plotIndex(letter)
        var plot = state.plots[idx]
        var crop = cropForLetter(letter)
        var rec = state.keys[letter]
        var cell = h('div', { class: 'dsf-key', 'data-letter': letter })
        var soil = dirtEl('dsf-key-soil', 20, 20, idx % 2 === 1)
        cell.appendChild(soil)
        if (plot.stage > 0) {
          var plant = sprite(crop.sprite, cropFrame(plot.stage, !!plot.harvestAt))
          plant.classList.add('dsf-key-plant')
          cell.appendChild(plant)
        } else {
          cell.classList.add('dsf-empty')
        }
        cell.appendChild(h('span', { class: 'dsf-key-letter' }, [btext(letter, { white: true })]))
        var pips = h('div', { class: 'dsf-key-pips' })
        for (var p = 0; p < 3; p++) pips.appendChild(h('span', { class: 'dsf-pip' + (p < plot.stage ? ' on' : '') }))
        cell.appendChild(pips)
        if (plot.stage >= 3) cell.classList.add('dsf-ready')
        cell.setAttribute('title', letter + ' 地：' + crop.name + (rec
          ? ' · 已按 ' + rec.n + ' 次 · 收割 ' + (rec.harvests || 0) + ' 次'
          : ' · 还没种'))
        cell.addEventListener('click', function (e) { e.stopPropagation(); onKey(letter) })
        rowEl.appendChild(cell)
      })
      keysList.appendChild(rowEl)
    })
  }

  function taskIcon(status) {
    var glyph = status === 'completed' ? '✔' : status === 'in_progress' ? '◐' : '○'
    return h('span', { class: 'dsf-task-glyph' }, glyph)
  }

  function todoKey(todo) {
    return String(todo && todo.status || '') + '|' + String(todo && todo.content || '')
  }

  function taskRow(todo, index) {
    var key = todoKey(todo)
    var on = state.selectedTaskKey === key
    var row = h('div', {
      class: 'dsf-item dsf-todo-' + todo.status
        + (todo.status === 'in_progress' ? ' dsf-task-current' : '')
        + (on ? ' dsf-task-on dsf-select-skin' : ''),
      'data-index': String(index),
      role: 'button',
      tabindex: '0',
      onclick: function (e) {
        e.stopPropagation()
        state.selectedTaskKey = state.selectedTaskKey === key ? '' : key
        state.selectedTask = state.selectedTaskKey ? index : -1
        renderTasksView()
        if (state.selectedTaskKey === key) say(clampText(todo.content, 60), 3000, 1)
      },
    }, [
      h('span', { class: 'dsf-task-icon dsf-task-' + todo.status }, [taskIcon(todo.status)]),
      h('span', { class: 'dsf-item-text' }, todo.content),
      todo.status === 'in_progress' ? h('span', { class: 'dsf-current-chip dsf-label-skin' }, '当前') : null,
      on ? h('span', { class: 'dsf-selected-chip dsf-label-skin' }, '已选') : null,
    ])
    return row
  }

  function renderTasksView() {
    if (!tasksList) return
    tasksList.innerHTML = ''
    state.selectedTask = -1
    host.todos.forEach(function (todo, i) {
      if (state.selectedTaskKey && todoKey(todo) === state.selectedTaskKey) state.selectedTask = i
    })
    var completed = host.todos.filter(function (t) { return t.status === 'completed' }).length
    var pct = host.todos.length ? Math.round(completed / host.todos.length * 100) : 0
    var bar = h('div', { class: 'dsf-progress', title: completed + ' / ' + host.todos.length })
    var fill = h('div', { class: 'dsf-progress-fill', style: { width: pct + '%' } })
    bar.appendChild(fill)
    tasksList.appendChild(bar)
    tasksList.appendChild(h('div', { class: 'dsf-dim dsf-small' },
      '完成 ' + completed + ' / ' + host.todos.length + ' · 耕种 ' + Math.round(state.farmSeconds) + ' 秒 · 收割 ' + totalHarvests() + ' 次'))
    if (host.todosFallback && host.todos.length) {
      tasksList.appendChild(h('div', { class: 'dsf-task-source' }, '当前会话还没写待办，显示最近一轮的待办'))
    }
    if (!host.todos.length) {
      tasksList.appendChild(h('div', { class: 'dsf-item dsf-dim' }, '还没有待办。AI 更新待办清单时会实时同步到这里。'))
      return
    }
    host.todos.forEach(function (todo, i) { tasksList.appendChild(taskRow(todo, i)) })
  }

  function renderUsageView() {
    if (!usageView) return
    var usage = host.usage
    var total = usage ? Number(usage.totalSeconds) || 0 : state.onlineSeconds
    var cur = usage && usage.current ? usage.current : null
    var key = [
      usage ? usage.updatedAt : 0, Math.floor(total),
      cur ? cur.name : '', cur && cur.ignored ? 'i' : '',
      usage && Array.isArray(usage.apps) ? usage.apps.length : 0,
      host.harness ? 1 : 0,
    ].join('|')
    if (key === lastUsageKey) return
    lastUsageKey = key
    usageView.innerHTML = ''

    var head = h('div', { class: 'dsf-usage-head' }, [
      h('div', { class: 'dsf-usage-total' }, [btext(fmtLong(total))]),
      h('div', { class: 'dsf-dim dsf-small' }, usage ? '今日前台软件使用时长' : '本页在线时长（桌面版记录软件）'),
    ])
    usageView.appendChild(head)

    if (cur) {
      var curName = String(cur.name || cur.process || '未知')
      usageView.appendChild(h('div', { class: 'dsf-usage-now' + (cur.ignored ? ' dsf-usage-idle' : '') }, [
        ico(cur.ignored ? 'face_cry' : 'face_green'),
        h('span', null, cur.ignored ? '当前未记录：' + curName : '正在用：' + curName),
        h('span', { class: 'dsf-usage-live' }, cur.ignored ? '暂停' : '记录中'),
      ]))
    }
    if (host.harness) {
      usageView.appendChild(h('div', { class: 'dsf-usage-harness' },
        '🤖 检测到 harness：' + (host.harnessNames && host.harnessNames.length ? host.harnessNames.join(' / ') : '运行中')))
    }

    var apps = usage && Array.isArray(usage.apps) ? usage.apps : []
    if (!apps.length) {
      usageView.appendChild(h('div', { class: 'dsf-item dsf-dim' },
        usage ? '今天还没有记录到软件使用。切到别的窗口再回来就会开始记。' : '桌面版会在后台记录每个前台软件的使用时长；DSH 页面只能记本页在线时长。'))
    } else {
      var max = 1
      apps.forEach(function (app) { max = Math.max(max, Number(app.seconds) || 0) })
      apps.slice(0, 10).forEach(function (app) {
        var sec = Number(app.seconds) || 0
        var pct = Math.max(2, Math.round(sec / max * 100))
        usageView.appendChild(h('div', { class: 'dsf-usage-row' + (app.current ? ' dsf-usage-current' : '') }, [
          h('div', { class: 'dsf-usage-line' }, [
            h('span', { class: 'dsf-usage-name', title: app.title || app.name }, [btext(String(app.name || app.key || '未知'))]),
            h('span', { class: 'dsf-usage-time' }, [btext(fmtShort(sec))]),
          ]),
          h('div', { class: 'dsf-usage-bar' }, [
            h('div', { class: 'dsf-usage-fill', style: { width: pct + '%' } }),
          ]),
        ]))
      })
    }
    usageView.appendChild(h('div', { class: 'dsf-usage-note' },
      '记录员每 1 秒看一眼前台窗口；切换软件时，小人会冒 3 秒「工作中」并下田。'))
  }

  function renderUsageStats() {
    var total = host.usage ? Number(host.usage.totalSeconds) || 0 : state.onlineSeconds
    if (clerkLabel) setBText(clerkLabel, '已工作 ' + fmtShort(total))
    renderStatus()
  }

  function renderBalanceView() {
    var box = views.balance
    if (!box) return
    box.innerHTML = ''
    box.appendChild(h('div', { class: 'dsf-dim dsf-small' }, '读取中…'))
    fetch(PREFIX + '/api/balance', { cache: 'no-store' })
      .then(function (r) { return r.json() })
      .then(function (data) {
        box.innerHTML = ''
        if (!data || !data.ok) {
          box.appendChild(h('div', { class: 'dsf-dim' }, '读取不到余额：' + String((data && data.error) || '未知错误')))
          return
        }
        var cur = data.currency === 'CNY' ? '¥' : data.currency === 'USD' ? '$' : (data.currency || '')
        box.appendChild(h('div', { class: 'dsf-balance' }, [
          h('div', { class: 'dsf-dim dsf-small' }, '可用余额（' + (data.source === 'account' ? '账号登录' : 'API Key') + '）'),
          h('div', { class: 'dsf-bal-big' }, [btext(cur + Number(data.totalBalance).toFixed(2))]),
          data.bonusBalance !== null && data.bonusBalance !== undefined
            ? h('div', { class: 'dsf-dim dsf-small' }, '其中赠金 ' + cur + Number(data.bonusBalance).toFixed(2)) : null,
          h('button', { class: 'dsf-btn', onclick: function (e) { e.stopPropagation(); renderBalanceView() } }, '刷新'),
        ]))
      })
      .catch(function () { box.innerHTML = ''; box.appendChild(h('div', { class: 'dsf-dim' }, '网络错误')) })
  }

  function renderBadge() {
    if (!badgeEl) return
    if (state.attention) {
      var txt = badgeEl.querySelector('.dsf-badge-text')
      if (txt) txt.textContent = '🙋 ' + state.attention.kind + '：' + clampText(state.attention.text, 16)
      badgeEl.classList.add('dsf-badge-show')
    } else {
      badgeEl.classList.remove('dsf-badge-show')
    }
  }

  function renderBubble() {
    if (!bubbleEl) return
    if (!bubbleText) {
      bubbleEl.innerHTML = ''
      bubbleEl.classList.remove('dsf-bubble-show')
      return
    }
    bubbleEl.innerHTML = ''
    appendBText(bubbleEl, bubbleText)
    bubbleEl.classList.add('dsf-bubble-show')
    updateBubblePosition()
  }

  function startTending() {
    workUntil = Date.now() + 8000
    say('去干活啦', 1800, 1)
    for (var i = 0; i < 6; i++) {
      var idx = pickAutoPlot(farmer)
      if (idx >= 0) enqueueAction(idx, 'auto', true)
    }
  }

  // ------------------------------------------------------------------
  // ☰ 面板：尺寸 / 停靠 / 详细
  // ------------------------------------------------------------------
  var panel = null
  function closePanel() {
    if (!panel) return
    panel.remove()
    panel = null
    if (panelHost) panelHost.classList.remove('dsf-panel-open')
    reportHitRects()
  }
  function hideIntro() {
    if (!introEl) return
    introEl.remove()
    introEl = null
  }
  function openPanel(tab) {
    closePanel()
    hideIntro()
    var active = tab || 'settings'
    var body = h('div', { class: 'dsf-panel-body' })
    var tabsEl = h('div', { class: 'dsf-tabs' })
    function render() {
      body.innerHTML = ''
      if (active === 'settings') body.appendChild(renderSettings())
      else if (active === 'tasks') body.appendChild(renderTasksPanel())
      else { body.appendChild(h('div', { class: 'dsf-dim' }, '读取中…')); renderBalancePanel(body) }
    }
    function switchPanelTab(t) {
      active = t
      Array.prototype.forEach.call(tabsEl.children, function (c) {
        c.classList.toggle('dsf-tab-on', c.getAttribute('data-tab') === t)
      })
      render()
    }
    ;[['settings', '尺寸'], ['tasks', '任务'], ['balance', '余额']].forEach(function (pair) {
      tabsEl.appendChild(h('button', {
        class: 'dsf-tab', 'data-tab': pair[0], onclick: function () { switchPanelTab(pair[0]) },
      }, pair[1]))
    })
    panel = h('div', { class: 'dsf-panel dsf-panel-paper', role: 'dialog', 'aria-label': farmTitle() }, [
      h('div', { class: 'dsf-panel-head' }, [
        h('div', null, [h('b', { class: 'dsf-panel-title' }, farmTitle()), h('span', { class: 'dsf-dim dsf-small' }, ' ' + state.day)]),
        h('button', { class: 'dsf-x', 'aria-label': '关闭', onclick: closePanel }, [h('span', { class: 'dsf-x-text' }, '×')]),
      ]),
      tabsEl,
      body,
    ])
    panel.addEventListener('click', function (e) { e.stopPropagation() })
    if (DESKTOP && panelHost) {
      panelHost.appendChild(panel)
      panelHost.classList.add('dsf-panel-open')
    } else {
      root.appendChild(panel)
    }
    switchPanelTab(active)
    reportHitRects()
  }

  function setWindowPreset(name) {
    if (!DESKTOP || !window.dsfDesktop || typeof window.dsfDesktop.setWindowSize !== 'function') return
    window.dsfDesktop.setWindowSize(name)
    say(name === 'small' ? '窗口调小了' : name === 'large' ? '窗口调大了' : '窗口调成中号', 1600)
  }

  function fitWindow() {
    if (!DESKTOP || !window.dsfDesktop || typeof window.dsfDesktop.fitWindow !== 'function') return
    closePanel()
    var rect = frameEl.getBoundingClientRect()
    state.settings.autoScale = false
    state.settings.scale = currentScaleValue
    applySettings()
    persist()
    window.dsfDesktop.fitWindow({
      width: Math.ceil(rect.width) + 24,
      height: Math.ceil(rect.height) + 24,
    })
    say('窗口已贴合内容', 1800)
  }

  function renderSettings() {
    var wrap = h('div')
    if (DESKTOP) wrap.appendChild(h('div', { class: 'dsf-desktop-note' }, '🖥️ 桌面版：全局按键已接管，Alt+Shift+F 显示/隐藏窗口；拖右下角把手也能改窗口大小'))
    wrap.appendChild(h('div', { class: 'dsf-sec-title' }, '尺寸'))
    wrap.appendChild(h('div', { class: 'dsf-dim dsf-small' },
      state.settings.autoScale ? '自动缩放：开（随窗口大小自适应）' : '当前 ' + Number(state.settings.scale).toFixed(2) + '×（手动）'))
    wrap.appendChild(h('div', { class: 'dsf-actions' }, [
      h('button', {
        class: 'dsf-btn' + (state.settings.autoScale ? ' dsf-btn-on' : ''),
        onclick: function () {
          state.settings.autoScale = !state.settings.autoScale
          if (!state.settings.autoScale) state.settings.scale = autoScaleValue()
          applySettings(); persist(); openPanel('settings')
        },
      }, state.settings.autoScale ? '自动缩放：开' : '自动缩放：关'),
    ]))
    if (DESKTOP) {
      wrap.appendChild(h('div', { class: 'dsf-actions' }, [
        h('button', { class: 'dsf-btn', onclick: function () { setWindowPreset('small'); openPanel('settings') } }, '小 320×520'),
        h('button', { class: 'dsf-btn', onclick: function () { setWindowPreset('medium'); openPanel('settings') } }, '中 400×700'),
        h('button', { class: 'dsf-btn', onclick: function () { setWindowPreset('large'); openPanel('settings') } }, '大 500×860'),
      ]))
      wrap.appendChild(h('div', { class: 'dsf-actions' }, [
        h('button', { class: 'dsf-btn', onclick: fitWindow }, '贴合当前内容'),
        h('button', { class: 'dsf-btn', onclick: function () { openPanel('settings') } }, '当前 ' + window.innerWidth + '×' + window.innerHeight),
      ]))
      var widthInput = h('input', {
        class: 'dsf-input', type: 'number', min: '300', max: '1600', step: '10',
        value: String(Math.round(window.innerWidth)), 'aria-label': '窗口宽度',
      })
      var heightInput = h('input', {
        class: 'dsf-input', type: 'number', min: '420', max: '1200', step: '10',
        value: String(Math.round(window.innerHeight)), 'aria-label': '窗口高度',
      })
      wrap.appendChild(h('div', { class: 'dsf-size-row' }, [
        h('span', { class: 'dsf-dim dsf-small' }, '自定义'),
        widthInput,
        h('span', { class: 'dsf-dim dsf-small' }, '×'),
        heightInput,
        h('button', {
          class: 'dsf-btn',
          onclick: function () {
            var w = clamp(Math.round(Number(widthInput.value) || window.innerWidth), 300, 1600)
            var hgt = clamp(Math.round(Number(heightInput.value) || window.innerHeight), 420, 1200)
            if (window.dsfDesktop && window.dsfDesktop.setWindowSizePx) {
              window.dsfDesktop.setWindowSizePx(w, hgt)
              say('窗口改成 ' + w + '×' + hgt, 1800)
            }
            openPanel('settings')
          },
        }, '应用'),
      ]))
    }
    wrap.appendChild(h('div', { class: 'dsf-actions' }, [
      h('button', { class: 'dsf-btn', onclick: function () { state.settings.autoScale = false; state.settings.scale = clamp((Number(state.settings.scale) || 1.5) - 0.25, 0.75, 2.5); applySettings(); persist(); openPanel('settings') } }, '－ 小'),
      h('button', { class: 'dsf-btn', onclick: function () { state.settings.autoScale = false; state.settings.scale = clamp((Number(state.settings.scale) || 1.5) + 0.25, 0.75, 2.5); applySettings(); persist(); openPanel('settings') } }, '＋ 大'),
    ]))
    wrap.appendChild(h('div', { class: 'dsf-sec-title' }, '停靠'))
    var pos = h('div', { class: 'dsf-actions' })
    ;[['bottom-left', '左下'], ['bottom-right', '右下'], ['top-left', '左上'], ['top-right', '右上']].forEach(function (p) {
      pos.appendChild(h('button', {
        class: 'dsf-btn' + (state.settings.position === p[0] ? ' dsf-btn-on' : ''),
        onclick: function () { state.settings.position = p[0]; applySettings(); persist(); openPanel('settings') },
      }, p[1]))
    })
    wrap.appendChild(pos)
    wrap.appendChild(h('div', { class: 'dsf-dim dsf-small' }, '快捷键 Alt+Shift+F 收起/展开；切页签不影响窗口大小'))
    wrap.appendChild(h('div', { class: 'dsf-sec-title' }, '存档'))
    wrap.appendChild(h('div', { class: 'dsf-actions' }, [
      h('button', {
        class: 'dsf-btn',
        onclick: function () {
          fetch(PREFIX + '/api/snapshot', { cache: 'no-store' })
            .then(function (r) { return r.json() })
            .then(function (payload) { applySnapshot(payload && payload.data); openPanel('settings') })
            .catch(function () { /* 忽略 */ })
        },
      }, '重新读取存档'),
    ]))
    return wrap
  }

  function renderTasksPanel() {
    var wrap = h('div')
    wrap.appendChild(h('div', { class: 'dsf-sec-title' }, '今日待办'))
    if (!host.todos.length) {
      wrap.appendChild(h('div', { class: 'dsf-item dsf-dim' }, '还没有待办。'))
      return wrap
    }
    host.todos.forEach(function (todo, i) {
      var key = todoKey(todo)
      var on = state.selectedTaskKey === key
      wrap.appendChild(h('div', {
        class: 'dsf-item dsf-todo-' + todo.status
          + (todo.status === 'in_progress' ? ' dsf-task-current' : '')
          + (on ? ' dsf-task-on dsf-select-skin' : ''),
        onclick: function (e) {
          e.stopPropagation()
          state.selectedTaskKey = state.selectedTaskKey === key ? '' : key
          state.selectedTask = state.selectedTaskKey ? i : -1
          renderTasksView()
          openPanel('tasks')
          if (state.selectedTaskKey === key) say(clampText(todo.content, 60), 3000, 1)
        },
      }, [
        h('span', { class: 'dsf-task-icon dsf-task-' + todo.status }, [taskIcon(todo.status)]),
        h('span', { class: 'dsf-item-text' }, todo.content),
        todo.status === 'in_progress' ? h('span', { class: 'dsf-current-chip dsf-label-skin' }, '当前') : null,
        on ? h('span', { class: 'dsf-selected-chip dsf-label-skin' }, '已选') : null,
      ]))
    })
    return wrap
  }

  function renderBalancePanel(box) {
    fetch(PREFIX + '/api/balance', { cache: 'no-store' })
      .then(function (r) { return r.json() })
      .then(function (data) {
        box.innerHTML = ''
        if (!data || !data.ok) {
          box.appendChild(h('div', { class: 'dsf-dim' }, '读取不到余额：' + String((data && data.error) || '未知错误')))
          return
        }
        var cur = data.currency === 'CNY' ? '¥' : data.currency === 'USD' ? '$' : (data.currency || '')
        box.appendChild(h('div', { class: 'dsf-balance' }, [
          h('div', { class: 'dsf-dim dsf-small' }, '可用余额（' + (data.source === 'account' ? '账号登录' : 'API Key') + '）'),
          h('div', { class: 'dsf-bal-big' }, [btext(cur + Number(data.totalBalance).toFixed(2))]),
          h('button', { class: 'dsf-btn', onclick: function () { openPanel('balance') } }, '刷新'),
        ]))
      })
      .catch(function () { box.innerHTML = ''; box.appendChild(h('div', { class: 'dsf-dim' }, '网络错误')) })
  }

  // ------------------------------------------------------------------
  // 开场待办 / 缩放 / 窗口把手 / 主循环 / 启动
  // ------------------------------------------------------------------
  var introEl = null
  function showIntro() {
    if (introEl) introEl.remove()
    var list = h('ul', { class: 'dsf-intro-list' })
    var items = host.todos.slice(0, 5)
    if (!items.length) list.appendChild(h('li', { class: 'dsf-intro-item dsf-dim' }, '今天还没待办，我先种着田～'))
    items.forEach(function (todo, i) {
      list.appendChild(h('li', { class: 'dsf-intro-item dsf-' + todo.status }, [
        h('span', { class: 'dsf-dot' }, [taskIcon(todo.status)]),
        h('span', { class: 'dsf-intro-text', title: todo.content }, clampText(todo.content, 26)),
        todo.status === 'in_progress' ? h('span', { class: 'dsf-current-chip dsf-label-skin' }, '当前') : null,
      ]))
    })
    introEl = h('div', { class: 'dsf-intro dsf-panel-paper', role: 'status' }, [
      h('div', { class: 'dsf-intro-head' }, [
        h('b', null, '📋 今日待办'),
        h('span', { class: 'dsf-dim dsf-small' }, '💰 ' + Math.floor(state.coins) + ' 金币'),
      ]),
      list,
      h('div', { class: 'dsf-dim dsf-small' }, '切页签看：农场 / 键盘 / 任务 / 工时 · 点这里展开'),
    ])
    introEl.addEventListener('click', function () { introEl.remove(); introEl = null; switchTab('tasks'); reportHitRects() })
    root.appendChild(introEl)
    requestAnimationFrame(function () { if (introEl) introEl.classList.add('dsf-intro-show'); reportHitRects() })
    setTimeout(function () {
      if (!introEl) return
      introEl.classList.remove('dsf-intro-show')
      setTimeout(function () { if (introEl) { introEl.remove(); introEl = null; reportHitRects() } }, 350)
    }, 8000)
  }

  function autoScaleValue() {
    var availW
    var availH
    if (DESKTOP) {
      availW = Math.max(220, window.innerWidth - 28)
      availH = Math.max(260, window.innerHeight - 28)
    } else {
      availW = Math.min(430, Math.max(260, window.innerWidth * 0.32))
      availH = Math.max(320, window.innerHeight - 120)
    }
    return clamp(Math.min(availW / DESIGN_W, availH / DESIGN_H), 0.75, 2.5)
  }

  function applySettings() {
    if (!root) return
    var s = state.settings.autoScale
      ? autoScaleValue()
      : clamp(Number(state.settings.scale) || 1.5, 0.75, 2.5)
    s = Math.round(s * 20) / 20
    currentScaleValue = s
    root.style.setProperty('--dsf-scale', String(s))
    root.classList.toggle('dsf-pos-bl', state.settings.position === 'bottom-left')
    root.classList.toggle('dsf-pos-br', state.settings.position === 'bottom-right')
    root.classList.toggle('dsf-pos-tl', state.settings.position === 'top-left')
    root.classList.toggle('dsf-pos-tr', state.settings.position === 'top-right')
    setCollapsed(!!state.settings.collapsed)
    reportHitRects()
  }
  function setCollapsed(v) {
    state.settings.collapsed = !!v
    root.classList.toggle('dsf-collapsed', !!v)
    persist()
    reportHitRects()
  }

  function buildResizeGrip() {
    var grip = h('div', { class: 'dsf-resize-grip', title: '拖动调整窗口大小；双击贴合内容' })
    grip.addEventListener('mousedown', function (e) {
      if (e.button !== 0) return
      e.preventDefault()
      e.stopPropagation()
      if (window.dsfDesktop && window.dsfDesktop.startResize) window.dsfDesktop.startResize()
    })
    window.addEventListener('mouseup', function () {
      if (window.dsfDesktop && window.dsfDesktop.endResize) window.dsfDesktop.endResize()
    })
    grip.addEventListener('dblclick', function (e) { e.stopPropagation(); fitWindow() })
    document.body.appendChild(grip)
  }

  // 主循环
  var lastNow = 0
  var coinCarry = 0
  var dayCheck = 0
  var statusTick = 0
  function tick(now) {
    var dt = lastNow ? Math.min(0.06, (now - lastNow) / 1000) : 0.016
    lastNow = now

    state.onlineSeconds += dt
    tickHarvest(dt)
    updateHelpers(dt)
    processActions()

    if (workingNow()) {
      state.farmSeconds += dt
      coinCarry += dt * (COIN_PER_MINUTE / 60)
      if (coinCarry >= 1) {
        var gain = Math.floor(coinCarry)
        coinCarry -= gain
        state.coins += gain
        renderHeader()
      }
      if (!state.allTasksDone && farmer.phase === 'idle' && !actionQueue.length && Date.now() >= farmer.nextAt) {
        var autoIdx = pickAutoPlot(farmer)
        if (autoIdx >= 0) {
          enqueueAction(autoIdx, 'auto', true)
          farmer.nextAt = Date.now() + rand(1000, 2800) / (1 + state.helpers * 0.22)
        } else {
          farmer.nextAt = Date.now() + 1000
        }
      }
    }

    updateActor(farmer, dt)
    drawActor(farmer)
    drawHelpers()
    drawClerk(now)
    renderSparks()
    if (bubbleText && Date.now() >= bubblePosAt) {
      bubblePosAt = Date.now() + 80
      updateBubblePosition()
    }

    if (lookTimer > 0) lookTimer -= dt
    if (bubbleUntil && Date.now() > bubbleUntil) { bubbleUntil = 0; bubbleText = ''; renderBubble() }

    dayCheck -= dt
    if (dayCheck <= 0) {
      dayCheck = 1
      rollover()
      renderHeader()
      renderUsageStats()
      updateBubblePosition()
    }

    statusTick -= dt
    if (statusTick <= 0) {
      statusTick = 1
      renderStatus()
      renderUsageStats()
    }
    requestAnimationFrame(tick)
  }

  function boot() {
    if (DESKTOP) document.documentElement.classList.add('dsf-desktop')
    loadLocal()
    buildUI()
    fetch(PREFIX + '/api/snapshot', { cache: 'no-store' })
      .then(function (r) { return r.json() })
      .then(function (payload) {
        applySnapshot(payload && payload.data)
        // 存档里已有的帮手恢复出场
        updateHelpers(0)
      })
      .catch(function () {})
    window.__dshStardew = {
      version: VERSION,
      state: state,
      host: host,
      farmer: farmer,
      helperActors: helperActors,
      switchTab: switchTab,
      showIntro: showIntro,
      say: say,
      showHerald: showHerald,
      fitWindow: fitWindow,
      setWindowPreset: setWindowPreset,
      pressKey: function (key) { if (key) onKey(String(key)) },
      workingNow: workingNow,
      plotCenter: plotCenter,
      refreshUsage: renderUsageView,
      spriteNames: Object.keys(SPRITES),
      crops: CROPS,
      font: FONT,
      helpers: function () { return state.helpers },
      enqueueAuto: function (idx) { enqueueAction(Number(idx) || 0, 'auto', true) },
      clearQueue: function () {
        actionQueue.length = 0
        claims = {}
        farmer.job = null
        farmer.phase = 'idle'
        farmer.moving = false
      },
      selectTask: function (i) {
        var idx = clamp(Number(i) || 0, 0, host.todos.length - 1)
        state.selectedTask = idx
        state.selectedTaskKey = host.todos[idx] ? todoKey(host.todos[idx]) : ''
        renderTasksView()
      },
      // 自检/调试：直接驱动一次角色状态机（不依赖真实帧率）
      debugJob: function (idx, auto) { return startJob(farmer, Number(idx) || 0, auto !== false, 'auto') },
      advance: function (dt) { updateActor(farmer, Number(dt) || 0.016) },
    }
    if (Array.isArray(window.__dsfKeyQueue) && window.__dsfKeyQueue.length) {
      var queued = window.__dsfKeyQueue.splice(0)
      queued.forEach(function (key) { if (key) onKey(String(key)) })
    }
    window.addEventListener('beforeunload', function () {
      try {
        var body = JSON.stringify({ data: serialize() })
        if (navigator.sendBeacon) navigator.sendBeacon(PREFIX + '/api/mutate', new Blob([body], { type: 'application/json' }))
      } catch (e) { /* 忽略 */ }
    })
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot)
  else boot()
})()
